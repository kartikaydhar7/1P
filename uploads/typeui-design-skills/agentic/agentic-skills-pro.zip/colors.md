# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFFFF | rgba(255, 255, 255, 0.05) |
| neutral-primary | #FFFFFF | #0a0a0a |
| neutral-primary-medium | #FFFFFF | rgba(255, 255, 255, 0.1) |
| neutral-primary-strong | #FFFFFF | rgba(255, 255, 255, 0.2) |
| neutral-secondary-soft | #F9FAFB | rgba(255, 255, 255, 0.05) |
| neutral-secondary | #F9FAFB | #0a0a0a |
| neutral-secondary-medium | #F9FAFB | rgba(255, 255, 255, 0.1) |
| neutral-secondary-strong | #F9FAFB | rgba(255, 255, 255, 0.2) |
| neutral-tertiary-soft | #F3F4F6 | rgba(255, 255, 255, 0.05) |
| neutral-tertiary | #F3F4F6 | rgba(255, 255, 255, 0.1) |
| neutral-tertiary-medium | #F3F4F6 | rgba(255, 255, 255, 0.2) |
| neutral-quaternary | #E5E7EB | rgba(255, 255, 255, 0.2) |
| quaternary-medium | #E5E7EB | rgba(255, 255, 255, 0.3) |
| gray | #D1D5DC | rgba(255, 255, 255, 0.3) |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #FDF2F9 | #2D0E22 |
| brand-soft | #FADDED | #5C1A46 |
| brand | #C8399C | #D94FB0 |
| brand-medium | #F0C4DE | #5C1A46 |
| brand-strong | #A52D80 | #C8399C |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #ECFDF5 | #002C22 |
| success | #007A55 | #009966 |
| success-medium | #D0FAE5 | #004F3B |
| success-strong | #006045 | #007A55 |
| danger-soft | #FEF0F2 | #4D0218 |
| danger | #C70036 | #C70036 |
| danger-medium | #FFE4E6 | #8B0836 |
| danger-strong | #A50036 | #A50036 |
| warning-soft | #FFF7ED | #7C2D12 |
| warning | #F97316 | #F97316 |
| warning-medium | #FFEDD5 | #7C2D12 |
| warning-strong | #C2410C | #C2410C |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | rgba(255, 255, 255, 0.1) | rgba(255, 255, 255, 0.1) |
| dark-strong | #111827 | rgba(255, 255, 255, 0.2) |
| disabled | #F3F4F6 | rgba(255, 255, 255, 0.1) |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #8B5CF6 |
| sky | #38BDF8 |
| teal | #14B8A6 |
| pink | #C8399C |
| cyan | #22D3EE |
| fuchsia | #D946EF |
| indigo | #6366F1 |
| orange | #FB923C |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #111827 | #111827 |
| heading | #111827 | #FFFFFF |
| body | rgba(255, 255, 255, 0.3) | #a1a1aa |
| body-subtle | #6B7280 | #a1a1aa |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #F0C4DE | #5C1A46 |
| fg-brand | #C8399C | #E876C0 |
| fg-brand-strong | #A52D80 | #F0C4DE |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #047857 | #065F46 |
| fg-success-strong | #065F46 | #10B981 |
| fg-danger | #BE123C | #F43F5E |
| fg-danger-strong | #881337 | #F87171 |
| fg-warning-subtle | #EA580C | #F97316 |
| fg-warning | #7C2D12 | #FBBF24 |
| fg-disabled | #a1a1aa | #6B7280 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #312E81 | #93C5FD |
| fg-purple | #8B5CF6 | #A78BFA |
| fg-purple-strong | #7C3AED | #DDD6FE |
| fg-cyan | #06B6D4 | #22D3EE |
| fg-indigo | #6366F1 | #818CF8 |
| fg-pink | #C8399C | #D94FB0 |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | rgba(255, 255, 255, 0.1) | rgba(255, 255, 255, 0.3) |
| border-buffer | #FFFFFF | #0a0a0a |
| border-buffer-medium | #FFFFFF | rgba(255, 255, 255, 0.1) |
| border-buffer-strong | #FFFFFF | rgba(255, 255, 255, 0.2) |
| border-muted | #F9FAFB | #111827 |
| border-light-subtle | #F3F4F6 | #111827 |
| border-light | #F3F4F6 | rgba(255, 255, 255, 0.1) |
| border-light-medium | #F3F4F6 | rgba(255, 255, 255, 0.2) |
| border-default-subtle | #E5E7EB | #111827 |
| border-default | #E5E7EB | rgba(255, 255, 255, 0.1) |
| border-default-medium | #E5E7EB | rgba(255, 255, 255, 0.2) |
| border-default-strong | #E5E7EB | rgba(255, 255, 255, 0.3) |
| border-success-subtle | #A7F3D0 | #064E3B |
| border-success | #047857 | #065F46 |
| border-danger-subtle | #FECDD3 | #881337 |
| border-danger | #BE123C | #BE123C |
| border-warning-subtle | #FED7AA | #7C2D12 |
| border-warning | #EA580C | #F97316 |
| border-brand-subtle | #F0C4DE | #5C1A46 |
| border-brand-light | #D94FB0 | #D94FB0 |
| border-brand | #C8399C | #E876C0 |
| border-dark-subtle | rgba(255, 255, 255, 0.1) | rgba(255, 255, 255, 0.2) |
| border-purple | #8B5CF6 | #8B5CF6 |
| border-orange | #FB923C | #FB923C |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand gradient background (see `buttons.md`)
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
