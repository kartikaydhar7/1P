# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFFFF | #141414 |
| neutral-primary | #FFFFFF | #000000 |
| neutral-primary-medium | #FFFFFF | #1F1F1F |
| neutral-primary-strong | #FFFFFF | #2A2A2A |
| neutral-secondary-soft | #FAFAFA | #141414 |
| neutral-secondary | #FAFAFA | #000000 |
| neutral-secondary-medium | #F5F5F5 | #1F1F1F |
| neutral-secondary-strong | #F0F0F0 | #2A2A2A |
| neutral-tertiary-soft | #F5F5F5 | #141414 |
| neutral-tertiary | #F0F0F0 | #1F1F1F |
| neutral-tertiary-medium | #F0F0F0 | #2A2A2A |
| neutral-quaternary | #D9D9D9 | #303030 |
| quaternary-medium | #D9D9D9 | #434343 |
| gray | #BFBFBF | #434343 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #E6F7FF | #111A2C |
| brand-soft | #BAE7FF | #112545 |
| brand | #1990FF | #1990FF |
| brand-medium | #91D5FF | #15325B |
| brand-strong | #096DD9 | #1990FF |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #F6FFED | #162312 |
| success | #52C41A | #49AA19 |
| success-medium | #D9F7BE | #1D3712 |
| success-strong | #389E0D | #52C41A |
| danger-soft | #FFF2F0 | #2C1215 |
| danger | #FF4D4F | #D32029 |
| danger-medium | #FFCCC7 | #58181C |
| danger-strong | #CF1322 | #E84749 |
| warning-soft | #FFFBE6 | #2B2111 |
| warning | #FAAD14 | #D89614 |
| warning-medium | #FFE58F | #443111 |
| warning-strong | #D48806 | #FAAD14 |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.15) | rgba(255,255,255,0.08) |
| `--color-1-700` | rgba(0,0,0,0.04) | rgba(0,0,0,0.12) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #141414 | #141414 |
| dark-strong | #000000 | #1F1F1F |
| disabled | #F5F5F5 | #1F1F1F |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #722ED1 |
| sky | #1890FF |
| teal | #13C2C2 |
| pink | #EB2F96 |
| cyan | #13C2C2 |
| fuchsia | #722ED1 |
| indigo | #2F54EB |
| orange | #FA8C16 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #000000 | #000000 |
| heading | #1F1F1F | #FFFFFF |
| body | #595959 | #A6A6A6 |
| body-subtle | #8C8C8C | #8C8C8C |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #91D5FF | #15325B |
| fg-brand | #1990FF | #69C0FF |
| fg-brand-strong | #096DD9 | #91D5FF |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #52C41A | #49AA19 |
| fg-success-strong | #389E0D | #73D13D |
| fg-danger | #FF4D4F | #FF4D4F |
| fg-danger-strong | #CF1322 | #FF7875 |
| fg-warning-subtle | #FAAD14 | #FAAD14 |
| fg-warning | #D48806 | #FFC53D |
| fg-disabled | #BFBFBF | #595959 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FAAD14 | #FAAD14 |
| fg-info | #2F54EB | #85A5FF |
| fg-purple | #722ED1 | #9254DE |
| fg-purple-strong | #531DAB | #B37FEB |
| fg-cyan | #13C2C2 | #36CFC9 |
| fg-indigo | #2F54EB | #597EF7 |
| fg-pink | #EB2F96 | #F759AB |
| fg-lime | #A0D911 | #BAE637 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #141414 | #434343 |
| border-buffer | #FFFFFF | #000000 |
| border-buffer-medium | #FFFFFF | #141414 |
| border-buffer-strong | #FFFFFF | #1F1F1F |
| border-muted | #FAFAFA | #141414 |
| border-light-subtle | #F0F0F0 | #141414 |
| border-light | #F0F0F0 | #303030 |
| border-light-medium | #F0F0F0 | #434343 |
| border-default-subtle | #D9D9D9 | #141414 |
| border-default | #D9D9D9 | #303030 |
| border-default-medium | #D9D9D9 | #434343 |
| border-default-strong | #D9D9D9 | #595959 |
| border-success-subtle | #B7EB8F | #274916 |
| border-success | #52C41A | #49AA19 |
| border-danger-subtle | #FFCCC7 | #58181C |
| border-danger | #FF4D4F | #D32029 |
| border-warning-subtle | #FFE58F | #443111 |
| border-warning | #FAAD14 | #D89614 |
| border-brand-subtle | #91D5FF | #15325B |
| border-brand-light | #1990FF | #1990FF |
| border-brand | #1990FF | #69C0FF |
| border-dark-subtle | #1F1F1F | #303030 |
| border-purple | #722ED1 | #9254DE |
| border-orange | #FA8C16 | #FA8C16 |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
