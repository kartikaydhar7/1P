# Typography

> Dependencies: `colors.md`

## Core Rules

- **Font:** 'Alibaba Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif — configured at app level, never override
- **Headings:** semibold weight (600), heading text color
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 38px | 1.21 | -0.4px | 20px |
| `h2` | 30px | 1.27 | — | — |
| `h3` | 24px | 1.33 | — | — |
| `h4` | 20px | 1.4 | — | — |
| `h5` | 16px | 1.5 | — | — |
| `h6` | 14px | 1.57 | — | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 30px | 24px |
| `h2` | 24px | 20px |
| `h3` | 20px | 18px |
| `h4` | 18px | 16px |
| `h5` | 16px | 14px |
| `h6` | 14px | 14px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.1 for any heading.

## Paragraphs

### Leading Paragraph
- Size: 16px
- Weight: normal
- Color: body
- Line-height: 1.57
- Max width: ~70 characters

### Normal Paragraph
- Size: 14px
- Weight: normal
- Color: body
- Line-height: 1.57
- Max width: ~65 characters

### Small Supporting Copy
- Size: 12px
- Weight: normal
- Color: body
- Line-height: 1.5
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 14px | 400 (regular) |
| Input labels | 14px | 400 (regular) |
| Captions / meta / badges | 12px | 400 (regular) |

Do not apply paragraph line-height (1.57) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, no underline, hover → underline
- **CTA links:** fg-brand color, regular weight, no underline, hover → underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, 0.4px letter-spacing, 12px or 14px

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, and spacing remain constant.
