# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-primary-soft
- **Border:** 2px, border-default color
- **Radius:** 16px (base)
- **Shadow:** shadow-sm

## Card Heading

- Desktop: 20px, medium weight, heading color
- Mobile: 16px, medium weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-primary-soft
- Border: 2px, border-default
- Radius: 16px
- Shadow: shadow-sm
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: neutral-secondary-medium background, shadow-md
- Transition: colors, box-shadow
- Cursor: pointer

## Rules

- Background: neutral-primary-soft
- Border: 2px, border-default
- Radius: 16px
- Shadow: shadow-sm
- Interactive hover: neutral-secondary-medium background, shadow-md
- Non-interactive: no hover styles
