# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFBF5 | #0F0E1A |
| neutral-primary | #FFFBF5 | #08071A |
| neutral-primary-medium | #FFFBF5 | #1A1933 |
| neutral-primary-strong | #FFFBF5 | #2D2B4A |
| neutral-secondary-soft | #F5EDE3 | #0F0E1A |
| neutral-secondary | #F5EDE3 | #08071A |
| neutral-secondary-medium | #F5EDE3 | #1A1933 |
| neutral-secondary-strong | #F5EDE3 | #2D2B4A |
| neutral-tertiary-soft | #EBE0D3 | #0F0E1A |
| neutral-tertiary | #EBE0D3 | #1A1933 |
| neutral-tertiary-medium | #EBE0D3 | #2D2B4A |
| neutral-quaternary | #DDD1C1 | #2D2B4A |
| quaternary-medium | #DDD1C1 | #3E3B5A |
| gray | #C8BAA8 | #3E3B5A |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #FFF0EB | #3D1A10 |
| brand-soft | #FFD9CC | #7A2E16 |
| brand | #E8734A | #EF855E |
| brand-medium | #FFBFA8 | #7A2E16 |
| brand-strong | #D05A32 | #E8734A |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #F0FAF4 | #002820 |
| success | #2D8B6F | #3BA385 |
| success-medium | #D4F5E2 | #004A3A |
| success-strong | #1F7558 | #2D8B6F |
| danger-soft | #FFF0F0 | #4D0218 |
| danger | #D44040 | #D44040 |
| danger-medium | #FFE0E0 | #8B0836 |
| danger-strong | #B52E2E | #B52E2E |
| warning-soft | #FFF5E6 | #7C2D12 |
| warning | #E89530 | #E89530 |
| warning-medium | #FFE6C0 | #7C2D12 |
| warning-strong | #C47A18 | #C47A18 |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.30) | rgba(255,255,255,0.15) |
| `--color-1-700` | rgba(0,0,0,0.15) | rgba(0,0,0,0.30) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #1B1B3A | #1B1B3A |
| dark-strong | #0F0E1A | #2D2B4A |
| disabled | #EBE0D3 | #1A1933 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #9B6DFF |
| sky | #5CB8E4 |
| teal | #3D9B8F |
| pink | #E05A9E |
| cyan | #35B8C8 |
| fuchsia | #C44ED0 |
| indigo | #5A4FCF |
| orange | #E89550 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFBF5 | #FFFBF5 |
| black | #1B1B3A | #1B1B3A |
| heading | #1B1B3A | #FFFBF5 |
| body | #5A5470 | #A89EB8 |
| body-subtle | #78708A | #A89EB8 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #FFBFA8 | #7A2E16 |
| fg-brand | #E8734A | #FF9672 |
| fg-brand-strong | #D05A32 | #FFBFA8 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #2D8B6F | #1F7558 |
| fg-success-strong | #1F7558 | #3BA385 |
| fg-danger | #D44040 | #F45A5A |
| fg-danger-strong | #B52E2E | #FF7A7A |
| fg-warning-subtle | #E89530 | #E89530 |
| fg-warning | #7C4A12 | #FBBF24 |
| fg-disabled | #A89EB8 | #5A5470 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #2E2870 | #93C5FD |
| fg-purple | #8B4CD0 | #9B6DFF |
| fg-purple-strong | #7536C2 | #D4C6FF |
| fg-cyan | #2E9EB2 | #35B8C8 |
| fg-indigo | #5A4FCF | #5A4FCF |
| fg-pink | #E05A9E | #E05A9E |
| fg-lime | #5A9E1A | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #1B1B3A | #5A5470 |
| border-buffer | #FFFBF5 | #08071A |
| border-buffer-medium | #FFFBF5 | #1A1933 |
| border-buffer-strong | #FFFBF5 | #2D2B4A |
| border-muted | #F5EDE3 | #0F0E1A |
| border-light-subtle | #EBE0D3 | #0F0E1A |
| border-light | #EBE0D3 | #1A1933 |
| border-light-medium | #EBE0D3 | #2D2B4A |
| border-default-subtle | #DDD1C1 | #0F0E1A |
| border-default | #DDD1C1 | #1A1933 |
| border-default-medium | #DDD1C1 | #2D2B4A |
| border-default-strong | #DDD1C1 | #3E3B5A |
| border-success-subtle | #A7F3D0 | #004A3A |
| border-success | #2D8B6F | #1F7558 |
| border-danger-subtle | #FFD0D0 | #B52E2E |
| border-danger | #D44040 | #D44040 |
| border-warning-subtle | #FFD9A8 | #7C2D12 |
| border-warning | #E89530 | #E89530 |
| border-brand-subtle | #FFBFA8 | #7A2E16 |
| border-brand-light | #EF855E | #EF855E |
| border-brand | #E8734A | #FF9672 |
| border-dark-subtle | #1B1B3A | #2D2B4A |
| border-purple | #9B6DFF | #9B6DFF |
| border-orange | #E89550 | #E89550 |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
