# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `0 1px 0 rgb(27 27 58 / 0.06)` |
| shadow-xs | `2px 2px 0 rgb(27 27 58 / 0.08)` |
| shadow-sm | `3px 3px 0 rgb(27 27 58 / 0.10)` |
| shadow-md | `4px 4px 0 rgb(27 27 58 / 0.12)` |
| shadow-lg | `6px 6px 0 rgb(27 27 58 / 0.15)` |
| shadow-xl | `8px 8px 0 rgb(27 27 58 / 0.18)` |
| shadow-2xl | `12px 12px 0 rgb(27 27 58 / 0.22)` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls, lightweight cards | shadow-xs or shadow-sm |
| Standard cards, popovers, dropdowns | shadow-md |
| Prominent cards, sticky surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use only these tokens — no custom box-shadow values
- Shadows are hard-offset (no blur) for the neobrutalism aesthetic
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
