# Design System - Bento Pro

This skill defines a premium bento-oriented interface language inspired by the `hen-ry.com` benefits experience: dark-first, editorial typography, asymmetric card mosaics, subtle glow layers, and conversion-focused messaging.

## Before Writing Any Code

1. Read every module that applies. For landing pages, start with `layout.md`, `content.md`, `typography.md`, `colors.md`, `cards.md`, and `buttons.md`.
2. Confirm global tokens exist in `globals.css` before creating components.
3. Use semantic HTML and keyboard-safe interactions by default.

## Critical Rules

- **Tokens are AGNOSTIC, NOT Tailwind classes:** The tokens defined in the `.md` files (like `neutral-primary-soft`, `heading`, `border-default`) are agnostic design system tokens, NOT literal Tailwind classes. Do not blindly use classes like `bg-neutral-primary-soft` unless you have explicitly mapped them in the CSS/Tailwind configuration. You must implement the mapping yourself.

- Bento layout is the baseline pattern, not a decorative add-on.
- Cards must feel tactile: soft borders, layered surfaces, and controlled hover lift.
- Keep copy compact, confident, and outcome-oriented.
- Every interactive element must define default, hover, focus-visible, active, and disabled states.
- Respect reduced-motion preferences for all animated reveals.

## Module Index

### Foundation
- [colors.md](colors.md) - palette and semantic token roles
- [typography.md](typography.md) - editorial hierarchy and reading rhythm
- [layout.md](layout.md) - section spacing, shells, and compositional rules
- [content.md](content.md) - bento grid recipes and responsive spans
- [radius.md](radius.md) - corner radii scale
- [shadows.md](shadows.md) - depth and glow treatment
- [borders.md](borders.md) - stroke usage and separators

### Components
- [hero.md](hero.md) - hero section patterns, geometric backgrounds, and ambient light
- [buttons.md](buttons.md) - button styles and state logic (keep existing)
- [button-group.md](button-group.md) - grouped actions
- [cards.md](cards.md) - bento tile anatomy and emphasis tiers
- [inputs.md](inputs.md) - form control treatment
- [alerts.md](alerts.md) - status blocks
- [badges.md](badges.md) - metadata and status chips
- [lists.md](lists.md) - bullet, feature, and metadata lists
- [avatars.md](avatars.md) - people and team markers
- [icon-shapes.md](icon-shapes.md) - icon container standards
-

### Complex Components
- [accordion.md](accordion.md) - expandable detail stacks
- [dropdown.md](dropdown.md) - action and selection menus
- [modals.md](modals.md) - focused overlays
- [tabs.md](tabs.md) - grouped content navigation
- [tables.md](tables.md) - dense data presentation
- [pagination.md](pagination.md) - segmented page traversal
- [sidebars.md](sidebars.md) - persistent navigation rails
- [radios-checkboxes-toggle.md](radios-checkboxes-toggle.md) - selection controls
- [tooltips-popovers.md](tooltips-popovers.md) - lightweight help layers
