# Borders

## Width Scale

| Context | Width |
|---|---|
| Structural Grid (sections, columns) | 1px (`rgba(255, 255, 255, 0.1)`) |
| Default (inputs, buttons, cards) | 2px |
| Emphasis / focus | 3px |

## Rules

- Use solid borders by default
- Dashed borders only for special cases like file dropzones
- Components in the same family must use matching border widths
- Never mix 2px and 3px borders within a single component

## Usage

| Context | Width |
|---|---|
| Inputs / selects / textareas | 2px default; 3px on focus or error |
| Buttons | 2px for variants that require outlining |
| Cards / containers | 2px; avoid stacked heavy borders |
