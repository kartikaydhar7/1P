# Typography

> Dependencies: `colors.md`

## Core Rules

- **Heading font:** Ultra, serif — configured at app level, never override
- **Body font:** Open Sans, sans-serif — configured at app level, never override
- **Headings:** regular weight (400), heading text color — Ultra is inherently ultra-heavy, do not add bold
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

All headings must feel massive and dominant — this is a bold style. The primary `h1` leads at 140px; every other heading (`h2`–`h6`) shares the same 120px base to keep the page punchy and impactful. Never shrink headings to conventional sizes.

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 140px | 1 | -1px | 24px |
| `h2` | 120px | 1 | -0.8px | — |
| `h3` | 120px | 1 | -0.8px | — |
| `h4` | 120px | 1.05 | -0.5px | — |
| `h5` | 120px | 1.05 | — | — |
| `h6` | 120px | 1.1 | — | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 80px | 60px |
| `h2` | 72px | 48px |
| `h3` | 72px | 48px |
| `h4` | 72px | 48px |
| `h5` | 72px | 48px |
| `h6` | 72px | 48px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1 for any heading.

## Word Breaking (CRITICAL)

Because headings are massive (120px+), they WILL overflow standard viewports. You MUST apply `overflow-wrap: break-word` and `word-break: break-word` to all headings to ensure they stack brutally down the page.

## Outline Text

For extreme emphasis and layering, use outline text: `-webkit-text-stroke: 2px var(--white); color: transparent;`.

## Micro Labels

Since paragraphs are banned on the homepage, use "Micro Labels" for metadata, navigation, and structural markers to create extreme contrast against the massive headings.
- Size: 10px or 11px
- Transform: uppercase
- Letter-spacing: 1px to 2px
- Weight: 600

## Homepage Rule

The homepage uses **headings only** — no paragraph text. Every piece of copy on the homepage must be rendered as a heading element (`h1`–`h6`). Body paragraphs, leading paragraphs, and supporting copy are reserved for interior/detail pages, never the homepage. The homepage should feel like a wall of bold, oversized type.

## Paragraphs (interior pages only)

### Leading Paragraph
- Size: 20px
- Weight: normal
- Color: body
- Line-height: 1.7
- Max width: ~70 characters

### Normal Paragraph
- Size: 16px
- Weight: normal
- Color: body
- Line-height: 1.7
- Max width: ~65 characters

### Small Supporting Copy
- Size: 14px
- Weight: normal
- Color: body
- Line-height: 1.6
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 16px | 600 (semibold) |
| Input labels | 14px or 16px | 600 (semibold) |
| Captions / meta / badges | 12px or 14px | 600 (semibold) |

Do not apply paragraph line-height (1.7) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline, hover → no underline
- **CTA links:** fg-brand color, medium weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, 0.4px letter-spacing, 12px or 14px

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, and spacing remain constant.
