# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFFFF | #1A1412 |
| neutral-primary | #FFFFFF | #0D0A08 |
| neutral-primary-medium | #FFFFFF | #2A211C |
| neutral-primary-strong | #FFFFFF | #3D3330 |
| neutral-secondary-soft | #F9F7F5 | #1A1412 |
| neutral-secondary | #F9F7F5 | #0D0A08 |
| neutral-secondary-medium | #F3EFEB | #2A211C |
| neutral-secondary-strong | #F3EFEB | #3D3330 |
| neutral-tertiary-soft | #EDE8E3 | #1A1412 |
| neutral-tertiary | #EDE8E3 | #2A211C |
| neutral-tertiary-medium | #E5DFD9 | #3D3330 |
| neutral-quaternary | #DDD6CE | #3D3330 |
| quaternary-medium | #DDD6CE | #4A403B |
| gray | #C9C0B7 | #4A403B |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #F5EFEA | #2A1F17 |
| brand-soft | #E9DDD4 | #3D2E22 |
| brand | #5D4432 | #7A5D4A |
| brand-medium | #D4C4B8 | #3D2E22 |
| brand-strong | #4A3628 | #5D4432 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #ECFDF5 | #002C22 |
| success | #007A55 | #009966 |
| success-medium | #D0FAE5 | #004F3B |
| success-strong | #006045 | #007A55 |
| danger-soft | #FEF0F2 | #4D0218 |
| danger | #C70036 | #C70036 |
| danger-medium | #FFE4E6 | #8B0836 |
| danger-strong | #A50036 | #A50036 |
| warning-soft | #FFF7ED | #7C2D12 |
| warning | #F97316 | #F97316 |
| warning-medium | #FFEDD5 | #7C2D12 |
| warning-strong | #C2410C | #C2410C |

### Button Shadow (CSS custom properties, used for the raised box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--btn-shadow` | 0 3px 0 0 #00000026 | 0 3px 0 0 #00000040 |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #2A211C | #2A211C |
| dark-strong | #1A1412 | #3D3330 |
| disabled | #EDE8E3 | #2A211C |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #A855F7 |
| sky | #0EA5E9 |
| teal | #0D9488 |
| pink | #DB2777 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #FB923C |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #3E2B1E | #3E2B1E |
| heading | #3E2B1E | #F5F0EB |
| body | #6B5B50 | #B0A59B |
| body-subtle | #8B7E74 | #B0A59B |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #D4C4B8 | #3D2E22 |
| fg-brand | #5D4432 | #A68A76 |
| fg-brand-strong | #4A3628 | #D4C4B8 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #047857 | #065F46 |
| fg-success-strong | #065F46 | #10B981 |
| fg-danger | #BE123C | #F43F5E |
| fg-danger-strong | #881337 | #F87171 |
| fg-warning-subtle | #EA580C | #F97316 |
| fg-warning | #7C2D12 | #FBBF24 |
| fg-disabled | #9CA3AF | #6B7280 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #312E81 | #93C5FD |
| fg-purple | #9333EA | #A855F7 |
| fg-purple-strong | #7E3AF2 | #DDD6FE |
| fg-cyan | #0891B2 | #06B6D4 |
| fg-indigo | #4F46E5 | #4F46E5 |
| fg-pink | #DB2777 | #DB2777 |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #3E2B1E | #6B5B50 |
| border-buffer | #FFFFFF | #0D0A08 |
| border-buffer-medium | #FFFFFF | #2A211C |
| border-buffer-strong | #FFFFFF | #3D3330 |
| border-muted | #F9F7F5 | #1A1412 |
| border-light-subtle | #EDE8E3 | #1A1412 |
| border-light | #EDE8E3 | #2A211C |
| border-light-medium | #EDE8E3 | #3D3330 |
| border-default-subtle | #DDD6CE | #1A1412 |
| border-default | #DDD6CE | #2A211C |
| border-default-medium | #DDD6CE | #3D3330 |
| border-default-strong | #DDD6CE | #4A403B |
| border-success-subtle | #A7F3D0 | #064E3B |
| border-success | #047857 | #065F46 |
| border-danger-subtle | #FECDD3 | #881337 |
| border-danger | #BE123C | #BE123C |
| border-warning-subtle | #FED7AA | #7C2D12 |
| border-warning | #EA580C | #F97316 |
| border-brand-subtle | #D4C4B8 | #3D2E22 |
| border-brand-light | #5D4432 | #5D4432 |
| border-brand | #5D4432 | #A68A76 |
| border-dark-subtle | #3E2B1E | #3D3330 |
| border-purple | #A855F7 | #A855F7 |
| border-orange | #FB923C | #FB923C |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
