# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FAF6F0 | #1B1714 |
| neutral-primary | #FAF6F0 | #0E0B08 |
| neutral-primary-medium | #FAF6F0 | #272118 |
| neutral-primary-strong | #FAF6F0 | #382F24 |
| neutral-secondary-soft | #F3EDE4 | #1B1714 |
| neutral-secondary | #F3EDE4 | #0E0B08 |
| neutral-secondary-medium | #F3EDE4 | #272118 |
| neutral-secondary-strong | #F3EDE4 | #382F24 |
| neutral-tertiary-soft | #EBE4D8 | #1B1714 |
| neutral-tertiary | #EBE4D8 | #272118 |
| neutral-tertiary-medium | #EBE4D8 | #382F24 |
| neutral-quaternary | #E0D7C9 | #382F24 |
| quaternary-medium | #E0D7C9 | #4A3F32 |
| gray | #D2C8B8 | #4A3F32 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #EBEEF7 | #111D40 |
| brand-soft | #CDD5EC | #1C398E |
| brand | #1C398E | #4D72C7 |
| brand-medium | #ABB7DD | #1C398E |
| brand-strong | #152B6B | #1C398E |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #ECFDF5 | #002C22 |
| success | #007A55 | #009966 |
| success-medium | #D0FAE5 | #004F3B |
| success-strong | #006045 | #007A55 |
| danger-soft | #FEF0F2 | #4D0218 |
| danger | #C70036 | #C70036 |
| danger-medium | #FFE4E6 | #8B0836 |
| danger-strong | #A50036 | #A50036 |
| warning-soft | #FFF7ED | #7C2D12 |
| warning | #F97316 | #F97316 |
| warning-medium | #FFEDD5 | #7C2D12 |
| warning-strong | #C2410C | #C2410C |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.40) | rgba(255,255,255,0.15) |
| `--color-1-700` | rgba(0,0,0,0.15) | rgba(0,0,0,0.30) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #2C2215 | #2C2215 |
| dark-strong | #1D1610 | #3D3428 |
| disabled | #EBE4D8 | #2C2215 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #A855F7 |
| sky | #0EA5E9 |
| teal | #0D9488 |
| pink | #DB2777 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #FB923C |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #2C2215 | #2C2215 |
| heading | #2C2215 | #FAF6F0 |
| body | #6B5C4A | #A99880 |
| body-subtle | #87786A | #A99880 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #ABB7DD | #1C398E |
| fg-brand | #1C398E | #7B9DE0 |
| fg-brand-strong | #152B6B | #ABB7DD |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #047857 | #065F46 |
| fg-success-strong | #065F46 | #10B981 |
| fg-danger | #BE123C | #F43F5E |
| fg-danger-strong | #881337 | #F87171 |
| fg-warning-subtle | #EA580C | #F97316 |
| fg-warning | #7C2D12 | #FBBF24 |
| fg-disabled | #A99880 | #6B5C4A |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #312E81 | #93C5FD |
| fg-purple | #9333EA | #A855F7 |
| fg-purple-strong | #7E3AF2 | #DDD6FE |
| fg-cyan | #0891B2 | #06B6D4 |
| fg-indigo | #4F46E5 | #4F46E5 |
| fg-pink | #DB2777 | #DB2777 |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #2C2215 | #5A4D3E |
| border-buffer | #FAF6F0 | #0E0B08 |
| border-buffer-medium | #FAF6F0 | #2C2215 |
| border-buffer-strong | #FAF6F0 | #3D3428 |
| border-muted | #F3EDE4 | #1B1714 |
| border-light-subtle | #EBE4D8 | #1B1714 |
| border-light | #EBE4D8 | #2C2215 |
| border-light-medium | #EBE4D8 | #3D3428 |
| border-default-subtle | #E0D7C9 | #1B1714 |
| border-default | #E0D7C9 | #2C2215 |
| border-default-medium | #E0D7C9 | #3D3428 |
| border-default-strong | #E0D7C9 | #5A4D3E |
| border-success-subtle | #A7F3D0 | #064E3B |
| border-success | #047857 | #065F46 |
| border-danger-subtle | #FECDD3 | #881337 |
| border-danger | #BE123C | #BE123C |
| border-warning-subtle | #FED7AA | #7C2D12 |
| border-warning | #EA580C | #F97316 |
| border-brand-subtle | #ABB7DD | #1C398E |
| border-brand-light | #1C398E | #1C398E |
| border-brand | #1C398E | #7B9DE0 |
| border-dark-subtle | #2C2215 | #3D3428 |
| border-purple | #A855F7 | #A855F7 |
| border-orange | #FB923C | #FB923C |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
