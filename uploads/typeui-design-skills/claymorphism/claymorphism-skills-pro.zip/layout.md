# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 112px |
| Section header → content | 56px or 72px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 32px |
| Wide component grid gap | 40px |
| Column layout gap | 56px |

## Container

Standard section container: max-width 1152px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 112px vertical padding
- A background color (use neutral-primary-soft for all sections — see `sections.md`)
- A centered container (max-width 1152px, 24px horizontal padding)
- A section header area with 56px bottom margin
- Section content below

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Backgrounds & Visual Depth

- Default to warm, cream-toned backgrounds that reinforce the claymorphism aesthetic — never use pure white or flat solid fills.
- Apply the claymorphism depth treatment to surfaces: combine outer drop shadows (with slight X-axis offset) and dual inner shadows (lighter top-left, darker bottom-right) to create the characteristic inflated, clay-like 3D appearance.
- Use contextual treatments — soft gradient washes, subtle noise textures, warm overlays — that enhance the friendly, tactile clay feel.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.

## Must

- All sections: consistent 112px vertical padding
- All containers: max-width 1152px, centered, 24px horizontal padding
- Section headers: 56px or 72px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
