# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 36px | Cards, modals, sections, table wrappers, accordion wrappers |
| default | 999px | Buttons, inputs, badges, tooltips, dropdown items, small controls |
| sm | 12px | Checkboxes, tiny elements |
| full | 9999px | Pills, avatars, toggles, dot indicators |

## Rules

- 999px is the default radius for interactive small components (buttons, inputs, badges) giving them a pill-like, inflated claymorphism shape
- 36px is the radius for larger container surfaces (cards, modals) keeping them soft and rounded
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
