# Sections

> Dependencies: `colors.md`, `layout.md`

## Background Color

All sections use the **same** background color: **neutral-primary-soft**.

Do NOT alternate between `neutral-primary-soft` and `neutral-secondary-soft`. Every section — hero, features, testimonials, CTA, footer — uses `neutral-primary-soft` as its background.

## Rules

- Every `<section>` element uses `neutral-primary-soft` as its background
- No alternating or striped section backgrounds
- Visual separation between sections comes from spacing, borders, or content — not background color changes
- Cards and nested surfaces may still use other neutral tokens (e.g., `neutral-secondary-soft` for card backgrounds) to create depth within a section
