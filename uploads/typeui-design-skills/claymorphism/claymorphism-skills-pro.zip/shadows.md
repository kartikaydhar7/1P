# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `2px 4px 6px rgba(0,0,0,0.06), inset -2px -2px 4px rgba(0,0,0,0.04), inset 2px 2px 4px rgba(255,255,255,0.7)` |
| shadow-xs | `3px 6px 10px rgba(0,0,0,0.08), inset -2px -3px 6px rgba(0,0,0,0.05), inset 2px 3px 6px rgba(255,255,255,0.65)` |
| shadow-sm | `4px 8px 16px rgba(0,0,0,0.1), inset -3px -4px 8px rgba(0,0,0,0.05), inset 3px 4px 8px rgba(255,255,255,0.6)` |
| shadow-md | `6px 12px 24px rgba(0,0,0,0.12), inset -4px -6px 10px rgba(0,0,0,0.05), inset 4px 6px 10px rgba(255,255,255,0.55)` |
| shadow-lg | `8px 16px 32px rgba(0,0,0,0.14), inset -5px -8px 14px rgba(0,0,0,0.05), inset 5px 8px 14px rgba(255,255,255,0.5)` |
| shadow-xl | `10px 24px 48px rgba(0,0,0,0.16), inset -6px -10px 18px rgba(0,0,0,0.05), inset 6px 10px 18px rgba(255,255,255,0.45)` |
| shadow-2xl | `12px 32px 64px rgba(0,0,0,0.2), inset -8px -12px 22px rgba(0,0,0,0.05), inset 8px 12px 22px rgba(255,255,255,0.4)` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls | shadow-sm |
| Standard cards, popovers, dropdowns | shadow-md or shadow-lg |
| Prominent cards, sticky surfaces | shadow-lg or shadow-xl |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use only these tokens — no custom box-shadow values
- Every shadow token includes a claymorphism inner-shadow pair (lighter top-left inset, darker bottom-right inset) that creates the characteristic inflated, clay-like 3D appearance
- The outer shadow uses a slight X-axis offset to reinforce the clay depth illusion
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
