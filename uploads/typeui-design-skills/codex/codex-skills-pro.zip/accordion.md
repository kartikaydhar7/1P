# Accordion

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Wrapper:** full width, 1px border (border-default color, #E5E7EB), 9999px radius — clips first/last item corners into a pill silhouette
- **Item separator:** 1px bottom border (border-default, #E5E7EB) on every item except last

## Trigger (Button)

- **Layout:** flex, space-between, full width
- **Padding:** 24px horizontal, 16px vertical
- **Font:** 16px, 500 (medium) weight, Open Sans
- **Text color:** heading (#000000)
- **Background:** neutral-primary-soft (#FFFFFF)
- **Hover:** neutral-secondary-medium background (#F5F5F5)
- **Focus:** outline none, 2px ring in brand color (#000000)
- **Transition:** colors, 150ms
- **Open state:** neutral-secondary-medium background (#F5F5F5)

## Panel (Content)

- **Padding:** 24px horizontal, 16px vertical
- **Background:** neutral-primary-soft (#FFFFFF)
- **Top border:** 1px, border-default color (#E5E7EB)
- **Font:** 16px, body color (#666666), 1.6 line-height

## Chevron Icon

- Size: 16x16px
- Color: body text color (#666666)
- Closed: 0deg rotation
- Open: 180deg rotation
- Transition: transform, 150ms

## Variants

### Default (Collapse)
One panel open at a time. Items stacked inside a single shared bordered/rounded wrapper.

### Separated Cards
Each item is independent — has its own 1px border (#E5E7EB), 9999px radius, and NO shadow. 8px bottom margin between items. No shared outer border.

### Always Open
Multiple panels can expand simultaneously. Same styling as Default.

### Flush
No outer border. Trigger and panel have transparent backgrounds. Only bottom border dividers between items. Use inside containers that already provide a background.

## States

| State | Trigger appearance |
|---|---|
| Closed | heading text (#000000), neutral-primary-soft background (#FFFFFF) |
| Open | heading text (#000000), neutral-secondary-medium background (#F5F5F5) |
| Hover | neutral-secondary-medium background (#F5F5F5) |
| Focus | 2px brand ring (#000000), no outline |
| Disabled | fg-disabled text (#8F8F8F), not-allowed cursor, no hover/focus |
