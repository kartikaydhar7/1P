# Alerts

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Padding:** 16px 20px
- **Radius:** 9999px (pill geometry — for full-width strip alerts use the same 9999px on the end caps)
- **Border:** 1px, border-default (#E5E7EB)
- **Heading:** 16px, 500 (medium) weight, heading color (#000000)
- **Body:** 14px, 400 (regular) weight, 1.5 line-height, body color (#666666)
- **Shadow:** none

## Variants

All alert variants share the same neutral palette — intent is communicated through the icon and heading text, never through colored backgrounds or borders.

### Brand
- **Background:** brand-softer (#FAFAFA)
- **Border:** border-brand-subtle (#E5E7EB)
- **Text:** fg-brand-strong (#000000)

### Success
- **Background:** success-soft (#F5F5F5)
- **Border:** border-success-subtle (#E5E7EB)
- **Text:** fg-success-strong (#000000)

### Danger
- **Background:** danger-soft (#F5F5F5)
- **Border:** border-danger-subtle (#E5E7EB)
- **Text:** fg-danger-strong (#000000)

### Warning
- **Background:** warning-soft (#F5F5F5)
- **Border:** border-warning-subtle (#E5E7EB)
- **Text:** fg-warning (#000000)
