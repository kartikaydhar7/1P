# Avatars

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Circular shape:** fully rounded (9999px)
- **Rounded square shape:** 6.08px radius (image-containing — this is the precise card-image radius)
- **Default size:** 40x40px
- **Image fit:** cover

## Sizes

| Size | Dimensions | Radius |
|---|---|---|
| Extra Small | 18x18px | 9999px |
| Small | 24x24px | 9999px |
| Base | 32x32px | 9999px |
| Large | 44x44px | 9999px |
| XL | 56x56px | 9999px |
| 2XL | 64x64px | 9999px |

The "rounded square" avatar uses 6.08px in every size — that value is intentional and must be exact.

## Bordered Avatar

- 4px padding, fully rounded (9999px), 1px outline in border-default color (#E5E7EB)
- No box-shadow ring — separation comes from the outline alone

## Stacked Avatars

- Displayed in a row (flex)
- Each avatar: 40x40px, fully rounded (9999px), 2px border in border-buffer color (#FFFFFF)
- Overlap: -16px negative margin on all except first

### Stacked Counter
- Same size as avatars (40x40px), fully rounded (9999px)
- Background: dark-strong (#000000), text: white, 12px font, 500 (medium) weight
- Same overlap margin as other avatars

## Avatar with Text

- Flex row, 12px gap between avatar and text
- Avatar: 40x40px, fully rounded (9999px), cover fit
- Name: heading color (#000000), 500 (medium) weight
- Subtitle: 14px, body color (#666666)
