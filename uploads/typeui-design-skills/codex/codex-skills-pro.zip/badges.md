# Badges

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Border:** 1px, border-default (#E5E7EB)
- **Default radius:** 9999px (pill is the default geometry for badges in this system)
- **Pill radius:** 9999px (same — there is no non-pill badge variant)
- **Shadow:** none

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Default (small) | 12px | 10px | 3px |
| Large | 14px | 12px | 5px |

Horizontal padding is increased relative to a square chip because pill geometry needs visual side room to register as a pill.

## Variants

All variants share the same neutral palette — intent is signaled by an inline icon or label, never by a colored background.

### Brand
- **Background:** brand-softer (#FAFAFA)
- **Border:** border-brand-subtle (#E5E7EB)
- **Text:** fg-brand-strong (#000000)

### Alternative (Neutral Soft)
- **Background:** neutral-primary-soft (#FFFFFF)
- **Border:** border-default (#E5E7EB)
- **Text:** heading (#000000)

### Gray (Neutral Medium)
- **Background:** neutral-secondary-medium (#F5F5F5)
- **Border:** border-default (#E5E7EB)
- **Text:** heading (#000000)

### Danger
- **Background:** danger-soft (#F5F5F5)
- **Border:** border-danger-subtle (#E5E7EB)
- **Text:** fg-danger-strong (#000000)

### Success
- **Background:** success-soft (#F5F5F5)
- **Border:** border-success-subtle (#E5E7EB)
- **Text:** fg-success-strong (#000000)

### Warning
- **Background:** warning-soft (#F5F5F5)
- **Border:** border-warning-subtle (#E5E7EB)
- **Text:** fg-warning (#000000)

### Dark
- **Background:** dark (#000000)
- **Border:** transparent
- **Text:** white

## Pill Badges

Use 9999px radius — this is the same as the default; the system has no non-pill badge variant. The "pill" naming is preserved for compatibility.

## Badges with Icons

- Icon size (default): 12x12px
- Icon size (large): 14x14px
- Icon spacing: 6px margin next to label

## Icon-only Badge

Square shape — equalize dimensions to 24x24px, no horizontal text padding. Radius stays 9999px (becomes a circle).

## Dismissible Badges

Badge content + a close button. Close button hover backgrounds per variant:

| Variant | Close button hover background |
|---|---|
| Brand | brand-soft (#F5F5F5) |
| Alternative | neutral-tertiary (#F5F5F5) |
| Gray | neutral-quaternary (#E5E7EB) |
| Danger | danger-medium (#E5E7EB) |
| Success | success-medium (#E5E7EB) |
| Warning | warning-medium (#E5E7EB) |

## Dot / Notification Badge

- Positioned absolutely: -4px top, -4px right
- Size: 10x10px, fully rounded (9999px)
- 2px border in border-buffer color (#FFFFFF)
- Background: danger (#000000)
