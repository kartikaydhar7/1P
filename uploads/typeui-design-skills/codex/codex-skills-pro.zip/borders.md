# Borders

## Width Scale

| Context | Width |
|---|---|
| Default (inputs, buttons, cards) | 1px |
| Emphasis / focus | 1px |

## Rules

- Use solid borders by default
- Dashed borders only for special cases like file dropzones
- Components in the same family must use matching border widths
- Never mix border widths within a single component
- Border color is exclusively #E5E7EB (border-default) — never darken, tint, or substitute another value for dividers and hairlines
- The single exception is filled #000000 buttons, which omit a visible border (use transparent or matching the background)

## Usage

| Context | Width |
|---|---|
| Inputs / selects / textareas | 1px default; 1px on focus or error (color shifts to #000000) |
| Buttons | 1px for outlined variants; transparent for filled #000000 buttons |
| Cards / containers | 1px in #E5E7EB only; never stack heavy borders |
