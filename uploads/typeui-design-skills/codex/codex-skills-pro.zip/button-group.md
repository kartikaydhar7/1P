# Button Groups

> Dependencies: `buttons.md`, `colors.md`, `radius.md`

## Core Specs

- **Wrapper:** inline-flex, 9999px radius (pill silhouette across the entire group), no shadow
- **Children overlap:** -1px left margin on all except first button
- **Buttons inside the group must NOT have individual shadows.** The wrapper has no shadow either — the group is intentionally flat.

## Anatomy

### Wrapper
- Display: inline-flex
- Radius: 9999px
- Shadow: none

### First Button
- 9999px radius on inline-start side only, 0 on inline-end (the start cap of the pill)

### Middle Button(s)
- No radius (0 on all corners)

### Last Button
- 9999px radius on inline-end side only, 0 on inline-start (the end cap of the pill)

### All buttons except first
- -1px left margin to overlap borders

## Rules

- Buttons inside groups follow all styles from `buttons.md` (background, border, focus rings) — including the no-shadow / no-glint rules
- Icon-only buttons: 16x16px icon, match height of text buttons
- The group's outer silhouette must read as a single pill — never mix the 9999px end caps with a 6.08px image-card radius inside the same group
