# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except ghost and disabled)

- **Radius:** 9999px (pill geometry on every button)
- **Border:** 1px solid (transparent on filled #000000 brand buttons; #E5E7EB on outlined variants)
- **Shadow:** none — buttons never carry a box-shadow
- **Glint effect:** disabled. The glint variables (`--color-1-400`, `--color-1-700`) resolve to fully transparent values; do NOT layer inset highlights or outer color glows on any button
- **Font weight:** 500 (medium)
- **Font:** Open Sans
- **Box sizing:** border-box
- **Transition:** color and background-color transitions on hover

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 14px | 6px |
| Small | 14px | 16px | 8px |
| Base (default) | 14px | 20px | 10px |
| Large | 16px | 24px | 12px |
| Extra large | 16px | 28px | 14px |

Horizontal padding is slightly more generous than typical because pill buttons need extra side room to read as pills, not capsules.

## Variants

### Brand
- **Background:** brand token (#000000)
- **Border:** transparent
- **Text:** white
- **Hover:** brand-strong background (stays #000000); apply a subtle opacity shift (e.g. 90%) for hover feedback since the color cannot deepen
- **Focus ring:** 2px, brand-medium color (#E5E7EB) offset, with a 1px #000000 outline
- **Glint:** none

### Secondary
- **Background:** neutral-secondary-medium (#F5F5F5)
- **Border:** border-default (#E5E7EB)
- **Text:** heading color (#000000)
- **Hover:** neutral-tertiary-medium background (#F5F5F5), heading text color
- **Focus ring:** 2px, neutral-tertiary color
- **Glint:** none

### Tertiary
- **Background:** neutral-primary-soft (#FFFFFF)
- **Border:** border-default (#E5E7EB)
- **Text:** heading color (#000000)
- **Hover:** neutral-secondary-medium background (#F5F5F5), heading text color
- **Focus ring:** 2px, neutral-tertiary-soft color
- **Glint:** none

### Success
- **Background:** success token (#000000)
- **Border:** transparent
- **Text:** white
- **Hover:** success-strong background (#000000) with subtle opacity shift
- **Focus ring:** 2px, success-medium color
- **Glint:** none

### Danger
- **Background:** danger token (#000000)
- **Border:** transparent
- **Text:** white
- **Hover:** danger-strong background (#000000) with subtle opacity shift
- **Focus ring:** 2px, danger-medium color
- **Glint:** none

### Warning
- **Background:** warning token (#000000)
- **Border:** transparent
- **Text:** white
- **Hover:** warning-strong background (#000000) with subtle opacity shift
- **Focus ring:** 2px, warning-medium color
- **Glint:** none

### Dark
- **Background:** dark token (#000000)
- **Border:** transparent
- **Text:** white
- **Hover:** dark-strong background (#000000) with subtle opacity shift
- **Focus ring:** 2px, neutral-tertiary color
- **Glint:** none

### Ghost (NO shadow, NO glint)
- **Radius:** 9999px (pill — same as every other button)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color (#000000)
- **Hover:** neutral-secondary-medium background (#F5F5F5)
- **Focus ring:** 2px, neutral-tertiary color
- **No shadow, no glint effect**

### Disabled (NO shadow, NO glint)
- **Background:** disabled token (#F5F5F5)
- **Border:** border-default-medium (#E5E7EB)
- **Text:** fg-disabled color (#8F8F8F)
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no glint**

## Icons in Buttons

- Icon size: 16x16px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
- Icon color inherits from button text color — never tint with an accent
- #000000 is the ONLY filled-button background color in the system — there are no colored CTAs (no blue, green, orange primary buttons). All status variants (success/danger/warning) keep the same #000000 fill; intent is communicated through the surrounding context, not the button color
