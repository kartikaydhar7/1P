# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-secondary-medium (#F5F5F5) — every card laid over a section surface uses #F5F5F5 to separate from the #FFFFFF page
- **Border:** none by default; if a hairline is needed, 1px in border-default (#E5E7EB)
- **Radius:** 9999px (pill geometry) for default cards. 6.08px for cards that contain images or thumbnail clips
- **Shadow:** none — cards have NO shadow under any circumstance. Separation comes from the #F5F5F5 surface tone against the #FFFFFF page, not from depth

## Card Heading

- Desktop: 20px, 500 (medium) weight, heading color (#000000)
- Mobile: 18px, 500 (medium) weight, heading color (#000000)
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-secondary-medium (#F5F5F5)
- Border: none (or 1px border-default if a hairline is required)
- Radius: 9999px (default) or 6.08px (image-containing card)
- Shadow: none
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: subtle opacity shift on the #F5F5F5 surface (e.g. mix toward #ECECEC) — never introduce a colored hover state and never add a shadow on hover
- Transition: background-color
- Cursor: pointer

## Rules

- Background: neutral-secondary-medium (#F5F5F5) for cards layered over section surfaces
- Default radius: 9999px; image-containing cards: 6.08px (exact, do not round). Use 6.08px on the card itself AND on the image clip — they must match. Do NOT mix 9999px pill radius with a 6.08px image clip inside the same card boundary; pick one geometry per card
- Shadow: none on every card variant — flat by design
- Interactive hover: tonal shift on the surface only, no shadow, no border darkening
- Non-interactive: no hover styles
- Color may only enter the card through embedded photography or editorial imagery; never tint the card chrome itself
