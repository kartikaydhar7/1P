# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFFFF | #000000 |
| neutral-primary | #FFFFFF | #000000 |
| neutral-primary-medium | #FFFFFF | #0A0A0A |
| neutral-primary-strong | #FFFFFF | #141414 |
| neutral-secondary-soft | #FFFFFF | #000000 |
| neutral-secondary | #FFFFFF | #0A0A0A |
| neutral-secondary-medium | #F5F5F5 | #141414 |
| neutral-secondary-strong | #F5F5F5 | #1F1F1F |
| neutral-tertiary-soft | #F5F5F5 | #0A0A0A |
| neutral-tertiary | #F5F5F5 | #141414 |
| neutral-tertiary-medium | #F5F5F5 | #1F1F1F |
| neutral-quaternary | #E5E7EB | #1F1F1F |
| quaternary-medium | #E5E7EB | #2A2A2A |
| gray | #E5E7EB | #2A2A2A |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #FAFAFA | #1A1A1A |
| brand-soft | #F5F5F5 | #2A2A2A |
| brand | #000000 | #FFFFFF |
| brand-medium | #E5E7EB | #404040 |
| brand-strong | #000000 | #FFFFFF |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #F5F5F5 | #0A0A0A |
| success | #000000 | #FFFFFF |
| success-medium | #E5E7EB | #1F1F1F |
| success-strong | #000000 | #FFFFFF |
| danger-soft | #F5F5F5 | #0A0A0A |
| danger | #000000 | #FFFFFF |
| danger-medium | #E5E7EB | #1F1F1F |
| danger-strong | #000000 | #FFFFFF |
| warning-soft | #F5F5F5 | #0A0A0A |
| warning | #000000 | #FFFFFF |
| warning-medium | #E5E7EB | #1F1F1F |
| warning-strong | #000000 | #FFFFFF |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0) | rgba(255,255,255,0) |
| `--color-1-700` | rgba(0,0,0,0) | rgba(0,0,0,0) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #000000 | #000000 |
| dark-strong | #000000 | #0A0A0A |
| disabled | #F5F5F5 | #1F1F1F |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #000000 |
| sky | #000000 |
| teal | #000000 |
| pink | #000000 |
| cyan | #000000 |
| fuchsia | #000000 |
| indigo | #000000 |
| orange | #000000 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #000000 | #000000 |
| heading | #000000 | #FFFFFF |
| body | #666666 | #B3B3B3 |
| body-subtle | #8F8F8F | #8F8F8F |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #666666 | #B3B3B3 |
| fg-brand | #000000 | #FFFFFF |
| fg-brand-strong | #000000 | #FFFFFF |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #000000 | #FFFFFF |
| fg-success-strong | #000000 | #FFFFFF |
| fg-danger | #000000 | #FFFFFF |
| fg-danger-strong | #000000 | #FFFFFF |
| fg-warning-subtle | #666666 | #B3B3B3 |
| fg-warning | #000000 | #FFFFFF |
| fg-disabled | #8F8F8F | #8F8F8F |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #000000 | #FFFFFF |
| fg-info | #000000 | #FFFFFF |
| fg-purple | #000000 | #FFFFFF |
| fg-purple-strong | #000000 | #FFFFFF |
| fg-cyan | #000000 | #FFFFFF |
| fg-indigo | #000000 | #FFFFFF |
| fg-pink | #000000 | #FFFFFF |
| fg-lime | #000000 | #FFFFFF |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #000000 | #FFFFFF |
| border-buffer | #FFFFFF | #000000 |
| border-buffer-medium | #FFFFFF | #0A0A0A |
| border-buffer-strong | #FFFFFF | #141414 |
| border-muted | #E5E7EB | #1F1F1F |
| border-light-subtle | #E5E7EB | #1F1F1F |
| border-light | #E5E7EB | #1F1F1F |
| border-light-medium | #E5E7EB | #1F1F1F |
| border-default-subtle | #E5E7EB | #1F1F1F |
| border-default | #E5E7EB | #1F1F1F |
| border-default-medium | #E5E7EB | #1F1F1F |
| border-default-strong | #E5E7EB | #1F1F1F |
| border-success-subtle | #E5E7EB | #1F1F1F |
| border-success | #000000 | #FFFFFF |
| border-danger-subtle | #E5E7EB | #1F1F1F |
| border-danger | #000000 | #FFFFFF |
| border-warning-subtle | #E5E7EB | #1F1F1F |
| border-warning | #000000 | #FFFFFF |
| border-brand-subtle | #E5E7EB | #1F1F1F |
| border-brand-light | #000000 | #FFFFFF |
| border-brand | #000000 | #FFFFFF |
| border-dark-subtle | #000000 | #1F1F1F |
| border-purple | #000000 | #FFFFFF |
| border-orange | #000000 | #FFFFFF |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (always #FFFFFF) — the entire page stays white wall-to-wall, never alternate section background colors
- Surface cards (cards layered on top of sections): neutral-secondary-medium (#F5F5F5)
- Footer background: brand (#000000), with white text inside it
- Primary buttons: brand background (#000000) — black is the only filled CTA color
- Headings: heading text color (#000000)
- Body text: body text color (#666666)
- Tertiary / disabled text: body-subtle (#8F8F8F)
- CTA links: fg-brand text color (#000000), underlined
- Default borders/dividers: border-default (#E5E7EB) — never darken or tint
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text
- Color may only be introduced through photography or editorial imagery — never through UI backgrounds, button fills, or accent chrome

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No colored accent (blue, green, orange, purple) on interactive elements or backgrounds — black is the only active color
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No background colors on section blocks — page stays #FFFFFF wall-to-wall
- No more than two typographic colors at once: heading (#000000) for primary and body (#666666) for secondary; body-subtle (#8F8F8F) is reserved for disabled/tertiary only
- No manual light/dark value swapping — let the CSS custom properties handle it
