# Dropdown

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `inputs.md`

## Core Specs

### Chevron Icon
- Size: 16x16px
- Spacing: 6px left margin, -2px right margin
- Color: inherits from trigger button

### Menu Container
- Background: neutral-primary-soft (#FFFFFF)
- Border: 1px, border-default (#E5E7EB)
- Radius: 9999px is reserved for compact pill menus; for standard list menus use 6.08px so the menu reads as an image-card-style surface that frames the contained items
- Shadow: none — separation from the page comes from the 1px #E5E7EB hairline only
- Z-index: elevated above content

### Menu List
- Padding: 8px
- Font: 14px, body color (#666666), 500 (medium) weight, Open Sans

### Menu Item
- Layout: inline-flex, vertically centered, full width
- Padding: 12px horizontal, 8px vertical
- Radius: 9999px (pill items inside the menu)
- Hover: neutral-tertiary-medium background (#F5F5F5), heading text (#000000)
- Transition: colors, 150ms

## Trigger Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Small | 14px | 16px | 8px |
| Base | 14px | 20px | 10px |
| Large | 16px | 24px | 12px |

Trigger uses 9999px pill radius (inherits from `buttons.md`).

## Icon-only Trigger

- Padding: 8px
- Min size: 44x44px
- Icon: 20x20px
- Radius: 9999px (circle)

## Variants

### Default
- Menu width: 200px, items have 9999px radius (pill rows)

### With Divider
- Top border (border-default, #E5E7EB) between child groups, skip first group

### With Header
- Header padding: 16px horizontal, 12px vertical
- Bottom border: border-default (#E5E7EB)
- Name: heading color (#000000), 14px, 600 (semibold) weight
- Email: body-subtle color (#8F8F8F), 14px, truncated

### With Icons
- Icon before label: 16x16px, 8px right margin, body color (#666666)
- On hover, icon color changes to heading (#000000)

### With Checkbox / Radio
- Inputs: 16x16px, 4px radius (the only sub-pixel exception, kept for visual reasons)
- Focus ring in brand-soft (#F5F5F5)
- Helper text: 12px, body-subtle color (#8F8F8F), 2px top margin

### With Search
- Search input at top of menu following `inputs.md` specs (9999px pill input)
- Left icon: 12px left padding, input 36px left padding

### Scrollable
- Max height: 240px, vertical scroll overflow

## States

| State | Appearance |
|---|---|
| Focused trigger | no outline, 2px brand ring (#000000) |
| Hover item | neutral-tertiary-medium background (#F5F5F5), heading text (#000000) |
| Active/open item | neutral-tertiary-soft background (#F5F5F5), heading text (#000000) |
| Disabled item | fg-disabled text (#8F8F8F), not-allowed cursor, no pointer events |
