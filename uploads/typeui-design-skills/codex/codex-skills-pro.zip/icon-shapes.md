# Icon Shapes

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- Box sizing: border-box
- Icon must be perfectly centered (inline-flex, centered both axes)
- Circle: fully rounded (9999px)
- Rounded square: 6.08px radius (matches the image-card radius for any container that holds visual content)

## Sizes

| Size | Container | Icon |
|---|---|---|
| XS | 24x24px | 14x14px |
| SM | 32x32px | 16x16px |
| MD | 40x40px | 20x20px |
| LG | 48x48px | 24x24px |
| XL | 56x56px | 28x28px |

## Color Variants

All variants use the same neutral surface — color/intent is communicated by the icon glyph itself, not by colored chrome.

### Brand
- Shape: circle (9999px)
- Background: brand-softer (#FAFAFA)
- Icon color: fg-brand-strong (#000000)

### Gray
- Shape: circle (9999px)
- Background: neutral-secondary-soft (#FFFFFF)
- Icon color: body (#666666)

### Danger
- Shape: circle (9999px)
- Background: danger-soft (#F5F5F5)
- Icon color: fg-danger-strong (#000000)

### Success
- Shape: circle (9999px)
- Background: success-soft (#F5F5F5)
- Icon color: fg-success-strong (#000000)

### Warning
- Shape: circle (9999px)
- Background: warning-soft (#F5F5F5)
- Icon color: fg-warning (#000000)
