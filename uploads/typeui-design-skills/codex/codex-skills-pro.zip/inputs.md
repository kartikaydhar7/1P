# Inputs

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Display:** block, full width
- **Radius:** 9999px (pill geometry — every input, including the conversational/single-line input field, uses 9999px). Multi-line textareas use 6.08px so the field reads as a content surface rather than a chip
- **Border:** 1px, border-default-medium (#E5E7EB)
- **Background:** neutral-secondary-medium (#F5F5F5)
- **Shadow:** none
- **Font:** 16px, Open Sans, heading color (#000000)
- **Padding:** 20px horizontal, 12px vertical (extra side room for pill geometry)
- **Placeholder:** body color (#666666)
- **Transition:** all properties, 200ms

## Label

- Display: block
- Font: 14px, 500 (medium) weight, Open Sans, heading color (#000000)
- Margin bottom: 8px
- Label `htmlFor` must match the input `id`

## States

### Default
- Border: border-default-medium (#E5E7EB)
- Background: neutral-secondary-medium (#F5F5F5)

### Hover
- Border: border-default-strong (#E5E7EB)

### Focus
- No outline
- Border: border-brand (#000000)
- Ring: 1px, brand color (#000000)

### Success
- Border: border-success (#000000)
- Focus ring: 1px, success color (#000000)

### Error / Danger
- Border: border-danger (#000000)
- Focus ring: 1px, danger color (#000000)

### Disabled
- Background: disabled (#F5F5F5)
- Text: fg-disabled (#8F8F8F)
- Cursor: not-allowed

## Input with Icons

- Icon size: 16x16px
- Icon color: body (#666666)
- Container: relative positioned wrapper
- Start icon: absolutely positioned left, 16px left padding — input gets 44px left padding (extra to compensate for pill geometry)
- End icon: absolutely positioned right, 16px right padding — input gets 44px right padding
- Icons vertically centered within the wrapper

## Rules

- Every input must have a unique `id`
- Every label must have a matching `htmlFor`
- Padding: 20px horizontal, 12px vertical unless overridden for icon variants
- No arbitrary hex or hardcoded colors
- Single-line inputs use 9999px radius; multi-line textareas use 6.08px
