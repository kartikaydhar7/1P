# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Minimum vertical gap between page sections | 64px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1152px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 96px vertical padding
- A solid #FFFFFF background — every page section stays white wall-to-wall
- A centered container (max-width 1152px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below

The footer is the only block that breaks this rule: footer background uses brand (#000000) with white text inside.

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use a JS motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Backgrounds & Visual Depth

- Default to a flat #FFFFFF canvas — no gradients, no noise textures, no decorative meshes on the core UI.
- Depth is communicated through whitespace, the single 1px #E5E7EB hairline, and the contrast between #FFFFFF (page) and #F5F5F5 (surface card).
- Color may only enter the page through editorial photography or imagery sitting inside cards — never through UI fills, button color, or section backgrounds.
- Every decorative element must serve a compositional purpose (separation or emphasis). No purely ornamental effects competing with content.

## Must

- All sections: consistent 96px vertical padding, with a minimum 64px vertical gap between sibling sections
- All containers: max-width 1152px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Page background is always #FFFFFF; only the footer uses #000000
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
