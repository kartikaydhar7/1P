# Lists

> Dependencies: `colors.md`

## Core Specs

- Item spacing: 16px vertical gap between list items
- Text: body color (#666666)
- Font: Open Sans, 16px, 400 (regular) weight

## List Icons

- Size: 20x20px
- Prevent squishing: no shrink
- Spacing: 8px right margin between icon and text
- Active/featured icon: fg-brand color (#000000)
- Neutral icon: body color (#666666)

## Inactive / Disabled Items

Strikethrough text in body-subtle color (#8F8F8F) on the list item.

## Pattern

Vertical flex list with 16px gap. Each item is a flex row with centered alignment — icon (20x20, no-shrink, 8px right margin) followed by a span of body-colored text.
