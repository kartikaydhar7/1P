# Modals

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `buttons.md`, `inputs.md`

## Core Specs

### Overlay (Backdrop)
- Fixed, covers full screen
- Z-index: 40
- Background: black (#000000) at 50% opacity
- Backdrop blur: small amount

### Content Container
- Background: neutral-primary (#FFFFFF)
- Radius: 6.08px (modal panels are content surfaces, not pills — they use the precise image-card radius)
- Shadow: none — separation from the page comes entirely from the backdrop scrim
- Padding: 24px

## Anatomy

### Header
- Bottom border: border-default (#E5E7EB)
- Top corners rounded (6.08px)
- Title: 22px, 600 (semibold) weight, heading color (#000000), -0.03em letter-spacing
- Close button: Ghost variant from `buttons.md`, 6px padding (rendered as a 9999px circle since the ghost button inherits pill geometry)

### Body
- Vertical padding: 24px
- Vertical spacing between elements: 24px
- Text: 16px, 1.6 line-height, body color (#666666), 0 letter-spacing

### Footer
- Top border: border-default (#E5E7EB)
- Bottom corners rounded (6.08px)
- Footer buttons follow `buttons.md` (9999px pill radius)

## Variants

### Default (Information)
Standard header + body + footer with primary/secondary action buttons.

### Pop-up (Confirmation)
Centered text, prominent icon, reduced padding:
- Body: 24px padding, text centered
- Icon: centered, 16px bottom margin, 48x48px, gray color (#666666)

### Form Modal
Body contains inputs following `inputs.md`. Vertical spacing between form elements: 16px.

## Rules

- Backdrop covers full screen with fixed positioning
- Content: neutral-primary (#FFFFFF) background, 6.08px radius, NO shadow
- Header/Footer separated by border-default (#E5E7EB) borders
- Close button must be present and functional, rendered as a 9999px ghost pill/circle
- Accessibility: `role="dialog"`, implement focus trap in code
- Dark mode automatic via token system
