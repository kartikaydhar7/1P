# Pagination

> Dependencies: `colors.md`, `radius.md`

## Container

Font: 14px, Open Sans. Items displayed as flex with 4px gap between independent pill items (no overlapping borders — every page item is its own pill).

## Pagination Item

- Layout: flex, centered both axes
- Size: 36x36px (or 40x40px) — square aspect ratio so a 9999px radius produces a circle
- Text: body color (#666666), 500 (medium) weight
- Background: neutral-secondary-medium (#F5F5F5)
- Border: 1px, border-default-medium (#E5E7EB)
- Radius: 9999px (every item is a circular pill)
- Hover: neutral-tertiary-medium background (#F5F5F5), heading text (#000000)
- Focus: no outline, 2px ring in brand color (#000000)
- Spacing: 4px gap between items

## Previous / Next Buttons

- Horizontal padding: 16px, height: 36px
- Radius: 9999px on all corners (full pill — these are not segmented end caps)
- Background: neutral-secondary-medium (#F5F5F5)
- Border: 1px, border-default-medium (#E5E7EB)

## Active Page Item

- Text: white
- Background: brand (#000000)
- Border: transparent
- Hover text: white (stays same)

## Rules

- Display as flex with 4px gap between items — items do NOT overlap; each is an independent pill
- Items: neutral-secondary-medium background (#F5F5F5), border-default-medium border (#E5E7EB), body text (#666666)
- Active: white text, black (#000000) background — the only filled state
- Every item uses 9999px radius — no segmented bar with shared end caps
- All items need hover and focus states
- No box-shadows on any item
