# Radios, Checkboxes & Toggles

> Dependencies: `colors.md`, `radius.md`

## Checkbox

- Size: 16x16px
- Radius: 4px (the only sub-pixel exception in the system — kept tiny so the check glyph reads cleanly; do not enlarge)
- Border: 1px, border-default-medium (#E5E7EB)
- Background: neutral-secondary-medium (#F5F5F5)
- Focus ring: 2px, brand-soft (#F5F5F5) with 1px #000000 outline
- Checked: brand background (#000000), white check glyph

### Disabled
- Border: border-light (#E5E7EB)
- Text: fg-disabled (#8F8F8F)

## Radio

- Size: 16x16px
- Radius: 9999px (fully rounded)
- Border: 1px, border-default-medium (#E5E7EB)
- Background: neutral-secondary-medium (#F5F5F5)
- Focus ring: 2px, brand-soft (#F5F5F5) with 1px #000000 outline
- Checked: border-brand (#000000), indicator: neutral-primary color (#FFFFFF) on a brand (#000000) inner dot

### Disabled
- Border: border-light-medium (#E5E7EB)
- Text: fg-disabled (#8F8F8F)

Group all radio items under the same `name` attribute.

## Toggle

### Track
- Fully rounded (9999px)
- Background: neutral-quaternary (#E5E7EB)
- Focus-within ring: 2px, brand-soft (#F5F5F5) with 1px #000000 outline
- Checked track: brand background (#000000)
- Disabled track: neutral-tertiary background (#F5F5F5)

### Thumb
- Fully rounded (9999px)
- Background: white (#FFFFFF)
- Border: 1px border-buffer (#FFFFFF) — effectively flush; no box-shadow

### Disabled
- Track: neutral-tertiary background (#F5F5F5)
- Label: fg-disabled text (#8F8F8F)

## Rules

- All selection inputs must have `id` matching label `htmlFor`
- Focus states use the appropriate brand token (#000000) for each control type
- Disabled states: no hover/focus interaction
- No shadows on any selection control — separation comes from the track/thumb contrast and the 1px hairline
