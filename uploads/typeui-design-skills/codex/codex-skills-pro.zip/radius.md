# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 9999px | Buttons, cards, inputs, modals, sections, pill chips, conversational input fields |
| default | 9999px | Badges, tooltips, dropdown items, small controls |
| sm | 6.08px | Image-containing card elements, thumbnail clips, image frames |
| full | 9999px | Pills, avatars, toggles, dot indicators |

## Rules

- 9999px is the default radius across the product — pill geometry defines the system
- 6.08px is reserved exclusively for image-containing cards and thumbnail clips — this near-flat value is intentional and must be exact
- The contrast between pill (9999px) and image card (6.08px) radii is intentional — never blend, average, or substitute one for the other
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
