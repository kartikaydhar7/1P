# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `none` |
| shadow-xs | `none` |
| shadow-sm | `none` |
| shadow-md | `none` |
| shadow-lg | `none` |
| shadow-xl | `none` |
| shadow-2xl | `none` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs (none) |
| Inputs, buttons, small controls, lightweight cards | shadow-xs (none) |
| Standard cards, popovers, dropdowns | shadow-md (none) |
| Prominent cards, sticky surfaces | shadow-lg (none) |
| Modals, high-priority overlays | shadow-xl (none) |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl (none) |

## Rules

- All cards and buttons have NO shadow — separation comes from whitespace, not depth
- Do not apply box-shadows to cards under any circumstance
- Do not apply box-shadows to buttons, ghost buttons, or pill buttons
- Use only these tokens — no custom box-shadow values
- The system is intentionally flat: depth is communicated through generous whitespace, the #E5E7EB hairline border, and the contrast between #FFFFFF page surface and #F5F5F5 surface cards
- The only acceptable elevation cue is the modal/overlay backdrop scrim, never a drop shadow on the modal panel itself
