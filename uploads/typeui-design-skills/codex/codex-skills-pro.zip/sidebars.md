# Sidebars

> Dependencies: `colors.md`, `radius.md`, `typography.md`, `badges.md`, `alerts.md`

## Core Specs

- Background: neutral-primary-soft (#FFFFFF)
- Right border: 1px, border-default (#E5E7EB) for left-sidebar; left border for right-sidebar
- Width: 256px
- Shadow: none

## Anatomy

### Outer Container
Hidden on mobile, visible at small breakpoint. Needs a toggle/trigger for mobile.

### Inner Wrapper
- Full height, vertical scroll overflow
- Padding: 16px horizontal, 20px vertical

### Navigation List
- Vertical spacing: 4px between items
- Font weight: 500 (medium), Open Sans

### Navigation Item
- Layout: flex, vertically centered
- Padding: 16px horizontal, 10px vertical
- Text: heading color (#000000)
- Radius: 9999px (every nav row is a pill — even when full-width)
- Hover: neutral-secondary-medium background (#F5F5F5)
- Transition: colors
- Icon: 20x20px, body color (#666666), hover → heading color (#000000), 75ms transition
- Label: 12px left margin from icon

### Active Item
- Background: neutral-secondary-medium (#F5F5F5)
- Text: heading (#000000)
- Optional 1px border in border-default (#E5E7EB)

### Separator
- 16px top padding, 16px top margin
- Top border: border-default (#E5E7EB)
- 8px vertical spacing below

### Bottom CTA / Card
- Padding: 16px
- Top margin: 24px
- Radius: 6.08px (this is a content card, not a pill row)
- Background: brand-softer (#FAFAFA) or neutral-secondary-medium (#F5F5F5)
- No shadow
- Can also use any alert variant from `alerts.md`

## Rules

- Responsive: hidden on mobile with a trigger mechanism
- Icons: 20x20px, body color (#666666); hover: heading color (#000000)
- Multi-level menus: indent with 44px left padding
- Spacing follows 8px grid
- Only neutral, brand (black), or status tokens — no arbitrary colors
- No box-shadows anywhere in the sidebar — depth comes from the 1px #E5E7EB rail and the surface tone
