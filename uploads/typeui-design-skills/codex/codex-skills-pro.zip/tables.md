# Tables

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Wrapper

- Horizontal scroll overflow
- Background: neutral-primary-soft (#FFFFFF)
- Radius: 6.08px (table panels are content surfaces, not pills)
- Border: 1px, border-default (#E5E7EB)
- Shadow: none

## Table Element

- Full width, left-aligned text (right-aligned for RTL)
- Font: 14px, body color (#666666), Open Sans

## Table Head

- Font: 12px, body-subtle color (#8F8F8F), 500 (medium) weight, uppercase, +0.011em letter-spacing
- Background: neutral-secondary-soft (#FFFFFF) — header is flush with the table surface, separated only by the bottom border
- Bottom border: border-default (#E5E7EB)
- Cell padding: 24px horizontal, 16px vertical

## Table Body

- Row background: neutral-primary (#FFFFFF)
- Row bottom border: border-default (#E5E7EB) — omit on last row to avoid doubling with wrapper border
- Row hover: neutral-secondary-soft background (#F5F5F5) (optional)
- Row header: 500 (medium) weight, heading color (#000000), no-wrap
- Cell padding: 24px horizontal, 16px vertical

## Rules

- Wrapper must have horizontal scroll overflow for responsive scrolling
- Last row: omit bottom border to avoid doubling with wrapper border
- Row headers: always `scope="row"` for semantic structure
- Hover on rows is optional and uses #F5F5F5 only
- No arbitrary hex codes — use token colors only
- No shadows on the wrapper or rows; the table reads flat
