# Tabs

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs

- Typography: 14px, 500 (medium) weight, body color (#666666), Open Sans
- Transitions: all properties, 200ms

## Variants

### 1. Underline (Default)

**Wrapper:** bottom border, border-default (#E5E7EB)

**Tab Item:**
- Padding: 16px horizontal, 16px vertical
- Bottom border: 2px, transparent
- Top corners: 9999px (pill cap on the active tab)
- Transition: colors, 150ms

| State | Appearance |
|---|---|
| Active | heading text (#000000), border-brand bottom border (#000000) |
| Inactive | transparent bottom border; hover → heading text (#000000), border-default-strong bottom border (#E5E7EB) |
| Disabled | fg-disabled text (#8F8F8F), not-allowed cursor |

### 2. Pills

**Tab Item:**
- Padding: 16px horizontal, 10px vertical
- Radius: 9999px (full pill)
- Font weight: 500 (medium)
- Transition: all, 200ms
- Shadow: none

| State | Appearance |
|---|---|
| Active | brand background (#000000), white text, NO shadow |
| Inactive | body text (#666666); hover → neutral-secondary-soft background (#F5F5F5), heading text (#000000) |
| Disabled | fg-disabled text (#8F8F8F), not-allowed cursor |

### 3. Full Width

Children sit in a row with 4px gap; each tab is its own pill (no overlapping borders).

**Tab Item:**
- Full width within its segment, centered text
- Padding: 16px horizontal, 14px vertical
- Background: neutral-primary-soft (#FFFFFF)
- Border: 1px, border-default (#E5E7EB)
- Radius: 9999px (every tab is its own pill)
- Transition: colors, 150ms
- Hover: neutral-secondary-medium background (#F5F5F5), heading text (#000000)

| State | Appearance |
|---|---|
| Active | brand background (#000000), white text |
| First / Last item | 9999px radius (same as every other tab; full-pill segments) |

## Tabs with Icons

- Icon size: 16x16px or 20x20px
- Spacing: 8px right margin
- Layout: inline-flex, centered
- Icons inherit the text color of the tab state
