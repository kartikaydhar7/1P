# Tooltips & Popovers

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Tooltips

### Core Specs
- Padding: 12px horizontal, 8px vertical
- Font: 14px, 500 (medium) weight, Open Sans
- Radius: 9999px (tooltips are pills in this system — they read as floating chips)
- Shadow: none — separation comes from the contrasting background tone alone
- Transition: opacity, 300ms

### Dark (Default)
- Background: dark (#000000)
- Text: white (#FFFFFF)
- Border: transparent

### Light
- Background: neutral-primary-medium (#FFFFFF)
- Text: heading color (#000000)
- Border: 1px, border-default (#E5E7EB)

## Popovers

### Core Specs
- Background: neutral-primary (#FFFFFF)
- Radius: 6.08px (popovers are content surfaces — they use the precise image-card radius, not the pill radius)
- Shadow: none
- Border: 1px, border-default (#E5E7EB)
- Transition: opacity, 300ms

### Header / Title
- Padding: 12px horizontal, 8px vertical
- Background: neutral-secondary-soft (#FFFFFF)
- Bottom border: border-default (#E5E7EB)
- Font: 14px, 500 (medium) weight, heading color (#000000)

### Body / Content
- Standard: 12px horizontal, 8px vertical padding; 14px, body color (#666666)
- Rich: 16px padding; 14px, body color (#666666)

## Arrows

- Size: 8x8px rotated 45deg
- Color must match the background of the tooltip/popover variant
- For pill-shaped tooltips, the arrow is optional — many pill tooltips read better without an arrow

## Rules

- Tooltips: 9999px radius (pill geometry)
- Popovers: 6.08px radius (content-surface geometry)
- Dark tooltips: dark (#000000) background, white text — the only place dark fill is used outside of buttons and the footer
- Light tooltips/popovers: semantic neutral background + 1px #E5E7EB border tokens
- Arrows match parent background color
- No box-shadows on either component
