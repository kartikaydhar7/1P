# Typography

> Dependencies: `colors.md`

## Core Rules

- **Font:** Open Sans, sans-serif — configured at app level, never override. Load from Google Fonts (https://fonts.google.com/specimen/Open+Sans) and use weights 400, 500, 600 only
- **Headings:** semibold weight (600), heading text color (#000000)
- **Body copy:** body text color (#666666), never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels
- **Weight discipline:** never go below 400 or above 600 — the 400/500/600 triad defines the entire typographic hierarchy

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 48px | 1 | -0.03em | 24px |
| `h2` | 40px | 1.1 | -0.03em | — |
| `h3` | 32px | 1.15 | -0.03em | — |
| `h4` | 26px | 1.2 | -0.03em | — |
| `h5` | 22px | 1.3 | — | — |
| `h6` | 20px | 1.35 | — | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 36px | 30px |
| `h2` | 32px | 26px |
| `h3` | 28px | 24px |
| `h4` | 24px | 22px |
| `h5` | 22px | 20px |
| `h6` | 18px | 18px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1 for any heading.

Letter-spacing of -0.03em is reserved for display text at 22px and above. Do NOT apply tracking overrides below 22px unless using all-caps labels.

## Paragraphs

### Leading Paragraph
- Size: 18px
- Weight: 400 (regular)
- Color: body (#666666)
- Line-height: 1.6
- Letter-spacing: 0 (no tracking at body sizes)
- Max width: ~70 characters

### Normal Paragraph
- Size: 16px
- Weight: 400 (regular)
- Color: body (#666666)
- Line-height: 1.6
- Letter-spacing: 0 (no tracking at body sizes)
- Max width: ~65 characters

### Small Supporting Copy
- Size: 14px
- Weight: 400 (regular)
- Color: body (#666666)
- Line-height: 1.5
- Letter-spacing: 0
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 16px | 500 (medium) |
| Input labels | 14px or 16px | 500 (medium) |
| Captions / meta / badges | 12px or 14px | 500 (medium) |

Do not apply paragraph line-height (1.6) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color (#000000), underline, hover → no underline
- **CTA links:** fg-brand color (#000000), 500 (medium) weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text — uses 600 weight
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, +0.011em letter-spacing, 12px or 14px, 500 weight
- Use no more than two typographic colors at once: #000000 (heading) for primary and #666666 (body) for secondary; #8F8F8F is reserved exclusively for disabled or tertiary metadata — never for prose

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, and spacing remain constant.
