# Color Tokens

**Dark mode only.** There is no light mode. All values below are the only values — set directly on `:root`.

## Background Tokens

### Neutral
| Token | Value |
|---|---|
| neutral-primary-soft | #0A0A0A |
| neutral-primary | #050505 |
| neutral-primary-medium | #111111 |
| neutral-primary-strong | #1A1A1A |
| neutral-secondary-soft | #0A0A0A |
| neutral-secondary | #050505 |
| neutral-secondary-medium | #111111 |
| neutral-secondary-strong | #1A1A1A |
| neutral-tertiary-soft | #0E0E0E |
| neutral-tertiary | #111111 |
| neutral-tertiary-medium | #1A1A1A |
| neutral-quaternary | #1A1A1A |
| quaternary-medium | #252525 |
| gray | #252525 |

### Brand
| Token | Value |
|---|---|
| brand-softer | #1A0810 |
| brand-soft | #3D0E1F |
| brand | #F44174 |
| brand-medium | #3D0E1F |
| brand-strong | #FF5A89 |

### Status
| Token | Value |
|---|---|
| success-soft | #061A14 |
| success | #00CC88 |
| success-medium | #0A2E22 |
| success-strong | #009966 |
| danger-soft | #1A0508 |
| danger | #FF3355 |
| danger-medium | #3D0A14 |
| danger-strong | #CC2244 |
| warning-soft | #1A0E04 |
| warning | #FF8833 |
| warning-medium | #331A08 |
| warning-strong | #DD5511 |

### Utility
| Token | Value |
|---|---|
| dark | #111111 |
| dark-strong | #1A1A1A |
| disabled | #111111 |

### Accent
| Token | Value |
|---|---|
| purple | #A855F7 |
| sky | #0EA5E9 |
| teal | #0D9488 |
| pink | #F44174 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #FB923C |

## Text Color Tokens

### Base
| Token | Value |
|---|---|
| white | #FFFFFF |
| black | #0A0A0A |
| heading | #EDEDED |
| body | #888888 |
| body-subtle | #666666 |

### Brand
| Token | Value |
|---|---|
| fg-brand-subtle | #3D0E1F |
| fg-brand | #F44174 |
| fg-brand-strong | #FFB0C7 |

### Status
| Token | Value |
|---|---|
| fg-success | #065F46 |
| fg-success-strong | #10B981 |
| fg-danger | #FF4466 |
| fg-danger-strong | #FF6677 |
| fg-warning-subtle | #FF8833 |
| fg-warning | #FFBB33 |
| fg-disabled | #444444 |

### Informational / Accent
| Token | Value |
|---|---|
| fg-yellow | #FACC15 |
| fg-info | #93C5FD |
| fg-purple | #A855F7 |
| fg-purple-strong | #DDD6FE |
| fg-cyan | #06B6D4 |
| fg-indigo | #4F46E5 |
| fg-pink | #F44174 |
| fg-lime | #84CC16 |

## Border Color Tokens

| Token | Value |
|---|---|
| border-dark | #333333 |
| border-buffer | #050505 |
| border-buffer-medium | #111111 |
| border-buffer-strong | #1A1A1A |
| border-muted | #0A0A0A |
| border-light-subtle | #0A0A0A |
| border-light | #111111 |
| border-light-medium | #1A1A1A |
| border-default-subtle | #0E0E0E |
| border-default | #1A1A1A |
| border-default-medium | #222222 |
| border-default-strong | #333333 |
| border-success-subtle | #0A2E22 |
| border-success | #065F46 |
| border-danger-subtle | #3D0A14 |
| border-danger | #CC2244 |
| border-warning-subtle | #331A08 |
| border-warning | #FF8833 |
| border-brand-subtle | #3D0E1F |
| border-brand-light | #F44174 |
| border-brand | #F44174 |
| border-dark-subtle | #222222 |
| border-purple | #A855F7 |
| border-orange | #FB923C |

## Semantic Usage Rules

- **Dark mode only** — no light mode, no `prefers-color-scheme` media queries, no `dark:` prefixes
- Page/section backgrounds: neutral-primary (#050505), consistent dark tone across all sections — no alternating colors
- Primary buttons: brand background (#F44174) with white text — always
- Headings: heading text color (#EDEDED)
- Body text: body text color (#888888)
- CTA links: fg-brand text color
- Default borders: border-default (#1A1A1A)
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No light mode — dark palette only, always
- No `@media (prefers-color-scheme: dark)` blocks
- No framework-specific dark-mode prefixes (e.g. utility-class `dark:` prefixes)
- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
