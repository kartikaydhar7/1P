# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1280px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Card Grids — Bento Layout

**Bento grid layout is mandatory.** Wherever cards appear (feature cards, testimonials, services, stats, etc.), arrange them in a bento-style grid — cards of intentionally varied sizes and span widths that create an asymmetric, magazine-like mosaic. No generic uniform grids (e.g. 3 equal columns of equal-height cards) are allowed. Mix `col-span-1`, `col-span-2`, `row-span-2`, and full-width spans to produce visual rhythm and hierarchy.

## Section Pattern

Each section has:
- 96px vertical padding
- A consistent dark background using neutral-primary, composable with subtle dark-to-black gradients for atmospheric depth — do not alternate section background colors
- A centered container (max-width 1280px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Backgrounds & Visual Depth

- **Dark mode only.** The entire site uses the dark palette. No light mode, no `prefers-color-scheme` queries, no `dark:` prefixes.
- Default to deep, near-black backgrounds with layered dark gradients for atmospheric depth. The entire page should feel like one continuous dark surface.
- Apply contextual treatments — dark gradient meshes, subtle noise textures, faint geometric grid patterns, layered dark transparencies, glass-morphism panels (backdrop-blur with semi-transparent dark backgrounds like rgba(10,10,10,0.7)), grain overlays — that align with the mono/matrix aesthetic.
- Navigation bars should use a contained card style (max-width 1280px, centered, 12px radius) with glassmorphism: semi-transparent dark background (rgba(10,10,10,0.6)–rgba(10,10,10,0.8)), backdrop-blur (12px–16px), subtle 1px border-default border, positioned sticky or fixed with 16px top margin from the viewport edge.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.

## Hero Section Gradients

Hero sections must use layered radial/linear gradients to create an atmospheric, premium glow effect behind the main heading:
- A large, soft radial gradient using the brand color at very low opacity (e.g. `radial-gradient(ellipse at top, rgba(244,65,116,0.08)–rgba(244,65,116,0.15), transparent 60%)`) centered behind the heading area
- Optional secondary subtle gradient (e.g. a cool blue/purple tint at low opacity for depth)
- Gradients must be layered using absolutely positioned overlay divs with `pointer-events-none`, not applied directly to the section background
- The hero CTA button must be the Brand variant: brand background (#F44174) with white text (#FFFFFF)

## Must

- All sections: consistent 96px vertical padding
- All containers: max-width 1280px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
- All card grids must use bento layout (varied card sizes/spans) — no generic uniform grids allowed
