# Typography

> Dependencies: `colors.md`

## Core Rules

- **Font:** "Geist Mono", monospace — configured at app level, never override
- **Headings:** semibold weight (600), heading text color
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 56px | 1.05 | -1.5px | 24px |
| `h2` | 42px | 1.1 | -1px | — |
| `h3` | 34px | 1.15 | -0.5px | — |
| `h4` | 28px | 1.2 | -0.3px | — |
| `h5` | 22px | 1.4 | — | — |
| `h6` | 18px | 1.3 | — | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 38px | 30px |
| `h2` | 34px | 26px |
| `h3` | 28px | 22px |
| `h4` | 24px | 20px |
| `h5` | 20px | 18px |
| `h6` | 16px | 16px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.1 for any heading.

## Paragraphs

### Leading Paragraph
- Size: 18px
- Weight: normal
- Color: body
- Line-height: 1.7
- Max width: ~65 characters

### Normal Paragraph
- Size: 15px
- Weight: normal
- Color: body
- Line-height: 1.7
- Max width: ~60 characters

### Small Supporting Copy
- Size: 13px
- Weight: normal
- Color: body
- Line-height: 1.6
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 14px | 500 (medium) |
| Input labels | 13px or 14px | 500 (medium) |
| Captions / meta / badges | 11px or 13px | 500 (medium) |

Do not apply paragraph line-height (1.7) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline, hover → no underline
- **CTA links:** fg-brand color, medium weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, 1px letter-spacing, 11px or 13px

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, and spacing remain constant.
