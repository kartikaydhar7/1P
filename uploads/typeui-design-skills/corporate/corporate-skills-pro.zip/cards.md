# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-primary-soft (white) or neutral-secondary-soft (#F8F8F8) depending on section context
- **Border:** 1px, border-default color
- **Radius:** 0px — all cards use sharp corners
- **Shadow:** shadow-xs
- **Padding:** 48px on desktop, 24px on mobile and tablet

## Card Heading

- Desktop: 20px, medium weight, heading color
- Mobile: 16px, medium weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-primary-soft
- Border: 1px, border-default
- Radius: 0px
- Shadow: shadow-xs
- Padding: 48px desktop, 24px mobile/tablet
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: neutral-secondary-medium background
- Transition: colors
- Cursor: pointer

## Rules

- Background: neutral-primary-soft
- Border: 1px, border-default
- Radius: 0px
- Shadow: shadow-xs
- Padding: 48px desktop, 24px mobile/tablet
- Interactive hover: neutral-secondary-medium background
- Non-interactive: no hover styles
