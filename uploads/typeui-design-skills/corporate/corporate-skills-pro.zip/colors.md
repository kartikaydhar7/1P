# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFFFF | #0A0A0A |
| neutral-primary | #FFFFFF | #000000 |
| neutral-primary-medium | #FFFFFF | #171717 |
| neutral-primary-strong | #FFFFFF | #262626 |
| neutral-secondary-soft | #F8F8F8 | #0A0A0A |
| neutral-secondary | #F8F8F8 | #000000 |
| neutral-secondary-medium | #F8F8F8 | #171717 |
| neutral-secondary-strong | #F8F8F8 | #262626 |
| neutral-tertiary-soft | #F0F0F0 | #0A0A0A |
| neutral-tertiary | #F0F0F0 | #171717 |
| neutral-tertiary-medium | #F0F0F0 | #262626 |
| neutral-quaternary | #E5E5E5 | #262626 |
| quaternary-medium | #E5E5E5 | #404040 |
| gray | #A3A3A3 | #404040 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #F5F5F5 | #171717 |
| brand-soft | #E5E5E5 | #262626 |
| brand | #0A0A0A | #F5F5F5 |
| brand-medium | #D4D4D4 | #262626 |
| brand-strong | #000000 | #FFFFFF |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #F0FDF4 | #052E16 |
| success | #16A34A | #22C55E |
| success-medium | #DCFCE7 | #14532D |
| success-strong | #15803D | #16A34A |
| danger-soft | #FEF2F2 | #450A0A |
| danger | #DC2626 | #EF4444 |
| danger-medium | #FEE2E2 | #7F1D1D |
| danger-strong | #B91C1C | #DC2626 |
| warning-soft | #FFFBEB | #78350F |
| warning | #F59E0B | #F59E0B |
| warning-medium | #FEF3C7 | #78350F |
| warning-strong | #D97706 | #D97706 |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.15) | rgba(255,255,255,0.08) |
| `--color-1-700` | rgba(0,0,0,0.08) | rgba(0,0,0,0.15) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #0A0A0A | #0A0A0A |
| dark-strong | #000000 | #262626 |
| disabled | #F0F0F0 | #171717 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #A855F7 |
| sky | #0EA5E9 |
| teal | #0D9488 |
| pink | #DB2777 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #FB923C |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #0A0A0A | #0A0A0A |
| heading | #0A0A0A | #FFFFFF |
| body | #525252 | #A3A3A3 |
| body-subtle | #737373 | #A3A3A3 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #D4D4D4 | #262626 |
| fg-brand | #0A0A0A | #F5F5F5 |
| fg-brand-strong | #000000 | #FFFFFF |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #16A34A | #15803D |
| fg-success-strong | #15803D | #22C55E |
| fg-danger | #DC2626 | #EF4444 |
| fg-danger-strong | #B91C1C | #FCA5A5 |
| fg-warning-subtle | #D97706 | #F59E0B |
| fg-warning | #92400E | #FBBF24 |
| fg-disabled | #A3A3A3 | #525252 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #312E81 | #93C5FD |
| fg-purple | #9333EA | #A855F7 |
| fg-purple-strong | #7E3AF2 | #DDD6FE |
| fg-cyan | #0891B2 | #06B6D4 |
| fg-indigo | #4F46E5 | #4F46E5 |
| fg-pink | #DB2777 | #DB2777 |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #171717 | #404040 |
| border-buffer | #FFFFFF | #000000 |
| border-buffer-medium | #FFFFFF | #171717 |
| border-buffer-strong | #FFFFFF | #262626 |
| border-muted | #FAFAFA | #0A0A0A |
| border-light-subtle | #F0F0F0 | #0A0A0A |
| border-light | #F0F0F0 | #171717 |
| border-light-medium | #F0F0F0 | #262626 |
| border-default-subtle | #E5E5E5 | #0A0A0A |
| border-default | #E5E5E5 | #171717 |
| border-default-medium | #E5E5E5 | #262626 |
| border-default-strong | #E5E5E5 | #404040 |
| border-success-subtle | #BBF7D0 | #14532D |
| border-success | #16A34A | #15803D |
| border-danger-subtle | #FECACA | #7F1D1D |
| border-danger | #DC2626 | #DC2626 |
| border-warning-subtle | #FDE68A | #78350F |
| border-warning | #D97706 | #F59E0B |
| border-brand-subtle | #D4D4D4 | #262626 |
| border-brand-light | #0A0A0A | #F5F5F5 |
| border-brand | #0A0A0A | #F5F5F5 |
| border-dark-subtle | #171717 | #262626 |
| border-purple | #A855F7 | #A855F7 |
| border-orange | #FB923C | #FB923C |

## Semantic Usage Rules

- Page/section backgrounds alternate: neutral-primary-soft (white), neutral-secondary-soft (gray #F8F8F8), and brand (#0A0A0A) for hero/dark feature sections
- Primary buttons: brand background (#0A0A0A)
- Headings: heading text color; on brand backgrounds use white
- Body text: body text color; on brand backgrounds use white or body-subtle
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text
- Section pattern from reference: brand (hero) → white → gray → white → brand (FAQ/footer)

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No manual light/dark value swapping — let the CSS custom properties handle it
