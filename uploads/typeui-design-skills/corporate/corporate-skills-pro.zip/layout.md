# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1152px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 96px vertical padding
- A background color following the alternation pattern (see below)
- A centered container (max-width 1152px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below

### Section Background Alternation

Sections alternate between three background treatments to create visual rhythm and contrast:

1. **Brand (dark):** brand background (#0A0A0A) — used for hero sections, CTA sections, FAQ, and footer. Text uses white color.
2. **White:** neutral-primary-soft (#FFFFFF) — default clean sections for content, products, features.
3. **Gray:** neutral-secondary-soft (#F8F8F8) — used for alternating content sections, feature grids, testimonials.

Reference pattern: brand (hero) → white → gray → white → brand (FAQ) → brand (footer). Adapt as needed but always maintain strong contrast between adjacent sections.

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Backgrounds & Visual Depth

- Default to clean, flat backgrounds with high contrast between sections.
- Avoid gradients, textures, noise, or decorative overlays — the design relies on stark color blocking (black, white, gray) and typography for visual hierarchy.
- Every element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.

## Must

- All sections: consistent 96px vertical padding
- All containers: max-width 1152px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Section backgrounds: alternate between brand (#0A0A0A), white (#FFFFFF), and gray (#F8F8F8) — never place two same-color sections adjacent
- On brand/dark sections: all text, headings, and icons use white; buttons use inverted (white bg, brand text) or outline styles
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
