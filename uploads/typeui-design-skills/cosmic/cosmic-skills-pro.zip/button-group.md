# Button Groups

> Dependencies: `buttons.md`, `colors.md`, `radius.md`

## Core Specs

- **Wrapper:** inline-flex, 4px radius, shadow-xs + glow-subtle
- **Children overlap:** -1px left margin on all except first button
- **Buttons inside the group must NOT have individual shadows.** Only the wrapper has a shadow.
- **Cut corners:** The wrapper uses the clip-path chamfer from `buttons.md`. Individual buttons within the group do NOT have their own clip-path — only the wrapper is clipped.

## Anatomy

### Wrapper
- Display: inline-flex
- Radius: 4px (or clip-path chamfer for the group outline)
- Shadow: shadow-xs + glow-subtle

### First Button
- 4px radius on inline-start side only, 0 on inline-end

### Middle Button(s)
- No radius (0 on all corners)

### Last Button
- 4px radius on inline-end side only, 0 on inline-start

### All buttons except first
- -1px left margin to overlap borders

## Rules

- Buttons inside groups follow all styles from `buttons.md` (background, border, focus rings) except individual shadows and individual clip-paths
- Icon-only buttons: 16x16px icon, match height of text buttons
