# Typography

> Dependencies: `colors.md`

## Core Rules

- **Font:** Audiowide, sans-serif — configured at app level via Google Fonts import, never override. Used for ALL text (headings and body)
- **Headings:** semibold weight (600), heading text color, uppercase, wide letter-spacing for sci-fi aesthetic
- **H1 special treatment:** h1 elements use a linear gradient text effect — `background: linear-gradient(135deg, fg-brand, fg-brand-strong)` with `background-clip: text` and `color: transparent`
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 60px | 1 | 2px | 24px |
| `h2` | 44px | 1.15 | 1.5px | — |
| `h3` | 36px | 1.2 | 1px | — |
| `h4` | 30px | 1.25 | 0.8px | — |
| `h5` | 24px | 1.5 | 0.5px | — |
| `h6` | 20px | 1.25 | 0.5px | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 40px | 32px |
| `h2` | 36px | 28px |
| `h3` | 30px | 24px |
| `h4` | 26px | 22px |
| `h5` | 22px | 20px |
| `h6` | 18px | 18px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.1 for any heading.

## H1 Gradient Text Rule

All h1 elements must use a gradient text effect:
- `background: linear-gradient(135deg, fg-brand, fg-brand-strong)`
- `background-clip: text` / `-webkit-background-clip: text`
- `color: transparent`
- This creates a brand-tinted gradient on the main page heading
- Only applies to h1 — all other headings use the standard heading text color

## Gradient Text Glow (Required)

Gradient text alone is too subtle against the dark #040B17 background. Every gradient-text heading MUST be wrapped in a parent element that applies a luminous drop-shadow glow:

- **Wrapper:** a `<div>` or `<span>` around the gradient-text element
- **Filter:** `filter: drop-shadow(0 0 30px rgba(38,112,173,0.6)) drop-shadow(0 0 60px rgba(26,80,128,0.3))`
- This makes the gradient text visibly glow and pop against the dark background
- The glow color uses fg-brand-strong (#2670AD → rgba(38,112,173,...)) and fg-brand (#1A5080 → rgba(26,80,128,...))
- Applies to h1 gradient headings and any h2/h3 that are styled with the gradient-text treatment for emphasis

Note: `text-shadow` does not work on `background-clip: text` elements because the text color is transparent. You MUST use `filter: drop-shadow()` on a wrapper element instead.

## Emphasis Gradient Headings

Section headings (h2) can optionally use the same gradient-text + glow treatment when they are the primary heading of a major section (hero, CTA, features). Apply the same rules as h1: `background: linear-gradient(...)`, `background-clip: text`, `color: transparent`, wrapped in a glow container.

## Paragraphs

### Leading Paragraph
- Size: 20px
- Weight: normal
- Color: body
- Line-height: 1.7
- Max width: ~70 characters

### Normal Paragraph
- Size: 16px
- Weight: normal
- Color: body
- Line-height: 1.7
- Max width: ~65 characters

### Small Supporting Copy
- Size: 14px
- Weight: normal
- Color: body
- Line-height: 1.6
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 16px | 500 (medium) |
| Input labels | 14px or 16px | 500 (medium) |
| Captions / meta / badges | 12px or 14px | 500 (medium) |

Do not apply paragraph line-height (1.7) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline, hover → no underline
- **CTA links:** fg-brand color, medium weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, 2px letter-spacing, 12px or 14px

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, and spacing remain constant.
