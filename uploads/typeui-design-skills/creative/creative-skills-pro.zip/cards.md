# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-primary-soft
- **Border:** 1px, border-default color
- **Radius:** 32px (base)
- **Shadow:** colored box-shadow matching the card's accent (e.g. `0 4px 20px rgba(accent, 0.12)`)
- **Backdrop layer:** Every card must have a colored offset backdrop layer behind it — see `layout.md` → Visual Effects → Card Backdrop Layer for the full pattern

## Card Heading

- Desktop: 20px, medium weight, heading color
- Mobile: 16px, medium weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-primary-soft
- Border: 1px, border-default
- Radius: 32px
- Shadow: colored shadow matching accent (e.g. `0 4px 20px rgba(accent, 0.12)`)
- Backdrop layer: colored offset layer behind (see `layout.md`)
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: neutral-secondary-medium background, `transform: translateY(-2px)`, shadow-md
- Transition: all 200ms ease
- Cursor: pointer

## Rules

- Background: neutral-primary-soft
- Border: 1px, border-default
- Radius: 32px
- Shadow: colored shadow matching card accent — NOT generic black shadow
- Backdrop layer: required on all cards in grids — colored, offset, slightly rotated layer behind the card (see `layout.md` Card Backdrop Layer)
- Alternate backdrop rotation across sibling cards for visual rhythm (+2deg, -2deg, +2deg)
- Interactive hover: neutral-secondary-medium background + lift effect + shadow increase
- Non-interactive: no hover styles
