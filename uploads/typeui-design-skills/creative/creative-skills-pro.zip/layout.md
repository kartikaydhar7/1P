# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1152px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 96px vertical padding
- A background color (alternate between neutral-primary-soft and neutral-secondary-soft)
- A centered container (max-width 1152px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below

## Motion & Animation

- **All interactive elements** must use `transition: all 200ms ease` as the baseline transition.
- Hover interactions combine: `transform: translateY(-2px)` + increased `box-shadow` for a lift effect.
- No abrupt state changes — every state shift should animate smoothly.
- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Visual Effects

### Colored Shadows
- Always use **colored shadows** instead of black ones — they feel modern and non-heavy.
  - Blue elements: `box-shadow: 0 4px 14px rgba(59, 130, 246, 0.3)`
  - Purple elements: `box-shadow: 0 4px 14px rgba(139, 92, 246, 0.3)`
  - Brand elements: `box-shadow: 0 4px 14px rgba(105, 62, 224, 0.3)`
  - Pink elements: `box-shadow: 0 4px 14px rgba(236, 72, 153, 0.3)`
  - Cyan elements: `box-shadow: 0 4px 14px rgba(34, 211, 238, 0.3)`
  - Cards (default): `box-shadow: 0 4px 20px <accent-color at 0.12 opacity>`

### Card Backdrop Layer (Stacked Offset Layer)
- **Every card** must have a **colored offset backdrop layer** behind it — a tinted, slightly rotated rectangle that peeks out from behind the card, creating a playful stacked-paper depth effect.
- Structure:
  1. Outer wrapper: `position: relative`
  2. Backdrop layer: `position: absolute; inset: 0; border-radius: 32px` with a colored gradient background, slightly rotated (`rotate(2deg)` to `rotate(-3deg)`) and offset (`translate(3–6px, 4–6px)`)
  3. Main card: `position: relative` (sits on top of the backdrop)
- The backdrop gradient should use the card's accent color at low opacity (10–18%):
  - Purple cards: `linear-gradient(135deg, rgba(139,92,246,0.15), rgba(105,62,224,0.08))`
  - Cyan cards: `linear-gradient(135deg, rgba(34,211,238,0.15), rgba(56,189,248,0.1))`
  - Pink cards: `linear-gradient(135deg, rgba(236,72,153,0.14), rgba(217,70,239,0.1))`
  - Orange cards: `linear-gradient(135deg, rgba(251,146,60,0.14), rgba(45,212,191,0.1))`
  - Brand cards: `linear-gradient(135deg, rgba(105,62,224,0.18), rgba(99,102,241,0.12))`
  - Green cards: `linear-gradient(135deg, rgba(34,197,94,0.14), rgba(16,185,129,0.08))`
- Alternate rotation direction across sibling cards for visual rhythm (e.g. +2deg, -2deg, +2deg)
- The main card also gets a matching colored `box-shadow` instead of a neutral one
- This pattern applies to: feature cards, pricing cards, stat cards, testimonial cards, and any card grid

### Gradients
- **Directional gradient for CTA blocks**: `135deg`, brand (#693EE0) → indigo (#6366F1)
- **Page background**: Very light purple-gray tint (#F8F7FC) — gives depth without contrast loss
- **Hero accent gradients**: Use vibrant multi-color gradients for decorative elements (purple → pink → cyan)

### Transitions
- **All interactive elements** should use `transition: all 200ms ease`
- Hover interactions combine: `transform: translateY(-2px)` + `box-shadow` increase
- No abrupt state changes — every state shift should animate smoothly

## Backgrounds & Visual Depth

- Default to layered, atmospheric backgrounds with a subtle purple-tinted base rather than flat solid fills.
- Apply contextual treatments — gradient meshes, noise textures, geometric patterns, layered transparencies, dramatic colored shadows, decorative borders, grain overlays — that align with the creative, colorful brand aesthetic.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.

## Must

- All sections: consistent 96px vertical padding
- All containers: max-width 1152px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
