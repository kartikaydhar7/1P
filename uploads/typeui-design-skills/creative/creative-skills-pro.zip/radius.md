# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 32px | Cards, sections, modals, accordion wrappers |
| default | 16px | Icon containers, tooltips, dropdown items, small controls |
| sm | 8px | Checkboxes, tiny elements |
| full | 9999px | Buttons, inputs, pills, avatars, toggles, badges, dot indicators |

## Rules

- Buttons and inputs are always pill-shaped (9999px / full)
- Cards, modals, and sections use 32px (base) for a soft, generous roundness
- Icon containers and smaller UI pieces use 16px (default)
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
