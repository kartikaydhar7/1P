# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `0 1px rgb(105 62 224 / 0.04)` |
| shadow-xs | `0 1px 2px 0 rgb(105 62 224 / 0.06)` |
| shadow-sm | `0 1px 3px 0 rgb(105 62 224 / 0.08), 0 1px 2px -1px rgb(105 62 224 / 0.06)` |
| shadow-md | `0 4px 6px -1px rgb(105 62 224 / 0.1), 0 2px 4px -2px rgb(105 62 224 / 0.06)` |
| shadow-lg | `0 10px 15px -3px rgb(105 62 224 / 0.12), 0 4px 6px -4px rgb(105 62 224 / 0.06)` |
| shadow-xl | `0 20px 25px -5px rgb(105 62 224 / 0.12), 0 8px 10px -6px rgb(105 62 224 / 0.06)` |
| shadow-2xl | `0 25px 50px -12px rgb(105 62 224 / 0.2)` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls, lightweight cards | shadow-xs or shadow-sm |
| Standard cards, popovers, dropdowns | shadow-md |
| Prominent cards, sticky surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use these tokens as the default — but colored shadows matching the element's accent are encouraged for interactive and branded components (see `layout.md` Visual Effects)
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level and add `transform: translateY(-2px)` for a lift effect
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
