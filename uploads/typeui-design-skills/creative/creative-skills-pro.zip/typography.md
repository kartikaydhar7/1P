# Typography

> Dependencies: `colors.md`

## Core Rules

- **Heading font:** Bangers, cursive — configured at app level via Google Fonts import, used exclusively for headings (`h1`–`h6`)
- **Body font:** Inter, sans-serif — used for all non-heading text: paragraphs, buttons, badges, labels, inputs, links, and UI controls
- **Headings:** normal weight (400) because Bangers is a display font with built-in visual weight, heading text color
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 64px | 1.05 | 1px | 24px |
| `h2` | 48px | 1.1 | 0.5px | — |
| `h3` | 40px | 1.15 | 0.5px | — |
| `h4` | 32px | 1.2 | — | — |
| `h5` | 26px | 1.3 | — | — |
| `h6` | 22px | 1.25 | — | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 44px | 36px |
| `h2` | 38px | 30px |
| `h3` | 32px | 26px |
| `h4` | 28px | 24px |
| `h5` | 24px | 22px |
| `h6` | 20px | 18px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.05 for any heading. Bangers headings benefit from slightly positive letter-spacing for readability at large sizes.

## Paragraphs

### Leading Paragraph
- Size: 20px
- Weight: normal
- Color: body
- Line-height: 1.7
- Max width: ~70 characters

### Normal Paragraph
- Size: 16px
- Weight: normal
- Color: body
- Line-height: 1.7
- Max width: ~65 characters

### Small Supporting Copy
- Size: 14px
- Weight: normal
- Color: body
- Line-height: 1.6
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 16px | 600 (semibold) |
| Input labels | 14px or 16px | 500 (medium) |
| Captions / meta / badges | 12px or 14px | 600 (semibold) |

Do not apply paragraph line-height (1.7) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline, hover → no underline
- **CTA links:** fg-brand color, medium weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, 0.4px letter-spacing, 12px or 14px

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, and spacing remain constant.
