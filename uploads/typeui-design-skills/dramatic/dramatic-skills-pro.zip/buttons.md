# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except ghost and disabled)

- **Radius:** 0px (sharp corners on all buttons, including pills)
- **Border:** 1px solid
- **Shadow:** shadow-xs
- **Font weight:** 600 (semibold)
- **Font:** Charis SIL
- **Box sizing:** border-box
- **Transition:** all properties on hover, 250ms ease-out

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 14px | 8px |
| Small | 14px | 16px | 10px |
| Base (default) | 14px | 20px | 12px |
| Large | 16px | 24px | 14px |
| Extra large | 16px | 28px | 16px |

## Variants

### Brand
- **Background:** brand gradient (`linear-gradient(135deg, #A855F7, #FF2A52, #FF6B35)`)
- **Border:** transparent
- **Text:** white
- **Hover:** gradient shifts brighter (increase saturation/lightness by ~8%), subtle lift with shadow-sm
- **Focus ring:** 4px, brand-medium color
- **Glint:** no

### Secondary
- **Background:** neutral-secondary-medium
- **Border:** border-default-medium
- **Text:** body color
- **Hover:** neutral-tertiary-medium background, heading text color
- **Focus ring:** 4px, neutral-tertiary color
- **Glint:** yes

### Tertiary
- **Background:** neutral-primary-soft
- **Border:** border-default
- **Text:** body color
- **Hover:** neutral-secondary-medium background, heading text color
- **Focus ring:** 4px, neutral-tertiary-soft color
- **Glint:** yes

### Success
- **Background:** success token
- **Border:** transparent
- **Text:** white
- **Hover:** success-strong background
- **Focus ring:** 4px, success-medium color
- **Glint:** yes

### Danger
- **Background:** danger token
- **Border:** transparent
- **Text:** white
- **Hover:** danger-strong background
- **Focus ring:** 4px, danger-medium color
- **Glint:** yes

### Warning
- **Background:** warning token
- **Border:** transparent
- **Text:** white
- **Hover:** warning-strong background
- **Focus ring:** 4px, warning-medium color
- **Glint:** yes

### Dark
- **Background:** dark token
- **Border:** transparent
- **Text:** white; optionally use gradient text (`linear-gradient(135deg, #A855F7, #FF2A52, #FF6B35)`) via `background-clip: text` for editorial emphasis
- **Hover:** dark-strong background, subtle shadow-sm lift
- **Focus ring:** 4px, neutral-tertiary color
- **Glint:** yes

### Ghost (NO shadow, NO glint)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color
- **Hover:** neutral-secondary-medium background
- **Focus ring:** 4px, neutral-tertiary color
- **No shadow, no glint effect**

### Disabled (NO shadow, NO glint)
- **Background:** disabled token
- **Border:** border-default-medium
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no glint**

## Icons in Buttons

- Icon size: 16x16px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
