# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FDFBF9 | #0E0B08 |
| neutral-primary | #FDFBF9 | #080604 |
| neutral-primary-medium | #FDFBF9 | #1E1A16 |
| neutral-primary-strong | #F9F6F0 | #352F28 |
| neutral-secondary-soft | #F5F0EB | #0E0B08 |
| neutral-secondary | #F5F0EB | #080604 |
| neutral-secondary-medium | #F5F0EB | #1E1A16 |
| neutral-secondary-strong | #F5F0EB | #352F28 |
| neutral-tertiary-soft | #EDE7E0 | #0E0B08 |
| neutral-tertiary | #EDE7E0 | #1E1A16 |
| neutral-tertiary-medium | #EDE7E0 | #352F28 |
| neutral-quaternary | #E2DCD4 | #352F28 |
| quaternary-medium | #E2DCD4 | #423B34 |
| gray | #C8BFB3 | #423B34 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #F9F6F0 | #2B0D14 |
| brand-soft | #FDDCE3 | #4D1A2A |
| brand | #FF2A52 | #FF2A52 |
| brand-medium | #FF8DA2 | #4D1A2A |
| brand-strong | #D9224A | #FF2A52 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #ECFDF5 | #002C22 |
| success | #007A55 | #009966 |
| success-medium | #D0FAE5 | #004F3B |
| success-strong | #006045 | #007A55 |
| danger-soft | #FEF0F2 | #4D0218 |
| danger | #C70036 | #C70036 |
| danger-medium | #FFE4E6 | #8B0836 |
| danger-strong | #A50036 | #A50036 |
| warning-soft | #FFF7ED | #7C2D12 |
| warning | #F97316 | #F97316 |
| warning-medium | #FFEDD5 | #7C2D12 |
| warning-strong | #C2410C | #C2410C |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.18) | rgba(255,255,255,0.10) |
| `--color-1-700` | rgba(0,0,0,0.06) | rgba(0,0,0,0.18) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #1A1412 | #1A1412 |
| dark-strong | #0E0B08 | #352F28 |
| disabled | #EDE7E0 | #1A1412 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #A855F7 |
| sky | #0EA5E9 |
| teal | #0D9488 |
| pink | #FF2A52 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #FF6B35 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #0E0B08 | #0E0B08 |
| heading | #1A1412 | #FDFBF9 |
| body | #5C544A | #9C958C |
| body-subtle | #78706A | #9C958C |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #FF8DA2 | #4D1A2A |
| fg-brand | #FF2A52 | #FF2A52 |
| fg-brand-strong | #D9224A | #FF8DA2 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #047857 | #065F46 |
| fg-success-strong | #065F46 | #10B981 |
| fg-danger | #BE123C | #F43F5E |
| fg-danger-strong | #881337 | #F87171 |
| fg-warning-subtle | #EA580C | #F97316 |
| fg-warning | #7C2D12 | #FBBF24 |
| fg-disabled | #9C958C | #5C544A |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #312E81 | #93C5FD |
| fg-purple | #9333EA | #A855F7 |
| fg-purple-strong | #7E3AF2 | #DDD6FE |
| fg-cyan | #0891B2 | #06B6D4 |
| fg-indigo | #4F46E5 | #4F46E5 |
| fg-pink | #FF2A52 | #FF2A52 |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #1A1412 | #4D4840 |
| border-buffer | #FDFBF9 | #080604 |
| border-buffer-medium | #FDFBF9 | #1A1412 |
| border-buffer-strong | #FDFBF9 | #352F28 |
| border-muted | #E2DCD4 | #352F28 |
| border-light-subtle | #EDE7E0 | #2B1E18 |
| border-light | #DDD6CC | #423B34 |
| border-light-medium | #C8BFB3 | #352F28 |
| border-default-subtle | #EDE7E0 | #2B1E18 |
| border-default | #DDD6CC | #423B34 |
| border-default-medium | #C8BFB3 | #352F28 |
| border-default-strong | #A89F94 | #1E1A16 |
| border-success-subtle | #A7F3D0 | #064E3B |
| border-success | #047857 | #065F46 |
| border-danger-subtle | #FECDD3 | #881337 |
| border-danger | #BE123C | #BE123C |
| border-warning-subtle | #FED7AA | #7C2D12 |
| border-warning | #EA580C | #F97316 |
| border-brand-subtle | #FDDCE3 | #4D1A2A |
| border-brand-light | #FF2A52 | #FF2A52 |
| border-brand | #D9224A | #FF2A52 |
| border-dark-subtle | #1A1412 | #352F28 |
| border-purple | #A855F7 | #A855F7 |
| border-orange | #FF6B35 | #FF6B35 |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default) with soft gradient overlays (`linear-gradient(135deg, #F3E8FF 0%, #FDFBF9 40%, #FFF1F3 100%)`) for hero and feature sections
- Primary buttons: brand gradient background (`linear-gradient(135deg, #A855F7, #FF2A52, #FF6B35)`) with white text
- Headings: hero/feature headings use gradient text (`linear-gradient(135deg, #A855F7, #FF2A52, #FF6B35)`) via `background-clip: text` and `-webkit-text-fill-color: transparent`; standard headings use the heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default (subtle warm neutral)
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
