# Layout & Spacing

## Spacing Rhythm

Base unit: **4px**. All spacing values should be multiples of 4px.

| Context | Value |
|---|---|
| Section vertical padding | 80px |
| Section header → content | 40px or 56px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 40px |

## Container

Standard section container: max-width 1280px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 80px vertical padding
- Background: neutral-primary-soft (#FDFBF9) as the base — hero and feature sections layer a soft gradient overlay on top
- A centered container (max-width 1280px, 24px horizontal padding)
- A section header area with 40px bottom margin
- Section content below

### Critical: Soft Gradient Background Rule

- **Hero and feature sections** use a soft multi-stop gradient overlay: `linear-gradient(135deg, #F3E8FF 0%, #FDFBF9 40%, #FFF1F3 100%)` — lavender to warm white to blush pink
- **Standard sections** use neutral-primary-soft (#FDFBF9) as a flat warm off-white background
- **Alternating sections** may use neutral-secondary-soft (#F5F0EB) to create subtle separation
- Section dividers (when needed): a thin 1px solid border in border-default color between sections, or generous whitespace (120px+ gap) as the primary separator
- The overall page tone is light, warm, and airy — no heavy dark surfaces unless used for intentional dramatic contrast (e.g., a dark hero card or CTA block)

### Editorial Color Discipline

- **Text**: Headings use heading text color for standard content; hero/feature headings use gradient text (`linear-gradient(135deg, #A855F7, #FF2A52, #FF6B35)`) via `background-clip: text`. Body text uses body/body-subtle tokens
- **Borders**: Subtle warm neutrals (border-default, border-light) for cards, inputs, and containers. Brand border tokens (border-brand, border-brand-light) reserved for active/focus states and brand-accented elements only
- **Buttons**: Brand gradient for primary CTA (`linear-gradient(135deg, #A855F7, #FF2A52, #FF6B35)`); dark token for strong/editorial CTAs; neutral tokens for secondary/tertiary buttons
- **Cards**: Warm off-white background (neutral-primary-soft) with subtle 1px border (border-default). Minimal shadows. Clean whitespace inside
- **Links and interactive elements**: fg-brand for default state, fg-brand-strong for hover
- **Icons**: body color for neutral, fg-brand for highlighted/active
- **Dominant palette**: warm whites (#FDFBF9, #F9F6F0), soft gradients (lavender → blush), and the brand gradient for emphasis. Dark (#1A1412) used sparingly for high-contrast text and CTAs

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.
- Editorial fashion aesthetic favors elegant, smooth transitions — keep durations moderate (200–400ms) with ease-out or cubic-bezier curves for a refined, luxurious feel.

## Backgrounds & Visual Depth

- Default to a warm off-white (#FDFBF9) base across the page. Hero and feature sections layer soft gradient overlays (lavender → warm white → blush pink) to create depth without heavy colors.
- Apply subtle editorial treatments — faint gradient washes, soft vignettes, or barely-visible paper textures — all at very low opacity (3–8%) so the warm white base stays dominant.
- Section separation is achieved primarily through generous vertical spacing (80–120px) and optional thin neutral borders, not through hard background color changes.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.
- Card and container depth comes from subtle shadows (shadow-xs to shadow-sm) and thin neutral borders, not from heavy elevation or colored borders.

## Must

- All sections: consistent 80px vertical padding
- All containers: max-width 1280px, centered, 24px horizontal padding
- Section headers: 40px or 56px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
- **Hero/feature backgrounds use soft gradient overlays** — lavender (#F3E8FF) through warm white (#FDFBF9) to blush (#FFF1F3)
- **Hero/feature headings use gradient text** — `linear-gradient(135deg, #A855F7, #FF2A52, #FF6B35)` via `background-clip: text`
- **Primary CTA buttons use gradient background** — same gradient direction and stops
- **Body surfaces stay warm and light** — neutral-primary-soft or neutral-secondary-soft, never heavy dark surfaces for general content
- **Sections separated by generous whitespace** and optional thin neutral borders, not by contrasting background colors
- **Photography and imagery should be large, dramatic, and high-contrast** — editorial fashion feel with generous whitespace framing
