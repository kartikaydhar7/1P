# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 0px | Buttons, cards, inputs, modals, sections |
| default | 0px | Badges, tooltips, dropdown items, small controls |
| sm | 0px | Checkboxes, tiny elements |
| full | 0px | Pills, avatars, toggles, dot indicators |

## Rules

- 0px is the radius for every element across the product — all corners are sharp
- Never use arbitrary radius values; every element must have 0px border-radius
- No rounded corners on any component, including pills, avatars, and toggles
