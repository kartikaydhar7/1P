# Typography

> Dependencies: `colors.md`

## Core Rules

- **Font:** Charis SIL, serif — configured at app level, never override
- **Headings:** bold weight (700), heading text color; hero/feature headings use gradient text (`linear-gradient(135deg, #A855F7, #FF2A52, #FF6B35)`) via `background-clip: text` and `-webkit-text-fill-color: transparent`
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

**Every heading must use viewport-width sizing: `font-size: 12vw`.** This applies to all heading levels (`h1`–`h6`) unconditionally — headings are always oversized and viewport-responsive. On a 1440px viewport this resolves to ~173px, on 768px to ~92px, on 375px to ~45px. The headings naturally scale with the viewport — no breakpoint overrides needed.

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 12vw | 0.9 | -2px | 32px |
| `h2` | 12vw | 0.9 | -1.5px | — |
| `h3` | 12vw | 0.95 | -1px | — |
| `h4` | 12vw | 1.0 | -0.5px | — |
| `h5` | 12vw | 1.05 | — | — |
| `h6` | 12vw | 1.1 | — | — |

All heading levels share the same `12vw` font size. Differentiate hierarchy through weight, color, gradient usage, letter-spacing, and semantic HTML order — not through size differences.

Never reduce line-height below 0.9 for any heading.

## Paragraphs

### Leading Paragraph
- Size: 20px
- Weight: normal
- Color: body
- Line-height: 1.6
- Max width: ~65 characters

### Normal Paragraph
- Size: 16px
- Weight: normal
- Color: body
- Line-height: 1.6
- Max width: ~60 characters

### Small Supporting Copy
- Size: 13px
- Weight: normal
- Color: body
- Line-height: 1.5
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 14px | 600 (semibold) |
| Input labels | 13px or 14px | 500 (medium) |
| Captions / meta / badges | 11px or 12px | 500 (medium) |

Do not apply paragraph line-height (1.6) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline, hover → no underline
- **CTA links:** fg-brand color, semibold weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, 1px letter-spacing, 12px or 13px

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, and spacing remain constant.
