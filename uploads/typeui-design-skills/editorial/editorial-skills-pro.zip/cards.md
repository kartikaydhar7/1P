# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** dark token
- **Border:** 1px, border-dark-subtle color
- **Radius:** 0px (base)
- **Shadow:** none

## Card Heading

- Desktop: 20px, medium weight, white text color
- Mobile: 16px, medium weight, white text color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: dark token
- Border: 1px, border-dark-subtle
- Radius: 0px
- Shadow: none
- Text: white
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: dark-strong background
- Transition: colors
- Cursor: pointer

## Rules

- Background: dark token
- Border: 1px, border-dark-subtle
- Radius: 0px
- Shadow: none
- Text on cards: white — all card text uses white color for contrast against the dark background
- Interactive hover: dark-strong background
- Non-interactive: no hover styles
