# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFFFF | #161616 |
| neutral-primary | #FFFFFF | #161616 |
| neutral-primary-medium | #FFFFFF | #262626 |
| neutral-primary-strong | #FFFFFF | #393939 |
| neutral-secondary-soft | #FFFFFF | #262626 |
| neutral-secondary | #FFFFFF | #161616 |
| neutral-secondary-medium | #F4F4F4 | #262626 |
| neutral-secondary-strong | #F4F4F4 | #393939 |
| neutral-tertiary-soft | #E0E0E0 | #262626 |
| neutral-tertiary | #E0E0E0 | #393939 |
| neutral-tertiary-medium | #E0E0E0 | #525252 |
| neutral-quaternary | #C6C6C6 | #525252 |
| quaternary-medium | #C6C6C6 | #6F6F6F |
| gray | #A8A8A8 | #6F6F6F |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #EDF5FF | #001D6C |
| brand-soft | #D0E2FF | #002D9C |
| brand | #1062FE | #4589FF |
| brand-medium | #A6C8FF | #002D9C |
| brand-strong | #0043CE | #1062FE |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #DEFBE6 | #044317 |
| success | #198038 | #42BE65 |
| success-medium | #A7F0BA | #0E6027 |
| success-strong | #0E6027 | #198038 |
| danger-soft | #FFF1F1 | #520408 |
| danger | #DA1E28 | #FA4D56 |
| danger-medium | #FFD7D9 | #750E13 |
| danger-strong | #A2191F | #DA1E28 |
| warning-soft | #FCF4D6 | #4E3800 |
| warning | #F1C21B | #F1C21B |
| warning-medium | #FDDC69 | #4E3800 |
| warning-strong | #8E6A00 | #8E6A00 |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #0A1829 | #0A1829 |
| dark-strong | #161616 | #393939 |
| disabled | #F4F4F4 | #262626 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #8A3FFC |
| sky | #1192E8 |
| teal | #009D9A |
| pink | #D02670 |
| cyan | #0072C3 |
| fuchsia | #A56EFF |
| indigo | #4589FF |
| orange | #EB6200 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #161616 | #161616 |
| heading | #161616 | #F4F4F4 |
| body | #525252 | #C6C6C6 |
| body-subtle | #6F6F6F | #A8A8A8 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #A6C8FF | #002D9C |
| fg-brand | #1062FE | #78A9FF |
| fg-brand-strong | #0043CE | #A6C8FF |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #198038 | #0E6027 |
| fg-success-strong | #0E6027 | #42BE65 |
| fg-danger | #DA1E28 | #FA4D56 |
| fg-danger-strong | #A2191F | #FF8389 |
| fg-warning-subtle | #8E6A00 | #F1C21B |
| fg-warning | #4E3800 | #FDDC69 |
| fg-disabled | #A8A8A8 | #6F6F6F |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #F1C21B | #F1C21B |
| fg-info | #002D9C | #A6C8FF |
| fg-purple | #8A3FFC | #A56EFF |
| fg-purple-strong | #6929C4 | #D4BBFF |
| fg-cyan | #0072C3 | #1192E8 |
| fg-indigo | #4589FF | #4589FF |
| fg-pink | #D02670 | #D02670 |
| fg-lime | #5B8C00 | #8CD211 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #262626 | #6F6F6F |
| border-buffer | #FFFFFF | #161616 |
| border-buffer-medium | #FFFFFF | #262626 |
| border-buffer-strong | #FFFFFF | #393939 |
| border-muted | #F4F4F4 | #262626 |
| border-light-subtle | #E0E0E0 | #262626 |
| border-light | #E0E0E0 | #393939 |
| border-light-medium | #E0E0E0 | #525252 |
| border-default-subtle | #C6C6C6 | #262626 |
| border-default | #C6C6C6 | #393939 |
| border-default-medium | #C6C6C6 | #525252 |
| border-default-strong | #A8A8A8 | #6F6F6F |
| border-success-subtle | #A7F0BA | #044317 |
| border-success | #198038 | #0E6027 |
| border-danger-subtle | #FFD7D9 | #750E13 |
| border-danger | #DA1E28 | #DA1E28 |
| border-warning-subtle | #FDDC69 | #4E3800 |
| border-warning | #8E6A00 | #F1C21B |
| border-brand-subtle | #A6C8FF | #002D9C |
| border-brand-light | #4589FF | #4589FF |
| border-brand | #1062FE | #78A9FF |
| border-dark-subtle | #262626 | #525252 |
| border-purple | #8A3FFC | #8A3FFC |
| border-orange | #EB6200 | #EB6200 |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft — all sections use white in light mode
- Cards: dark token background with white text — use for article and content cards
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
