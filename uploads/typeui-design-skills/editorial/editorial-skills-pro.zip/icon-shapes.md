# Icon Shapes

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- Box sizing: border-box
- Icon must be perfectly centered (inline-flex, centered both axes)
- Square: 0px radius
- Rounded square: 0px radius (MD/LG/XL), 0px radius (XS/SM)

## Sizes

| Size | Container | Icon |
|---|---|---|
| XS | 24x24px | 14x14px |
| SM | 32x32px | 16x16px |
| MD | 40x40px | 20x20px |
| LG | 48x48px | 24x24px |
| XL | 56x56px | 28x28px |

## Color Variants

### Brand
- Shape: square
- Background: brand-softer
- Icon color: fg-brand-strong

### Gray
- Shape: square
- Background: neutral-secondary-soft
- Icon color: body

### Danger
- Shape: square
- Background: danger-soft
- Icon color: fg-danger-strong

### Success
- Shape: square
- Background: success-soft
- Icon color: fg-success-strong

### Warning
- Shape: square
- Background: warning-soft
- Icon color: fg-warning
