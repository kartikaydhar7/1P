# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `0 1px 2px rgb(0 0 0 / 0.02)` |
| shadow-xs | `0 1px 2px rgb(0 0 0 / 0.04)` |
| shadow-sm | `0 2px 4px rgb(0 0 0 / 0.06)` |
| shadow-md | `0 4px 8px rgb(0 0 0 / 0.08)` |
| shadow-lg | `0 8px 16px rgb(0 0 0 / 0.1)` |
| shadow-xl | `0 12px 24px rgb(0 0 0 / 0.12)` |
| shadow-2xl | `0 16px 32px rgb(0 0 0 / 0.16)` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls | none — use borders for separation |
| Standard cards, popovers, dropdowns | shadow-sm or shadow-md |
| Prominent cards, sticky surfaces | shadow-md |
| Modals, high-priority overlays | shadow-lg |
| Hero overlays, top-level emphasis (sparingly) | shadow-xl |

## Rules

- Use only these tokens — no custom box-shadow values
- Prefer borders over shadows for component separation — shadows are used sparingly
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
