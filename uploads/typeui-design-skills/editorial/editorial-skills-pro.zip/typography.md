# Typography

> Dependencies: `colors.md`

## Core Rules

- **Font:** 'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif — configured at app level, never override
- **Headings:** weight varies by level (see scale below), heading text color
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

### Desktop

| Element | Size | Weight | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|---|
| `h1` | 54px | 300 (light) | 1.07 | -0.64px | 24px |
| `h2` | 42px | 300 (light) | 1.1 | — | — |
| `h3` | 32px | 400 (regular) | 1.25 | — | — |
| `h4` | 28px | 400 (regular) | 1.29 | — | — |
| `h5` | 20px | 600 (semibold) | 1.4 | — | — |
| `h6` | 16px | 600 (semibold) | 1.5 | — | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 36px | 32px |
| `h2` | 32px | 28px |
| `h3` | 28px | 24px |
| `h4` | 24px | 20px |
| `h5` | 20px | 18px |
| `h6` | 16px | 16px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.05 for any heading.

## Paragraphs

### Leading Paragraph
- Size: 20px
- Weight: normal
- Color: body
- Line-height: 1.5
- Max width: ~75 characters

### Normal Paragraph
- Size: 16px
- Weight: normal
- Color: body
- Line-height: 1.5
- Max width: ~75 characters

### Small Supporting Copy
- Size: 14px
- Weight: normal
- Color: body
- Line-height: 1.43
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 14px | 400 (regular) |
| Input labels | 14px or 16px | 400 (regular) |
| Captions / meta / badges | 12px or 14px | 400 (regular) |

Do not apply paragraph line-height (1.5) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline, hover → no underline
- **CTA links:** fg-brand color, medium weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, 0.5px letter-spacing, 12px or 14px

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, and spacing remain constant.
