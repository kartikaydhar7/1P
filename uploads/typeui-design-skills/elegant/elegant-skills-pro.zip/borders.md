# Borders

## Width Scale

| Context | Width |
|---|---|
| Default (inputs, buttons, cards) | 1px |
| Emphasis / focus | 2px |

## Rules

- Use solid borders by default
- Dashed borders only for special cases like file dropzones
- Components in the same family must use matching border widths
- Never mix 1px and 2px borders within a single component
- Borders use pure gray tones (no blue-tinted grays) to match the neutral palette
- Borders are a primary design element — they define section boundaries, bento cells, and card edges

## Usage

| Context | Width |
|---|---|
| Inputs / selects / textareas | 1px default; 2px on focus or error |
| Buttons | 1px for variants that require outlining |
| Cards / containers | 1px subtle; avoid stacked heavy borders |
| Sections (top & bottom) | 1px border-default — every section gets top and bottom borders |
| Sections (left & right) | 1px border-default on inner containers to form bento-grid cells |
| Bento grid cells | 1px border-default on all four sides |

## Section Border Pattern

- Every page section has a 1px solid border-default on its top and bottom edges
- Inner content blocks, cards, and grid cells within sections also get 1px borders to form a visible bento-grid structure
- Adjacent borders naturally collapse; use negative margins (-1px) where needed to prevent double borders
- The overall effect is an editorial, structured grid where every content block is clearly delineated
