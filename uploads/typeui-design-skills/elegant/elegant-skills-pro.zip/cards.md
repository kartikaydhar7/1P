# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-primary-soft (white) or neutral-secondary-soft (#F8F8F8) depending on section context
- **Border:** 1px, border-default color on all four sides — borders are a key visual element in the bento-card aesthetic
- **Radius:** 0px — all cards use sharp corners
- **Shadow:** shadow-2xs (minimal — borders carry the visual weight, not shadows)
- **Padding:** 48px on desktop, 24px on mobile and tablet
- **Pattern overlay:** optionally add subtle dot/grid background patterns inside cards on white sections for editorial texture

## Card Heading

- Desktop: 20px, medium weight, heading color
- Mobile: 16px, medium weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-primary-soft
- Border: 1px, border-default on all four sides
- Radius: 0px
- Shadow: shadow-2xs
- Padding: 48px desktop, 24px mobile/tablet
- No hover styles. Non-interactive cards must NOT have hover background changes.
- Optionally include subtle dot/grid pattern as background for editorial texture

### Interactive Card (clickable)
- Same base styles as static card
- Hover: neutral-secondary-medium background
- Transition: colors
- Cursor: pointer

## Rules

- Background: neutral-primary-soft
- Border: 1px, border-default on all four sides — cards function as bento cells
- Radius: 0px
- Shadow: shadow-2xs (borders carry visual weight)
- Padding: 48px desktop, 24px mobile/tablet
- Interactive hover: neutral-secondary-medium background
- Non-interactive: no hover styles
- Cards in a grid should share borders where possible (use negative margins to collapse adjacent borders)
- Subtle dot/grid patterns are encouraged inside cards on white sections for added texture
