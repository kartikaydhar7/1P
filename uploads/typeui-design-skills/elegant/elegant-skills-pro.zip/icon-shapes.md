# Icon Shapes

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- Box sizing: border-box
- Icon must be perfectly centered (inline-flex, centered both axes)
- Circle: fully rounded (9999px)
- Square: 0px radius (all sizes) — default shape for the bordered-editorial aesthetic
- All icon containers use 1px border-default border by default for the bento/editorial style

## Sizes

| Size | Container | Icon |
|---|---|---|
| XS | 24x24px | 14x14px |
| SM | 32x32px | 16x16px |
| MD | 40x40px | 20x20px |
| LG | 48x48px | 24x24px |
| XL | 56x56px | 28x28px |

## Color Variants

### Brand
- Shape: square (0px radius)
- Background: brand-softer
- Border: 1px, border-brand-subtle
- Icon color: fg-brand-strong

### Gray
- Shape: square (0px radius)
- Background: neutral-primary-soft
- Border: 1px, border-default
- Icon color: body

### Danger
- Shape: square (0px radius)
- Background: danger-soft
- Border: 1px, border-danger-subtle
- Icon color: fg-danger-strong

### Success
- Shape: square (0px radius)
- Background: success-soft
- Border: 1px, border-success-subtle
- Icon color: fg-success-strong

### Warning
- Shape: square (0px radius)
- Background: warning-soft
- Border: 1px, border-warning-subtle
- Icon color: fg-warning
