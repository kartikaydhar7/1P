# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1152px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 96px vertical padding
- A background color following the alternation pattern (see below)
- Visible 1px borders: top and bottom (border-default), and optionally left/right borders on inner containers to create a bento-grid structure
- A centered container (max-width 1152px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below

### Section Background Alternation

Sections use predominantly light backgrounds with borders for separation instead of heavy color blocking:

1. **White:** neutral-primary-soft (#FFFFFF) — primary section background for hero, content, features. Use subtle dot/grid patterns as decorative overlays.
2. **Gray:** neutral-secondary-soft (#F8F8F8) — alternating sections for feature grids, testimonials, footer.
3. **Dark:** dark (#0A0A0A) — used sparingly for code showcase, CTA emphasis, or feature highlight sections. Text uses white color.

Reference pattern: white with pattern (hero) → white with bordered cards (services) → gray (feature) → white → dark (code/showcase) → gray (footer). Always use 1px border-default borders between sections.

### Section Borders

- Every section has a 1px border-default border on top and bottom to visually separate it from adjacent sections
- Inner content containers can have left/right borders to form bento-grid cells
- Cards and content blocks within sections also use visible borders on all sides
- This creates a structured, editorial grid where borders are a primary design element

### Soft Background Patterns

Add subtle CSS background patterns to white sections for visual texture and modern feel:
- **Dot grid:** small dots (1px) at regular intervals (~24px) using border-default or lighter color at low opacity
- **Fine grid lines:** thin 1px lines forming a grid at ~48px intervals using border-light color at low opacity
- **Crosshatch:** diagonal fine lines at very low opacity for special sections
- Patterns should be barely visible — they add texture without competing with content
- Apply patterns to hero sections, feature sections, or any white section that benefits from added depth
- Never use patterns on dark sections or gray sections (the gray itself provides enough differentiation)

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Backgrounds & Visual Depth

- Default to clean, flat backgrounds with visible borders separating sections and content blocks.
- Use subtle dot/grid CSS patterns on white sections for modern visual texture — keep them minimal and low-opacity so they enhance without competing with content.
- Avoid heavy gradients, noise overlays, or saturated decorative effects.
- Borders are the primary visual separator — not color contrast alone. Every section and content block should feel like a cell in a structured grid.
- Every element must serve a compositional purpose (depth, separation, or emphasis). Patterns add editorial sophistication, not decoration.

## Must

- All sections: consistent 96px vertical padding, 1px border-default borders on top and bottom
- All containers: max-width 1152px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Section backgrounds: predominantly white (#FFFFFF) and gray (#F8F8F8), with dark (#0A0A0A) used sparingly for code/showcase sections — borders handle visual separation
- White sections: add subtle dot/grid patterns for editorial texture where appropriate
- On dark sections: all text, headings, and icons use white; buttons use inverted (white bg, dark text) or brand-accent styles
- Cards, content blocks, and bento cells: visible 1px borders on all sides — borders are a core design element
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
