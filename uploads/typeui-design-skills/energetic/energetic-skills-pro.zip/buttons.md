# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `sections.md`

## Core Specs

- **Radius:** 24px (default) or 9999px for pills
- **Border:** none
- **Shadow:** shadow-xs
- **Glint effect:** combined box-shadow with a solid bottom ledge and a soft inset top highlight for a 3D "pressable" feel:
  - `0 4px 0 0 var(--color-1-700), inset 0 2px 4px 0 var(--color-1-400)`
- **Font size:** 20px
- **Font weight:** 500 (medium)
- **Font:** Gabarito
- **Padding:** 16px vertical, 24px horizontal
- **Background:** white
- **Text color:** inherits the current section background color (brand color)
- **Box sizing:** border-box
- **Transition:** transform 150ms, box-shadow 150ms

## Single Variant

There is only **one** button style in this design system. Every button uses the same appearance:

- **Background:** white
- **Text:** section background color (the brand color applied to the parent section)
- **Hover:** slight scale-up (1.03), shadow lifts to `0 6px 0 0 var(--color-1-700), inset 0 2px 4px 0 var(--color-1-400)`
- **Active / Pressed:** translate down 2px, shadow shrinks to `0 2px 0 0 var(--color-1-700), inset 0 1px 2px 0 var(--color-1-400)` for a physical "click" feel
- **Focus ring:** 4px, white at 40% opacity
- **Glint:** yes

### Disabled
- **Background:** white at 50% opacity
- **Text:** section background color at 40% opacity
- **Cursor:** not-allowed
- **No hover, no active, no focus, no glint**

## Icons in Buttons

- Icon size: 20x20px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
- Icon color: same as text color (section background color)
