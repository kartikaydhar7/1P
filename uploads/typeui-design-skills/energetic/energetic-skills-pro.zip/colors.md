# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFFFF | #0F1024 |
| neutral-primary | #FFFFFF | #08091A |
| neutral-primary-medium | #FFFFFF | #181A33 |
| neutral-primary-strong | #FFFFFF | #262845 |
| neutral-secondary-soft | #FAFAFF | #0F1024 |
| neutral-secondary | #FAFAFF | #08091A |
| neutral-secondary-medium | #FAFAFF | #181A33 |
| neutral-secondary-strong | #FAFAFF | #262845 |
| neutral-tertiary-soft | #F2F0FA | #0F1024 |
| neutral-tertiary | #F2F0FA | #181A33 |
| neutral-tertiary-medium | #F2F0FA | #262845 |
| neutral-quaternary | #E5E1F5 | #262845 |
| quaternary-medium | #E5E1F5 | #353859 |
| gray | #D0CCE3 | #353859 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #F0EBFF | #1A0D4D |
| brand-soft | #DDD4FF | #2D1A80 |
| brand | #6733FF | #7C4DFF |
| brand-medium | #C4B0FF | #2D1A80 |
| brand-strong | #5229CC | #6733FF |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #E6FFF5 | #002E22 |
| success | #00CC88 | #00CC88 |
| success-medium | #B8FFE0 | #004F3B |
| success-strong | #00A86B | #00A86B |
| danger-soft | #FFF0F0 | #4D0A0A |
| danger | #EC4747 | #EC4747 |
| danger-medium | #FFDADA | #6B1A1A |
| danger-strong | #D43030 | #D43030 |
| warning-soft | #FFF5EB | #7C2D12 |
| warning | #FF8C42 | #FF8C42 |
| warning-medium | #FFE0C4 | #7C2D12 |
| warning-strong | #E86B14 | #E86B14 |

### Button Glint (CSS custom properties, used for the 3D pressed-button effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.55) | rgba(255,255,255,0.25) |
| `--color-1-700` | rgba(103,51,255,0.28) | rgba(0,0,0,0.40) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #1A1A3E | #1A1A3E |
| dark-strong | #0F0F2E | #2A2A55 |
| disabled | #F2F0FA | #181A33 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #6733FF |
| sky | #00AAFF |
| teal | #00CC88 |
| pink | #FF3B8B |
| cyan | #00D4E0 |
| fuchsia | #D946EF |
| indigo | #5B4DFF |
| orange | #FF8C42 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #0F0F2E | #0F0F2E |
| heading | #0F0F2E | #FFFFFF |
| body | #4A4566 | #A8A3C0 |
| body-subtle | #6B6580 | #A8A3C0 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #C4B0FF | #2D1A80 |
| fg-brand | #6733FF | #A78BFF |
| fg-brand-strong | #5229CC | #C4B0FF |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #00A86B | #004F3B |
| fg-success-strong | #004F3B | #00CC88 |
| fg-danger | #EC4747 | #FF6B6B |
| fg-danger-strong | #D43030 | #FF8F8F |
| fg-warning-subtle | #FF8C42 | #FF8C42 |
| fg-warning | #CC5500 | #FFD166 |
| fg-disabled | #A8A3C0 | #5A5575 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FFD166 | #FFD166 |
| fg-info | #2D1A80 | #A78BFF |
| fg-purple | #6733FF | #A78BFF |
| fg-purple-strong | #5229CC | #DDD4FF |
| fg-cyan | #00B8C9 | #00D4E0 |
| fg-indigo | #5B4DFF | #5B4DFF |
| fg-pink | #FF3B8B | #FF3B8B |
| fg-lime | #6BBF00 | #A0E833 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #1A1A3E | #3D3866 |
| border-buffer | #FFFFFF | #08091A |
| border-buffer-medium | #FFFFFF | #181A33 |
| border-buffer-strong | #FFFFFF | #262845 |
| border-muted | #FAFAFF | #0F1024 |
| border-light-subtle | #F2F0FA | #0F1024 |
| border-light | #F2F0FA | #181A33 |
| border-light-medium | #F2F0FA | #262845 |
| border-default-subtle | #E5E1F5 | #0F1024 |
| border-default | #E5E1F5 | #181A33 |
| border-default-medium | #E5E1F5 | #262845 |
| border-default-strong | #E5E1F5 | #353859 |
| border-success-subtle | #80FFCC | #004F3B |
| border-success | #00A86B | #004F3B |
| border-danger-subtle | #FFB8B8 | #6B1A1A |
| border-danger | #EC4747 | #EC4747 |
| border-warning-subtle | #FFD4A8 | #7C2D12 |
| border-warning | #FF8C42 | #FF8C42 |
| border-brand-subtle | #C4B0FF | #2D1A80 |
| border-brand-light | #7C4DFF | #7C4DFF |
| border-brand | #6733FF | #A78BFF |
| border-dark-subtle | #1A1A3E | #2A2A55 |
| border-purple | #6733FF | #6733FF |
| border-orange | #FF8C42 | #FF8C42 |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
