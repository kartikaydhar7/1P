# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 36px | Cards, modals, tables, sections, large surfaces |
| default | 24px | Buttons, inputs, alerts, tabs, badges, medium controls |
| sm | 6px | Checkboxes, tiny elements |
| full | 9999px | Pills, avatars, toggles, dot indicators |

## Rules

- 36px is the default radius for large surface components (cards, modals, tables)
- 24px is the default radius for interactive controls (buttons, inputs, dropdowns)
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
