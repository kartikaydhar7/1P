# Sections

> Dependencies: `colors.md`, `layout.md`

## Background Rule

All sections across the landing page use a single, consistent **brand** background color. Every section shares the same background — there is no alternating between different colors.

One color. One identity. The entire page feels cohesive and branded.

## Section Appearance

- **Background:** brand token (same for every section)
- **Text — headings:** white
- **Text — body:** white at 85% opacity for readable hierarchy
- **Text — subtle/meta:** white at 65% opacity
- **Links:** white, underlined, hover → no underline
- **Borders inside sections:** white at 15% opacity
- **Icons:** white

## Buttons in Sections

Buttons follow `buttons.md` — white background with text color matching the section background (brand color). This creates high-contrast, punchy CTAs that pop against the colored background.

## Rules

- Every section: brand background, no exceptions on landing pages
- Never alternate neutral-primary-soft / neutral-secondary-soft for landing page sections — that pattern is only for internal/dashboard layouts
- Section vertical padding and container rules from `layout.md` still apply
- All text within sections must use white or white-with-opacity — never use the standard heading/body tokens which are designed for neutral backgrounds
- Cards within brand-colored sections should use white (neutral-primary-soft) backgrounds to create contrast and content separation
