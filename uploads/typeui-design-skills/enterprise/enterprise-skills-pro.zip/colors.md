# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #EDEADE | #101828 |
| neutral-primary | #EDEADE | #030712 |
| neutral-primary-medium | #EDEADE | #1E2939 |
| neutral-primary-strong | #EDEADE | #333E4F |
| neutral-secondary-soft | #F5F3EA | #101828 |
| neutral-secondary | #F5F3EA | #030712 |
| neutral-secondary-medium | #E3E0D3 | #1E2939 |
| neutral-secondary-strong | #D8D5C7 | #333E4F |
| neutral-tertiary-soft | #E3E0D3 | #101828 |
| neutral-tertiary | #DDDAC8 | #1E2939 |
| neutral-tertiary-medium | #D2CFBF | #333E4F |
| neutral-quaternary | #C7C4B4 | #333E4F |
| quaternary-medium | #BCBAA8 | #4A5565 |
| gray | #A6A494 | #4A5565 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #E7EDED | #0A2020 |
| brand-soft | #C4D4D4 | #0E3333 |
| brand | #072C2C | #0D4A4A |
| brand-medium | #97B5B5 | #0E3333 |
| brand-strong | #051E1E | #072C2C |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #ECFDF5 | #002C22 |
| success | #007A55 | #009966 |
| success-medium | #D0FAE5 | #004F3B |
| success-strong | #006045 | #007A55 |
| danger-soft | #FEF0F2 | #4D0218 |
| danger | #C70036 | #C70036 |
| danger-medium | #FFE4E6 | #8B0836 |
| danger-strong | #A50036 | #A50036 |
| warning-soft | #FFF7ED | #7C2D12 |
| warning | #e05809 | #e05809 |
| warning-medium | #FFEDD5 | #7C2D12 |
| warning-strong | #B84A07 | #B84A07 |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(0,0,0,0) | rgba(0,0,0,0) |
| `--color-1-700` | rgba(0,0,0,0) | rgba(0,0,0,0) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #1F2937 | #1F2937 |
| dark-strong | #111827 | #374151 |
| disabled | #E3E0D3 | #1F2937 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #A855F7 |
| sky | #0EA5E9 |
| teal | #0D9488 |
| pink | #DB2777 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #e05809 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #111827 | #111827 |
| heading | #111827 | #FFFFFF |
| body | #4B5563 | #9CA3AF |
| body-subtle | #6B7280 | #9CA3AF |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #97B5B5 | #0E3333 |
| fg-brand | #072C2C | #2FA8A8 |
| fg-brand-strong | #051E1E | #97B5B5 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #047857 | #065F46 |
| fg-success-strong | #065F46 | #10B981 |
| fg-danger | #BE123C | #F43F5E |
| fg-danger-strong | #881337 | #F87171 |
| fg-warning-subtle | #e05809 | #e05809 |
| fg-warning | #7C2D12 | #FBBF24 |
| fg-disabled | #9CA3AF | #6B7280 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #312E81 | #93C5FD |
| fg-purple | #9333EA | #A855F7 |
| fg-purple-strong | #7E3AF2 | #DDD6FE |
| fg-cyan | #0891B2 | #06B6D4 |
| fg-indigo | #4F46E5 | #4F46E5 |
| fg-pink | #DB2777 | #DB2777 |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #1F2937 | #4B5563 |
| border-buffer | #EDEADE | #030712 |
| border-buffer-medium | #EDEADE | #1F2937 |
| border-buffer-strong | #EDEADE | #374151 |
| border-muted | #F5F3EA | #111827 |
| border-light-subtle | #E6E3D6 | #111827 |
| border-light | #E6E3D6 | #1F2937 |
| border-light-medium | #D9D6C6 | #374151 |
| border-default-subtle | #D2CFBF | #111827 |
| border-default | #CECBB8 | #1F2937 |
| border-default-medium | #C3C0AD | #374151 |
| border-default-strong | #B5B29E | #4B5563 |
| border-success-subtle | #A7F3D0 | #064E3B |
| border-success | #047857 | #065F46 |
| border-danger-subtle | #FECDD3 | #881337 |
| border-danger | #BE123C | #BE123C |
| border-warning-subtle | #FED7AA | #7C2D12 |
| border-warning | #e05809 | #e05809 |
| border-brand-subtle | #97B5B5 | #0E3333 |
| border-brand-light | #0A3D3D | #0A3D3D |
| border-brand | #072C2C | #2FA8A8 |
| border-dark-subtle | #1F2937 | #374151 |
| border-purple | #A855F7 | #A855F7 |
| border-orange | #e05809 | #e05809 |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
