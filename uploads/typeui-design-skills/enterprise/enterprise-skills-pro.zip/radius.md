# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 2px | Buttons, cards, inputs, modals, sections, badges, tooltips, dropdown items, small controls |
| default | 2px | (Alias for base) |
| sm | 2px | Checkboxes, tiny elements |
| full | 9999px | Avatars, dot indicators, toggles ONLY (never buttons or cards) |

## Rules

- **STRICTLY 2px** is the default radius across the entire product for all structural and interactive elements (cards, buttons, inputs, modals, badges, etc.).
- Never use arbitrary radius values outside this scale.
- Do not use `rounded-full` or `rounded-md` for buttons, cards, or inputs. Always use `rounded-[2px]`.
- Radius must be consistent within each component family.
