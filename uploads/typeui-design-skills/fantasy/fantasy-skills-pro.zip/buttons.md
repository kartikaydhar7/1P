# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except ghost and disabled)

- **Radius:** 2px (base) or 9999px for pills
- **Border:** 2px solid
- **Shadow:** shadow-xs
- **Glint effect:** Every button except ghost and disabled gets a combined box-shadow that layers the base shadow with an inset top-edge highlight and a subtle outer color glow:
  - `var(--shadow-xs), inset var(--color-1-400) 0 1px 0px 0px, var(--color-1-700) 0 4px 10px -5px`
- **Font weight:** 700 (bold)
- **Font:** "New Rocker", serif for primary/brand buttons; Inter for utility buttons
- **Text transform:** uppercase
- **Letter spacing:** 0.1em
- **Box sizing:** border-box
- **Transition:** color, filter, transform, box-shadow, border-color transitions on hover

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 12px | 6px |
| Small | 14px | 12px | 8px |
| Base (default) | 14px | 16px | 10px |
| Large | 16px | 20px | 12px |
| Extra large | 16px | 24px | 14px |

## Variants

### Brand
- **Background:** linear-gradient(brand-light top to brand-dark bottom)
- **Border:** fg-brand (blue light)
- **Text:** heading color (gold)
- **Text shadow:** 0 1px 3px rgba(0,0,0,0.9)
- **Hover:** brightness(1.2), border lightens, subtle blue glow
- **Active:** brightness(0.85), scale(0.98)
- **Focus ring:** 3px, brand-medium color
- **Glint:** yes

### Secondary
- **Background:** linear-gradient(neutral-primary-medium top to neutral-primary bottom)
- **Border:** border-default-medium
- **Text:** body color
- **Hover:** brightness(1.15), heading text color, border lightens
- **Focus ring:** 3px, neutral-tertiary color
- **Glint:** yes

### Tertiary
- **Background:** neutral-primary-soft
- **Border:** border-default
- **Text:** body color
- **Hover:** neutral-secondary-medium background, heading text color
- **Focus ring:** 3px, neutral-tertiary-soft color
- **Glint:** yes

### Success
- **Background:** success token
- **Border:** transparent
- **Text:** white
- **Hover:** success-strong background
- **Focus ring:** 3px, success-medium color
- **Glint:** yes

### Danger
- **Background:** danger token
- **Border:** transparent
- **Text:** white
- **Hover:** danger-strong background
- **Focus ring:** 3px, danger-medium color
- **Glint:** yes

### Warning
- **Background:** warning token
- **Border:** transparent
- **Text:** white
- **Hover:** warning-strong background
- **Focus ring:** 3px, warning-medium color
- **Glint:** yes

### Dark
- **Background:** dark token
- **Border:** transparent
- **Text:** white
- **Hover:** dark-strong background
- **Focus ring:** 3px, neutral-tertiary color
- **Glint:** yes

### Ghost (NO shadow, NO glint)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color
- **Hover:** neutral-secondary-medium background
- **Focus ring:** 3px, neutral-tertiary color
- **No shadow, no glint effect**

### Disabled (NO shadow, NO glint)
- **Background:** disabled token
- **Border:** border-default-medium
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no glint**

## Icons in Buttons

- Icon size: 16x16px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
