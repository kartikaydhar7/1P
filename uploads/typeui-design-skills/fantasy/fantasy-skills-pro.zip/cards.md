# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** linear-gradient(neutral-primary-medium top to neutral-primary bottom)
- **Border:** 2px, brand at 25% opacity
- **Radius:** 2px (base)
- **Shadow:** shadow-md
- **Inner border:** 1px inset border at brand 15% opacity, offset 3px from edges

## Card Heading

- Desktop: 20px, normal weight, heading color (gold), heading font ("New Rocker")
- Mobile: 16px, normal weight, heading color (gold), heading font ("New Rocker")
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: linear-gradient(neutral-primary-medium top to neutral-primary bottom)
- Border: 2px, brand at 25% opacity
- Radius: 2px
- Shadow: shadow-md
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: border-color increases to brand at 50% opacity, blue glow shadow appears
- Transition: box-shadow, border-color
- Cursor: pointer

## Rules

- Background: dark gradient, not flat color
- Border: 2px, brand-tinted at low opacity
- Radius: 2px
- Shadow: shadow-md
- Interactive hover: border brightens + blue glow shadow
- Non-interactive: no hover styles
