# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #0e1520 | #080c14 |
| neutral-primary | #0a0e18 | #060a10 |
| neutral-primary-medium | #141e30 | #0e1520 |
| neutral-primary-strong | #1e3050 | #1a2540 |
| neutral-secondary-soft | #0e1520 | #080c14 |
| neutral-secondary | #0a0e18 | #060a10 |
| neutral-secondary-medium | #141e30 | #0e1a2e |
| neutral-secondary-strong | #1e3060 | #1a3060 |
| neutral-tertiary-soft | #101828 | #0a1220 |
| neutral-tertiary | #141e30 | #0e1a2e |
| neutral-tertiary-medium | #1a2a48 | #162040 |
| neutral-quaternary | #1e3060 | #1a3060 |
| quaternary-medium | #2e4870 | #2a4060 |
| gray | #2e4870 | #2a4060 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #091428 | #091428 |
| brand-soft | #0C1E3E | #0C1E3E |
| brand | #024FCB | #024FCB |
| brand-medium | #0C1E3E | #0C1E3E |
| brand-strong | #023FA2 | #023FA2 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #071F1A | #071F1A |
| success | #00CC88 | #00CC88 |
| success-medium | #0A3028 | #0A3028 |
| success-strong | #009966 | #009966 |
| danger-soft | #2A0A14 | #2A0A14 |
| danger | #E03050 | #E03050 |
| danger-medium | #3A1020 | #3A1020 |
| danger-strong | #C02040 | #C02040 |
| warning-soft | #2A1A08 | #2A1A08 |
| warning | #F0A030 | #F0A030 |
| warning-medium | #3A2410 | #3A2410 |
| warning-strong | #D08020 | #D08020 |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(184,216,248,0.15) | rgba(184,216,248,0.10) |
| `--color-1-700` | rgba(0,0,0,0.30) | rgba(0,0,0,0.50) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #060a10 | #060a10 |
| dark-strong | #030610 | #0a0e18 |
| disabled | #0e1520 | #0a1220 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #A855F7 |
| sky | #0EA5E9 |
| teal | #0D9488 |
| pink | #DB2777 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #FB923C |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #060a10 | #060a10 |
| heading | #F8B700 | #F8B700 |
| body | #94A3B8 | #94A3B8 |
| body-subtle | #64748B | #64748B |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #0C1E3E | #0C1E3E |
| fg-brand | #3A88E8 | #3A88E8 |
| fg-brand-strong | #B8D8F8 | #B8D8F8 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #00CC88 | #00CC88 |
| fg-success-strong | #10B981 | #10B981 |
| fg-danger | #F43F5E | #F43F5E |
| fg-danger-strong | #F87171 | #F87171 |
| fg-warning-subtle | #F0A030 | #F0A030 |
| fg-warning | #FBBF24 | #FBBF24 |
| fg-disabled | #2a4060 | #2a4060 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #F8B700 | #F8B700 |
| fg-info | #93C5FD | #93C5FD |
| fg-purple | #A855F7 | #A855F7 |
| fg-purple-strong | #DDD6FE | #DDD6FE |
| fg-cyan | #06B6D4 | #06B6D4 |
| fg-indigo | #4F46E5 | #4F46E5 |
| fg-pink | #DB2777 | #DB2777 |
| fg-lime | #84CC16 | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #1a3060 | #1a3060 |
| border-buffer | #060a10 | #060a10 |
| border-buffer-medium | #0a0e18 | #0a0e18 |
| border-buffer-strong | #0e1520 | #0e1520 |
| border-muted | #080c14 | #080c14 |
| border-light-subtle | #0a1220 | #0a1220 |
| border-light | #0e1520 | #0e1520 |
| border-light-medium | #162040 | #162040 |
| border-default-subtle | #0a1220 | #0a1220 |
| border-default | #0e1a2e | #0e1a2e |
| border-default-medium | #1a3060 | #1a3060 |
| border-default-strong | #2a4060 | #2a4060 |
| border-success-subtle | #0A3028 | #0A3028 |
| border-success | #009966 | #009966 |
| border-danger-subtle | #3A1020 | #3A1020 |
| border-danger | #E03050 | #E03050 |
| border-warning-subtle | #3A2410 | #3A2410 |
| border-warning | #F0A030 | #F0A030 |
| border-brand-subtle | #0C1E3E | #0C1E3E |
| border-brand-light | #024FCB | #024FCB |
| border-brand | #3A88E8 | #3A88E8 |
| border-dark-subtle | #0e1520 | #0e1520 |
| border-purple | #A855F7 | #A855F7 |
| border-orange | #FB923C | #FB923C |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft for ALL sections — do not alternate, every section uses the same background
- Page body: apply a single full-page gradient (linear-gradient 180deg from #060a10 at top through #080c14 in the middle to #060a10 at bottom)
- Primary buttons: brand background with gradient treatment
- Headings: heading text color (gold #F8B700)
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
- No alternating background colors between sections — all sections must share the same background
