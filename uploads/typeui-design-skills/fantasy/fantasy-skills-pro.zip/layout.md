# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1152px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 96px vertical padding
- The SAME background color (neutral-primary-soft) — never alternate between sections
- A centered container (max-width 1152px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below

## Page Background

Apply a single full-page gradient to the body or root container:
- `linear-gradient(180deg, #060a10 0%, #080c14 50%, #060a10 100%)`
- This gradient spans the entire page height, not per-section
- Individual sections do NOT have their own gradient — they inherit from the page
- All sections share the same transparent/neutral-primary-soft background on top of this gradient

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Backgrounds & Visual Depth

- Default to layered, atmospheric backgrounds rather than flat solid fills.
- **Section Image Backgrounds:** Every section that uses a background image MUST have `mix-blend-mode: overlay` and `opacity: 0.4` applied to the image element.
- Apply contextual treatments — noise textures, subtle grid patterns, radial glow effects, blue-tinted vignettes, inset shadows, decorative borders — that align with the dark fantasy aesthetic.
- Decorative elements like runic symbols, faint grid lines, or radial glows at low opacity can enhance atmosphere without competing with content.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.

## Must

- All sections: consistent 96px vertical padding
- All sections: SAME background color — no alternating backgrounds
- All containers: max-width 1152px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
