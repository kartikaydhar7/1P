# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 2px | Buttons, cards, inputs, modals, sections |
| default | 2px | Badges, tooltips, dropdown items, small controls |
| sm | 2px | Checkboxes, tiny elements |
| full | 9999px | Pills, avatars, toggles, dot indicators |

## Rules

- 2px is the default radius across the product — angular, sharp edges matching the dark fantasy aesthetic
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
