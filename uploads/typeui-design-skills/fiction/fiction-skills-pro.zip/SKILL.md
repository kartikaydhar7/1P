# Design System — Agent Instructions

This skill describes the visual design language for all UI output. Every component, layout, and page should follow the design specs in the module files below. These describe *what the design looks like* — you choose how to implement the styles.

## Style
A playful, energetic, cartoonesque interface inspired by friendly children's-book illustrations — warm cream backgrounds, big bold custom display typography, saturated brand color blocks, thick black outlines, generously rounded shapes, flat surfaces with almost no shadows, and decorative hand-drawn-feeling illustrations in every section.


## Before Writing Any Code

1. **Read every module that applies.** For a landing page, read at minimum: `layout.md`, `typography.md`, `colors.md`, `buttons.md`, `cards.md`, `shadows.md`, `radius.md`, `borders.md`. Do NOT write JSX until you have loaded all relevant modules.

## Critical Rules

- **Tokens are AGNOSTIC design system tokens:** The tokens defined in the `.md` files (like `neutral-primary-soft`, `heading`, `border-default`) are stack-agnostic semantic names. They are NOT literal class names from any framework. Map them yourself in your CSS / theme configuration.

- **Cross-reference modules.** A card containing buttons must satisfy both `cards.md` AND `buttons.md`.
- **Dark mode is automatic.** The custom properties resolve differently in light/dark via `prefers-color-scheme`. Never manually swap colors.
- **Every interactive element needs hover, focus, and disabled states** — defined in the relevant module.
- **Use semantic HTML:** proper heading hierarchy (`h1`→`h6`), `<button>` for actions, `<a>` for navigation, ARIA attributes where needed.

## Global Design Rules (apply to every page)

- **Headings are oversized.** Display headings start at 96px and go up. Each heading is hard-capped at **maximum 2 rows** — wrap to a new line / shrink wording if it would overflow. Always reserve generous empty space above and below headings.
- **Paragraphs are short and breathable.** Limit body paragraphs to **maximum 4 rows**. Always reserve generous empty space around paragraphs (top, bottom, sides).
- **Sections alternate colors playfully.** Page sections rotate through five backgrounds in this order: brand → secondary-brand → tertiary-brand → quaternary-brand → quinary-brand → (loop). Adjacent sections must never share the same background.
- **Cards on a section use a derivative lighter tint of that section's color** (see `cards.md`). They never use a flat white surface inside a colored section.
- **Every component (cards, buttons, inputs, badges, alerts, etc.) carries a 4px brand-color outline.**
- **Components use 16px radius. Cards use 32px radius.**
- **Flat aesthetic.** Buttons, cards, inputs are flat color blocks with a thick brand outline. Avoid drop shadows, gradients, blurs. Shadows, when present, are tiny offset shapes (see `shadows.md`).
- **Every section must include a playful graphic** — a cartoon icon, illustration, character, sticker, sparkle, doodle, or oversized punctuation mark — placed as a decorative anchor inside the section. Sections without illustrative assets are not allowed.

## Do

- Always use the configured brand typeface (Cossette Texte) for every text element to maintain brand personality.
- Use `secondary-brand` (Canvas Almond) as the primary page background color for a warm, inviting foundation.
- Reach for `brand-strong` (Type Black) for primary text content so it lands with high contrast against the warm light backgrounds.
- Lean into the vibrant accent colors — `tertiary-brand` (Grape Punch), `quaternary-brand` (Sunshine Yellow), `quinary-brand` (Bubblegum Red) — for card backgrounds and highlight elements to create visual energy and playfulness.
- Apply card border-radius rules from `radius.md`: 32px for main cards, 15px for general / accent rectangular elements, 5px for small buttons, 144px for speech-bubble shapes.
- Space elements using multiples of the 6px base unit (per `layout.md`); favor `elementGap` of 12px for tight clusters and `cardPadding` of 29px for content blocks.
- Use ghost buttons with `white` text and `border-brand` outline for navigation and secondary actions on dark / colored sections — keep them light and non-obtrusive.
- Embrace rounded corners and slightly irregular forms; let elements feel a bit hand-placed.

## Don't

- Avoid traditional soft / blurred drop shadows. Rely on vibrant background colors, thick brand outlines, offset-block shadows, and irregular shapes for element definition.
- Do not introduce additional font families — the configured brand typeface (Cossette Texte) is the sole typographic voice of the system.
- Refrain from heavily structured grid layouts; allow elements to be positioned more organically, like "sticker bombing" — slight rotations, varied placements, overlapping playful assets.
- Do not use dark, desaturated colors as primary background elements. The system thrives on a light, warm canvas (`secondary-brand` / `neutral-primary-soft`) with vivid accents.
- Avoid strictly symmetrical or rigid component designs; embrace rounded corners and slightly irregular forms.
- Never use generic blue for primary interactive elements. Leverage the brand's vibrant palette — especially `tertiary-brand` (Grape Punch), `success` (Leafy Green), or `quinary-brand` (Bubblegum Red).
- Do not apply padding to ghost buttons. They must read as text-only interactive elements framed by their 4px brand border.

## Module Index

### Foundation (read first for any UI work)
- [colors.md](colors.md) — all background, text, and border color tokens
- [typography.md](typography.md) — heading scale, paragraphs, labels, links
- [layout.md](layout.md) — spacing rhythm, containers, animation, visual depth
- [radius.md](radius.md) — border-radius scale
- [shadows.md](shadows.md) — elevation tokens
- [borders.md](borders.md) — border widths and styles

### Components
- [buttons.md](buttons.md) — button variants, sizes, states, glint effect
- [button-group.md](button-group.md) — grouped button structure
- [cards.md](cards.md) — card structure, background, interactivity
- [inputs.md](inputs.md) — form controls, labels, states
- [alerts.md](alerts.md) — alert variants
- [badges.md](badges.md) — badge variants, sizes, dismissible chips
- [lists.md](lists.md) — list components
- [avatars.md](avatars.md) — avatar variants, sizes, indicators
- [icon-shapes.md](icon-shapes.md) — icon containers

### Complex Components
- [accordion.md](accordion.md) — accordion variants
- [dropdown.md](dropdown.md) — dropdown menus
- [modals.md](modals.md) — modal dialogs
- [tabs.md](tabs.md) — tab navigation
- [tables.md](tables.md) — table structure
- [pagination.md](pagination.md) — pagination components
- [sidebars.md](sidebars.md) — sidebar navigation
- [radios-checkboxes-toggle.md](radios-checkboxes-toggle.md) — selection controls
- [tooltips-popovers.md](tooltips-popovers.md) — tooltips and popovers
- [content.md](content.md) — grid system, responsiveness
