# Accordion

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Wrapper:** full width, 4px border (border-brand color), 16px radius — clips first/last item corners
- **Item separator:** 2px bottom border (border-default-subtle) on every item except last

## Trigger (Button)

- **Layout:** flex, space-between, full width
- **Padding:** 32px horizontal, 24px vertical
- **Font:** 20px, bold weight
- **Text color:** heading
- **Background:** secondary-brand-softer
- **Hover:** secondary-brand-soft background
- **Focus:** outline none, 4px ring in tertiary-brand-soft color
- **Transition:** colors, 150ms
- **Open state:** secondary-brand-soft background

## Panel (Content)

- **Padding:** 32px horizontal, 24px vertical
- **Background:** secondary-brand-softer
- **Top border:** 2px, border-default-subtle color
- **Font:** 18px, body color, 1.6 line-height (max 4 rows per paragraph)

## Chevron Icon

- Size: 20x20px
- Color: heading text color
- Closed: 0deg rotation
- Open: 180deg rotation
- Transition: transform, 150ms

## Variants

### Default (Collapse)
One panel open at a time. Items stacked inside a single shared bordered/rounded wrapper.

### Separated Cards
Each item is independent — has its own 4px brand border, 32px radius, and no shadow. 16px bottom margin between items. No shared outer border.

### Always Open
Multiple panels can expand simultaneously. Same styling as Default.

### Flush
No outer border. Trigger and panel have transparent backgrounds. Only 2px bottom border dividers between items. Use inside containers that already provide a background.

## States

| State | Trigger appearance |
|---|---|
| Closed | heading text, secondary-brand-softer background |
| Open | heading text, secondary-brand-soft background |
| Hover | secondary-brand-soft background |
| Focus | 4px tertiary-brand-soft ring, no outline |
| Disabled | fg-disabled text, not-allowed cursor, no hover/focus |
