# Alerts

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Padding:** 24px
- **Radius:** 16px (base)
- **Border:** 4px solid
- **Heading:** 20px, bold weight
- **Body:** 16px, normal weight, 1.6 line-height (max 4 rows)

## Variants

### Brand
- **Background:** secondary-brand-softer
- **Border:** 4px, border-brand
- **Text:** heading

### Success
- **Background:** success-soft
- **Border:** 4px, border-success
- **Text:** fg-success-strong

### Danger
- **Background:** danger-soft
- **Border:** 4px, border-danger
- **Text:** fg-danger-strong

### Warning
- **Background:** warning-soft
- **Border:** 4px, border-warning
- **Text:** heading
