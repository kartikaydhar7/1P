# Avatars

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Circular shape:** fully rounded (9999px)
- **Rounded square shape:** 16px radius
- **Default size:** 48x48px
- **Image fit:** cover
- **Border:** every avatar has a 4px brand outline (border-brand)

## Sizes

| Size | Dimensions | Radius |
|---|---|---|
| Extra Small | 24x24px | 8px |
| Small | 32x32px | 8px |
| Base | 40x40px | 16px |
| Large | 56x56px | 16px |
| XL | 72x72px | 16px |
| 2XL | 96x96px | 16px |

## Bordered Avatar

- 4px solid brand outline (default for all avatars)
- Optional: 4px box-shadow ring in border-brand color for stacked / focus emphasis

## Stacked Avatars

- Displayed in a row (flex)
- Each avatar: 48x48px, fully rounded, 4px border in border-brand color
- Overlap: -20px negative margin on all except first

### Stacked Counter
- Same size as avatars (48x48px), fully rounded
- Background: brand, text: white, 14px font, bold weight
- Same overlap margin as other avatars

## Avatar with Text

- Flex row, 16px gap between avatar and text
- Avatar: 48x48px, fully rounded, cover fit, 4px brand border
- Name: heading color, bold weight, 18px
- Subtitle: 16px, body color
