# Badges

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Border:** 4px solid
- **Default radius:** 16px
- **Pill radius:** 9999px

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Default (small) | 14px | 12px | 4px |
| Large | 16px | 16px | 6px |

## Variants

### Brand
- **Background:** secondary-brand
- **Border:** 4px, border-brand
- **Text:** heading

### Alternative (Neutral Soft)
- **Background:** neutral-primary-soft
- **Border:** 4px, border-brand
- **Text:** heading

### Gray (Neutral Medium)
- **Background:** neutral-secondary-medium
- **Border:** 4px, border-brand
- **Text:** heading

### Danger
- **Background:** danger-soft
- **Border:** 4px, border-danger
- **Text:** fg-danger-strong

### Success
- **Background:** success-soft
- **Border:** 4px, border-success
- **Text:** fg-success-strong

### Warning
- **Background:** warning-soft
- **Border:** 4px, border-warning
- **Text:** heading

### Dark
- **Background:** dark
- **Border:** 4px, border-brand
- **Text:** white

### Tertiary (Vivid Purple)
- **Background:** tertiary-brand-soft
- **Border:** 4px, border-brand
- **Text:** heading

### Quinary (Warm Red-Orange)
- **Background:** quinary-brand-soft
- **Border:** 4px, border-brand
- **Text:** heading

## Pill Badges

Use 9999px radius instead of 16px on any variant. Border stays 4px.

## Badges with Icons

- Icon size (default): 14x14px
- Icon size (large): 16x16px
- Icon spacing: 6px margin next to label

## Icon-only Badge

Square shape — equalize dimensions to 32x32px, no horizontal text padding.

## Dismissible Badges

Badge content + a close button. Close button hover backgrounds per variant:

| Variant | Close button hover background |
|---|---|
| Brand | secondary-brand-medium |
| Alternative | neutral-tertiary |
| Gray | neutral-quaternary |
| Danger | danger-medium |
| Success | success-medium |
| Warning | warning-medium |
| Tertiary | tertiary-brand-medium |
| Quinary | quinary-brand-medium |

## Dot / Notification Badge

- Positioned absolutely: -6px top, -6px right
- Size: 16x16px, fully rounded
- 4px border in border-brand color
- Background: danger
