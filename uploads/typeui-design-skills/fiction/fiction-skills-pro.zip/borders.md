# Borders

## Width Scale

| Context | Width |
|---|---|
| Default (cards, buttons, inputs, badges, alerts, modals, dropdowns, all components) | 4px |
| Emphasis / focus ring | 4px |
| Internal dividers (table rows, accordion items, list separators, sidebar separators) | 2px |

## Color

- **Default border color across every component:** border-brand (#222222) — the brand-color outline is a defining feature of the system.
- Status variants (success, danger, warning) use their respective `border-success` / `border-danger` / `border-warning` tokens at 4px.
- Internal dividers may use `border-default-subtle` or `border-light` at 2px so they read quieter than component outlines.

## Rules

- Use solid borders by default.
- Dashed borders only for special cases like file dropzones (still 4px, brand color).
- Components in the same family must use matching border widths.
- Never mix border widths within a single component (one component = one border width).
- Never reduce a component outline below 4px to "soften" it — use a softer color instead.

## Usage

| Context | Width | Color |
|---|---|---|
| Inputs / selects / textareas | 4px default; 4px brand on focus or status color on error | border-brand / border-danger / border-success |
| Buttons | 4px on every variant (including primary, secondary, ghost-style) | border-brand or matching status color |
| Cards / containers | 4px | border-brand |
| Internal dividers | 2px | border-default-subtle / border-light |
