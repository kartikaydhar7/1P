# Button Groups

> Dependencies: `buttons.md`, `colors.md`, `radius.md`

## Core Specs

- **Wrapper:** inline-flex, 16px radius, no shadow (flat aesthetic — the 4px brand outline carries the visual weight)
- **Children overlap:** -4px left margin on all except first button (so the 4px brand outlines merge into one shared edge)
- **Buttons inside the group keep their 4px brand outline** but should not double-stack at the seams (handled by the -4px overlap).

## Anatomy

### Wrapper
- Display: inline-flex
- Radius: 16px
- Shadow: none

### First Button
- 16px radius on inline-start side only, 0 on inline-end

### Middle Button(s)
- No radius (0 on all corners)

### Last Button
- 16px radius on inline-end side only, 0 on inline-start

### All buttons except first
- -4px left margin to merge the brand outlines into one shared 4px edge

## Rules

- Buttons inside groups follow all styles from `buttons.md` (background, 4px brand border, focus rings)
- Icon-only buttons: 18x18px icon, match height of text buttons
