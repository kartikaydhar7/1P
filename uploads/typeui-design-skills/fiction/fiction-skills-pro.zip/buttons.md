# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except disabled)

- **Radius:** 16px (base) or 9999px for pills
- **Border:** 4px solid (brand color by default; status color for status variants)
- **Shadow:** none — flat style. Hover may add `shadow-sm` (2px offset block) for the lift effect.
- **Glint effect:** disabled in this system (kept as no-op for compatibility). Buttons read as flat colored blocks with a thick brand outline.
- **Font weight:** 700 (bold)
- **Font:** Cossette Texte
- **Box sizing:** border-box
- **Transition:** color and transform transitions on hover (150ms)

## Sizes

| Size | Font size | Horizontal padding | Vertical padding | Radius |
|---|---|---|---|---|
| Extra small | 14px | 16px | 8px | 5px (xs from `radius.md`) |
| Small | 16px | 20px | 10px | 16px (base) |
| Base (default) | 18px | 24px | 14px | 16px (base) |
| Large | 20px | 32px | 18px | 16px (base) |
| Extra large | 24px | 40px | 22px | 16px (base) |

## Variants

### Brand
- **Background:** brand token (#222222)
- **Border:** 4px, border-brand
- **Text:** white (cream)
- **Hover:** brand-strong background, translate -2px / +2px (offset feel), shadow-sm
- **Focus ring:** 4px, brand-medium color
- **Glint:** none

### Secondary
- **Background:** secondary-brand (warm cream)
- **Border:** 4px, border-brand
- **Text:** heading color
- **Hover:** secondary-brand-medium background, shadow-sm
- **Focus ring:** 4px, secondary-brand-strong
- **Glint:** none

### Tertiary
- **Background:** tertiary-brand (vivid purple)
- **Border:** 4px, border-brand
- **Text:** white
- **Hover:** tertiary-brand-medium background, shadow-sm
- **Focus ring:** 4px, tertiary-brand-soft
- **Glint:** none

### Success
- **Background:** success token
- **Border:** 4px, border-brand
- **Text:** white
- **Hover:** success-strong background, shadow-sm
- **Focus ring:** 4px, success-medium color
- **Glint:** none

### Danger
- **Background:** danger token (#FD4C38)
- **Border:** 4px, border-brand
- **Text:** white
- **Hover:** danger-strong background, shadow-sm
- **Focus ring:** 4px, danger-medium color
- **Glint:** none

### Warning
- **Background:** warning token (#FFD80B)
- **Border:** 4px, border-brand
- **Text:** heading color (dark on yellow for contrast)
- **Hover:** warning-strong background, shadow-sm
- **Focus ring:** 4px, warning-medium color
- **Glint:** none

### Dark
- **Background:** dark token (#222222)
- **Border:** 4px, border-brand
- **Text:** white
- **Hover:** dark-strong background, shadow-sm
- **Focus ring:** 4px, neutral-tertiary color
- **Glint:** none

### Ghost (text-only, framed by border — used on dark / colored sections for navigation and secondary actions)
- **Background:** transparent
- **Border:** 4px, border-brand (or `white` border when used on dark `brand` sections so it reads against the dark fill)
- **Text:** `white` (Paper White)
- **Padding:** **none** — ghost buttons have no internal padding. They appear as text-only interactive elements framed tightly by their 4px border.
- **Hover:** subtle text underline; optionally fill background with `secondary-brand-softer` at low opacity. No background swap that adds visual weight.
- **Focus ring:** 4px, `secondary-brand-medium`
- **No shadow, no glint, no padding**

### Disabled (NO shadow, NO glint)
- **Background:** disabled token
- **Border:** 4px, border-brand-subtle
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no glint**

## Icons in Buttons

- Icon size: 18x18px (base), scale with size step
- Spacing: 10px gap between icon and label (matches `elementGap` from `layout.md`)
- Layout: inline-flex, vertically centered

## Don't

- **Never use generic blue for primary interactive buttons.** Use the brand's vibrant palette: `brand`, `tertiary-brand` (Grape Punch), `success` (Leafy Green), or `quinary-brand` (Bubblegum Red).
- **Do not apply padding to ghost buttons.** They must read as text-only interactive elements framed by their 4px border.
- **Never use traditional soft / blurred drop shadows on buttons.** Hover lift uses offset-block shadows from `shadows.md`.
- Do not introduce additional radius values for buttons outside the scale defined in `radius.md`.
