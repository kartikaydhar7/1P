# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** a derivative lighter tint of the parent section's color (see "Card Surface Color" below). Vibrant accent cards may use full-saturation `tertiary-brand` (Grape Punch), `quaternary-brand` (Sunshine Yellow), or `quinary-brand` (Bubblegum Red) backgrounds for high-energy moments.
- **Border:** 4px solid, `border-brand` color
- **Radius:** 32px (main cards). Smaller rectangular accent / sticker-style cards use 15px (`accent` from `radius.md`). Speech-bubble cards use 144px (`speech-bubble`).
- **Shadow:** none on rest. Hover may add `shadow-sm` (2px offset block).
- **Padding:** `cardPadding` token (29px) by default; 24px for compact cards; 36px for spacious cards.

## Card Surface Color

A card always sits on top of a section that uses one of the brand colors. Its background must be the **softer derivative** of that section's color so it reads as a lighter "sticker" on top of the colored field — never plain white.

| Parent section background | Card background |
|---|---|
| brand (#222222) | brand-softer |
| secondary-brand (#FFE9CE) | secondary-brand-softer |
| tertiary-brand (#8B53FF) | tertiary-brand-softer |
| quaternary-brand (#FFD80B) | quaternary-brand-softer |
| quinary-brand (#FD4C38) | quinary-brand-softer |
| neutral-primary-soft (cream page bg) | neutral-primary-medium |

If a card sits inside another card, step the surface one tint lighter again.

### Vibrant Accent Cards

For highlight cards, feature callouts, or energy moments, use a **full-saturation** brand accent as the card background instead of the softer derivative:

| Accent intent | Card background | Card text |
|---|---|---|
| Playful highlight | `tertiary-brand` (Grape Punch) | `white` |
| Bright optimistic | `quaternary-brand` (Sunshine Yellow) | `heading` |
| Hot / urgent / energetic | `quinary-brand` (Bubblegum Red) | `white` |

Vibrant accent cards still use 4px `border-brand` outline and the standard card radius (32px main / 15px accent rectangle / 144px speech-bubble).

## Card Heading

- Desktop: 40px, bold weight, heading color
- Mobile: 28px, bold weight, heading color
- Max 2 rows (per `typography.md`)
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: derivative of section color (per table above)
- Border: 4px, border-brand
- Radius: 32px
- Shadow: none
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: nudge with shadow-sm (2px brand-color offset block) and translate -2px / +2px for a playful "pop" feel
- Transition: transform and box-shadow, 150ms
- Cursor: pointer

## Rules

- Background: lighter derivative tint of parent section color (never plain white inside a colored section), or a full-saturation accent (`tertiary-brand` / `quaternary-brand` / `quinary-brand`) for highlight cards
- Border: 4px, `border-brand`
- Radius: 32px for main cards, 15px for rectangular accent / sticker-style mini cards, 144px for speech-bubble cards
- Padding: `cardPadding` (29px) by default
- Shadow: none on rest, optional `shadow-sm` on interactive hover
- Interactive hover: subtle 2px translate + offset block shadow
- Non-interactive: no hover styles
- Every card must contain its content with at least 24px of inner breathing room around headings and paragraphs (per `typography.md`)
- Embrace slightly irregular forms — accent / sticker cards may use slight rotations (-6deg to +6deg) per the sticker-bombing rules in `layout.md`

## Don't

- Do not use a plain white card background on top of a colored brand section.
- Do not use generic blue or any out-of-palette color for card backgrounds.
- Do not apply traditional soft drop shadows to cards.
- Do not arrange cards in strictly symmetrical, perfectly-aligned grids — embrace organic placement and rounded, slightly irregular forms.
