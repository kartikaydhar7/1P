# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFF8EC | #1A1612 |
| neutral-primary | #FFFBF4 | #14110D |
| neutral-primary-medium | #FFF1DC | #221C16 |
| neutral-primary-strong | #FFE9CE | #2C241B |
| neutral-secondary-soft | #FFF1DC | #1A1612 |
| neutral-secondary | #FFE9CE | #14110D |
| neutral-secondary-medium | #FBDDB2 | #221C16 |
| neutral-secondary-strong | #F5C68A | #2C241B |
| neutral-tertiary-soft | #FFE9CE | #1A1612 |
| neutral-tertiary | #FBDDB2 | #221C16 |
| neutral-tertiary-medium | #F5C68A | #2C241B |
| neutral-quaternary | #EBB672 | #3A2F23 |
| quaternary-medium | #EBB672 | #4A3C2D |
| gray | #D9A35A | #4A3C2D |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #E8E8E8 | #2A2A2A |
| brand-soft | #BFBFBF | #404040 |
| brand | #222222 | #F5F0E6 |
| brand-medium | #4A4A4A | #2A2A2A |
| brand-strong | #000000 | #FFFFFF |

### Secondary Brand (warm cream — playful section)
| Token | Light | Dark |
|---|---|---|
| secondary-brand-softer | #FFF8EC | #2A2418 |
| secondary-brand-soft | #FFF1DC | #3A311F |
| secondary-brand | #FFE9CE | #FFE9CE |
| secondary-brand-medium | #FBDDB2 | #B89E73 |
| secondary-brand-strong | #F5C68A | #D9B88A |

### Tertiary Brand (vivid purple — playful section)
| Token | Light | Dark |
|---|---|---|
| tertiary-brand-softer | #F2EAFF | #2A1F4D |
| tertiary-brand-soft | #C9ADFF | #4A2F8A |
| tertiary-brand | #8B53FF | #8B53FF |
| tertiary-brand-medium | #6B33D9 | #A77BFF |
| tertiary-brand-strong | #4A1FA8 | #C9ADFF |

### Quaternary Brand (sunny yellow — playful section)
| Token | Light | Dark |
|---|---|---|
| quaternary-brand-softer | #FFF8C7 | #4D4400 |
| quaternary-brand-soft | #FFEC75 | #8A7700 |
| quaternary-brand | #FFD80B | #FFD80B |
| quaternary-brand-medium | #D9B500 | #FFE65A |
| quaternary-brand-strong | #A88A00 | #FFEC75 |

### Quinary Brand (warm red-orange — playful section)
| Token | Light | Dark |
|---|---|---|
| quinary-brand-softer | #FFE2DD | #4D1810 |
| quinary-brand-soft | #FFA89C | #8A2B1F |
| quinary-brand | #FD4C38 | #FD4C38 |
| quinary-brand-medium | #D43825 | #FE7768 |
| quinary-brand-strong | #A82817 | #FFA89C |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #E8F8E0 | #1F3A14 |
| success | #2FA84F | #4ECB6F |
| success-medium | #C5EFB0 | #2A5C1F |
| success-strong | #1F7A38 | #2FA84F |
| danger-soft | #FFE2DD | #4D1810 |
| danger | #FD4C38 | #FD4C38 |
| danger-medium | #FFA89C | #8A2B1F |
| danger-strong | #A82817 | #FE7768 |
| warning-soft | #FFF8C7 | #4D4400 |
| warning | #FFD80B | #FFD80B |
| warning-medium | #FFEC75 | #8A7700 |
| warning-strong | #A88A00 | #FFE65A |

### Button Glint (kept for compatibility — visual effect is disabled in flat style)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0) | rgba(255,255,255,0) |
| `--color-1-700` | rgba(0,0,0,0) | rgba(0,0,0,0) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #222222 | #222222 |
| dark-strong | #000000 | #111111 |
| disabled | #F0E6D4 | #2C241B |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #8B53FF |
| sky | #4FB7E8 |
| teal | #2BB39A |
| pink | #FF6FA8 |
| cyan | #2FC3D6 |
| fuchsia | #D63FBF |
| indigo | #5B45E0 |
| orange | #FD4C38 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFBF4 | #FFFBF4 |
| black | #000000 | #000000 |
| heading | #000000 | #FFF8EC |
| body | #000000 | #E8DCC4 |
| body-subtle | #4A4A4A | #B8A982 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #BFBFBF | #404040 |
| fg-brand | #222222 | #FFF8EC |
| fg-brand-strong | #000000 | #FFFFFF |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #1F7A38 | #2FA84F |
| fg-success-strong | #15522A | #4ECB6F |
| fg-danger | #A82817 | #FD4C38 |
| fg-danger-strong | #7A1A0E | #FE7768 |
| fg-warning-subtle | #A88A00 | #FFD80B |
| fg-warning | #6B5800 | #FFE65A |
| fg-disabled | #B8A982 | #6B5C42 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FFD80B | #FFD80B |
| fg-info | #5B45E0 | #A77BFF |
| fg-purple | #8B53FF | #8B53FF |
| fg-purple-strong | #4A1FA8 | #C9ADFF |
| fg-cyan | #2FC3D6 | #2FC3D6 |
| fg-indigo | #5B45E0 | #5B45E0 |
| fg-pink | #FF6FA8 | #FF6FA8 |
| fg-lime | #8FCB2B | #A8D854 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #222222 | #FFF8EC |
| border-buffer | #FFF8EC | #14110D |
| border-buffer-medium | #FFF8EC | #1A1612 |
| border-buffer-strong | #FFF8EC | #221C16 |
| border-muted | #FFE9CE | #14110D |
| border-light-subtle | #FFE9CE | #14110D |
| border-light | #FBDDB2 | #1A1612 |
| border-light-medium | #F5C68A | #221C16 |
| border-default-subtle | #222222 | #FFF8EC |
| border-default | #222222 | #FFF8EC |
| border-default-medium | #222222 | #FFF8EC |
| border-default-strong | #000000 | #FFFFFF |
| border-success-subtle | #C5EFB0 | #2A5C1F |
| border-success | #1F7A38 | #2FA84F |
| border-danger-subtle | #FFA89C | #8A2B1F |
| border-danger | #FD4C38 | #FE7768 |
| border-warning-subtle | #FFEC75 | #8A7700 |
| border-warning | #FFD80B | #FFE65A |
| border-brand-subtle | #BFBFBF | #404040 |
| border-brand-light | #4A4A4A | #B8B8B8 |
| border-brand | #222222 | #FFF8EC |
| border-dark-subtle | #222222 | #FFF8EC |
| border-purple | #8B53FF | #8B53FF |
| border-orange | #FD4C38 | #FD4C38 |

## Semantic Usage Rules

- **Primary page background:** `secondary-brand` (Canvas Almond, warm cream) — the inviting foundation that every page sits on. `neutral-primary-soft` is the secondary fallback for very neutral surfaces.
- **Section backgrounds alternate** through the 5 brand colors in order: brand → secondary-brand → tertiary-brand → quaternary-brand → quinary-brand → (loop). Adjacent sections must never share the same background color.
- **Cards on a colored section** use a softer, lighter derivative tint of that section's color (e.g. cards on a `tertiary-brand` section use `tertiary-brand-softer`). Never plain white inside a colored section.
- **Vibrant accent backgrounds** for cards, highlight blocks, and energy moments: `tertiary-brand` (Grape Punch), `quaternary-brand` (Sunshine Yellow), `quinary-brand` (Bubblegum Red). Use them generously to inject playfulness.
- **Primary buttons:** `brand` background, `white` text
- **Headings & primary text:** `heading` token (resolves to `brand-strong` / Type Black in light mode) for maximum contrast on light backgrounds
- **Body text:** `body` token, short paragraphs
- **CTA links:** `fg-brand`, underlined
- **Default borders on every component:** `border-brand` (#222222), 4px width
- **Status borders match intent:** success → `border-success`, danger → `border-danger`, warning → `border-warning`
- **Disabled:** `disabled` background + `fg-disabled` text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (`fg-purple`, etc.) for body copy or navigation
- Never put a plain white card on top of a colored brand section — always use the section's lighter tint
- Adjacent sections must not repeat the same brand background color
- No manual light/dark value swapping — let the custom properties handle it
- **No dark, desaturated colors as primary background elements.** The system thrives on a light, warm canvas (`secondary-brand` / `neutral-primary-soft`) with vivid accents. Reserve `brand` (#222222) backgrounds for occasional emphasis sections, never as the dominant page surface.
- **Never use generic blue for primary interactive elements.** Use the brand's vibrant palette: `tertiary-brand` (Grape Punch), `success` (Leafy Green), or `quinary-brand` (Bubblegum Red).
