# Content & Grid System

> Dependencies: `layout.md`, `typography.md`

## Containers

| Type | Max width | Horizontal padding |
|---|---|---|
| Standard | 1280px | 32px |
| Internal (reading) | 720px | — (45–60 char line length, max 4 rows per paragraph) |

## Vertical Padding

| Breakpoint | Vertical padding |
|---|---|
| Mobile | 80px |
| Tablet (≥768px) | 120px |
| Desktop (≥1024px) | 160px (hero/feature sections always 160px) |

## Grid System

Mobile-first with flexible desktop configurations.

| Context | Gap |
|---|---|
| Standard content/cards | 32px |
| Compact widgets/metadata | 24px |

### Responsive Columns

| Breakpoint | Columns |
|---|---|
| Mobile (default) | 1 |
| Small/Tablet (≥640px) | 1–2 |
| Desktop (≥1024px) | 2–4 |

Cards inside grids must remain large enough to host oversized headings and breathable padding — favor fewer, larger cards over dense column counts.

## Breakpoints

| Name | Width |
|---|---|
| Small | 640px |
| Medium | 768px |
| Large | 1024px |
| Extra large | 1280px |
| 2x Extra large | 1536px |

## Rules

- Always design mobile-first
- Use layout shifts (column → row) to accommodate horizontal space
- Lists: 32px indentation, 16px vertical gap between items
- Body copy: 18px, 1.6 line-height, max 4 rows per paragraph
- All interactive links follow brand underline/hover protocol
- Every content section must include a playful decorative graphic (per `layout.md`)
