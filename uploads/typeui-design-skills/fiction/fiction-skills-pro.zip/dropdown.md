# Dropdown

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `inputs.md`

## Core Specs

### Chevron Icon
- Size: 20x20px
- Spacing: 8px left margin, -4px right margin
- Color: inherits from trigger button

### Menu Container
- Background: secondary-brand-softer
- Border: 4px, border-brand
- Radius: 16px (base)
- Shadow: shadow-md (4px brand-color offset block)
- Z-index: elevated above content

### Menu List
- Padding: 12px
- Font: 16px, body color, bold weight

### Menu Item
- Layout: inline-flex, vertically centered, full width
- Padding: 12px horizontal, 12px vertical
- Radius: 16px
- Hover: secondary-brand-soft background, heading text
- Transition: colors, 150ms

## Trigger Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Small | 16px | 20px | 10px |
| Base | 18px | 24px | 14px |
| Large | 20px | 32px | 18px |

## Icon-only Trigger

- Padding: 12px
- Min size: 52x52px
- Icon: 22x22px

## Variants

### Default
- Menu width: 240px, items have 16px radius

### With Divider
- Top 2px border (border-default-subtle) between child groups, skip first group

### With Header
- Header padding: 20px horizontal, 16px vertical
- Bottom border: 2px, border-default-subtle
- Name: heading color, 18px, bold weight
- Email: body-subtle color, 14px, truncated

### With Icons
- Icon before label: 20x20px, 12px right margin, body color
- On hover, icon color changes to heading

### With Checkbox / Radio
- Inputs: 20x20px, 8px radius, focus ring in tertiary-brand-soft
- Helper text: 14px, body-subtle color, 4px top margin

### With Search
- Search input at top of menu following `inputs.md` specs (4px brand border, 16px radius)
- Left icon: 16px left padding, input 48px left padding

### Scrollable
- Max height: 280px, vertical scroll overflow

## States

| State | Appearance |
|---|---|
| Focused trigger | no outline, 4px tertiary-brand-soft ring |
| Hover item | secondary-brand-soft background, heading text |
| Active/open item | secondary-brand-medium background, heading text |
| Disabled item | fg-disabled text, not-allowed cursor, no pointer events |
