# Icon Shapes

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- Box sizing: border-box
- Icon must be perfectly centered (inline-flex, centered both axes)
- Circle: fully rounded (9999px)
- Rounded square: 16px radius (MD/LG/XL), 8px radius (XS/SM)
- Border: 4px, border-brand on every icon shape (the playful flat-cartoon look requires the outline)

## Sizes

| Size | Container | Icon |
|---|---|---|
| XS | 32x32px | 16x16px |
| SM | 40x40px | 20x20px |
| MD | 56x56px | 28x28px |
| LG | 72x72px | 36x36px |
| XL | 96x96px | 48x48px |

## Color Variants

### Brand
- Shape: circle
- Background: secondary-brand
- Border: 4px, border-brand
- Icon color: heading

### Gray
- Shape: circle
- Background: neutral-secondary-soft
- Border: 4px, border-brand
- Icon color: heading

### Danger
- Shape: circle
- Background: danger-soft
- Border: 4px, border-danger
- Icon color: fg-danger-strong

### Success
- Shape: circle
- Background: success-soft
- Border: 4px, border-success
- Icon color: fg-success-strong

### Warning
- Shape: circle
- Background: warning-soft
- Border: 4px, border-warning
- Icon color: heading

### Tertiary (Vivid Purple)
- Shape: circle
- Background: tertiary-brand
- Border: 4px, border-brand
- Icon color: white

### Quaternary (Sunny Yellow)
- Shape: circle
- Background: quaternary-brand
- Border: 4px, border-brand
- Icon color: heading

### Quinary (Warm Red-Orange)
- Shape: circle
- Background: quinary-brand
- Border: 4px, border-brand
- Icon color: white
