# Inputs

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Display:** block, full width
- **Radius:** 16px (base)
- **Border:** 4px solid, border-brand color
- **Background:** secondary-brand-softer (warm cream so the input still reads light on any colored section)
- **Shadow:** none — flat aesthetic
- **Font:** 18px, Cossette Texte, heading color
- **Padding:** 18px horizontal, 14px vertical
- **Placeholder:** body-subtle color
- **Transition:** all properties, 200ms

## Label

- Display: block
- Font: 16px, bold weight, heading color
- Margin bottom: 12px
- Label `htmlFor` must match the input `id`

## States

### Default
- Border: 4px, border-brand
- Background: secondary-brand-softer

### Hover
- Border: 4px, border-brand-strong (deeper black)
- Background: secondary-brand-soft

### Focus
- No outline
- Border: 4px, border-brand-strong
- Ring: 4px, tertiary-brand-soft (playful purple halo)

### Success
- Border: 4px, border-success
- Focus ring: 4px, success-medium

### Error / Danger
- Border: 4px, border-danger
- Focus ring: 4px, danger-medium

### Disabled
- Background: disabled
- Border: 4px, border-brand-subtle
- Text: fg-disabled
- Cursor: not-allowed

## Input with Icons

- Icon size: 20x20px
- Icon color: body
- Container: relative positioned wrapper
- Start icon: absolutely positioned left, 16px left padding — input gets 48px left padding
- End icon: absolutely positioned right, 16px right padding — input gets 48px right padding
- Icons vertically centered within the wrapper

## Rules

- Every input must have a unique `id`
- Every label must have a matching `htmlFor`
- Padding: 18px horizontal, 14px vertical unless overridden for icon variants
- Border is always 4px brand color (or status color for error/success)
- Background is the warm cream (`secondary-brand-softer`) so the field reads consistently on any section color
- No arbitrary hex or hardcoded colors
