# Layout & Spacing

## Spacing Rhythm

Base unit: **6px**. All spacing values should be multiples of 6px (with two named tokens that anchor common patterns).

### Named spacing tokens

| Token | Value | Use |
|---|---|---|
| `elementGap` | 12px | Tight clusters — icon + label, badge groups, inline metadata, sidebar item rows |
| `cardPadding` | 29px | Inner padding for content blocks / cards (the slightly off-grid 29px is intentional and gives the system its hand-placed playful feel) |

### Layout values (multiples of 6)

| Context | Value |
|---|---|
| Section vertical padding | 144px |
| Section header → content | 72px |
| Heading → paragraph | 30px |
| Container horizontal padding | 36px |
| Flex/grid row gap | 24px |
| Card grid gap | 36px |
| Wide component grid gap | 60px |
| Column layout gap | 72px |

## Container

Standard section container: max-width 1280px, centered, 36px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`) — oversized, max 2 rows, generous breathing room
2. Leading paragraph — max 4 rows
3. Normal paragraph(s) — max 4 rows each
4. Lists, CTA links, or component grids
5. At least one playful graphic asset (illustration, sticker, oversized punctuation, character, or doodle) anchored within the section

## Section Pattern

Each section has:
- 144px vertical padding (top and bottom)
- A background color that **alternates playfully** (see "Section Color Alternation" below)
- A centered container (max-width 1280px, 36px horizontal padding)
- A section header area with 72px bottom margin
- Section content below
- At least one decorative playful graphic positioned for compositional balance

## Section Color Alternation

Sections rotate through the five brand colors in order, looping when exhausted:

1. brand (#222222) → text uses cream (`white` token)
2. secondary-brand (#FFE9CE) → text uses heading
3. tertiary-brand (#8B53FF) → text uses cream (`white` token)
4. quaternary-brand (#FFD80B) → text uses heading
5. quinary-brand (#FD4C38) → text uses cream (`white` token)

Rules:
- Adjacent sections must never share the same background color.
- Each new section picks the next color in the rotation. The rotation may start from any color, but it must keep advancing.
- The page hero may use any of the five brand colors as its starting backdrop.
- Cards on a section use the section color's softer derivative (see `cards.md`).

## Playful Illustrations & Decorative Assets

Every section must include at least one of the following decorative elements:
- A cartoon illustration (character, mascot, doodled object)
- An oversized playful icon or sticker (sparkle, star, heart, arrow, exclamation mark)
- A hand-drawn-feeling shape (squiggle, blob, scribble, underline, circled accent)
- An oversized typographic element ("BANG", "WOW", "!", "?", "&") used as decoration, not content
- A speech-bubble shape (using the 144px `speech-bubble` radius from `radius.md`)

Rules for decorative assets:
- Use solid brand colors (or contrasting brand colors) with thick `border-brand` outlines to match the system's flat-cartoon style.
- Position to support composition (anchor a corner, frame a heading, balance white space) — never as random clutter.
- Keep all assets crisp / vector. Avoid photographs, gradients, or noisy textures.

## Organic "Sticker Bombing" Composition

Avoid heavily structured, perfectly-aligned grid layouts. Let elements feel hand-placed:

- Use slight rotations (-6deg to +6deg) on decorative stickers, badges, and accent cards.
- Vary placements — overlap a sticker on the corner of a card, let an oversized punctuation mark bleed past a section edge, anchor a doodle slightly off-center.
- Allow accent rectangles (using the 15px `accent` radius) to break the main grid line for a playful collage feel.
- Symmetrical and rigid component arrangements are discouraged. Embrace rounded corners and slightly irregular forms.
- Scale and position decorative elements freely; they don't need to align to the spacing rhythm the way content does.

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `keyframes`. Use a JS animation library only when CSS cannot achieve the behavior.
- Lean into playful, slightly bouncy easing (e.g. `cubic-bezier(.68,-0.6,.32,1.6)`) for hover and reveal moments.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered delays delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Backgrounds & Visual Depth

- The system is intentionally **flat**. Backgrounds are solid brand-color fills — no gradient meshes, no noise, no blur.
- Visual depth comes from: thick `#222222` outlines on every component, offset-block shadows on prominent surfaces, and the playful illustrations layered over the colored fields.
- Decorative elements (illustrations, stickers, oversized type) provide depth and rhythm — never purely ornamental clutter.

## Must

- All sections: consistent 144px vertical padding
- All containers: max-width 1280px, centered, 36px horizontal padding
- Section headers: 72px bottom margin
- Spacing values: multiples of the 6px base unit
- `elementGap` (12px) for tight clusters; `cardPadding` (29px) for content blocks
- Sections rotate through the five brand colors; adjacent sections never share a background
- Every section includes at least one playful decorative graphic
- Generous vertical rhythm — never crowded, always breathable
- Layouts readable and properly spaced on both desktop and mobile

## Don't

- Don't use heavily structured, perfectly-aligned grid layouts. Embrace organic "sticker bombing" arrangements.
- Don't make compositions strictly symmetrical or rigid. Embrace rounded corners and slightly irregular forms.
- Don't position decorative assets randomly — every sticker / illustration must support the composition.
