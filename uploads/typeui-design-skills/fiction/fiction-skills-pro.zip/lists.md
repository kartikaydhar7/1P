# Lists

> Dependencies: `colors.md`

## Core Specs

- Item spacing: 24px vertical gap between list items
- Text: body color, 18px

## List Icons

- Size: 24x24px
- Prevent squishing: no shrink
- Spacing: 12px right margin between icon and text
- Active/featured icon: fg-brand color (often inside a circular icon-shape with 4px brand outline — see `icon-shapes.md`)
- Neutral icon: heading color

## Inactive / Disabled Items

Strikethrough text with body-subtle color decoration on the list item.

## Pattern

Vertical flex list with 24px gap. Each item is a flex row with centered alignment — icon (24x24px, no-shrink, 12px right margin) followed by a span of body-colored text. Lists never overflow 4 visible rows of text per item.
