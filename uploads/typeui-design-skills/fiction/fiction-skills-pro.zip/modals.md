# Modals

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `buttons.md`, `inputs.md`

## Core Specs

### Overlay (Backdrop)
- Fixed, covers full screen
- Z-index: 40
- Background: brand (#222222) at 50% opacity
- No blur — keep the playful flat aesthetic

### Content Container
- Background: secondary-brand-softer (warm cream)
- Border: 4px, border-brand
- Radius: 16px (modal counts as a component, not a card — uses 16px per `radius.md`)
- Shadow: shadow-xl (8px brand-color offset block)
- Padding: 32px

## Anatomy

### Header
- Bottom border: 2px, border-default-subtle
- Top corners rounded (16px, inherited from container)
- Title: 32px, bold weight, heading color, max 2 rows
- Close button: Ghost variant from `buttons.md`, 8px padding

### Body
- Vertical padding: 32px
- Vertical spacing between elements: 24px
- Text: 18px, 1.6 line-height, body color, max 4 rows per paragraph

### Footer
- Top border: 2px, border-default-subtle
- Bottom corners rounded (16px, inherited from container)

## Variants

### Default (Information)
Standard header + body + footer with primary/secondary action buttons.

### Pop-up (Confirmation)
Centered text, prominent icon, reduced padding:
- Body: 32px padding, text centered
- Icon: centered, 24px bottom margin, 64x64px, brand outline (per `icon-shapes.md`)

### Form Modal
Body contains inputs following `inputs.md` (4px brand border, 16px radius). Vertical spacing between form elements: 24px.

## Rules

- Backdrop covers full screen with fixed positioning, brand color at 50% opacity
- Content: secondary-brand-softer background, 16px radius, 4px brand border, shadow-xl offset block
- Header/Footer separated by 2px border-default-subtle borders
- Close button must be present and functional
- Accessibility: `role="dialog"`, implement focus trap in code
- Dark mode automatic via token system
- Modal headers and body still respect heading max-2-rows and paragraph max-4-rows rules
