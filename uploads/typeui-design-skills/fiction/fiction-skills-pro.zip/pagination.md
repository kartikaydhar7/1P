# Pagination

> Dependencies: `colors.md`, `radius.md`

## Container

Font: 16px, bold weight. Items displayed as flex with -4px overlap so the 4px brand outlines merge into one shared edge.

## Pagination Item

- Layout: flex, centered both axes
- Size: 48x48px
- Text: heading color, bold weight
- Background: secondary-brand-softer
- Border: 4px, border-brand
- Hover: secondary-brand-soft background, heading text
- Focus: no outline, 4px ring in tertiary-brand-soft
- Overlap: -4px left margin

## Previous / Next Buttons

- Horizontal padding: 20px, height: 48px
- First item: 16px radius on inline-start side
- Last item: 16px radius on inline-end side

## Active Page Item

- Text: white
- Background: brand (#222222)
- Hover: stays brand background, white text

## Rules

- Display as flex with -4px child overlap so brand outlines share edges
- Items: secondary-brand-softer background, 4px border-brand border, heading text
- Active: white text on brand background
- First item: rounded inline-start (16px), Last item: rounded inline-end (16px)
- All items need hover and focus states
