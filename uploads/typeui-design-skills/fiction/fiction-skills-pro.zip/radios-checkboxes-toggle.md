# Radios, Checkboxes & Toggles

> Dependencies: `colors.md`, `radius.md`

## Checkbox

- Size: 24x24px
- Radius: 8px
- Border: 4px, border-brand
- Background: secondary-brand-softer
- Checked: brand background, white check icon
- Focus ring: 4px, tertiary-brand-soft

### Disabled
- Border: 4px, border-brand-subtle
- Text: fg-disabled

## Radio

- Size: 24x24px
- Radius: fully rounded (9999px)
- Border: 4px, border-brand
- Background: secondary-brand-softer
- Focus ring: 4px, tertiary-brand-soft
- Checked: brand background, white inner dot indicator

### Disabled
- Border: 4px, border-brand-subtle
- Text: fg-disabled

Group all radio items under the same `name` attribute.

## Toggle

### Track
- Fully rounded (9999px)
- Background: secondary-brand-softer
- Border: 4px, border-brand
- Focus-within ring: 4px, tertiary-brand-soft
- Checked track: brand background
- Disabled track: disabled background

### Thumb
- Fully rounded (9999px)
- Background: white (cream)
- Border: 4px, border-brand

### Disabled
- Track: disabled background
- Label: fg-disabled text

## Rules

- All selection inputs must have `id` matching label `htmlFor`
- All controls carry the 4px brand outline that defines the system
- Focus states use the playful tertiary-brand-soft halo
- Disabled states: no hover/focus interaction
