# Border Radius

| Token | Value | Default usage |
|---|---|---|
| xs | 5px | Smaller buttons (extra-small button variant), tiny chip controls |
| sm | 8px | Checkboxes, tiny elements |
| accent | 15px | Rectangular accent elements, sticker-style decorative blocks, mini cards, highlight chips |
| base | 16px | Buttons, inputs, modals, alerts, badges, sections, all components except cards |
| default | 16px | Dropdown items, small controls, popovers, tooltip panels |
| card | 32px | Cards (any variant, any surface) |
| speech-bubble | 144px | Speech bubble shapes, oversized pill callouts, playful chat-style asset containers |
| full | 9999px | Pills, avatars, toggles, dot indicators |

## Component-specific overrides

| Component | Radius |
|---|---|
| Cards (main, any variant) | 32px (card) |
| Rectangular accent elements / sticker blocks / mini cards | 15px (accent) |
| Extra-small buttons | 5px (xs) |
| Speech bubbles, oversized pill callouts | 144px (speech-bubble) |

## Rules

- **All main cards use 32px radius.** No exceptions for primary content cards — interactive cards, static cards, sidebar bottom CTA cards, modal bodies that read as cards, all use 32px.
- **All other standard components (buttons, inputs, badges, alerts, modals, dropdowns, tabs, popovers, tooltips) use 16px radius.**
- **Use 15px (accent) for rectangular sticker-style decorative blocks** — small accent rectangles, micro cards, highlight chips that sit alongside a main card without competing with it.
- **Use 5px (xs) for extra-small button variants** — pill-tag buttons, tiny inline action buttons.
- **Use 144px (speech-bubble) for speech bubble shapes** — chat-style callouts, oversized pill messages, playful conversation assets.
- Never use arbitrary radius values outside this scale.
- Radius must be consistent within each component family.
- Pill / fully-rounded shape (9999px) is reserved for badges marked as pills, avatars, toggles, and dot indicators.
