# Shadows

The system is intentionally **flat**. Components rely on thick brand-color outlines, not blurred drop shadows. Shadows, when used, are crisp offset blocks (no blur, no spread) so surfaces still feel cartoonesque and stickered onto the page.

| Token | CSS value |
|---|---|
| shadow-2xs | `0 0 0 0 transparent` |
| shadow-xs | `0 0 0 0 transparent` |
| shadow-sm | `2px 2px 0 0 #222222` |
| shadow-md | `4px 4px 0 0 #222222` |
| shadow-lg | `6px 6px 0 0 #222222` |
| shadow-xl | `8px 8px 0 0 #222222` |
| shadow-2xl | `12px 12px 0 0 #222222` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs (none) |
| Inputs, buttons, small controls, lightweight cards | shadow-xs (none) — flat on rest |
| Standard cards, popovers, dropdowns | shadow-md (4px offset block) |
| Prominent cards, sticky surfaces | shadow-lg (6px offset block) |
| Modals, high-priority overlays | shadow-xl (8px offset block) |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl (12px offset block) |

## Rules

- Default state for buttons, inputs, and most cards is **flat — no shadow.** The 4px brand outline carries the visual weight.
- When a shadow is needed (modals, popovers, hover-lift on prominent cards), use the offset-block style above. Never use blurred soft shadows.
- Never stack multiple shadow tokens on one element.
- Hover/focus on interactive elevated elements: nudge offset by 2px (e.g. `shadow-sm` → `shadow-md`) — do not add blur.
- Shadow color is always the brand color — implementations should reference `border-brand` so dark mode inverts automatically.

## Don't

- **Avoid traditional box-shadows** (any shadow with a non-zero blur radius or spread). The system never uses soft, blurred, atmospheric drop shadows.
- Do not rely on shadow for element definition. Element definition comes from **vibrant background colors, thick brand outlines, and irregular sticker-style shapes** — not blurred elevation.
- Do not use shadow color values other than the brand outline color.
- Do not stack offset-block shadows in opposite directions on the same element.
