# Sidebars

> Dependencies: `colors.md`, `radius.md`, `typography.md`, `badges.md`, `alerts.md`

## Core Specs

- Background: secondary-brand-softer (warm cream)
- Right border: 4px, border-brand (for left-sidebar); left border for right-sidebar
- Width: 288px

## Anatomy

### Outer Container
Hidden on mobile, visible at small breakpoint. Needs a toggle/trigger for mobile.

### Inner Wrapper
- Full height, vertical scroll overflow
- Padding: 20px horizontal, 24px vertical

### Navigation List
- Vertical spacing: 12px between items
- Font weight: bold
- Font size: 18px

### Navigation Item
- Layout: flex, vertically centered
- Padding: 14px horizontal, 12px vertical
- Text: heading color
- Radius: 16px (base)
- Border: 4px transparent border by default (so layout doesn't shift on active state)
- Hover: secondary-brand-soft background
- Transition: colors, 100ms
- Icon: 24x24px, heading color, 100ms transition
- Label: 16px left margin from icon

### Active Item
- Background: brand (#222222)
- Border: 4px, border-brand
- Text: white

### Separator
- 24px top padding, 24px top margin
- Top border: 2px, border-default-subtle
- 12px vertical spacing below

### Bottom CTA / Card
- Padding: 24px
- Top margin: 32px
- Radius: 32px (this is a card — see `cards.md`)
- Border: 4px, border-brand
- Background: tertiary-brand-softer (or any other softer brand-color tint to add color to the corner)
- Can also use any alert variant from `alerts.md`

## Rules

- Responsive: hidden on mobile with a trigger mechanism
- Icons: 24x24px, heading color
- Multi-level menus: indent with 52px left padding
- Spacing follows 8px grid
- Only neutral, brand, or status tokens — no arbitrary colors
