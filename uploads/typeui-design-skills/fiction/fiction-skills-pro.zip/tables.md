# Tables

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Wrapper

- Horizontal scroll overflow
- Background: secondary-brand-softer
- Radius: 32px (the table reads as a card — uses card radius)
- Border: 4px, border-brand
- Shadow: none on rest

## Table Element

- Full width, left-aligned text (right-aligned for RTL)
- Font: 16px, body color

## Table Head

- Font: 18px, heading color, bold weight
- Background: secondary-brand
- Bottom border: 2px, border-default-subtle
- Cell padding: 32px horizontal, 20px vertical

## Table Body

- Row background: secondary-brand-softer
- Row bottom border: 2px, border-default-subtle (omit on last row to avoid doubling with wrapper border)
- Row hover: secondary-brand-soft background (optional)
- Row header: bold weight, heading color, no-wrap
- Cell padding: 32px horizontal, 24px vertical

## Rules

- Wrapper must have horizontal scroll overflow for responsive scrolling
- Last row: omit bottom border to avoid doubling with wrapper border
- Row headers: always `scope="row"` for semantic structure
- Hover on rows is optional
- No arbitrary hex codes — use token colors only
