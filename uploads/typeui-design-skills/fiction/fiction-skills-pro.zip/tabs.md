# Tabs

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs

- Typography: 18px, bold weight, body color
- Transitions: all properties, 200ms

## Variants

### 1. Underline (Default)

**Wrapper:** bottom border, 4px, border-brand

**Tab Item:**
- Padding: 24px horizontal, 20px vertical
- Bottom border: 4px, transparent
- Top corners: 16px radius
- Transition: colors, 150ms

| State | Appearance |
|---|---|
| Active | heading text, 4px border-brand bottom border (sits flush over the wrapper border) |
| Inactive | transparent bottom border; hover → heading text, 4px border-brand-subtle bottom border |
| Disabled | fg-disabled text, not-allowed cursor |

### 2. Pills

**Tab Item:**
- Padding: 20px horizontal, 14px vertical
- Radius: 16px (base)
- Border: 4px, border-brand
- Font weight: bold
- Transition: all, 200ms

| State | Appearance |
|---|---|
| Active | brand background, white text |
| Inactive | secondary-brand-softer background, heading text; hover → secondary-brand-soft background |
| Disabled | fg-disabled text, not-allowed cursor |

### 3. Full Width

Children overlap with -4px left margin on all except first so brand outlines share edges.

**Tab Item:**
- Full width, centered text
- Padding: 24px horizontal, 20px vertical
- Background: secondary-brand-softer
- Border: 4px, border-brand
- Transition: colors, 150ms
- Hover: secondary-brand-soft background

| State | Appearance |
|---|---|
| Active | brand background, white text |
| First item | rounded inline-start (16px) |
| Last item | rounded inline-end (16px) |

## Tabs with Icons

- Icon size: 20x20px or 24x24px
- Spacing: 10px right margin
- Layout: inline-flex, centered
- Icons inherit the text color of the tab state
