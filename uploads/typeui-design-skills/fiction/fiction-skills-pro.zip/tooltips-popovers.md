# Tooltips & Popovers

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Tooltips

### Core Specs
- Padding: 14px horizontal, 10px vertical
- Font: 16px, bold weight
- Radius: 16px
- Border: 4px, border-brand
- Shadow: shadow-sm (2px brand-color offset block)
- Transition: opacity, 200ms

### Dark (Default)
- Background: brand (#222222)
- Text: white
- Border: 4px, border-brand-strong

### Light
- Background: secondary-brand-softer
- Text: heading
- Border: 4px, border-brand

## Popovers

### Core Specs
- Background: secondary-brand-softer
- Radius: 16px (base)
- Shadow: shadow-md (4px brand-color offset block)
- Border: 4px, border-brand
- Transition: opacity, 200ms

### Header / Title
- Padding: 16px horizontal, 12px vertical
- Background: secondary-brand
- Bottom border: 2px, border-default-subtle
- Font: 18px, bold weight, heading color

### Body / Content
- Standard: 16px horizontal, 12px vertical padding; 16px, body color
- Rich: 24px padding; 16px, body color, max 4 rows per paragraph

## Arrows

- Size: 12x12px rotated 45deg
- Color must match the background of the tooltip/popover variant
- Outline: 4px brand-color stroke on the two outward-facing edges so the arrow matches the component outline

## Rules

- Tooltips: 16px radius, 4px brand border
- Popovers: 16px radius, 4px brand border
- Dark tooltips: brand background, white text
- Light tooltips/popovers: secondary-brand-softer background + brand outline
- Arrows match parent background color and continue the brand outline
