# Typography

> Dependencies: `colors.md`

## Core Rules

- **Font:** Cossette Texte (Google Fonts), serif fallback — configured at app level, never override. Use as the single typeface across headings, body, UI labels.
- **Headings:** bold weight (700), heading text color, oversized display sizing
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels
- **Headings are hard-capped at 2 rows.** If text would wrap to a 3rd row, shorten the wording, reduce size by one step, or break to a new line manually.
- **Paragraphs are hard-capped at 4 rows.** Split into multiple paragraphs or trim copy if it would overflow.
- **Generous free space around every heading and paragraph** — see "Spacing Around Text" below.

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 144px | 1 | -1.5px | 48px |
| `h2` | 120px | 1.05 | -1px | 40px |
| `h3` | 96px | 1.05 | -0.5px | 32px |
| `h4` | 72px | 1.1 | — | 24px |
| `h5` | 56px | 1.15 | — | 20px |
| `h6` | 40px | 1.2 | — | 16px |

Minimum heading size on desktop is **96px** for `h1`–`h3`. Smaller sizes are reserved for `h4`–`h6` (subheaders inside cards or compact UI areas).

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 96px | 64px |
| `h2` | 80px | 56px |
| `h3` | 64px | 48px |
| `h4` | 52px | 40px |
| `h5` | 40px | 32px |
| `h6` | 32px | 24px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1 for any heading. Never let a heading wrap beyond 2 rows.

## Paragraphs

### Leading Paragraph
- Size: 24px
- Weight: normal
- Color: body
- Line-height: 1.6
- Max width: ~60 characters
- Max rows: 4

### Normal Paragraph
- Size: 18px
- Weight: normal
- Color: body
- Line-height: 1.6
- Max width: ~60 characters
- Max rows: 4

### Small Supporting Copy
- Size: 14px
- Weight: normal
- Color: body
- Line-height: 1.5
- Max rows: 4
- Use only for helper text, legal text, captions, metadata.

## Spacing Around Text

Headings and paragraphs must always sit inside a generous amount of empty space:

| Element | Margin / padding rule |
|---|---|
| `h1` | min 64px above, min 48px below |
| `h2` | min 56px above, min 40px below |
| `h3` | min 48px above, min 32px below |
| `h4`–`h6` | min 32px above, min 24px below |
| Paragraph (any size) | min 24px above, min 24px below, min 24px horizontal padding from any container edge |

Never let a heading or paragraph touch the edge of its container. Never stack two text blocks with less than 24px between them.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 18px | 700 (bold) |
| Input labels | 16px or 18px | 700 (bold) |
| Captions / meta / badges | 14px or 16px | 700 (bold) |

Do not apply paragraph line-height (1.6) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline, hover → no underline
- **CTA links:** fg-brand color, bold weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, 0.4px letter-spacing, 12px or 14px

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via custom properties). Size, weight, and spacing remain constant.

## Do

- Always use the configured brand typeface (Cossette Texte) for every text element to maintain brand personality.
- Use the `heading` token (resolves to `brand-strong` / Type Black on light backgrounds) for primary text content to keep contrast crisp.
- Reserve generous empty space around every heading and paragraph (per the Spacing Around Text table).

## Don't

- Do not introduce additional font families. The configured brand typeface (Cossette Texte) is the sole typographic voice of the system. No mixing with other display, serif, or system fonts.
- Do not let a heading wrap beyond 2 rows or a paragraph beyond 4 rows.
- Do not use brand color tokens for long-form paragraphs.
