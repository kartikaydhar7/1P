# Borders

## Width Scale

| Context | Width |
|---|---|
| Inputs (focus/error state only) | 2px |

## Rules

- No visible borders on cards, sections, containers, or layout elements
- Borders are only used on form inputs during focus or error states
- Dashed borders only for special cases like file dropzones
- Section separation is achieved through alternating background colors, not borders
- Never add decorative borders to cards, wrappers, nav bars, or content sections

## Usage

| Context | Width |
|---|---|
| Inputs / selects / textareas | no border default; 2px on focus or error |
| Buttons | no border — use background color for variant distinction |
| Cards / containers / sections | no border — use background color contrast |
