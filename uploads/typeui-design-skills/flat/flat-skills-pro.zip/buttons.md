# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except ghost and disabled)

- **Radius:** 6px (base) or 9999px for pills
- **Border:** none
- **Shadow:** none
- **Glint effect:** none — this is a flat design system, no inset highlights or outer glows
- **Font weight:** 500 (medium)
- **Font:** Geist
- **Box sizing:** border-box
- **Transition:** color transitions on hover

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 12px | 6px |
| Small | 14px | 12px | 8px |
| Base (default) | 14px | 16px | 10px |
| Large | 16px | 20px | 12px |
| Extra large | 16px | 24px | 14px |

## Variants

### Brand
- **Background:** brand token
- **Border:** none
- **Text:** white
- **Hover:** brand-strong background
- **Focus ring:** 4px, brand-medium color
- **Glint:** none

### Secondary
- **Background:** neutral-secondary-soft
- **Border:** none
- **Text:** body color
- **Hover:** neutral-tertiary-soft background, heading text color
- **Focus ring:** 4px, neutral-tertiary color
- **Glint:** none

### Tertiary
- **Background:** neutral-tertiary-soft
- **Border:** none
- **Text:** body color
- **Hover:** neutral-tertiary-medium background, heading text color
- **Focus ring:** 4px, neutral-tertiary-soft color
- **Glint:** none

### Success
- **Background:** success token
- **Border:** none
- **Text:** white
- **Hover:** success-strong background
- **Focus ring:** 4px, success-medium color
- **Glint:** none

### Danger
- **Background:** danger token
- **Border:** none
- **Text:** white
- **Hover:** danger-strong background
- **Focus ring:** 4px, danger-medium color
- **Glint:** none

### Warning
- **Background:** warning token
- **Border:** none
- **Text:** white
- **Hover:** warning-strong background
- **Focus ring:** 4px, warning-medium color
- **Glint:** none

### Dark
- **Background:** dark token
- **Border:** none
- **Text:** white
- **Hover:** dark-strong background
- **Focus ring:** 4px, neutral-tertiary color
- **Glint:** none

### Ghost (NO shadow, NO glint)
- **Background:** transparent
- **Border:** none
- **Text:** heading color
- **Hover:** neutral-secondary-soft background
- **Focus ring:** 4px, neutral-tertiary color
- **No shadow, no glint effect**

### Disabled (NO shadow, NO glint)
- **Background:** disabled token
- **Border:** none
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no glint**

## Icons in Buttons

- Icon size: 16x16px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
