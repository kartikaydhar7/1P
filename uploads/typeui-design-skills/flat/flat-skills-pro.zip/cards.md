# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-secondary-soft
- **Border:** none
- **Radius:** 6px (base)
- **Shadow:** none

## Card Heading

- Desktop: 20px, medium weight, heading color
- Mobile: 16px, medium weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-secondary-soft
- Border: none
- Radius: 6px
- Shadow: none
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: neutral-tertiary-soft background
- Transition: colors
- Cursor: pointer

## Rules

- Background: neutral-secondary-soft
- Border: none — cards must never have visible borders
- Radius: 6px
- Shadow: none
- Interactive hover: neutral-tertiary-soft background
- Non-interactive: no hover styles
- Separation between cards is achieved through background color contrast and spacing, never through borders or shadows
