# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFFFF | #2C3E50 |
| neutral-primary | #FFFFFF | #1A252F |
| neutral-primary-medium | #FFFFFF | #34495E |
| neutral-primary-strong | #FFFFFF | #4B6584 |
| neutral-secondary-soft | #ECF0F1 | #2C3E50 |
| neutral-secondary | #ECF0F1 | #1A252F |
| neutral-secondary-medium | #ECF0F1 | #34495E |
| neutral-secondary-strong | #ECF0F1 | #4B6584 |
| neutral-tertiary-soft | #D5DBDB | #2C3E50 |
| neutral-tertiary | #D5DBDB | #34495E |
| neutral-tertiary-medium | #D5DBDB | #4B6584 |
| neutral-quaternary | #BDC3C7 | #4B6584 |
| quaternary-medium | #BDC3C7 | #5D7B99 |
| gray | #95A5A6 | #5D7B99 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #E8F8F5 | #0A3D32 |
| brand-soft | #D0F0E8 | #117A63 |
| brand | #19BC9C | #1ABC9C |
| brand-medium | #A2E0D0 | #117A63 |
| brand-strong | #148F77 | #19BC9C |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #EAFAF1 | #0B3D2E |
| success | #27AE60 | #2ECC71 |
| success-medium | #D5F5E3 | #1A7A45 |
| success-strong | #1E8449 | #27AE60 |
| danger-soft | #FDEDEC | #4A0E0E |
| danger | #E74C3C | #E74C3C |
| danger-medium | #FADBD8 | #922B21 |
| danger-strong | #C0392B | #C0392B |
| warning-soft | #FEF5E7 | #7E5109 |
| warning | #F39C12 | #F39C12 |
| warning-medium | #FDEBD0 | #9C640C |
| warning-strong | #D68910 | #D68910 |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(0,0,0,0) | rgba(0,0,0,0) |
| `--color-1-700` | rgba(0,0,0,0) | rgba(0,0,0,0) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #2C3E50 | #2C3E50 |
| dark-strong | #1A252F | #34495E |
| disabled | #ECF0F1 | #34495E |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #9B59B6 |
| sky | #3498DB |
| teal | #16A085 |
| pink | #E91E63 |
| cyan | #1ABC9C |
| fuchsia | #8E44AD |
| indigo | #2980B9 |
| orange | #F39C12 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #2C3E50 | #2C3E50 |
| heading | #2C3E50 | #ECF0F1 |
| body | #34495E | #BDC3C7 |
| body-subtle | #7F8C8D | #95A5A6 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #A2E0D0 | #0A3D32 |
| fg-brand | #19BC9C | #1ABC9C |
| fg-brand-strong | #148F77 | #A2E0D0 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #27AE60 | #1E8449 |
| fg-success-strong | #1E8449 | #2ECC71 |
| fg-danger | #E74C3C | #E74C3C |
| fg-danger-strong | #C0392B | #E74C3C |
| fg-warning-subtle | #E67E22 | #F39C12 |
| fg-warning | #D68910 | #F1C40F |
| fg-disabled | #95A5A6 | #7F8C8D |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #F1C40F | #F1C40F |
| fg-info | #2C3E50 | #3498DB |
| fg-purple | #9B59B6 | #9B59B6 |
| fg-purple-strong | #8E44AD | #BB8FCE |
| fg-cyan | #1ABC9C | #1ABC9C |
| fg-indigo | #2980B9 | #2980B9 |
| fg-pink | #E91E63 | #E91E63 |
| fg-lime | #27AE60 | #2ECC71 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #2C3E50 | #7F8C8D |
| border-buffer | #FFFFFF | #1A252F |
| border-buffer-medium | #FFFFFF | #2C3E50 |
| border-buffer-strong | #FFFFFF | #34495E |
| border-muted | #ECF0F1 | #1A252F |
| border-light-subtle | #ECF0F1 | #1A252F |
| border-light | #ECF0F1 | #2C3E50 |
| border-light-medium | #ECF0F1 | #34495E |
| border-default-subtle | #D5DBDB | #1A252F |
| border-default | #D5DBDB | #2C3E50 |
| border-default-medium | #D5DBDB | #34495E |
| border-default-strong | #D5DBDB | #4B6584 |
| border-success-subtle | #A9DFBF | #0B3D2E |
| border-success | #27AE60 | #1E8449 |
| border-danger-subtle | #F5B7B1 | #78281F |
| border-danger | #E74C3C | #E74C3C |
| border-warning-subtle | #FAD7A0 | #7E5109 |
| border-warning | #F39C12 | #F39C12 |
| border-brand-subtle | #A2E0D0 | #0A3D32 |
| border-brand-light | #19BC9C | #19BC9C |
| border-brand | #148F77 | #1ABC9C |
| border-dark-subtle | #2C3E50 | #4B6584 |
| border-purple | #9B59B6 | #9B59B6 |
| border-orange | #F39C12 | #F39C12 |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
