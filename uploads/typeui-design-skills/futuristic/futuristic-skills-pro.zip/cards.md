# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-primary-soft
- **Border:** 1px, border-default color
- **Radius:** 2px (base)
- **Shadow:** shadow-xs
- **Cut corners:** Apply `clip-path: polygon(14px 0%, 100% 0%, 100% calc(100% - 14px), calc(100% - 14px) 100%, 0% 100%, 0% 14px)` for angled corner geometry

## Card Heading

- Desktop: 20px, medium weight, heading color, uppercase, 1px letter-spacing
- Mobile: 16px, medium weight, heading color, uppercase, 0.5px letter-spacing
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-primary-soft
- Border: 1px, border-default
- Radius: 2px
- Shadow: shadow-xs
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: neutral-secondary-medium background, border transitions to border-brand-subtle
- Transition: all properties 150ms ease-out
- Cursor: pointer

## Rules

- Background: neutral-primary-soft
- Border: 1px, border-default
- Radius: 2px
- Shadow: shadow-xs
- Interactive hover: neutral-secondary-medium background, border-brand-subtle border glow
- Non-interactive: no hover styles
