# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #0D0D14 | #0A0A10 |
| neutral-primary | #08080E | #04040A |
| neutral-primary-medium | #12121C | #0E0E16 |
| neutral-primary-strong | #1C1C2A | #181822 |
| neutral-secondary-soft | #0B0B12 | #08080E |
| neutral-secondary | #09090F | #06060C |
| neutral-secondary-medium | #10101A | #0C0C14 |
| neutral-secondary-strong | #1A1A26 | #14141E |
| neutral-tertiary-soft | #0E0E16 | #0A0A12 |
| neutral-tertiary | #14141E | #10101A |
| neutral-tertiary-medium | #1C1C28 | #181822 |
| neutral-quaternary | #24243A | #1E1E2C |
| quaternary-medium | #2E2E42 | #282840 |
| gray | #3A3A52 | #343450 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #081C22 | #061518 |
| brand-soft | #0E3340 | #0A2832 |
| brand | #54EAFD | #54EAFD |
| brand-medium | #124858 | #0D3540 |
| brand-strong | #3DC8DB | #42D0E2 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #001F14 | #001A10 |
| success | #00E676 | #00E676 |
| success-medium | #003D27 | #002E1B |
| success-strong | #00C060 | #00B854 |
| danger-soft | #2A0010 | #1F000C |
| danger | #FF003C | #FF1744 |
| danger-medium | #4D001C | #3A0015 |
| danger-strong | #D40030 | #D40030 |
| warning-soft | #2A1A00 | #1F1400 |
| warning | #FFD600 | #FFEA00 |
| warning-medium | #3D2600 | #2E1C00 |
| warning-strong | #E6B800 | #E6C200 |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(84,234,253,0.15) | rgba(84,234,253,0.10) |
| `--color-1-700` | rgba(0,0,0,0.30) | rgba(0,0,0,0.40) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #0A0A14 | #0A0A14 |
| dark-strong | #060610 | #1A1A28 |
| disabled | #0D0D16 | #0A0A12 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #B44DFF |
| sky | #00D4FF |
| teal | #00FFD1 |
| pink | #FF1493 |
| cyan | #54EAFD |
| fuchsia | #FF00FF |
| indigo | #6366F1 |
| orange | #FF6B1A |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #0A0A10 | #0A0A10 |
| heading | #F0F0F8 | #EEEEF6 |
| body | #8B8CA0 | #7E7F94 |
| body-subtle | #6E6F84 | #5C5D72 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #1B6070 | #0E3D4E |
| fg-brand | #54EAFD | #54EAFD |
| fg-brand-strong | #42D0E2 | #8AF2FF |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #00E676 | #00C060 |
| fg-success-strong | #00C060 | #39FF8E |
| fg-danger | #FF003C | #FF4D6E |
| fg-danger-strong | #D40030 | #FF6B88 |
| fg-warning-subtle | #FFD600 | #FFEA00 |
| fg-warning | #E6B800 | #FFEA00 |
| fg-disabled | #4A4A5E | #3A3A50 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FCEE0A | #FCEE0A |
| fg-info | #54EAFD | #7CF0FF |
| fg-purple | #B44DFF | #B44DFF |
| fg-purple-strong | #9B30FF | #D4A0FF |
| fg-cyan | #54EAFD | #54EAFD |
| fg-indigo | #6366F1 | #818CF8 |
| fg-pink | #FF1493 | #FF1493 |
| fg-lime | #76FF03 | #76FF03 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #2A2A3E | #3A3A52 |
| border-buffer | #08080E | #04040A |
| border-buffer-medium | #08080E | #0E0E16 |
| border-buffer-strong | #08080E | #1A1A28 |
| border-muted | #0B0B12 | #06060C |
| border-light-subtle | #0E0E16 | #06060C |
| border-light | #0E0E16 | #10101A |
| border-light-medium | #0E0E16 | #1C1C28 |
| border-default-subtle | #181822 | #0A0A12 |
| border-default | #181822 | #14141E |
| border-default-medium | #181822 | #1E1E2C |
| border-default-strong | #181822 | #2A2A3E |
| border-success-subtle | #004D30 | #00331F |
| border-success | #00E676 | #00C060 |
| border-danger-subtle | #660020 | #4D0018 |
| border-danger | #FF003C | #FF003C |
| border-warning-subtle | #664800 | #4D3600 |
| border-warning | #FFD600 | #FFEA00 |
| border-brand-subtle | #1B6070 | #0E3D4E |
| border-brand-light | #54EAFD | #54EAFD |
| border-brand | #54EAFD | #7CF0FF |
| border-dark-subtle | #2A2A3E | #22222E |
| border-purple | #B44DFF | #B44DFF |
| border-orange | #FF6B1A | #FF6B1A |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
