# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1152px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 96px vertical padding
- A **unified dark gradient background** across all sections — do NOT alternate between different background colors. The entire page uses a single continuous dark gradient (e.g. from `#04040A` via `#0A0A14` to `#08080E`) so all sections share the same dark tone. Individual sections should be transparent or inherit the page-level gradient.
- A centered container (max-width 1152px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.
- Favor sharp, fast transitions (150ms–250ms) with ease-out timing for a snappy, high-tech feel. Avoid slow, floaty easing.
- Subtle glitch or flicker effects on headings and CTAs reinforce the cyberpunk aesthetic — use sparingly.

## Backgrounds & Visual Depth

- Default to layered, atmospheric backgrounds rather than flat solid fills.
- Apply contextual treatments — neon gradient meshes, digital noise textures, geometric grid patterns, layered transparencies, dramatic neon-glow shadows, angular decorative borders, scanline overlays — that align with the cyberpunk aesthetic.
- Use subtle diagonal lines, hex grids, or circuit-board patterns as background textures to reinforce the futuristic tech atmosphere.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.

## Must

- All sections: consistent 96px vertical padding
- All containers: max-width 1152px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
