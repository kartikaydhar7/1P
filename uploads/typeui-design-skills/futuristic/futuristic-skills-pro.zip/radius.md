# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 2px | Buttons, cards, inputs, modals, sections — sharp angular edges with a subtle chamfer |
| default | 2px | Badges, tooltips, dropdown items, small controls |
| sm | 0px | Checkboxes, tiny elements — fully sharp |
| full | 9999px | Pills, avatars, toggles, dot indicators |

## Rules

- 2px is the default radius across the product — sharp and angular for the cyberpunk aesthetic
- Use clip-path with angled polygon cuts for primary interactive elements (buttons, cards, inputs) to achieve the signature cut-corner look: `clip-path: polygon(12px 0%, 100% 0%, 100% calc(100% - 12px), calc(100% - 12px) 100%, 0% 100%, 0% 12px)`
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
