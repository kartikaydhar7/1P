# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `0 1px rgba(84, 234, 253, 0.06)` |
| shadow-xs | `0 1px 3px 0 rgba(84, 234, 253, 0.08)` |
| shadow-sm | `0 1px 4px 0 rgba(84, 234, 253, 0.12), 0 1px 2px -1px rgba(0, 0, 0, 0.25)` |
| shadow-md | `0 4px 8px -1px rgba(84, 234, 253, 0.14), 0 2px 4px -2px rgba(0, 0, 0, 0.3)` |
| shadow-lg | `0 10px 20px -3px rgba(84, 234, 253, 0.15), 0 4px 6px -4px rgba(0, 0, 0, 0.35)` |
| shadow-xl | `0 20px 30px -5px rgba(84, 234, 253, 0.14), 0 8px 10px -6px rgba(0, 0, 0, 0.35)` |
| shadow-2xl | `0 25px 50px -12px rgba(84, 234, 253, 0.22)` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls, lightweight cards | shadow-xs or shadow-sm |
| Standard cards, popovers, dropdowns | shadow-md |
| Prominent cards, sticky surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use only these tokens — no custom box-shadow values
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
