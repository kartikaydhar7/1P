# Tooltips & Popovers

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Tooltips

### Core Specs
- Padding: 12px horizontal, 8px vertical
- Font: 13px, medium weight
- Radius: 2px (default)
- Shadow: shadow-xs
- Transition: opacity, 200ms ease-out

### Dark (Default)
- Background: dark
- Text: white
- Border: 1px, border-default-medium

### Light
- Background: neutral-primary-medium
- Text: heading color
- Border: 1px, border-default

## Popovers

### Core Specs
- Background: neutral-primary
- Radius: 2px (base)
- Shadow: shadow-md
- Border: 1px, border-default
- Transition: opacity, 200ms ease-out
- Cut corners: Apply `clip-path: polygon(10px 0%, 100% 0%, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0% 100%, 0% 10px)` for angled corner geometry

### Header / Title
- Padding: 12px horizontal, 8px vertical
- Background: neutral-secondary-soft
- Bottom border: border-default
- Font: 13px, medium weight, heading color, uppercase, 0.5px letter-spacing

### Body / Content
- Standard: 12px horizontal, 8px vertical padding; 13px, body color
- Rich: 16px padding; 13px, body color

## Arrows

- Size: 8x8px rotated 45deg
- Color must match the background of the tooltip/popover variant

## Rules

- Tooltips: 2px radius
- Popovers: 2px radius
- Dark tooltips: dark background, white text
- Light tooltips/popovers: semantic neutral background + border tokens
- Arrows match parent background color
