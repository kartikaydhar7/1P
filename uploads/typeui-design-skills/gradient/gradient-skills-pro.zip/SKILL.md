# Design System — Agent Instructions

This skill describes the visual design language for all UI output. Every component, layout, and page should follow the design specs in the module files below. These describe *what the design looks like* — you choose how to implement the styles.

## Style
A light, gradient-forward interface with glassmorphism panels, Geist sans-serif typography, soft pastel multi-stop gradient backgrounds, and pill-shaped interactive elements — delivering a modern, airy, premium aesthetic.

## Gradient Background Rule (CRITICAL)

**Every page and section background MUST be a beautiful multi-stop gradient — NEVER a flat single color.** This is the defining visual characteristic of this design system.

- Use 3–5 color stops with harmonious pastel combinations: soft pinks, lavenders, mints, sky blues, peaches
- Example gradients: `linear-gradient(135deg, #FCE7F3 0%, #EDE9FE 25%, #DBEAFE 50%, #D1FAE5 75%, #FEF3C7 100%)`
- Alternate gradient directions between sections for visual variety
- Layer radial or conic gradients for depth when appropriate
- Cards and interactive elements float on top using glassmorphism (translucent white + backdrop-blur)

## Glassmorphism Rule

All cards, panels, buttons, inputs, dropdowns, modals, and interactive containers use:
- Background: rgba(255,255,255,0.6) with backdrop-filter: blur(24px)
- Border: 1px solid rgba(255,255,255,0.8)
- Soft, diffused shadows

## Before Writing Any Code

1. **Read every module that applies.** For a landing page, read at minimum: `layout.md`, `typography.md`, `colors.md`, `buttons.md`, `cards.md`, `shadows.md`, `radius.md`, `borders.md`. Do NOT write JSX until you have loaded all relevant modules.

## Critical Rules

- **Tokens are AGNOSTIC, NOT Tailwind classes:** The tokens defined in the `.md` files (like `neutral-primary-soft`, `heading`, `border-default`) are agnostic design system tokens, NOT literal Tailwind classes. Do not blindly use classes like `bg-neutral-primary-soft` unless you have explicitly mapped them in the CSS/Tailwind configuration. You must implement the mapping yourself.

- **Cross-reference modules.** A card containing buttons must satisfy both `cards.md` AND `buttons.md`.
- **Gradient backgrounds are mandatory.** Every page and section MUST use a multi-stop pastel gradient — never a flat single color. This is non-negotiable.
- **Dark mode is automatic.** The CSS custom properties resolve differently in light/dark via `@media (prefers-color-scheme: dark)`. Never manually swap colors.
- **Every interactive element needs hover, focus, and disabled states** — defined in the relevant module.
- **Use semantic HTML:** proper heading hierarchy (`h1`→`h6`), `<button>` for actions, `<a>` for navigation, ARIA attributes where needed.

## Module Index

### Foundation (read first for any UI work)
- [colors.md](colors.md) — all background, text, and border color tokens
- [typography.md](typography.md) — heading scale, paragraphs, labels, links
- [layout.md](layout.md) — spacing rhythm, containers, animation, visual depth
- [radius.md](radius.md) — border-radius scale
- [shadows.md](shadows.md) — elevation tokens
- [borders.md](borders.md) — border widths and styles

### Components
- [buttons.md](buttons.md) — button variants, sizes, states, glint effect
- [button-group.md](button-group.md) — grouped button structure
- [cards.md](cards.md) — card structure, background, interactivity
- [inputs.md](inputs.md) — form controls, labels, states
- [alerts.md](alerts.md) — alert variants
- [badges.md](badges.md) — badge variants, sizes, dismissible chips
- [lists.md](lists.md) — list components
- [avatars.md](avatars.md) — avatar variants, sizes, indicators
- [icon-shapes.md](icon-shapes.md) — icon containers

### Complex Components
- [accordion.md](accordion.md) — accordion variants
- [dropdown.md](dropdown.md) — dropdown menus
- [modals.md](modals.md) — modal dialogs
- [tabs.md](tabs.md) — tab navigation
- [tables.md](tables.md) — table structure
- [pagination.md](pagination.md) — pagination components
- [sidebars.md](sidebars.md) — sidebar navigation
- [radios-checkboxes-toggle.md](radios-checkboxes-toggle.md) — selection controls
- [tooltips-popovers.md](tooltips-popovers.md) — tooltips and popovers
- [content.md](content.md) — grid system, responsiveness
