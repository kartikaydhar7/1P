# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** rgba(255,255,255,0.6) with backdrop-blur-xl (backdrop-filter: blur(24px))
- **Border:** 1px solid rgba(255,255,255,0.8)
- **Radius:** 32px
- **Padding:** 32px
- **Shadow:** 0 8px 30px rgb(0,0,0,0.04)

## Card Heading

- Desktop: 20px, medium weight, heading color
- Mobile: 16px, medium weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: rgba(255,255,255,0.6) with backdrop-blur-xl
- Border: 1px solid rgba(255,255,255,0.8)
- Radius: 32px
- Padding: 32px
- Shadow: 0 8px 30px rgb(0,0,0,0.04)
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: shadow 0 8px 30px rgb(0,0,0,0.08)
- Transition: shadow (transition-shadow)
- Cursor: pointer

## Rules

- Background: rgba(255,255,255,0.6) with backdrop-blur-xl (backdrop-filter: blur(24px))
- Border: 1px solid rgba(255,255,255,0.8)
- Radius: 32px
- Padding: 32px
- Shadow: 0 8px 30px rgb(0,0,0,0.04)
- Interactive hover: shadow changes to 0 8px 30px rgb(0,0,0,0.08), transition-shadow
- Non-interactive: no hover styles
