# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | rgba(255,255,255,0.6) | rgba(255,255,255,0.06) |
| neutral-primary | #FFFFFF | #030712 |
| neutral-primary-medium | rgba(255,255,255,0.75) | rgba(255,255,255,0.08) |
| neutral-primary-strong | rgba(255,255,255,0.85) | rgba(255,255,255,0.12) |
| neutral-secondary-soft | rgba(248,250,252,0.5) | rgba(248,250,252,0.04) |
| neutral-secondary | #F8FAFC | #030712 |
| neutral-secondary-medium | rgba(248,250,252,0.65) | rgba(248,250,252,0.06) |
| neutral-secondary-strong | rgba(248,250,252,0.8) | rgba(248,250,252,0.1) |
| neutral-tertiary-soft | rgba(241,245,249,0.5) | rgba(241,245,249,0.04) |
| neutral-tertiary | rgba(241,245,249,0.65) | rgba(241,245,249,0.06) |
| neutral-tertiary-medium | rgba(241,245,249,0.75) | rgba(241,245,249,0.08) |
| neutral-quaternary | rgba(226,232,240,0.6) | rgba(226,232,240,0.08) |
| quaternary-medium | rgba(226,232,240,0.75) | rgba(226,232,240,0.12) |
| gray | rgba(203,213,225,0.6) | rgba(203,213,225,0.1) |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #F0FDFA | #042F2E |
| brand-soft | #CCFBF1 | #134E4A |
| brand | #0D9488 | #14B8A6 |
| brand-medium | #99F6E4 | #134E4A |
| brand-strong | #0F766E | #0D9488 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #ECFDF5 | #002C22 |
| success | #007A55 | #009966 |
| success-medium | #D0FAE5 | #004F3B |
| success-strong | #006045 | #007A55 |
| danger-soft | #FEF0F2 | #4D0218 |
| danger | #C70036 | #C70036 |
| danger-medium | #FFE4E6 | #8B0836 |
| danger-strong | #A50036 | #A50036 |
| warning-soft | #FFF7ED | #7C2D12 |
| warning | #F97316 | #F97316 |
| warning-medium | #FFEDD5 | #7C2D12 |
| warning-strong | #C2410C | #C2410C |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.35) | rgba(255,255,255,0.12) |
| `--color-1-700` | rgba(0,0,0,0.04) | rgba(0,0,0,0.25) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #0F172A | #0F172A |
| dark-strong | #020617 | #1E293B |
| disabled | rgba(241,245,249,0.6) | rgba(30,41,59,0.6) |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #A78BFA |
| sky | #38BDF8 |
| teal | #2DD4BF |
| pink | #F472B6 |
| cyan | #22D3EE |
| fuchsia | #D946EF |
| indigo | #818CF8 |
| orange | #FB923C |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #0F172A | #0F172A |
| heading | #0F172A | #F8FAFC |
| body | #475569 | #94A3B8 |
| body-subtle | #64748B | #94A3B8 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #99F6E4 | #134E4A |
| fg-brand | #0D9488 | #2DD4BF |
| fg-brand-strong | #0F766E | #99F6E4 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #047857 | #065F46 |
| fg-success-strong | #065F46 | #10B981 |
| fg-danger | #BE123C | #F43F5E |
| fg-danger-strong | #881337 | #F87171 |
| fg-warning-subtle | #EA580C | #F97316 |
| fg-warning | #7C2D12 | #FBBF24 |
| fg-disabled | #9CA3AF | #6B7280 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #312E81 | #93C5FD |
| fg-purple | #9333EA | #A855F7 |
| fg-purple-strong | #7E3AF2 | #DDD6FE |
| fg-cyan | #0891B2 | #06B6D4 |
| fg-indigo | #4F46E5 | #4F46E5 |
| fg-pink | #DB2777 | #DB2777 |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #0F172A | #334155 |
| border-buffer | #FFFFFF | #030712 |
| border-buffer-medium | #FFFFFF | #1E293B |
| border-buffer-strong | #FFFFFF | #334155 |
| border-muted | rgba(255,255,255,0.4) | rgba(255,255,255,0.04) |
| border-light-subtle | rgba(255,255,255,0.5) | rgba(255,255,255,0.04) |
| border-light | rgba(255,255,255,0.6) | rgba(255,255,255,0.06) |
| border-light-medium | rgba(255,255,255,0.7) | rgba(255,255,255,0.08) |
| border-default-subtle | rgba(255,255,255,0.6) | rgba(255,255,255,0.06) |
| border-default | rgba(255,255,255,0.8) | rgba(255,255,255,0.08) |
| border-default-medium | rgba(255,255,255,0.85) | rgba(255,255,255,0.1) |
| border-default-strong | rgba(255,255,255,0.9) | rgba(255,255,255,0.14) |
| border-success-subtle | #A7F3D0 | #064E3B |
| border-success | #047857 | #065F46 |
| border-danger-subtle | #FECDD3 | #881337 |
| border-danger | #BE123C | #BE123C |
| border-warning-subtle | #FED7AA | #7C2D12 |
| border-warning | #EA580C | #F97316 |
| border-brand-subtle | #99F6E4 | #134E4A |
| border-brand-light | #14B8A6 | #14B8A6 |
| border-brand | #0D9488 | #2DD4BF |
| border-dark-subtle | #1E293B | #334155 |
| border-purple | #A78BFA | #A78BFA |
| border-orange | #FB923C | #FB923C |

## Semantic Usage Rules

- Page/section backgrounds: always a multi-stop gradient — never a flat single color. Use pastel gradient meshes (pinks, lavenders, mints, sky blues) for light mode
- Cards/panels: neutral-primary-soft background with backdrop-blur-xl for glassmorphism
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default (translucent white for glassmorphism)
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No flat, single-color page or section backgrounds — always use gradients
- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No manual light/dark value swapping — let the CSS custom properties handle it
