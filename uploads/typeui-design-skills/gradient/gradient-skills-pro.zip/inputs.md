# Inputs

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Display:** block, full width
- **Radius:** 9999px (pill shape — all inputs are pills by default)
- **Border:** 1px solid rgba(255,255,255,0.8)
- **Background:** rgba(255,255,255,0.6) with backdrop-blur-xl (backdrop-filter: blur(24px))
- **Shadow:** shadow-xs
- **Font:** 14px, Geist, heading color
- **Padding:** 12px horizontal (16px for pill shape), 10px vertical
- **Placeholder:** body color
- **Transition:** all properties, 200ms

## Label

- Display: block
- Font: 14px, medium weight, heading color
- Margin bottom: 8px
- Label `htmlFor` must match the input `id`

## States

### Default
- Border: 1px solid rgba(255,255,255,0.8)
- Background: rgba(255,255,255,0.6) with backdrop-blur-xl

### Hover
- Border: rgba(255,255,255,0.9)

### Focus
- No outline
- Border: border-brand
- Ring: 1px, brand color

### Success
- Border: border-success
- Focus ring: 1px, success color

### Error / Danger
- Border: border-danger
- Focus ring: 1px, danger color

### Disabled
- Background: disabled
- Text: fg-disabled
- Cursor: not-allowed

## Input with Icons

- Icon size: 16x16px
- Icon color: body
- Container: relative positioned wrapper
- Start icon: absolutely positioned left, 12px left padding — input gets 36px left padding
- End icon: absolutely positioned right, 12px right padding — input gets 36px right padding
- Icons vertically centered within the wrapper

## Rules

- Every input must have a unique `id`
- Every label must have a matching `htmlFor`
- Padding: 12px horizontal, 10px vertical unless overridden for icon variants
- No arbitrary hex or hardcoded colors
