# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1152px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 96px vertical padding
- A **transparent** background — the section inherits the page-level gradient. **Do NOT apply individual gradient backgrounds to sections.**
- A centered container (max-width 1152px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Backgrounds & Visual Depth

- **CRITICAL: The page has ONE single continuous multi-stop gradient background applied to the outermost page wrapper — NEVER a flat single color, and NEVER per-section gradients.** The entire page shares one gradient that flows from top to bottom. All sections are transparent and inherit this background.
- Use beautiful, harmonious pastel gradient combinations with 3–5 stops: soft pinks (#FCE7F3, #FBCFE8), lavenders (#EDE9FE, #DDD6FE), mints (#D1FAE5, #A7F3D0), sky blues (#DBEAFE, #BAE6FD), peaches (#FED7AA, #FFEDD5).
- Example page gradient: `linear-gradient(135deg, #FCE7F3 0%, #EDE9FE 20%, #DBEAFE 40%, #CCFBF1 60%, #D1FAE5 80%, #FEF3C7 100%)`
- **Do NOT apply separate gradient backgrounds to individual sections.** Sections must remain transparent so the single page gradient shows through.
- Apply contextual treatments — soft noise textures, layered transparencies — that align with the airy, premium aesthetic, but never as opaque section backgrounds.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.
- Cards and panels sit on top of the gradient background using glassmorphism (translucent white with backdrop-blur).

## Must

- All sections: consistent 96px vertical padding
- All containers: max-width 1152px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
