# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 32px | Cards, modals, sections, large panels |
| default | 16px | Badges, tooltips, dropdown items, small controls |
| sm | 8px | Checkboxes, tiny elements |
| full | 9999px | Buttons, inputs, pills, avatars, toggles, dot indicators |

## Rules

- 32px is the default radius for cards, panels, and containers
- 9999px (full/pill) is the default radius for all interactive elements: buttons, inputs, selects, search fields
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
