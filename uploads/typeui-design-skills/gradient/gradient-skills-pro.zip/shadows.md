# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `0 1px rgb(0 0 0 / 0.03)` |
| shadow-xs | `0 1px 2px 0 rgb(0 0 0 / 0.03)` |
| shadow-sm | `0 2px 4px 0 rgb(0 0 0 / 0.04)` |
| shadow-md | `0 8px 30px rgb(0 0 0 / 0.04)` |
| shadow-lg | `0 8px 30px rgb(0 0 0 / 0.08)` |
| shadow-xl | `0 16px 40px rgb(0 0 0 / 0.1)` |
| shadow-2xl | `0 24px 50px -12px rgb(0 0 0 / 0.15)` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls | shadow-xs or shadow-sm |
| Cards (default resting state), popovers, dropdowns | shadow-md |
| Cards (hover state), prominent surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use only these tokens — no custom box-shadow values
- Shadows are intentionally soft and diffused to match the glassmorphism aesthetic
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level (e.g. shadow-md → shadow-lg)
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
