# Accordion

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`

## Core Specs

- **Wrapper:** full width, 4px solid black border (border-default color), 20px radius, brand-secondary (white) background, shadow-md hard offset — clips first/last item corners
- **Item separator:** 2px solid black bottom border on every item except last

## Trigger (Button)

- **Layout:** flex, space-between, full width
- **Padding:** 32px horizontal, 24px vertical
- **Font:** Oswald, 20px, bold weight, uppercase
- **Text color:** brand color (deep green) over the white surface
- **Background:** brand-secondary (white)
- **Hover:** brand-quaternary background, black text
- **Focus:** outline none, 4px ring in brand-tertiary color
- **Transition:** colors, 200ms
- **Open state:** brand color background, brand-secondary (white) text

## Panel (Content)

- **Padding:** 32px horizontal, 24px vertical
- **Background:** brand-secondary (white)
- **Top border:** 2px solid black
- **Font:** Oswald, 18px, body color (over a dark background) or brand color (over the white panel) — when panel is white, body copy uses brand color set, 1.5 line-height

## Chevron Icon

- Size: 20x20px
- Color: brand color (matches trigger text)
- Closed: 0deg rotation
- Open: 180deg rotation
- Transition: transform, 200ms

## Variants

### Default (Collapse)
One panel open at a time. Items stacked inside a single shared bordered/rounded wrapper.

### Separated Cards
Each item is independent — has its own 4px solid black border, 20px radius, brand-secondary (white) background, and shadow-md hard offset. 16px bottom margin between items. No shared outer border.

### Always Open
Multiple panels can expand simultaneously. Same styling as Default.

### Flush
No outer border, no shadow. Trigger and panel have transparent backgrounds. Only 2px black bottom border dividers between items. Use inside containers that already provide a white surface.

## States

| State | Trigger appearance |
|---|---|
| Closed | brand color text, brand-secondary (white) background |
| Open | brand-secondary (white) text, brand color background |
| Hover | brand-quaternary background, black text |
| Focus | 4px brand-tertiary ring, no outline |
| Disabled | fg-disabled text, not-allowed cursor, no hover/focus |
