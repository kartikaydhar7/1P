# Alerts

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`

## Core Specs

- **Padding:** 24px
- **Radius:** 20px
- **Border:** 4px solid black
- **Shadow:** shadow-sm (6px 6px 0 #000000) — hard offset block
- **Heading:** Oswald, 20px, bold weight, uppercase
- **Body:** 16px, normal weight, 1.5 line-height

## Variants

### Brand
- **Background:** brand-secondary (white)
- **Border:** 4px solid black
- **Text:** brand color (heading + body)

### Success
- **Background:** success-soft
- **Border:** 4px solid black
- **Text:** fg-success-strong

### Danger
- **Background:** danger-soft
- **Border:** 4px solid black
- **Text:** fg-danger-strong

### Warning
- **Background:** warning-soft
- **Border:** 4px solid black
- **Text:** fg-warning
