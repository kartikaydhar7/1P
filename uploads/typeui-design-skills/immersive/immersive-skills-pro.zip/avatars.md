# Avatars

> Dependencies: `colors.md`, `radius.md`, `borders.md`

## Core Specs

- **Circular shape:** fully rounded (9999px)
- **Rounded square shape:** 20px radius
- **Default size:** 48x48px
- **Image fit:** cover
- **Border:** 4px solid black on every avatar (matches the system silhouette)

## Sizes

| Size | Dimensions | Radius |
|---|---|---|
| Extra Small | 24x24px | 8px |
| Small | 32x32px | 8px |
| Base | 40x40px | 20px |
| Large | 48x48px | 20px |
| XL | 64x64px | 20px |
| 2XL | 80x80px | 20px |

## Bordered Avatar

- 4px solid black border, fully rounded (or 20px for square avatars)
- Optional: shadow-xs (4px 4px 0 #000000) hard offset to lift the avatar off the canvas

## Stacked Avatars

- Displayed in a row (flex)
- Each avatar: 48x48px, fully rounded, 4px solid black border
- Overlap: -16px negative margin on all except first

### Stacked Counter
- Same size as avatars (48x48px), fully rounded, 4px solid black border
- Background: brand color, text: brand-secondary (white), 14px Oswald font, bold weight, uppercase
- Same overlap margin as other avatars

## Avatar with Text

- Flex row, 16px gap between avatar and text
- Avatar: 48x48px, fully rounded, 4px solid black border, cover fit
- Name: heading color, Oswald, bold weight, uppercase
- Subtitle: 14px, body color
