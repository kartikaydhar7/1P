# Badges

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `typography.md`

## Core Specs

- **Border:** 4px solid black
- **Default radius:** 20px
- **Pill radius:** 9999px
- **Font:** Oswald, bold weight, uppercase
- **Optional shadow:** shadow-2xs (2px 2px 0 #000000) for badges that need to pop off a card surface

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Default (small) | 14px | 12px | 4px |
| Large | 16px | 16px | 6px |

## Variants

### Brand
- **Background:** brand color (deep green)
- **Border:** 4px solid black
- **Text:** brand-secondary (white)

### Alternative (Neutral Soft)
- **Background:** brand-secondary (white)
- **Border:** 4px solid black
- **Text:** brand color

### Gray (Neutral Medium)
- **Background:** brand-quaternary (hot pink)
- **Border:** 4px solid black
- **Text:** black

### Danger
- **Background:** danger
- **Border:** 4px solid black
- **Text:** brand-secondary (white)

### Success
- **Background:** success
- **Border:** 4px solid black
- **Text:** brand-secondary (white)

### Warning
- **Background:** warning
- **Border:** 4px solid black
- **Text:** black

### Dark
- **Background:** black
- **Border:** 4px solid black
- **Text:** brand-secondary (white)

### Tertiary (Accent)
- **Background:** brand-tertiary (#0023D1)
- **Border:** 4px solid black
- **Text:** brand-secondary (white)

## Pill Badges

Use 9999px radius instead of 20px on any variant.

## Badges with Icons

- Icon size (default): 14x14px
- Icon size (large): 16x16px
- Icon spacing: 8px margin next to label

## Icon-only Badge

Square shape — equalize dimensions to 32x32px, no horizontal text padding, 20px radius, 4px solid black border.

## Dismissible Badges

Badge content + a close button. Close button hover backgrounds per variant:

| Variant | Close button hover background |
|---|---|
| Brand | brand-strong |
| Alternative | brand-quaternary |
| Gray | brand-tertiary |
| Danger | danger-strong |
| Success | success-strong |
| Warning | warning-strong |
| Tertiary | brand-quaternary |

## Dot / Notification Badge

- Positioned absolutely: -6px top, -6px right
- Size: 16x16px, fully rounded
- 2px solid black border
- Background: brand-quaternary (hot pink) for visibility against the brand-color canvas
