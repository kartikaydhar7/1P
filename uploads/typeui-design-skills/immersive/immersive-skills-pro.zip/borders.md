# Borders

## Width Scale

| Context | Width |
|---|---|
| Default (inputs, buttons, cards, surfaces) | 4px |
| Emphasis / focus | 4px (color shift instead of width shift) |
| Fine internal dividers | 2px |

## Rules

- Use solid black borders by default — heavy, posterlike, never soft
- Borders are a primary visual element, not an afterthought; they define the silhouette of every surface
- Cards over the brand-colored canvas MUST have a 4px solid black border
- Dashed borders only for special cases like file dropzones
- Components in the same family must use matching border widths
- Never mix 4px and 2px borders within a single component
- Focus states change border COLOR (e.g., to brand-tertiary) rather than width

## Usage

| Context | Width |
|---|---|
| Inputs / selects / textareas | 4px default; 4px brand-tertiary on focus or 4px danger border on error |
| Buttons | No border — silhouette comes from the hard offset shadow |
| Cards / containers / surfaces | 4px solid black, no exceptions |
| Internal dividers within a card | 2px solid black |
