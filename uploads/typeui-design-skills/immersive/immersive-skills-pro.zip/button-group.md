# Button Groups

> Dependencies: `buttons.md`, `colors.md`, `radius.md`, `shadows.md`, `borders.md`

## Core Specs

- **Wrapper:** inline-flex, 20px radius, 4px solid black border around the entire group, shadow-md (8px 8px 0 #000000) hard offset
- **Wrapper transform:** `skewX(-15deg)` on the wrapper so the entire group reads as one slanted poster — counter-skew the inner button labels and icons
- **Children overlap:** each child shares a 4px solid black divider on its trailing edge (no double borders)
- **Buttons inside the group must NOT have individual shadows or individual skews.** Only the wrapper has the shadow and the skew.

## Anatomy

### Wrapper
- Display: inline-flex
- Radius: 20px
- Border: 4px solid black
- Shadow: shadow-md (8px 8px 0 #000000)
- Transform: `skewX(-15deg)`

### First Button
- 20px radius on inline-start side only, 0 on inline-end
- No left divider

### Middle Button(s)
- No radius (0 on all corners)
- 4px solid black left divider

### Last Button
- 20px radius on inline-end side only, 0 on inline-start
- 4px solid black left divider

## Hover

- The wrapper shadow grows to shadow-lg (10px 10px 0 #000000) on hover
- Individual buttons inside may change background color on hover, but never grow their own shadow

## Rules

- Buttons inside groups follow all color/text styles from `buttons.md` (background, text color) except they do NOT have individual shadows or individual skews — those belong to the wrapper
- Counter-skew labels and icons `skewX(15deg)` so content reads upright
- Icon-only buttons: 20x20px icon, match height of text buttons
