# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Signature Style (applies to every variant except ghost and disabled)

Every button is a posterlike, skewed block with a hard black offset shadow. This is the most recognizable element of the system and must remain consistent across the entire app.

- **Cursor:** pointer
- **Display:** inline-flex
- **Padding:** 11px 33px
- **Text decoration:** none
- **Font:** Oswald, 25px, bold (700), uppercase
- **Color:** white text on top of the brand-secondary surface (overridden per variant)
- **Background:** brand-secondary (white) — buttons sit on top of the brand-colored canvas, so the white block is what gives them visual punch
- **Border:** none (silhouette is created by the offset shadow + skew, not a border)
- **Radius:** 20px (from `radius.md`)
- **Box shadow:** `6px 6px 0 0 #000000` (hard offset block — equivalent to shadow-sm in `shadows.md`)
- **Transform:** `skewX(-15deg)` on the button itself; the inner label content should be counter-skewed `skewX(15deg)` so the text reads upright while the silhouette stays slanted
- **Transition:** 1s on default rest state, 0.5s when entering hover/active

## Hover & Active

- **Box shadow:** `10px 10px 0 0 #000000` (the offset visibly grows — equivalent to shadow-lg)
- **Transition:** 0.5s
- **Optional translate:** the button may shift `-2px, -2px` to amplify the press-out feel as the shadow grows
- The skew and radius do not change on hover

## Focus

- 4px outline in brand-tertiary color, offset by 4px from the silhouette
- The hard shadow remains; the focus ring layers on top

## Sizes

All sizes preserve the 25px label / 11px 33px proportions for the default. Smaller and larger sizes scale proportionally while keeping the skew, radius, and hard shadow.

| Size | Font size | Horizontal padding | Vertical padding | Shadow |
|---|---|---|---|---|
| Extra small | 16px | 18px | 6px | shadow-2xs (2px 2px 0 #000) |
| Small | 18px | 22px | 8px | shadow-xs (4px 4px 0 #000) |
| Base (default) | 25px | 33px | 11px | shadow-sm (6px 6px 0 #000) |
| Large | 28px | 40px | 14px | shadow-md (8px 8px 0 #000) |
| Extra large | 32px | 48px | 18px | shadow-lg (10px 10px 0 #000) |

## Variants

### Brand (Primary CTA)
- **Background:** brand-secondary (white)
- **Text:** brand color (deep green)
- **Hover:** background stays brand-secondary; shadow grows to shadow-lg
- **Focus ring:** 4px, brand-tertiary color
- The primary CTA across the entire app uses this variant — every button is the brand-secondary (white) block sitting on the brand-colored canvas

### Secondary
- **Background:** brand-tertiary (#0023D1)
- **Text:** brand-secondary (white)
- **Hover:** background stays brand-tertiary; shadow grows to shadow-lg
- **Focus ring:** 4px, brand-quaternary color

### Tertiary
- **Background:** transparent over brand-secondary surfaces, or brand-secondary over brand surfaces
- **Text:** brand color
- **Border:** 4px solid black (this is the only variant where a border is used instead of a shadow-only silhouette)
- **Hover:** background fills with brand-quaternary, text becomes black; shadow grows to shadow-lg
- **Focus ring:** 4px, brand-tertiary color

### Success
- **Background:** success token
- **Text:** white
- **Hover:** shadow grows to shadow-lg
- **Focus ring:** 4px, success-medium color

### Danger
- **Background:** danger token
- **Text:** white
- **Hover:** shadow grows to shadow-lg
- **Focus ring:** 4px, danger-medium color

### Warning
- **Background:** warning token
- **Text:** black
- **Hover:** shadow grows to shadow-lg
- **Focus ring:** 4px, warning-medium color

### Dark
- **Background:** black
- **Text:** brand-secondary (white)
- **Hover:** shadow grows to shadow-lg (note: shadow stays black — the silhouette merges with the shadow on hover for a stamped effect)
- **Focus ring:** 4px, brand-quaternary color

### Ghost (NO shadow, NO skew)
- **Background:** transparent
- **Text:** brand-secondary (over brand surfaces) or brand color (over white surfaces)
- **Border:** none
- **Transform:** none — the ghost variant is the only one that opts out of the skew
- **Radius:** 20px
- **Hover:** underline appears under the label, no background change
- **Focus ring:** 4px, brand-tertiary color
- **No shadow, no skew, no fill**

### Disabled (NO shadow, NO interactive states)
- **Background:** disabled token
- **Text:** fg-disabled color
- **Transform:** still skewed for visual consistency, but no hover or shadow changes
- **Cursor:** not-allowed
- **Box shadow:** none
- **No hover, no focus, no shadow growth**

## Icons in Buttons

- Icon size: 20x20px (24x24px on large/xl sizes)
- Spacing: 12px gap between icon and label
- Icons should also be counter-skewed `skewX(15deg)` so they appear upright inside the slanted button silhouette

## Rules

- The skew + hard offset shadow combination is non-negotiable — it is the signature gesture of the system
- Always counter-skew the label content so text reads upright
- Never replace the hard offset shadow with a soft drop shadow
- Buttons sit ON TOP of the brand-colored canvas — they do not need a background "section" of their own
- Maintain a minimum 16px clearance around any button so the offset shadow is never clipped
