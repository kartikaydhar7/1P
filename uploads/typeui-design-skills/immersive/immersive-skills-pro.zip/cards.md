# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`, `borders.md`

## Core Specs

Cards are the primary surface that lifts content off the brand-colored canvas. They are bold white blocks with thick black borders and hard offset shadows — the same posterlike language used by every other component.

- **Background:** brand-secondary (white)
- **Border:** 4px solid black
- **Radius:** 20px
- **Outer padding (gap from card edge to inner content wrapper):** 8px — this 8px buffer between the 4px border and the inner content gives the card a "framed" feel
- **Inner content padding:** 24px (on top of the 8px buffer for total 32px from border edge to text)
- **Shadow:** shadow-md (8px 8px 0 #000000) — solid hard offset, no blur
- **Box sizing:** border-box

## Card Heading

- Desktop: 24px, bold weight, uppercase, brand color (deep green) — heading sits on the white card surface
- Mobile: 20px, bold weight, uppercase, brand color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level

## States

### Static Card (no interactivity)
- Background: brand-secondary (white)
- Border: 4px solid black
- Radius: 20px
- Padding: 8px outer + 24px inner
- Shadow: shadow-md (8px 8px 0 #000000)
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: shadow grows to shadow-lg (10px 10px 0 #000000); card may translate `-2px, -2px` to amplify the lift
- Optional hover accent: top-left corner of the card flashes a 8px brand-quaternary tab/ribbon
- Transition: transform and box-shadow, 0.5s
- Cursor: pointer

### Featured / Hero Card
- Same base styles
- Shadow: shadow-lg or shadow-xl depending on prominence
- May overlap a decorative brand-quaternary or brand-tertiary block sitting behind the card to add visual depth (must follow `layout.md` decoration rules)

## Rules

- Background: brand-secondary (white) — always, no other card surface color
- Border: 4px solid black — always, no soft borders
- Radius: 20px — always
- Outer padding: 8px between the 4px border and the inner content wrapper
- Shadow: hard offset only (shadow-md baseline, shadow-lg on hover for interactive cards)
- Interactive hover: shadow grows by one level + optional translate
- Non-interactive: no hover styles
- Cards must always sit on top of the brand-colored canvas — never on a white-on-white surface
