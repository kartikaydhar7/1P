# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #00592B | #00401F |
| neutral-primary | #00592B | #002E16 |
| neutral-primary-medium | #00592B | #00401F |
| neutral-primary-strong | #00592B | #00592B |
| neutral-secondary-soft | #00592B | #00401F |
| neutral-secondary | #00592B | #002E16 |
| neutral-secondary-medium | #FFFFFF | #00401F |
| neutral-secondary-strong | #F2EDE2 | #00592B |
| neutral-tertiary-soft | #FFFFFF | #00401F |
| neutral-tertiary | #F2EDE2 | #00592B |
| neutral-tertiary-medium | #E8E0CC | #007038 |
| neutral-quaternary | #D6CCB0 | #007038 |
| quaternary-medium | #D6CCB0 | #2A8859 |
| gray | #B8AC8A | #2A8859 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #E5F1EA | #002E16 |
| brand-soft | #B3D6BF | #00401F |
| brand | #00592B | #00592B |
| brand-medium | #4D8A6B | #00401F |
| brand-strong | #003F1E | #00592B |

### Brand Secondary / Tertiary / Quaternary
| Token | Light | Dark |
|---|---|---|
| brand-secondary | #FFFFFF | #FFFFFF |
| brand-tertiary | #0023D1 | #0023D1 |
| brand-quaternary | #E374C7 | #E374C7 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #E5F1EA | #002E16 |
| success | #00592B | #007038 |
| success-medium | #B3D6BF | #00401F |
| success-strong | #003F1E | #00592B |
| danger-soft | #FDECEC | #4D0218 |
| danger | #C42424 | #C42424 |
| danger-medium | #FAD2D2 | #8B0836 |
| danger-strong | #8E1717 | #8E1717 |
| warning-soft | #FFF4D6 | #6E4A00 |
| warning | #E0A100 | #E0A100 |
| warning-medium | #FFE7A0 | #6E4A00 |
| warning-strong | #8A6300 | #8A6300 |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.18) | rgba(255,255,255,0.10) |
| `--color-1-700` | rgba(0,0,0,0.35) | rgba(0,0,0,0.55) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #000000 | #000000 |
| dark-strong | #000000 | #000000 |
| disabled | #E8E0CC | #00401F |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #E374C7 |
| sky | #0023D1 |
| teal | #00592B |
| pink | #E374C7 |
| cyan | #0023D1 |
| fuchsia | #E374C7 |
| indigo | #0023D1 |
| orange | #E0A100 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #000000 | #000000 |
| heading | #FFFFFF | #FFFFFF |
| body | #F2EDE2 | #F2EDE2 |
| body-subtle | #D6CCB0 | #D6CCB0 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #B3D6BF | #4D8A6B |
| fg-brand | #00592B | #B3D6BF |
| fg-brand-strong | #003F1E | #FFFFFF |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #003F1E | #B3D6BF |
| fg-success-strong | #002E16 | #E5F1EA |
| fg-danger | #8E1717 | #F8B5B5 |
| fg-danger-strong | #5C0808 | #FAD2D2 |
| fg-warning-subtle | #E0A100 | #FFCB47 |
| fg-warning | #8A6300 | #FFE7A0 |
| fg-disabled | #B8AC8A | #4D8A6B |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #E0A100 | #FFCB47 |
| fg-info | #0023D1 | #6F90FF |
| fg-purple | #E374C7 | #E374C7 |
| fg-purple-strong | #B83BA0 | #F2A8E0 |
| fg-cyan | #0023D1 | #6F90FF |
| fg-indigo | #0023D1 | #6F90FF |
| fg-pink | #E374C7 | #E374C7 |
| fg-lime | #00592B | #4D8A6B |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #000000 | #000000 |
| border-buffer | #FFFFFF | #00592B |
| border-buffer-medium | #FFFFFF | #00401F |
| border-buffer-strong | #000000 | #000000 |
| border-muted | #00401F | #002E16 |
| border-light-subtle | #00592B | #002E16 |
| border-light | #00592B | #00401F |
| border-light-medium | #003F1E | #00592B |
| border-default-subtle | #000000 | #000000 |
| border-default | #000000 | #000000 |
| border-default-medium | #000000 | #000000 |
| border-default-strong | #000000 | #000000 |
| border-success-subtle | #B3D6BF | #003F1E |
| border-success | #003F1E | #B3D6BF |
| border-danger-subtle | #FAD2D2 | #8E1717 |
| border-danger | #8E1717 | #C42424 |
| border-warning-subtle | #FFE7A0 | #6E4A00 |
| border-warning | #8A6300 | #E0A100 |
| border-brand-subtle | #B3D6BF | #00401F |
| border-brand-light | #4D8A6B | #4D8A6B |
| border-brand | #00592B | #B3D6BF |
| border-dark-subtle | #000000 | #000000 |
| border-purple | #E374C7 | #E374C7 |
| border-orange | #0023D1 | #0023D1 |

## Semantic Usage Rules

- Page/section backgrounds: brand color (deep green) for ALL sections — the entire app uses a single immersive brand-colored canvas, not alternating neutrals
- Surface cards over sections: brand-secondary (white) background, with heavy black border and 8px outer padding gap
- Primary buttons: brand-secondary (white) background with brand-color text, hard offset shadow, skewed silhouette
- Headings: heading text color (white over the brand surface)
- Body text: body text color (warm cream over the brand surface)
- CTA links: brand-secondary text color with underline
- Default borders: heavy black borders for surfaces and components
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text
- Use brand-tertiary (#0023D1) for secondary accents, links inside white surfaces, and informational highlights
- Use brand-quaternary (#E374C7) for playful highlights, decorative shapes, badges, and gamified callouts

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No alternating section backgrounds — every section uses the same brand color so the page reads as a single continuous immersive canvas
- No soft drop shadows on surfaces — use hard offset block shadows only
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No manual light/dark value swapping — let the CSS custom properties handle it
