# Content & Grid System

> Dependencies: `layout.md`, `typography.md`

## Containers

| Type | Max width | Horizontal padding |
|---|---|---|
| Standard | 1280px | 32px |
| Internal (reading) | 720px | — (45–75 char line length) |

## Vertical Padding

| Breakpoint | Vertical padding |
|---|---|
| Mobile | 64px |
| Tablet (≥768px) | 96px |
| Desktop (≥1024px) | 128px (160px for hero/feature sections) |

## Grid System

Mobile-first with flexible desktop configurations. Card grids should give each white card enough room for the 8px outer padding, 4px black border, and the hard offset shadow without clipping.

| Context | Gap |
|---|---|
| Standard content/cards | 32px |
| Compact widgets/metadata | 16px |
| Wide feature grids | 48px |

### Responsive Columns

| Breakpoint | Columns |
|---|---|
| Mobile (default) | 1 |
| Small/Tablet (≥640px) | 2 |
| Desktop (≥1024px) | 2–4 |

Favour fewer, larger cards over dense grids — the immersive exhibit feel relies on scale and breathing room.

## Breakpoints

| Name | Width |
|---|---|
| Small | 640px |
| Medium | 768px |
| Large | 1024px |
| Extra large | 1280px |
| 2x Extra large | 1536px |

## Rules

- Always design mobile-first
- Use layout shifts (column → row) to accommodate horizontal space
- Lists: 32px indentation, 12px vertical gap between items
- Body copy: 18px, 1.5 line-height
- All interactive links follow brand underline/hover protocol
- Always leave at least 16px of clearance on the bottom-right of any card or button so its hard offset shadow is never clipped
