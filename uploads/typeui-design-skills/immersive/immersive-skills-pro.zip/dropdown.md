# Dropdown

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `inputs.md`, `typography.md`

## Core Specs

### Chevron Icon
- Size: 20x20px
- Spacing: 8px left margin, -2px right margin
- Color: inherits from trigger button

### Menu Container
- Background: brand-secondary (white)
- Border: 4px solid black
- Radius: 20px
- Shadow: shadow-md (8px 8px 0 #000000) — hard offset
- Z-index: elevated above content

### Menu List
- Padding: 12px
- Font: Oswald, 16px, brand color (deep green), bold weight, uppercase

### Menu Item
- Layout: inline-flex, vertically centered, full width
- Padding: 12px horizontal, 12px vertical
- Radius: 12px (default)
- Hover: brand-quaternary background, black text
- Transition: colors, 200ms

## Trigger Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Small | 16px | 18px | 8px |
| Base | 20px | 24px | 10px |
| Large | 25px | 33px | 11px |

Triggers follow the signature button silhouette from `buttons.md` (skewed, hard offset shadow) unless used inside a card body where a flatter, bordered trigger may be appropriate.

## Icon-only Trigger

- Padding: 12px
- Min size: 48x48px
- Icon: 24x24px

## Variants

### Default
- Menu width: 224px, items have 12px radius

### With Divider
- 2px solid black top border between child groups, skip first group

### With Header
- Header padding: 20px horizontal, 16px vertical
- Bottom border: 2px solid black
- Name: brand color, Oswald, 16px, bold weight, uppercase
- Email: body-subtle color, 14px, truncated

### With Icons
- Icon before label: 20x20px, 12px right margin, brand color
- On hover, icon color changes to black

### With Checkbox / Radio
- Inputs: 20x20px, 4px solid black border, focus ring in brand-tertiary
- Helper text: 12px, body-subtle color, 4px top margin

### With Search
- Search input at top of menu following `inputs.md` specs
- Left icon: 16px left padding, input 44px left padding

### Scrollable
- Max height: 240px, vertical scroll overflow

## States

| State | Appearance |
|---|---|
| Focused trigger | no outline, 4px brand-tertiary ring |
| Hover item | brand-quaternary background, black text |
| Active/open item | brand color background, brand-secondary (white) text |
| Disabled item | fg-disabled text, not-allowed cursor, no pointer events |
