# Icon Shapes

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`

## Core Specs

- Box sizing: border-box
- Icon must be perfectly centered (inline-flex, centered both axes)
- Circle: fully rounded (9999px)
- Rounded square: 20px radius (MD/LG/XL), 8px radius (XS/SM)
- Border: 4px solid black on every shape — matches the system silhouette
- Optional shadow: shadow-xs (4px 4px 0 #000000) for icon shapes that need to lift off a card surface

## Sizes

| Size | Container | Icon |
|---|---|---|
| XS | 32x32px | 16x16px |
| SM | 40x40px | 20x20px |
| MD | 48x48px | 24x24px |
| LG | 56x56px | 28x28px |
| XL | 64x64px | 32x32px |

## Color Variants

### Brand
- Shape: circle
- Background: brand color (deep green)
- Icon color: brand-secondary (white)

### Gray (Neutral)
- Shape: circle
- Background: brand-secondary (white)
- Icon color: brand color

### Tertiary (Accent)
- Shape: rounded square (20px)
- Background: brand-tertiary (#0023D1)
- Icon color: brand-secondary (white)

### Quaternary (Playful)
- Shape: rounded square (20px)
- Background: brand-quaternary (#E374C7)
- Icon color: black

### Danger
- Shape: circle
- Background: danger
- Icon color: brand-secondary (white)

### Success
- Shape: circle
- Background: success
- Icon color: brand-secondary (white)

### Warning
- Shape: circle
- Background: warning
- Icon color: black
