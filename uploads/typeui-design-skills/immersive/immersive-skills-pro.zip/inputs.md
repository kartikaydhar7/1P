# Inputs

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`

## Core Specs

- **Display:** block, full width
- **Radius:** 20px
- **Border:** 4px solid black
- **Background:** brand-secondary (white)
- **Shadow:** shadow-xs (4px 4px 0 #000000) — hard offset
- **Font:** Oswald, 18px, brand color (deep green)
- **Padding:** 20px horizontal, 16px vertical
- **Placeholder:** body-subtle color, uppercase, Oswald
- **Transition:** all properties, 200ms

## Label

- Display: block
- Font: Oswald, 16px, bold weight, uppercase, heading color
- Margin bottom: 12px
- Label `htmlFor` must match the input `id`

## States

### Default
- Border: 4px solid black
- Background: brand-secondary (white)
- Shadow: shadow-xs (4px 4px 0 #000000)

### Hover
- Shadow grows to shadow-sm (6px 6px 0 #000000)
- Border stays 4px solid black

### Focus
- No outline
- Border: 4px solid brand-tertiary (#0023D1)
- Shadow: shadow-sm (6px 6px 0 #000000)

### Success
- Border: 4px solid border-success
- Shadow: shadow-xs (4px 4px 0 #000000)

### Error / Danger
- Border: 4px solid border-danger
- Shadow: shadow-xs (4px 4px 0 #000000)

### Disabled
- Background: disabled
- Text: fg-disabled
- No shadow
- Cursor: not-allowed

## Input with Icons

- Icon size: 20x20px
- Icon color: brand color
- Container: relative positioned wrapper
- Start icon: absolutely positioned left, 16px left padding — input gets 48px left padding
- End icon: absolutely positioned right, 16px right padding — input gets 48px right padding
- Icons vertically centered within the wrapper

## Rules

- Every input must have a unique `id`
- Every label must have a matching `htmlFor`
- Padding: 20px horizontal, 16px vertical unless overridden for icon variants
- No arbitrary hex or hardcoded colors — always use design tokens
- Inputs always sit on the brand-color canvas with their white surface and hard offset shadow, matching the cards/buttons silhouette
