# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 128px |
| Section header → content | 64px or 80px |
| Heading → paragraph | 24px |
| Container horizontal padding | 32px |
| Flex/grid row gap | 24px |
| Card grid gap | 32px |
| Wide component grid gap | 48px |
| Column layout gap | 64px |

The whole experience favours generous, posterlike breathing room. Headings are oversized, white cards punch out of the brand-colored canvas with thick borders and hard shadows, so the layout itself must give them room to land.

## Container

Standard section container: max-width 1280px, centered, 32px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`) — oversized, uppercase, bold
2. Leading paragraph — large supporting line of copy
3. Normal paragraph(s)
4. Lists, CTA buttons, or component grids of white cards

## Section Pattern

Every section in the entire app shares the SAME background — the brand color (deep green). There is no alternation between neutral backgrounds; the entire page reads as one continuous immersive canvas. Sections are differentiated by content, oversized typography, decorative shapes, and the layered white cards that punch off the canvas.

Each section has:
- 128px vertical padding
- Brand-color background (always the same — never alternate)
- A centered container (max-width 1280px, 32px horizontal padding)
- A section header area with 64px bottom margin
- Section content below
- Optional decorative blocks (brand-tertiary, brand-quaternary, or solid black silhouettes) sitting behind cards to add depth

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use a motion library only when CSS cannot achieve the behavior.
- The site is designed to feel like a guided digital exhibit, not a static page — lean into scroll-triggered reveals, parallax depth on decorative blocks, staggered card entrances, and oversized heading animations
- Cards and buttons should react to hover with a press-out gesture (translate `-2px, -2px` while the hard offset shadow grows) — this is the signature interaction
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention; every interaction should feel gamified and tactile
- Mix bold typographic moments (oversized rotating words, marquee strips, animated numerals) with playful illustrated or geometric accents

## Backgrounds & Visual Depth

- The base canvas is a single, immersive brand-color fill across the entire app — every section, header, and footer
- Layer decorative geometric blocks (solid brand-tertiary or brand-quaternary rectangles, circles, or skewed shapes) behind cards and headings to create depth without breaking the brand-color continuity
- White cards and buttons act as the primary "lifted" elements; the contrast of crisp white over brand-green is what creates the depth
- Decorative shapes may use hard black borders and offset shadows to match the system language
- Optional grain or noise overlays at very low opacity are allowed for texture, but never compete with the white cards
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.

## Must

- All sections: consistent 128px vertical padding
- All sections: SAME brand-color background — never alternate or break the continuous canvas
- All containers: max-width 1280px, centered, 32px horizontal padding
- Section headers: 64px or 80px bottom margin
- White cards always have 8px outer padding gap, 4px black border, 20px radius, and a hard offset shadow
- Consistent vertical rhythm, generous breathing room, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
