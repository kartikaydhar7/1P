# Lists

> Dependencies: `colors.md`, `typography.md`

## Core Specs

- Item spacing: 16px vertical gap between list items
- Text: body color (over the brand canvas) or brand color (over white card surfaces)
- Font: Oswald, 18px, normal weight

## List Icons

- Size: 24x24px
- Prevent squishing: no shrink
- Spacing: 12px right margin between icon and text
- Active/featured icon: brand-quaternary (hot pink) for playful punch, or brand-tertiary (#0023D1) for informational lists
- Neutral icon: brand color (over white surfaces) or brand-secondary white (over brand canvas)

## Inactive / Disabled Items

Strikethrough text with body-subtle color decoration on the list item.

## Pattern

Vertical flex list with 16px gap. Each item is a flex row with centered alignment — icon (24x24, no-shrink, 12px right margin) followed by a span of body-colored text in Oswald.

When the list is rendered inside a white card surface, prefer brand color text and brand-quaternary or brand-tertiary icons. When rendered directly on the brand-color canvas, use brand-secondary (white) text and brand-quaternary icons.
