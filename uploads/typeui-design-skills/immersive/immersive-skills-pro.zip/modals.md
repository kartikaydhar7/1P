# Modals

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `buttons.md`, `inputs.md`, `typography.md`

## Core Specs

### Overlay (Backdrop)
- Fixed, covers full screen
- Z-index: 40
- Background: brand color (deep green) at 75% opacity — the modal "drops" the player back into the immersive canvas
- Optional grain or noise overlay for texture, very low opacity

### Content Container
- Background: brand-secondary (white)
- Border: 4px solid black
- Radius: 20px
- Shadow: shadow-xl (14px 14px 0 #000000) — hard offset block
- Outer padding gap: 8px between the 4px border and the inner content wrapper
- Inner padding: 32px

## Anatomy

### Header
- Bottom border: 4px solid black (or 2px if used inside a tighter modal)
- Top corners rounded (20px)
- Title: Oswald, 32px, bold weight, uppercase, brand color
- Close button: Ghost variant from `buttons.md`, 12px padding

### Body
- Vertical padding: 32px
- Vertical spacing between elements: 24px
- Text: 18px, 1.5 line-height, brand color (modal body sits on white)

### Footer
- Top border: 4px solid black
- Bottom corners rounded (20px)
- Padding: 24px
- Buttons follow `buttons.md` (skewed, hard offset shadow)

## Variants

### Default (Information)
Standard header + body + footer with primary/secondary action buttons.

### Pop-up (Confirmation)
Centered text, prominent icon, reduced padding:
- Body: 32px padding, text centered
- Icon: centered, 24px bottom margin, 64x64px, brand-quaternary background, 4px solid black border, 20px radius — matches `icon-shapes.md` Quaternary variant

### Form Modal
Body contains inputs following `inputs.md`. Vertical spacing between form elements: 24px.

## Rules

- Backdrop covers full screen with fixed positioning, brand-color tint at 75% opacity
- Content: brand-secondary (white) background, 20px radius, 4px solid black border, shadow-xl hard offset
- Header/Footer separated by 4px solid black borders
- Close button must be present and functional
- Accessibility: `role="dialog"`, implement focus trap in code
- Dark mode automatic via token system
