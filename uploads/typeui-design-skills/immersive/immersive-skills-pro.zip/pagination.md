# Pagination

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`

## Container

Font: Oswald, 16px, bold weight, uppercase. Items displayed as flex with -4px overlap so the heavy black borders align rather than double.

## Pagination Item

- Layout: flex, centered both axes
- Size: 48x48px
- Text: brand color (over white surfaces) or brand-secondary white (over brand canvas), bold weight, uppercase
- Background: brand-secondary (white)
- Border: 4px solid black
- Hover: brand-quaternary background, black text
- Focus: no outline, 4px brand-tertiary ring offset 4px
- Overlap: -4px left margin so adjacent borders align

## Previous / Next Buttons

- Horizontal padding: 20px, height: 48px
- First item: 20px radius on inline-start side
- Last item: 20px radius on inline-end side

## Active Page Item

- Text: brand-secondary (white)
- Background: brand color (deep green)
- Hover text: brand-secondary (stays same)
- Optional shadow-2xs (2px 2px 0 #000000) hard offset to lift the active page

## Rules

- Display as flex with -4px child overlap so borders align cleanly
- Items: brand-secondary (white) background, 4px solid black border, brand color text
- Active: brand color background, brand-secondary (white) text
- First item: rounded start (20px), Last item: rounded end (20px)
- All items need hover and focus states
