# Radios, Checkboxes & Toggles

> Dependencies: `colors.md`, `radius.md`, `borders.md`

## Checkbox

- Size: 24x24px
- Radius: 8px
- Border: 4px solid black
- Background: brand-secondary (white)
- Focus ring: 4px, brand-tertiary
- Checked: brand color background, brand-secondary (white) checkmark icon

### Disabled
- Border: 4px solid border-light
- Background: disabled
- Text: fg-disabled

## Radio

- Size: 24x24px
- Radius: fully rounded (9999px)
- Border: 4px solid black
- Background: brand-secondary (white)
- Focus ring: 4px, brand-tertiary
- Checked: 4px solid black border, brand color filled inner dot

### Disabled
- Border: 4px solid border-light-medium
- Background: disabled
- Text: fg-disabled

Group all radio items under the same `name` attribute.

## Toggle

### Track
- Size: 56x32px
- Fully rounded
- Background: brand-secondary (white)
- Border: 4px solid black
- Focus-within ring: 4px, brand-tertiary
- Checked track: brand color background
- Disabled track: disabled background

### Thumb
- Size: 20x20px
- Fully rounded
- Background: brand-secondary (white) when off, brand-quaternary (hot pink) when on
- Border: 2px solid black
- Transition: transform 200ms

### Disabled
- Track: disabled background
- Label: fg-disabled text

## Rules

- All selection inputs must have `id` matching label `htmlFor`
- Focus states use brand-tertiary ring for every control type
- Disabled states: no hover/focus interaction
- All controls match the heavy black border + hard silhouette of the system
