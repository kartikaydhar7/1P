# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 20px | Buttons, cards, inputs, modals, popovers, tables, sections, surfaces |
| default | 12px | Inner menu items, nested controls inside a 20px container |
| sm | 8px | Checkboxes, tiny elements |
| full | 9999px | Pills, avatars, toggles, dot indicators |

## Rules

- 20px is the default radius across the product — every component, card, and surface uses 20px unless it is explicitly a tiny control or pill
- All cards (white surfaces over the brand background) MUST use 20px radius
- All buttons MUST use 20px radius (combined with the skewed silhouette defined in `buttons.md`)
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
