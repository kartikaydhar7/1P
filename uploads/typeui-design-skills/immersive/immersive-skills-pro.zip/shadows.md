# Shadows

Shadows in this system are HARD OFFSET BLOCK shadows (no blur, no softness). They sit behind a surface as a solid black slab to create the playful, posterlike, gamified depth seen across the experience.

| Token | CSS value |
|---|---|
| shadow-2xs | `2px 2px 0 0 #000000` |
| shadow-xs | `4px 4px 0 0 #000000` |
| shadow-sm | `6px 6px 0 0 #000000` |
| shadow-md | `8px 8px 0 0 #000000` |
| shadow-lg | `10px 10px 0 0 #000000` |
| shadow-xl | `14px 14px 0 0 #000000` |
| shadow-2xl | `20px 20px 0 0 #000000` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs |
| Inputs, small controls, lightweight cards | shadow-xs |
| Buttons (default) | shadow-sm |
| Standard cards, popovers, dropdowns | shadow-md |
| Prominent cards, sticky surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use only these tokens — no custom box-shadow values, never use blurred drop shadows
- All shadows are solid black, hard-edged, offset to the bottom-right; this is the signature look
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level (the offset visibly grows, reinforcing the gamified press effect)
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
