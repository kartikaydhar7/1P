# Sidebars

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`, `badges.md`, `alerts.md`

## Core Specs

- Background: brand-secondary (white)
- Right border: 4px solid black (for left-sidebar); left border for right-sidebar
- Width: 288px

The sidebar is one of the few full-height white surfaces in the system — it functions as a permanent "framed panel" that lifts off the brand-color canvas.

## Anatomy

### Outer Container
Hidden on mobile, visible at small breakpoint. Needs a toggle/trigger for mobile.

### Inner Wrapper
- Full height, vertical scroll overflow
- Padding: 16px horizontal, 24px vertical

### Navigation List
- Vertical spacing: 12px between items
- Font: Oswald, bold weight, uppercase

### Navigation Item
- Layout: flex, vertically centered
- Padding: 12px horizontal, 12px vertical
- Text: brand color (deep green)
- Radius: 20px
- Hover: brand-quaternary background, black text
- Transition: colors, 200ms
- Icon: 24x24px, brand color, hover → black, 200ms transition
- Label: 16px left margin from icon

### Active Item
- Background: brand color
- Text: brand-secondary (white)
- Optional 4px solid black border + shadow-2xs (2px 2px 0 #000000) for the active item to mimic the signature card silhouette

### Separator
- 24px top padding, 24px top margin
- Top border: 2px solid black
- 12px vertical spacing below

### Bottom CTA / Card
- Padding: 24px
- Top margin: 32px
- Radius: 20px
- Background: brand color (deep green)
- Text: brand-secondary (white)
- Border: 4px solid black
- Shadow: shadow-sm (6px 6px 0 #000000) hard offset
- Can also use any alert variant from `alerts.md`

## Rules

- Responsive: hidden on mobile with a trigger mechanism
- Icons: 24x24px, brand color (hover: black)
- Multi-level menus: indent with 48px left padding
- Spacing follows 8px grid
- Only neutral, brand, brand-tertiary, brand-quaternary, or status tokens — no arbitrary colors
