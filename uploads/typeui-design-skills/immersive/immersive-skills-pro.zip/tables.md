# Tables

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`

## Wrapper

- Horizontal scroll overflow
- Background: brand-secondary (white)
- Radius: 20px
- Border: 4px solid black
- Shadow: shadow-md (8px 8px 0 #000000) hard offset
- Outer padding gap: 8px between border and table edge — same framed treatment as cards

## Table Element

- Full width, left-aligned text (right-aligned for RTL)
- Font: Oswald, 16px, brand color (deep green)

## Table Head

- Font: Oswald, 16px, bold weight, uppercase, brand-secondary (white)
- Background: brand color (deep green)
- Bottom border: 4px solid black
- Cell padding: 32px horizontal, 16px vertical

## Table Body

- Row background: brand-secondary (white)
- Row bottom border: 2px solid black (omit on last row to avoid doubling with wrapper border)
- Row hover: brand-quaternary background at 30% opacity (optional)
- Row header: bold weight, uppercase, brand color, no-wrap
- Cell padding: 32px horizontal, 20px vertical

## Rules

- Wrapper must have horizontal scroll overflow for responsive scrolling
- Last row: omit bottom border to avoid doubling with wrapper border
- Row headers: always `scope="row"` for semantic structure
- Hover on rows is optional — keep it subtle (brand-quaternary at low opacity) so it doesn't fight the immersive canvas
- No arbitrary hex codes — use token colors only
