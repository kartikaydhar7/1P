# Tabs

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`

## Core Specs

- Typography: Oswald, 18px, bold weight, uppercase, brand color (over white surfaces) or brand-secondary (over brand canvas)
- Transitions: all properties, 200ms

## Variants

### 1. Underline (Default)

**Wrapper:** bottom border, 4px solid black

**Tab Item:**
- Padding: 24px horizontal, 20px vertical
- Bottom border: 4px transparent (will become brand color on active)
- Top corners: 20px radius
- Transition: colors, 200ms

| State | Appearance |
|---|---|
| Active | brand color text, 4px solid brand color bottom border |
| Inactive | transparent bottom border; hover → black text, 4px solid brand-quaternary bottom border |
| Disabled | fg-disabled text, not-allowed cursor |

### 2. Pills

**Tab Item:**
- Padding: 20px horizontal, 12px vertical
- Radius: 20px
- Border: 4px solid black
- Font weight: bold, uppercase
- Transition: all, 200ms

| State | Appearance |
|---|---|
| Active | brand color background, brand-secondary (white) text, shadow-xs (4px 4px 0 #000000) hard offset |
| Inactive | brand-secondary (white) background, brand color text; hover → brand-quaternary background, black text |
| Disabled | fg-disabled text, not-allowed cursor |

### 3. Full Width

Children overlap with -4px left margin so the heavy black borders align rather than double.

**Tab Item:**
- Full width, centered text
- Padding: 24px horizontal, 20px vertical
- Background: brand-secondary (white)
- Border: 4px solid black
- Transition: colors, 200ms
- Hover: brand-quaternary background, black text

| State | Appearance |
|---|---|
| Active | brand color background, brand-secondary (white) text |
| First item | rounded start (20px) |
| Last item | rounded end (20px) |

## Tabs with Icons

- Icon size: 20x20px or 24x24px
- Spacing: 12px right margin
- Layout: inline-flex, centered
- Icons inherit the text color of the tab state
