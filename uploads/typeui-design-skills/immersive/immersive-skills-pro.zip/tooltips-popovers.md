# Tooltips & Popovers

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`

## Tooltips

### Core Specs
- Padding: 16px horizontal, 12px vertical
- Font: Oswald, 14px, bold weight, uppercase
- Radius: 20px
- Border: 4px solid black
- Shadow: shadow-xs (4px 4px 0 #000000) hard offset
- Transition: opacity, 200ms

### Dark (Default)
- Background: black
- Text: brand-secondary (white)
- Border: 4px solid black

### Light
- Background: brand-secondary (white)
- Text: brand color (deep green)
- Border: 4px solid black

### Brand
- Background: brand color (deep green)
- Text: brand-secondary (white)
- Border: 4px solid black

## Popovers

### Core Specs
- Background: brand-secondary (white)
- Radius: 20px
- Border: 4px solid black
- Shadow: shadow-md (8px 8px 0 #000000) hard offset
- Outer padding gap: 8px between border and inner content — same framed treatment as cards
- Transition: opacity, 200ms

### Header / Title
- Padding: 16px horizontal, 12px vertical
- Background: brand color (deep green)
- Bottom border: 4px solid black
- Font: Oswald, 16px, bold weight, uppercase, brand-secondary (white)

### Body / Content
- Standard: 16px horizontal, 12px vertical padding; 16px, brand color
- Rich: 24px padding; 16px, brand color

## Arrows

- Size: 12x12px rotated 45deg
- Color must match the background of the tooltip/popover variant
- 4px solid black border on the two visible edges so the arrow reads as part of the framed silhouette

## Rules

- Tooltips: 20px radius, 4px solid black border
- Popovers: 20px radius, 4px solid black border, 8px outer padding gap
- Dark tooltips: black background, brand-secondary (white) text
- Light tooltips/popovers: brand-secondary (white) background + brand color text
- Brand tooltips: brand color background, brand-secondary (white) text
- Arrows match parent background color and carry the same 4px black border treatment
