# Typography

> Dependencies: `colors.md`

## Core Rules

- **Font:** Oswald, sans-serif — configured at app level, never override. Oswald is a condensed display family; embrace its tall, narrow proportions for an immersive editorial-poster feel
- **Headings:** bold weight (700), uppercase, slightly tightened letter-spacing, heading text color
- **Body copy:** body text color, normal weight (400), regular sentence case, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 96px | 0.95 | -1.5px | 32px |
| `h2` | 64px | 1 | -1px | 24px |
| `h3` | 44px | 1.1 | -0.5px | 20px |
| `h4` | 32px | 1.2 | -0.25px | 16px |
| `h5` | 24px | 1.3 | 0 | 12px |
| `h6` | 20px | 1.3 | 0.5px | 12px |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 64px | 44px |
| `h2` | 48px | 36px |
| `h3` | 36px | 28px |
| `h4` | 28px | 24px |
| `h5` | 22px | 20px |
| `h6` | 18px | 18px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 0.95 for any heading. Headings should feel oversized, bold, and posterlike.

## Paragraphs

### Leading Paragraph
- Size: 22px
- Weight: normal (400)
- Color: body
- Line-height: 1.5
- Max width: ~70 characters

### Normal Paragraph
- Size: 18px
- Weight: normal (400)
- Color: body
- Line-height: 1.5
- Max width: ~65 characters

### Small Supporting Copy
- Size: 14px
- Weight: normal (400)
- Color: body
- Line-height: 1.5
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 25px | 700 (bold), uppercase |
| Input labels | 16px or 18px | 600 (semibold), uppercase |
| Captions / meta / badges | 12px or 14px | 600 (semibold), uppercase |

Do not apply paragraph line-height (1.5) to control labels. Labels should be tight and posterlike.

## Links

- **Inline links:** Same size as surrounding text, brand-secondary color (over brand surfaces) or brand color (over white surfaces), underline, hover → no underline
- **CTA links:** brand color, bold weight, uppercase, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps is the default for headings, buttons, and labels: uppercase, 0.5px letter-spacing minimum, 12px or larger
- Mix oversized headings with much smaller body copy for dramatic editorial contrast

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, and spacing remain constant.
