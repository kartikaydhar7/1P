# Accordion

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Wrapper:** full width, 1px border (border-default color), 0px radius — sharp rectangular corners
- **Item separator:** 1px bottom border (border-default) on every item except last

## Trigger (Button)

- **Layout:** flex, space-between, full width
- **Padding:** 24px horizontal, 18px vertical
- **Font:** 16px, semibold (600), 0.4px tracking
- **Text color:** heading
- **Background:** neutral-secondary-soft when on cream sections; neutral-primary when on burnt-orange sections
- **Hover:** neutral-tertiary-soft background
- **Focus:** outline none, 2px solid border-brand outline with 2px outer offset
- **Transition:** background-color and color, 150ms ease-out
- **Open state:** neutral-tertiary background, fg-brand-strong text

## Panel (Content)

- **Padding:** 24px horizontal, 20px vertical
- **Background:** neutral-primary
- **Top border:** 1px, border-default color
- **Font:** 14px, body color, 1.6 line-height

## Chevron Icon

- Size: 16x16px
- Color: body text color
- Closed: 0deg rotation
- Open: 180deg rotation
- Transition: transform, 150ms ease-out

## Variants

### Default (Collapse)
One panel open at a time. Items stacked inside a single shared bordered wrapper. Sharp corners (0px radius).

### Separated Cards
Each item is independent — has its own 1px border (border-default) and 0px radius. 12px bottom margin between items. No shared outer border. No shadow.

### Always Open
Multiple panels can expand simultaneously. Same styling as Default.

### Flush
No outer border. Trigger and panel have transparent backgrounds. Only bottom border dividers between items. Use inside containers that already provide a background.

## States

| State | Trigger appearance |
|---|---|
| Closed | heading text, neutral-secondary-soft background |
| Open | fg-brand-strong text, neutral-tertiary background |
| Hover | neutral-tertiary-soft background |
| Focus | 2px brand outline with 2px offset, no default outline |
| Disabled | fg-disabled text, not-allowed cursor, no hover/focus |
