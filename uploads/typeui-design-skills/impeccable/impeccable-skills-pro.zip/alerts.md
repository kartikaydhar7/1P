# Alerts

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Padding:** 20px
- **Radius:** 0px (sharp rectangular corners)
- **Border:** 1px (or 2px for the brand and danger variants for graphic emphasis)
- **Heading:** 16px, semibold (600), 0.4px tracking
- **Body:** 14px, normal weight, 1.55 line-height

## Variants

### Brand
- **Background:** brand-softer
- **Border:** 2px border-brand
- **Text:** fg-brand-strong

### Success
- **Background:** success-soft
- **Border:** 1px border-success-subtle
- **Text:** fg-success-strong

### Danger
- **Background:** danger-soft
- **Border:** 2px border-danger
- **Text:** fg-danger-strong

### Warning
- **Background:** warning-soft
- **Border:** 1px border-warning-subtle
- **Text:** fg-warning
