# Avatars

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Circular shape:** 0px radius (sharp square crop — circles are not used in this system)
- **Rounded square shape:** 0px radius
- **Default size:** 40x40px
- **Image fit:** cover

## Sizes

| Size | Dimensions | Radius |
|---|---|---|
| Extra Small | 18x18px | 0px |
| Small | 24x24px | 0px |
| Base | 32x32px | 0px |
| Large | 44x44px | 0px |
| XL | 56x56px | 0px |
| 2XL | 64x64px | 0px |

## Bordered Avatar

- 0px padding (no halo gap), 0px radius, 2px solid outline in border-orange color for graphic emphasis
- Alternative: 2px solid border in border-default color

## Stacked Avatars

- Displayed in a row (flex)
- Each avatar: 40x40px, 0px radius, 2px border in border-buffer color
- Overlap: -12px negative margin on all except first

### Stacked Counter
- Same size as avatars (40x40px), 0px radius
- Background: dark-strong, text: white, 12px font, semibold weight, 0.4px tracking
- Same overlap margin as other avatars

## Avatar with Text

- Flex row, 12px gap between avatar and text
- Avatar: 40x40px, 0px radius, cover fit
- Name: heading color, semibold weight
- Subtitle: 14px, body color
