# Badges

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Border:** 1px
- **Default radius:** 0px
- **Pill radius:** 0px (pills are flat rectangles in this system)
- **Font:** "Chakra Petch", uppercase, 0.6px tracking, semibold (600)

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Default (small) | 11px | 8px | 3px |
| Large | 13px | 10px | 5px |

## Variants

### Brand
- **Background:** brand-softer
- **Border:** 1px border-brand-subtle
- **Text:** fg-brand-strong

### Alternative (Neutral Soft)
- **Background:** neutral-primary
- **Border:** 1px border-default
- **Text:** heading

### Gray (Neutral Medium)
- **Background:** neutral-secondary-medium
- **Border:** 1px border-default
- **Text:** heading

### Danger
- **Background:** danger-soft
- **Border:** 1px border-danger-subtle
- **Text:** fg-danger-strong

### Success
- **Background:** success-soft
- **Border:** 1px border-success-subtle
- **Text:** fg-success-strong

### Warning
- **Background:** warning-soft
- **Border:** 1px border-warning-subtle
- **Text:** fg-warning

### Dark
- **Background:** dark
- **Border:** dark
- **Text:** white

## Pill Badges

Pills use the same 0px radius as default badges in this system. Use the "Pill" variant only for naming consistency — visually they are flat rectangles.

## Badges with Icons

- Icon size (default): 12x12px
- Icon size (large): 14x14px
- Icon spacing: 4px margin next to label

## Icon-only Badge

Square shape — equalize dimensions to 24x24px, no horizontal text padding.

## Dismissible Badges

Badge content + a close button. Close button hover backgrounds per variant:

| Variant | Close button hover background |
|---|---|
| Brand | brand-soft |
| Alternative | neutral-tertiary |
| Gray | neutral-quaternary |
| Danger | danger-medium |
| Success | success-medium |
| Warning | warning-medium |

## Dot / Notification Badge

- Positioned absolutely: -4px top, -4px right
- Size: 10x10px, 0px radius (square dot)
- 2px border in border-buffer color
- Background: danger
