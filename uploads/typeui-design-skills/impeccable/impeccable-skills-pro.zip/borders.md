# Borders

## Width Scale

| Context | Width |
|---|---|
| Default (inputs, buttons, cards) | 1px |
| Emphasis / focus | 2px |
| Heavy / graphic accents (section dividers, illustration frames) | 3px |

## Rules

- Use solid borders by default — they replace shadows as the primary depth/separation device
- Dashed borders only for special cases like file dropzones
- Components in the same family must use matching border widths
- Never mix 1px and 2px borders within a single component
- Borders should always use a token from `colors.md` — never raw hex values

## Usage

| Context | Width |
|---|---|
| Inputs / selects / textareas | 1px default; 2px on focus or error |
| Buttons | 1px for variants that require outlining |
| Cards / containers | 1px default; 2px for a graphic, framed look on burnt-orange sections |
| Section dividers (horizontal rules) | 1px in border-default; 3px in border-orange for graphic emphasis |
