# Button Groups

> Dependencies: `buttons.md`, `colors.md`, `radius.md`

## Core Specs

- **Wrapper:** inline-flex, 0px radius, no shadow
- **Children overlap:** -1px left margin on all except first button (so adjacent borders collapse cleanly)
- **Buttons inside the group must NOT have individual shadows.** Shadows are disabled across the whole system.

## Anatomy

### Wrapper
- Display: inline-flex
- Radius: 0px
- Shadow: none

### First Button
- 0px radius on every corner

### Middle Button(s)
- 0px radius on every corner

### Last Button
- 0px radius on every corner

### All buttons except first
- -1px left margin to overlap borders

## Rules

- Buttons inside groups follow all styles from `buttons.md` (background, border, focus rings) — no individual shadows because the system has no shadows
- Icon-only buttons: 16x16px icon, match height of text buttons
- All corners are sharp (0px) — the visual unity of the group comes from the seamless border overlap, not from rounded ends
