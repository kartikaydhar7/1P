# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except ghost and disabled)

- **Radius:** 0px (all buttons, including pill-style buttons — pills are flat rectangles in this system)
- **Border:** 1px solid
- **Shadow:** none
- **Glint effect:** disabled in this system. The glint variables resolve to fully transparent values, so the layered box-shadow has no visual effect. Do not invent custom highlight overlays.
- **Font weight:** 600 (semibold)
- **Font:** "Chakra Petch"
- **Letter-spacing:** 0.4px
- **Box sizing:** border-box
- **Transition:** background-color, color, and border-color, 150ms ease-out

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 12px | 6px |
| Small | 14px | 14px | 8px |
| Base (default) | 14px | 20px | 12px |
| Large | 16px | 24px | 14px |
| Extra large | 16px | 32px | 16px |

## Variants

### Brand
- **Background:** brand token (#CC8800 amber)
- **Border:** brand token
- **Text:** white
- **Hover:** brand-strong background, brand-strong border
- **Focus ring:** 2px solid border-brand, 2px outer offset
- **Glint:** none

### Secondary
- **Background:** neutral-secondary-medium
- **Border:** border-default-medium
- **Text:** heading color
- **Hover:** neutral-tertiary-medium background, border-default-strong border
- **Focus ring:** 2px solid border-default-strong, 2px outer offset
- **Glint:** none

### Tertiary
- **Background:** neutral-primary
- **Border:** border-default
- **Text:** heading color
- **Hover:** neutral-secondary-medium background, border-default-strong border
- **Focus ring:** 2px solid border-default, 2px outer offset
- **Glint:** none

### Success
- **Background:** success token
- **Border:** success token
- **Text:** white
- **Hover:** success-strong background, success-strong border
- **Focus ring:** 2px solid border-success, 2px outer offset
- **Glint:** none

### Danger
- **Background:** danger token (#BE3F00 burnt orange)
- **Border:** danger token
- **Text:** white
- **Hover:** danger-strong background, danger-strong border
- **Focus ring:** 2px solid border-danger, 2px outer offset
- **Glint:** none

### Warning
- **Background:** warning token
- **Border:** warning token
- **Text:** dark token
- **Hover:** warning-strong background, warning-strong border
- **Focus ring:** 2px solid border-warning, 2px outer offset
- **Glint:** none

### Dark
- **Background:** dark token
- **Border:** dark token
- **Text:** white
- **Hover:** dark-strong background, dark-strong border
- **Focus ring:** 2px solid border-dark, 2px outer offset
- **Glint:** none

### Ghost (no background, no glint)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color
- **Hover:** neutral-secondary-medium background
- **Focus ring:** 2px solid border-default, 2px outer offset
- **No shadow, no glint effect**

### Disabled (no glint)
- **Background:** disabled token
- **Border:** border-default
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no glint**

## Icons in Buttons

- Icon size: 16x16px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
