# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-primary (white) on cream sections; neutral-primary-soft (cream) on burnt-orange sections
- **Border:** 1px, border-default color (2px border-orange for graphic emphasis variants)
- **Radius:** 0px (sharp rectangular corners)
- **Shadow:** none

## Card Heading

- Desktop: 24px, semibold (600), heading color, optional 0.4px tracking
- Mobile: 18px, semibold, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-primary on cream sections, neutral-primary-soft on burnt-orange sections
- Border: 1px, border-default
- Radius: 0px
- Shadow: none
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: neutral-secondary-medium background, border-default-strong border
- Transition: background-color and border-color, 150ms ease-out
- Cursor: pointer

## Rules

- Background: neutral-primary on cream sections, neutral-primary-soft on burnt-orange sections
- Border: 1px, border-default (or 2px border-orange for graphic emphasis)
- Radius: 0px
- Shadow: none — depth comes from solid borders and color contrast against the section background
- Interactive hover: neutral-secondary-medium background, border-default-strong border
- Non-interactive: no hover styles
- Cards may include a small inline SVG illustration or geometric accent in a corner — keep it within the warm palette (cream / amber / burnt orange)
