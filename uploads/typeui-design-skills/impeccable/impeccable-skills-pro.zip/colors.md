# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #F8E9D1 | #1A0F05 |
| neutral-primary | #FFFFFF | #0D0704 |
| neutral-primary-medium | #FFF6E0 | #2B1810 |
| neutral-primary-strong | #F0DBB8 | #3D2517 |
| neutral-secondary-soft | #BE3F00 | #BE3F00 |
| neutral-secondary | #F8E9D1 | #1A0F05 |
| neutral-secondary-medium | #FFF6E0 | #2B1810 |
| neutral-secondary-strong | #F0DBB8 | #3D2517 |
| neutral-tertiary-soft | #FFF6E0 | #1A0F05 |
| neutral-tertiary | #F0DBB8 | #2B1810 |
| neutral-tertiary-medium | #E5C895 | #3D2517 |
| neutral-quaternary | #D4B27A | #4F3220 |
| quaternary-medium | #C49E5F | #65422A |
| gray | #A88247 | #7E5328 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #FFF6E0 | #3D2900 |
| brand-soft | #FFE9B8 | #664400 |
| brand | #CC8800 | #FFAA00 |
| brand-medium | #FFD580 | #8F5F00 |
| brand-strong | #8F5F00 | #FFD580 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #EDF5E0 | #1F3505 |
| success | #4A7C0F | #6BA51F |
| success-medium | #D9EBC2 | #2D4D08 |
| success-strong | #2D4D08 | #8FCC2C |
| danger-soft | #FCEAE5 | #5C1008 |
| danger | #BE3F00 | #E84A3D |
| danger-medium | #FAC1B6 | #8F2E00 |
| danger-strong | #8F2E00 | #FF6B5C |
| warning-soft | #FFFAE0 | #4A3500 |
| warning | #F4B400 | #F4B400 |
| warning-medium | #FFF1B0 | #6B5000 |
| warning-strong | #B38400 | #FFD24D |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0) | rgba(255,255,255,0) |
| `--color-1-700` | rgba(0,0,0,0) | rgba(0,0,0,0) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #1A0F05 | #1A0F05 |
| dark-strong | #0D0704 | #3D2517 |
| disabled | #F0DBB8 | #2B1810 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #7C3AED |
| sky | #0891B2 |
| teal | #0D9488 |
| pink | #E11D48 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #BE3F00 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #1A0F05 | #1A0F05 |
| heading | #1A0F05 | #F8E9D1 |
| body | #4F3220 | #E5C895 |
| body-subtle | #6B4F2A | #C49E5F |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #FFD580 | #664400 |
| fg-brand | #CC8800 | #FFAA00 |
| fg-brand-strong | #8F5F00 | #FFD580 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #2D4D08 | #6BA51F |
| fg-success-strong | #1F3505 | #8FCC2C |
| fg-danger | #8F2E00 | #E84A3D |
| fg-danger-strong | #5C1F00 | #FF6B5C |
| fg-warning-subtle | #B38400 | #F4B400 |
| fg-warning | #6B5000 | #FFD24D |
| fg-disabled | #A88247 | #7E5328 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #F4B400 | #F4B400 |
| fg-info | #5C3D00 | #FFD580 |
| fg-purple | #7C3AED | #A78BFA |
| fg-purple-strong | #5B21B6 | #C4B5FD |
| fg-cyan | #0891B2 | #22D3EE |
| fg-indigo | #4F46E5 | #818CF8 |
| fg-pink | #E11D48 | #F472B6 |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #1A0F05 | #4F3220 |
| border-buffer | #F8E9D1 | #0D0704 |
| border-buffer-medium | #FFF6E0 | #1A0F05 |
| border-buffer-strong | #FFFFFF | #2B1810 |
| border-muted | #F0DBB8 | #1A0F05 |
| border-light-subtle | #F0DBB8 | #1A0F05 |
| border-light | #E5C895 | #2B1810 |
| border-light-medium | #D4B27A | #3D2517 |
| border-default-subtle | #E5C895 | #1A0F05 |
| border-default | #D4B27A | #3D2517 |
| border-default-medium | #C49E5F | #4F3220 |
| border-default-strong | #A88247 | #65422A |
| border-success-subtle | #C5E0A0 | #1F3505 |
| border-success | #4A7C0F | #6BA51F |
| border-danger-subtle | #FAC1B6 | #5C1008 |
| border-danger | #BE3F00 | #E84A3D |
| border-warning-subtle | #FFE9B8 | #4A3500 |
| border-warning | #F4B400 | #F4B400 |
| border-brand-subtle | #FFD580 | #664400 |
| border-brand-light | #E0A018 | #FFAA00 |
| border-brand | #CC8800 | #FFAA00 |
| border-dark-subtle | #1A0F05 | #3D2517 |
| border-purple | #7C3AED | #A78BFA |
| border-orange | #BE3F00 | #BE3F00 |

## Semantic Usage Rules

- Page/section backgrounds: alternate ONLY between neutral-primary-soft (#F8E9D1 cream) and neutral-secondary-soft (#BE3F00 burnt orange) — no other section background colors
- Primary buttons: brand background (#CC8800 amber)
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text
- On burnt-orange sections (#BE3F00), text defaults to neutral-primary-soft (#F8E9D1) and components flip to cream surfaces with dark text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No section background colors other than the two approved values (#F8E9D1 cream and #BE3F00 burnt orange)
- No gradients or purple-to-blue color washes — the palette is solid, warm, and graphic
- No manual light/dark value swapping — let the CSS custom properties handle it
