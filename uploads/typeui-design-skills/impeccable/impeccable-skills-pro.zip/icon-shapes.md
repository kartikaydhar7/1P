# Icon Shapes

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- Box sizing: border-box
- Icon must be perfectly centered (inline-flex, centered both axes)
- Circle: 0px radius (sharp square in this system — circles are not used)
- Rounded square: 0px radius (sharp square)

## Sizes

| Size | Container | Icon |
|---|---|---|
| XS | 24x24px | 14x14px |
| SM | 32x32px | 16x16px |
| MD | 40x40px | 20x20px |
| LG | 48x48px | 24x24px |
| XL | 56x56px | 28x28px |

## Color Variants

### Brand
- Shape: square
- Background: brand-softer
- Border: 1px border-brand-subtle
- Icon color: fg-brand-strong

### Gray
- Shape: square
- Background: neutral-secondary-medium
- Border: 1px border-default
- Icon color: body

### Danger
- Shape: square
- Background: danger-soft
- Border: 1px border-danger-subtle
- Icon color: fg-danger-strong

### Success
- Shape: square
- Background: success-soft
- Border: 1px border-success-subtle
- Icon color: fg-success-strong

### Warning
- Shape: square
- Background: warning-soft
- Border: 1px border-warning-subtle
- Icon color: fg-warning
