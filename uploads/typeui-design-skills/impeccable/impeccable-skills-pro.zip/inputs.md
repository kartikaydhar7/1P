# Inputs

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Display:** block, full width
- **Radius:** 0px (sharp rectangular corners)
- **Border:** 1px, border-default-medium
- **Background:** neutral-primary
- **Shadow:** none
- **Font:** 14px, "Chakra Petch", heading color
- **Padding:** 14px horizontal, 12px vertical
- **Placeholder:** body-subtle color
- **Transition:** background-color, border-color, and color, 200ms ease-out

## Label

- Display: block
- Font: 14px, semibold weight (600), heading color, 0.4px tracking
- Margin bottom: 8px
- Label `htmlFor` must match the input `id`

## States

### Default
- Border: 1px, border-default-medium
- Background: neutral-primary

### Hover
- Border: border-default-strong

### Focus
- No default outline
- Border: 2px, border-brand
- Outline: 2px solid border-brand-subtle, 2px outer offset

### Success
- Border: 2px, border-success
- Focus outline: 2px solid border-success-subtle, 2px offset

### Error / Danger
- Border: 2px, border-danger
- Focus outline: 2px solid border-danger-subtle, 2px offset

### Disabled
- Background: disabled
- Border: border-default-subtle
- Text: fg-disabled
- Cursor: not-allowed

## Input with Icons

- Icon size: 16x16px
- Icon color: body
- Container: relative positioned wrapper
- Start icon: absolutely positioned left, 12px left padding — input gets 40px left padding
- End icon: absolutely positioned right, 12px right padding — input gets 40px right padding
- Icons vertically centered within the wrapper

## Rules

- Every input must have a unique `id`
- Every label must have a matching `htmlFor`
- Padding: 14px horizontal, 12px vertical unless overridden for icon variants
- No arbitrary hex or hardcoded colors
- All corners are sharp (0px) — never round inputs
