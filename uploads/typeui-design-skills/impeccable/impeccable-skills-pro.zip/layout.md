# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 120px |
| Section header → content | 56px or 72px |
| Heading → paragraph | 16px |
| Container horizontal padding | 32px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 40px |
| Column layout gap | 56px |

## Container

Standard section container: max-width 1200px, centered, 32px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Every full-width section follows the same graphic, alternating rhythm — this is the load-bearing visual identity of the system.

- **Section background colors are LIMITED to TWO values:**
  - Primary: `neutral-primary-soft` (#F8E9D1 — warm cream)
  - Alternative: `neutral-secondary-soft` (#BE3F00 — burnt orange)
- Sections alternate between these two colors as the page scrolls — never use any other color for full-width section backgrounds
- 120px vertical padding (top and bottom) on every section
- A centered container (max-width 1200px, 32px horizontal padding)
- A section header area with 56px or 72px bottom margin
- Section content below
- Each section should feature one or more graphic illustrations or geometric SVG shapes (suns/discs, towers, silhouettes, lines, terraces) placed compositionally — not as decoration but as a structural element of the section
- On cream sections: text defaults to `heading` color, illustrations use burnt orange and amber
- On burnt-orange sections: text defaults to `neutral-primary-soft` (#F8E9D1), illustrations use cream and a darker burnt-red

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use a motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.
- Easing: prefer `cubic-bezier(0.22, 1, 0.36, 1)` (ease-out-quart) — never bounce or elastic.

## Backgrounds & Visual Depth

- Default to flat, graphic backgrounds — the cream / burnt-orange alternation IS the depth system. No shadows, no gradients, no blur, no glassmorphism.
- Compose each section with illustrated, hand-drawn-feeling SVG elements (suns, moons, mountains, towers, silhouettes, terraces, geometric arcs) reminiscent of editorial poster design.
- Use solid color blocks, thick borders, and geometric shapes for separation rather than soft elevation.
- Every decorative element must serve a compositional purpose (depth, separation, or storytelling). No purely ornamental effects competing with content.

## Must

- All sections: consistent 120px vertical padding
- All containers: max-width 1200px, centered, 32px horizontal padding
- Section headers: 56px or 72px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
- Section backgrounds STRICTLY alternate between #F8E9D1 (cream) and #BE3F00 (burnt orange)
- At least one graphic illustration or geometric SVG composition per major section
