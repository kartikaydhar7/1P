# Modals

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `buttons.md`, `inputs.md`

## Core Specs

### Overlay (Backdrop)
- Fixed, covers full screen
- Z-index: 40
- Background: dark token at 60% opacity
- No backdrop blur — clarity through solid color, not glass

### Content Container
- Background: neutral-primary
- Radius: 0px (sharp rectangular corners)
- Shadow: none — depth comes from the dark backdrop and a 2px border-default-strong border
- Border: 2px, border-default-strong
- Padding: 24px

## Anatomy

### Header
- Bottom border: 1px border-default
- Top corners: 0px
- Title: 22px, semibold (600), heading color, 0.4px tracking
- Close button: Ghost variant from `buttons.md`, 8px padding

### Body
- Vertical padding: 24px
- Vertical spacing between elements: 24px
- Text: 16px, 1.65 line-height, body color

### Footer
- Top border: 1px border-default
- Bottom corners: 0px

## Variants

### Default (Information)
Standard header + body + footer with primary/secondary action buttons.

### Pop-up (Confirmation)
Centered text, prominent icon, reduced padding:
- Body: 24px padding, text centered
- Icon: centered, 16px bottom margin, 48x48px, fg-brand-strong color, 0px radius

### Form Modal
Body contains inputs following `inputs.md`. Vertical spacing between form elements: 16px.

## Rules

- Backdrop covers full screen with fixed positioning
- Content: neutral-primary background, 0px radius, 2px border-default-strong border, no shadow
- Header/Footer separated by 1px border-default borders
- Close button must be present and functional
- Accessibility: `role="dialog"`, implement focus trap in code
- Dark mode automatic via token system
