# Pagination

> Dependencies: `colors.md`, `radius.md`

## Container

Font: 14px, semibold (600), 0.4px tracking. Items displayed as flex with -1px overlap for seamless borders.

## Pagination Item

- Layout: flex, centered both axes
- Size: 40x40px
- Text: body color
- Background: neutral-primary
- Border: 1px, border-default-medium
- Radius: 0px
- Hover: neutral-tertiary-medium background, heading text
- Focus: no default outline, 2px solid border-brand outline with 2px outer offset
- Overlap: -1px left margin

## Previous / Next Buttons

- Horizontal padding: 14px, height: 40px
- First item: 0px radius
- Last item: 0px radius

## Active Page Item

- Text: white
- Background: brand
- Border: 1px border-brand
- Hover background: brand-strong

## Rules

- Display as flex with -1px child overlap for seamless borders
- Items: neutral-primary background, border-default-medium border, body text
- Active: white text, brand background, brand border
- All corners are sharp (0px) — first and last items match the rest
- All items need hover and focus states
