# Radios, Checkboxes & Toggles

> Dependencies: `colors.md`, `radius.md`

## Checkbox

- Size: 18x18px
- Radius: 0px (sharp square)
- Border: 1.5px, border-default-strong
- Background: neutral-primary
- Checked: brand background, brand border, white check
- Focus outline: 2px solid border-brand-subtle, 2px outer offset

### Disabled
- Border: border-default-subtle
- Background: disabled
- Text: fg-disabled

## Radio

- Size: 18x18px
- Radius: 0px (sharp square — no circular radio in this system)
- Border: 1.5px, border-default-strong
- Background: neutral-primary
- Focus outline: 2px solid border-brand-subtle, 2px outer offset
- Checked: brand border, indicator: brand background filling the inner square

### Disabled
- Border: border-default-subtle
- Text: fg-disabled

Group all radio items under the same `name` attribute.

## Toggle

### Track
- Radius: 0px (rectangular track — no rounded toggle)
- Width: 40px, height: 22px
- Background: neutral-quaternary
- Border: 1px, border-default
- Focus-within outline: 2px solid border-brand-subtle, 2px outer offset
- Checked track: brand background, border-brand
- Disabled track: neutral-tertiary background

### Thumb
- Radius: 0px (square thumb that slides inside the track)
- Size: 18x18px
- Background: neutral-primary
- Border: 1px, border-default-strong

### Disabled
- Track: neutral-tertiary background
- Label: fg-disabled text

## Rules

- All selection inputs must have `id` matching label `htmlFor`
- Focus states use a 2px brand outline with 2px outer offset
- Disabled states: no hover/focus interaction
- All shapes are 0px radius — sharp squares only
