# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 0px | Buttons, cards, inputs, modals, sections |
| default | 0px | Badges, tooltips, dropdown items, small controls |
| sm | 0px | Checkboxes, tiny elements |
| full | 0px | Pills, avatars, toggles, dot indicators |

## Rules

- 0px is the default radius across the entire product — every component uses sharp, square corners
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
- The graphic, editorial aesthetic is achieved through sharp geometry — never soften it with rounded corners
