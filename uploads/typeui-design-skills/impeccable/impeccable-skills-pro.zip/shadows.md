# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `none` |
| shadow-xs | `none` |
| shadow-sm | `none` |
| shadow-md | `none` |
| shadow-lg | `none` |
| shadow-xl | `none` |
| shadow-2xl | `none` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls, lightweight cards | shadow-xs or shadow-sm |
| Standard cards, popovers, dropdowns | shadow-md |
| Prominent cards, sticky surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Shadows are disabled across the entire system — every shadow token resolves to `none`
- Depth and separation are conveyed through solid borders, color contrast, and the alternating cream / burnt-orange section pattern instead
- Never override a shadow token with a custom box-shadow value
- Hover/focus states use color and border changes for feedback, not shadow elevation
- Components in the same family share the same baseline (no elevation)
