# Sidebars

> Dependencies: `colors.md`, `radius.md`, `typography.md`, `badges.md`, `alerts.md`

## Core Specs

- Background: neutral-primary-soft (cream)
- Right border: 1px, border-default (for left-sidebar); left border for right-sidebar
- Width: 264px

## Anatomy

### Outer Container
Hidden on mobile, visible at small breakpoint. Needs a toggle/trigger for mobile.

### Inner Wrapper
- Full height, vertical scroll overflow
- Padding: 16px horizontal, 20px vertical

### Navigation List
- Vertical spacing: 4px between items
- Font weight: semibold (600), 0.4px tracking

### Navigation Item
- Layout: flex, vertically centered
- Padding: 12px horizontal, 10px vertical
- Text: heading color
- Radius: 0px
- Hover: neutral-secondary-medium background
- Transition: background-color and color, 150ms ease-out
- Icon: 20x20px, body color, hover → heading color, 75ms transition
- Label: 12px left margin from icon

### Active Item
- Background: brand-softer
- Border-left: 3px solid border-brand (graphic accent stripe)
- Text: fg-brand-strong

### Separator
- 16px top padding, 16px top margin
- Top border: 1px border-default
- 8px vertical spacing below

### Bottom CTA / Card
- Padding: 20px
- Top margin: 24px
- Radius: 0px
- Border: 2px border-orange (graphic frame)
- Background: brand-softer
- Can also use any alert variant from `alerts.md`

## Rules

- Responsive: hidden on mobile with a trigger mechanism
- Icons: 20x20px, body color (hover: heading color)
- Multi-level menus: indent with 44px left padding
- Spacing follows 8px grid
- Active items use a 3px left border in border-brand for a poster-like graphic accent
- Only neutral, brand, or status tokens — no arbitrary colors
