# Tables

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Wrapper

- Horizontal scroll overflow
- Background: neutral-primary
- Radius: 0px (sharp rectangular corners)
- Border: 2px, border-default-strong (replaces shadow as the framing device)
- Shadow: none

## Table Element

- Full width, left-aligned text (right-aligned for RTL)
- Font: 14px, body color

## Table Head

- Font: 12px, heading color, semibold (600), uppercase, 0.6px tracking
- Background: neutral-secondary-soft (cream tint)
- Bottom border: 2px, border-default-strong
- Cell padding: 24px horizontal, 14px vertical

## Table Body

- Row background: neutral-primary
- Row bottom border: 1px border-default (omit on last row to avoid doubling with wrapper border)
- Row hover: neutral-secondary-medium background (optional)
- Row header: semibold weight, heading color, no-wrap
- Cell padding: 24px horizontal, 16px vertical

## Rules

- Wrapper must have horizontal scroll overflow for responsive scrolling
- Wrapper uses a 2px border in border-default-strong instead of any shadow
- Last row: omit bottom border to avoid doubling with wrapper border
- Row headers: always `scope="row"` for semantic structure
- Hover on rows is optional
- No arbitrary hex codes — use token colors only
- All corners are sharp (0px)
