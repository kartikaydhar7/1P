# Tabs

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs

- Typography: 14px, semibold (600), 0.4px tracking, body color
- Transitions: background-color, color, and border-color, 200ms ease-out

## Variants

### 1. Underline (Default)

**Wrapper:** bottom border, 1px border-default

**Tab Item:**
- Padding: 18px horizontal, 14px vertical
- Bottom border: 3px, transparent
- Top corners: 0px
- Transition: color and border-color, 150ms ease-out

| State | Appearance |
|---|---|
| Active | fg-brand-strong text, 3px border-brand bottom border |
| Inactive | transparent bottom border; hover → heading text, 3px border-default-strong bottom border |
| Disabled | fg-disabled text, not-allowed cursor |

### 2. Pills

**Tab Item:**
- Padding: 18px horizontal, 10px vertical
- Radius: 0px (rectangular pills)
- Border: 1px transparent
- Font weight: semibold
- Transition: background-color, color, and border-color, 200ms ease-out

| State | Appearance |
|---|---|
| Active | brand background, white text, brand border |
| Inactive | body text; hover → neutral-secondary-medium background, heading text |
| Disabled | fg-disabled text, not-allowed cursor |

### 3. Full Width

Children overlap with -1px left margin on all except first.

**Tab Item:**
- Full width, centered text
- Padding: 18px horizontal, 16px vertical
- Background: neutral-primary
- Border: 1px, border-default
- Radius: 0px
- Transition: background-color, color, and border-color, 150ms ease-out
- Hover: neutral-secondary-medium background, heading text

| State | Appearance |
|---|---|
| Active | neutral-secondary-soft background, fg-brand-strong text, border-brand top accent (3px) |
| First item | 0px radius (sharp corners) |
| Last item | 0px radius (sharp corners) |

## Tabs with Icons

- Icon size: 16x16px or 20x20px
- Spacing: 8px right margin
- Layout: inline-flex, centered
- Icons inherit the text color of the tab state
