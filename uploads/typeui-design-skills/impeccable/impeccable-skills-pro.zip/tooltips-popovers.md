# Tooltips & Popovers

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Tooltips

### Core Specs
- Padding: 12px horizontal, 8px vertical
- Font: 13px, semibold (600), 0.4px tracking
- Radius: 0px
- Shadow: none
- Transition: opacity, 200ms ease-out

### Dark (Default)
- Background: dark
- Text: white
- Border: 1px, dark-strong

### Light
- Background: neutral-primary
- Text: heading color
- Border: 1px, border-default-strong

## Popovers

### Core Specs
- Background: neutral-primary
- Radius: 0px
- Shadow: none
- Border: 2px, border-default-strong
- Transition: opacity, 200ms ease-out

### Header / Title
- Padding: 14px horizontal, 10px vertical
- Background: neutral-secondary-soft (cream tint)
- Bottom border: 1px border-default
- Font: 14px, semibold (600), heading color, 0.4px tracking

### Body / Content
- Standard: 14px horizontal, 10px vertical padding; 14px, body color
- Rich: 18px padding; 14px, body color, 1.55 line-height

## Arrows

- Size: 8x8px rotated 45deg (sharp triangular tail)
- Color must match the background of the tooltip/popover variant
- Border on the two visible edges should match the wrapper border

## Rules

- Tooltips: 0px radius, no shadow
- Popovers: 0px radius, 2px solid border replaces the shadow as the depth cue
- Dark tooltips: dark background, white text
- Light tooltips/popovers: semantic neutral background + border tokens
- Arrows match parent background color and inherit border color on visible edges
