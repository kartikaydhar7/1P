# Typography

> Dependencies: `colors.md`

## Core Rules

- **Font:** "Chakra Petch", sans-serif — configured at app level, never override. Load weights 300, 400, 500, 600, 700 (with italics where used).
- **Headings:** semibold weight (600) or bold (700) for hero scale, heading text color, slight uppercase tracking allowed for display headings
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 72px | 1 | -1px | 24px |
| `h2` | 52px | 1.1 | -0.5px | 20px |
| `h3` | 40px | 1.15 | -0.3px | 16px |
| `h4` | 32px | 1.2 | -0.2px | 14px |
| `h5` | 24px | 1.3 | 0 | 12px |
| `h6` | 20px | 1.35 | 0.4px | 12px |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 48px | 36px |
| `h2` | 40px | 32px |
| `h3` | 32px | 26px |
| `h4` | 28px | 22px |
| `h5` | 22px | 20px |
| `h6` | 18px | 18px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.0 for any heading.

## Paragraphs

### Leading Paragraph
- Size: 20px
- Weight: 400 (normal)
- Color: body
- Line-height: 1.6
- Max width: ~70 characters

### Normal Paragraph
- Size: 16px
- Weight: 400 (normal)
- Color: body
- Line-height: 1.65
- Max width: ~65 characters

### Small Supporting Copy
- Size: 14px
- Weight: 400 (normal)
- Color: body
- Line-height: 1.55
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 14px | 600 (semibold) |
| Input labels | 14px or 16px | 500 (medium) |
| Captions / meta / badges | 12px or 14px | 600 (semibold), uppercase, 0.6px tracking |

Do not apply paragraph line-height (1.6) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline (1px solid current), hover → fg-brand-strong color, underline thickens to 2px
- **CTA links:** fg-brand color, semibold weight, no underline at rest, hover → underline appears

## Emphasis

- `<strong>` for high-priority emphasis in body text — use 700 weight
- `<em>` for tone emphasis only, italic, not visual hierarchy
- All-caps only for short labels: uppercase, 0.6px letter-spacing, 12px or 14px

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, and spacing remain constant.
