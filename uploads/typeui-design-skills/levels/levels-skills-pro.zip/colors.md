# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #000000 | #000000 |
| neutral-primary | #000000 | #000000 |
| neutral-primary-medium | #050505 | #050505 |
| neutral-primary-strong | #0A0A0A | #0A0A0A |
| neutral-secondary-soft | #000000 | #000000 |
| neutral-secondary | #000000 | #000000 |
| neutral-secondary-medium | #0A0A0A | #0A0A0A |
| neutral-secondary-strong | #111111 | #111111 |
| neutral-tertiary-soft | #0A0A0A | #0A0A0A |
| neutral-tertiary | #111111 | #111111 |
| neutral-tertiary-medium | #1A1A1A | #1A1A1A |
| neutral-quaternary | #222222 | #222222 |
| quaternary-medium | #2A2A2A | #2A2A2A |
| gray | #3A3A3A | #3A3A3A |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #1C0D00 | #1C0D00 |
| brand-soft | #331400 | #331400 |
| brand | #FF6C00 | #FF6C00 |
| brand-medium | #331400 | #331400 |
| brand-strong | #CC5500 | #CC5500 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #001A12 | #001A12 |
| success | #009966 | #009966 |
| success-medium | #002E1F | #002E1F |
| success-strong | #007A55 | #007A55 |
| danger-soft | #1A0008 | #1A0008 |
| danger | #C70036 | #C70036 |
| danger-medium | #330010 | #330010 |
| danger-strong | #A50036 | #A50036 |
| warning-soft | #1A0E00 | #1A0E00 |
| warning | #F97316 | #F97316 |
| warning-medium | #331C00 | #331C00 |
| warning-strong | #C2410C | #C2410C |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.12) | rgba(255,255,255,0.12) |
| `--color-1-700` | rgba(0,0,0,0.25) | rgba(0,0,0,0.25) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #E5E7EB | #E5E7EB |
| dark-strong | #D1D5DC | #D1D5DC |
| disabled | #111111 | #111111 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #A855F7 |
| sky | #0EA5E9 |
| teal | #0D9488 |
| pink | #DB2777 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #FF6C00 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #000000 | #000000 |
| heading | #FFFFFF | #FFFFFF |
| body | #9CA3AF | #9CA3AF |
| body-subtle | #71717A | #71717A |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #FFCFA3 | #FFCFA3 |
| fg-brand | #FF6C00 | #FF6C00 |
| fg-brand-strong | #FF8C33 | #FF8C33 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #10B981 | #10B981 |
| fg-success-strong | #34D399 | #34D399 |
| fg-danger | #F43F5E | #F43F5E |
| fg-danger-strong | #FB7185 | #FB7185 |
| fg-warning-subtle | #F97316 | #F97316 |
| fg-warning | #FBBF24 | #FBBF24 |
| fg-disabled | #52525B | #52525B |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #93C5FD | #93C5FD |
| fg-purple | #A855F7 | #A855F7 |
| fg-purple-strong | #C084FC | #C084FC |
| fg-cyan | #22D3EE | #22D3EE |
| fg-indigo | #818CF8 | #818CF8 |
| fg-pink | #EC4899 | #EC4899 |
| fg-lime | #84CC16 | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #4B5563 | #4B5563 |
| border-buffer | #000000 | #000000 |
| border-buffer-medium | #000000 | #000000 |
| border-buffer-strong | #0A0A0A | #0A0A0A |
| border-muted | #0A0A0A | #0A0A0A |
| border-light-subtle | #111111 | #111111 |
| border-light | #1A1A1A | #1A1A1A |
| border-light-medium | #222222 | #222222 |
| border-default-subtle | #1A1A1A | #1A1A1A |
| border-default | #222222 | #222222 |
| border-default-medium | #2A2A2A | #2A2A2A |
| border-default-strong | #333333 | #333333 |
| border-success-subtle | #064E3B | #064E3B |
| border-success | #059669 | #059669 |
| border-danger-subtle | #881337 | #881337 |
| border-danger | #E11D48 | #E11D48 |
| border-warning-subtle | #92400E | #92400E |
| border-warning | #F97316 | #F97316 |
| border-brand-subtle | #6B2E00 | #6B2E00 |
| border-brand-light | #FF6C00 | #FF6C00 |
| border-brand | #FF6C00 | #FF6C00 |
| border-dark-subtle | #4B5563 | #4B5563 |
| border-purple | #A855F7 | #A855F7 |
| border-orange | #FF6C00 | #FF6C00 |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (black) for all sections — no alternating tints
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
