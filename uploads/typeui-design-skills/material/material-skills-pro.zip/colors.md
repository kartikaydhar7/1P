# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFBFE | #1D1B20 |
| neutral-primary | #FFFFFF | #141218 |
| neutral-primary-medium | #FFFBFE | #2B2930 |
| neutral-primary-strong | #FFFBFE | #36343B |
| neutral-secondary-soft | #F7F2FA | #1D1B20 |
| neutral-secondary | #F7F2FA | #141218 |
| neutral-secondary-medium | #F3EDF7 | #2B2930 |
| neutral-secondary-strong | #F3EDF7 | #36343B |
| neutral-tertiary-soft | #ECE6F0 | #1D1B20 |
| neutral-tertiary | #ECE6F0 | #2B2930 |
| neutral-tertiary-medium | #ECE6F0 | #36343B |
| neutral-quaternary | #E6E0E4 | #36343B |
| quaternary-medium | #E6E0E4 | #49454F |
| gray | #CAC4D0 | #49454F |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #F6EDFF | #2D1F5E |
| brand-soft | #EADDFF | #4F378B |
| brand | #675496 | #D0BCFF |
| brand-medium | #D0BCFF | #4F378B |
| brand-strong | #4F378B | #675496 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #E8F5E9 | #002114 |
| success | #2E7D32 | #66BB6A |
| success-medium | #C8E6C9 | #003822 |
| success-strong | #1B5E20 | #2E7D32 |
| danger-soft | #F9DEDC | #410002 |
| danger | #B3261E | #F2B8B5 |
| danger-medium | #FCEEEE | #8C1D18 |
| danger-strong | #8C1D18 | #B3261E |
| warning-soft | #FFF3E0 | #4E2600 |
| warning | #E65100 | #FFB74D |
| warning-medium | #FFE0B2 | #4E2600 |
| warning-strong | #BF360C | #E65100 |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #1D1B20 | #1D1B20 |
| dark-strong | #141218 | #36343B |
| disabled | #F3EDF7 | #2B2930 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #9A82DB |
| sky | #0288D1 |
| teal | #00897B |
| pink | #D81B60 |
| cyan | #00ACC1 |
| fuchsia | #AB47BC |
| indigo | #3F51B5 |
| orange | #FB8C00 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #1D1B20 | #1D1B20 |
| heading | #1D1B20 | #E6E0E4 |
| body | #49454F | #CAC4D0 |
| body-subtle | #79747E | #938F99 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #D0BCFF | #4F378B |
| fg-brand | #675496 | #D0BCFF |
| fg-brand-strong | #21005D | #EADDFF |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #2E7D32 | #1B5E20 |
| fg-success-strong | #1B5E20 | #66BB6A |
| fg-danger | #B3261E | #F2B8B5 |
| fg-danger-strong | #8C1D18 | #FFB4AB |
| fg-warning-subtle | #E65100 | #FFB74D |
| fg-warning | #BF360C | #FFCC80 |
| fg-disabled | #CAC4D0 | #79747E |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #F9A825 | #FDD835 |
| fg-info | #1A237E | #90CAF9 |
| fg-purple | #7B1FA2 | #CE93D8 |
| fg-purple-strong | #6A1B9A | #E1BEE7 |
| fg-cyan | #00838F | #4DD0E1 |
| fg-indigo | #3F51B5 | #7986CB |
| fg-pink | #D81B60 | #F48FB1 |
| fg-lime | #558B2F | #9CCC65 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #1D1B20 | #49454F |
| border-buffer | #FFFFFF | #141218 |
| border-buffer-medium | #FFFFFF | #2B2930 |
| border-buffer-strong | #FFFFFF | #36343B |
| border-muted | #F7F2FA | #1D1B20 |
| border-light-subtle | #ECE6F0 | #1D1B20 |
| border-light | #ECE6F0 | #2B2930 |
| border-light-medium | #ECE6F0 | #36343B |
| border-default-subtle | #E7E0EC | #1D1B20 |
| border-default | #E7E0EC | #2B2930 |
| border-default-medium | #CAC4D0 | #49454F |
| border-default-strong | #CAC4D0 | #79747E |
| border-success-subtle | #C8E6C9 | #003822 |
| border-success | #2E7D32 | #1B5E20 |
| border-danger-subtle | #F9DEDC | #8C1D18 |
| border-danger | #B3261E | #B3261E |
| border-warning-subtle | #FFE0B2 | #4E2600 |
| border-warning | #E65100 | #FFB74D |
| border-brand-subtle | #D0BCFF | #4F378B |
| border-brand-light | #675496 | #D0BCFF |
| border-brand | #675496 | #D0BCFF |
| border-dark-subtle | #1D1B20 | #36343B |
| border-purple | #9A82DB | #CE93D8 |
| border-orange | #FB8C00 | #FFB74D |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
