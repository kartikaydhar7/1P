# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 12px | Cards, inputs, modals, sections |
| default | 8px | Badges, chips, tooltips, dropdown items, small controls |
| sm | 4px | Checkboxes, tiny elements |
| full | 9999px | Buttons, pills, avatars, toggles, FABs, dot indicators |

## Rules

- Buttons use 9999px (full) as the default radius for a pill shape
- 12px (base) is the default radius for containers and surfaces
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
