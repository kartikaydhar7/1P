# Avatars

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Circular shape:** fully rounded (9999px)
- **Rounded square shape:** 2px radius (universal across the system)
- **Default size:** 40x40px
- **Image fit:** cover

## Sizes

| Size | Dimensions | Radius |
|---|---|---|
| Extra Small | 18x18px | 2px |
| Small | 24x24px | 2px |
| Base | 32x32px | 2px |
| Large | 44x44px | 2px |
| XL | 56x56px | 2px |
| 2XL | 64x64px | 2px |

## Bordered Avatar

- 4px padding, fully rounded, 1px outline in border-default color
- Alternative: 1px box-shadow ring in border-default color

## Stacked Avatars

- Displayed in a row (flex)
- Each avatar: 32x32px, fully rounded, 1px border in border-buffer color
- Overlap: -10px negative margin on all except first

### Stacked Counter
- Same size as avatars (32x32px), fully rounded
- Background: neutral-primary-medium, text: heading, 11px font, medium weight, uppercase
- Same overlap margin as other avatars

## Avatar with Text

- Flex row, 10px gap between avatar and text
- Avatar: 32x32px, fully rounded, cover fit
- Name: heading color, bold weight (700), Space Mono
- Subtitle: 12px, body-subtle color, uppercase, 0.04em letter-spacing
