# Badges

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Border:** 1px
- **Default radius:** 2px
- **Pill radius:** 9999px
- **Text treatment:** uppercase, 0.04em letter-spacing, medium weight (500)

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Default (small) | 11px | 6px | 2px |
| Large | 12px | 8px | 4px |

## Variants

### Brand
- **Background:** brand-softer
- **Border:** border-brand-subtle
- **Text:** fg-brand-strong

### Alternative (Neutral Soft)
- **Background:** neutral-primary-medium
- **Border:** border-default
- **Text:** heading

### Gray (Neutral Medium)
- **Background:** neutral-secondary-medium
- **Border:** border-default
- **Text:** body

### Danger
- **Background:** danger-soft
- **Border:** border-danger-subtle
- **Text:** fg-danger-strong

### Success
- **Background:** success-soft
- **Border:** border-success-subtle
- **Text:** fg-success-strong

### Warning
- **Background:** warning-soft
- **Border:** border-warning-subtle
- **Text:** fg-warning

### Dark
- **Background:** dark
- **Border:** border-default
- **Text:** heading

## Pill Badges

Use 9999px radius instead of 2px on any variant. Pills are best for status tags such as "LIVE", "BID", "ASK".

## Badges with Icons

- Icon size (default): 11x11px
- Icon size (large): 12x12px
- Icon spacing: 4px margin next to label

## Icon-only Badge

Square shape — equalize dimensions to 20x20px (default) or 24x24px (large), no horizontal text padding, 2px radius.

## Dismissible Badges

Badge content + a close button. Close button hover backgrounds per variant:

| Variant | Close button hover background |
|---|---|
| Brand | brand-soft |
| Alternative | neutral-tertiary |
| Gray | neutral-quaternary |
| Danger | danger-medium |
| Success | success-medium |
| Warning | warning-medium |

## Dot / Notification Badge

- Positioned absolutely: -4px top, -4px right
- Size: 8x8px, fully rounded
- 1px border in border-buffer color
- Background: danger
