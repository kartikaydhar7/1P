# Borders

## Width Scale

| Context | Width |
|---|---|
| Default (inputs, buttons, cards) | 1px |
| Emphasis / focus | 1px (with a separate 2px focus ring color) |
| Decorative split borders (e.g. brand button top/bottom edge) | 1px on top and bottom only, 0 on sides |

## Rules

- Use solid borders by default — the system reads through hairline 1px lines, not heavier strokes
- Dashed borders only for special cases like file dropzones
- Components in the same family must use matching border widths
- Never mix 1px and 2px borders within a single component
- Borders always use a token from `colors.md` (border-default, border-default-medium, border-brand, etc.) — never raw hex
- Decorative borders that fade at the edges (radial-gradient border images) are reserved for the brand button — see `buttons.md`

## Usage

| Context | Width |
|---|---|
| Inputs / selects / textareas | 1px default; 1px in border-brand on focus or border-danger on error, with a 2px focus ring color |
| Buttons | 1px for variants that require outlining; 1px top + 1px bottom only on the brand button |
| Cards / containers | 1px subtle; avoid stacked heavy borders |
| Section dividers | 1px in border-default-subtle, full width, no padding |
