# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except brand, ghost, and disabled)

- **Radius:** 2px (base) or 9999px for pills
- **Border:** 1px solid
- **Shadow:** shadow-xs
- **Glint effect:** Every button except brand, ghost, and disabled gets a layered effect that combines the base shadow with an inset top-edge highlight and a subtle outer brand glow:
  - base: `shadow-xs`
  - inset top edge: `--color-1-400` (subtle green-tinted highlight along the top inner edge)
  - outer halo: `--color-1-700` (faint green-tinted glow below the button)
- **Font:** Space Mono, monospace
- **Font weight:** 700 (bold)
- **Text treatment:** uppercase, 0.04em letter-spacing
- **Box sizing:** border-box
- **Transition:** color and background transitions on hover, 150ms

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 11px | 10px | 6px |
| Small | 12px | 12px | 8px |
| Base (default) | 14px | 16px | 10px |
| Large | 14px | 20px | 12px |
| Extra large | 16px | 24px | 14px |

## Variants

### Brand (the signature primary action — Cyber Slick gridline button)

The brand button is the system's signature interaction. It is decorative on purpose: a flat surface with a faint scan-line grid running through it, topped and bottomed by a hairline edge that fades to nothing at the corners. Reserve it for the single most important action per screen.

**Surface composition (all stacked into the background, in this exact order from top to bottom):**

1. **Radial halo** — a soft green glow centered in the button. It uses the brand-button background tint (a translucent green at roughly 36% opacity over the surface) and fades to fully transparent by ~95% of the radius. This is what gives the button its "lit-from-within" feel.
2. **Horizontal scan lines** — a 1px green-tinted line repeated every 15px vertically. The line color is a very faint translucent green (the "pattern" tint, roughly 7% opacity).
3. **Vertical scan lines** — a 1px green-tinted line repeated every 15px horizontally, using the same pattern tint.

The three layers compose into a flat green grid lit from the center.

**Edge / border (instead of a normal solid border):**

- Top edge: 1px line that uses a radial-gradient image — bright brand green at the center, fading to fully transparent at both horizontal ends.
- Bottom edge: same treatment as the top edge.
- Left and right: no border (0 width). The grid is open on the sides.

**Token mapping for the brand button:**

| Role | Token / value |
|---|---|
| Halo center color (~36% alpha) | brand at 36% opacity |
| Pattern line color (~7% alpha) | brand at 7% opacity |
| Edge gradient peak | brand |
| Text color | heading (matches the `on-primary` reading on the dark surface) — uppercase, 0.5em letter-spacing |
| Padding | 16px vertical, 48px horizontal |
| Font size | 16px (large) up to 20px (extra-large hero placement) |
| Font weight | 700 (bold) |
| Text transform | uppercase |
| Letter-spacing | 0.5em (intentionally wide — this is part of the visual identity) |
| Cursor | pointer |
| Filter | hue-rotate baseline at 0deg |

**Hover:**
- The horizontal and vertical scan-line spacing tightens from 15px → 10px, giving the impression of the grid pulling closer to the surface. Transition the background-size over ~200ms.
- Halo and edge gradient remain unchanged.

**Active / pressed:**
- Apply a hue-rotate of ~250deg to the entire button. The green grid shifts toward magenta/violet for the duration of the press, then snaps back on release.

**Focus:**
- 2px focus ring in brand color, offset 2px from the button.

**Disabled brand:**
- Halo, pattern, and edge all desaturate to gray (use border-default-medium for the edge gradient peak, neutral-tertiary at low opacity for the halo, and border-default-subtle for the scan lines).
- Text: fg-disabled.
- Cursor: not-allowed.

### Secondary
- **Background:** neutral-secondary-medium
- **Border:** border-default-medium
- **Text:** body color, uppercase, 0.04em letter-spacing
- **Hover:** neutral-tertiary-medium background, heading text color
- **Focus ring:** 2px, brand color
- **Glint:** yes

### Tertiary
- **Background:** neutral-primary-soft
- **Border:** border-default
- **Text:** body color, uppercase, 0.04em letter-spacing
- **Hover:** neutral-secondary-medium background, heading text color
- **Focus ring:** 2px, border-default-strong color
- **Glint:** yes

### Success
- **Background:** success token
- **Border:** transparent
- **Text:** dark (uppercase, 0.04em letter-spacing — this is the on-primary token reading on a green surface)
- **Hover:** success-strong background
- **Focus ring:** 2px, success color
- **Glint:** yes

### Danger
- **Background:** danger token
- **Border:** transparent
- **Text:** white
- **Hover:** danger-strong background
- **Focus ring:** 2px, danger color
- **Glint:** yes

### Warning
- **Background:** warning token
- **Border:** transparent
- **Text:** dark
- **Hover:** warning-strong background
- **Focus ring:** 2px, warning color
- **Glint:** yes

### Dark
- **Background:** dark token
- **Border:** border-default
- **Text:** heading
- **Hover:** dark-strong background
- **Focus ring:** 2px, border-default-strong color
- **Glint:** yes

### Ghost (NO shadow, NO glint)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color, uppercase, 0.04em letter-spacing
- **Hover:** neutral-secondary-medium background
- **Focus ring:** 2px, border-default-strong color
- **No shadow, no glint effect**

### Disabled (NO shadow, NO glint)
- **Background:** disabled token
- **Border:** border-default-subtle
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no glint**

## Icons in Buttons

- Icon size: 14x14px (small/base) or 16x16px (large/xl)
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
- Icon color: matches the button's text color in every state

## Rules

- The brand button is unique — no other variant should attempt to mimic the radial halo, scan-line grid, or fading hairline edges
- Use the brand button for exactly one action per screen — the single-accent rule is load-bearing
- Never combine the brand button's wide letter-spacing with the brand's body or heading typography
- Never disable the uppercase text treatment on any non-disabled button — uppercase + bold is part of the system identity
