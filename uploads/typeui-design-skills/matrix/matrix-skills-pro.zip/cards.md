# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-primary-medium (the card surface tone — a single step lifted off the page surface)
- **Border:** 1px, border-default color
- **Radius:** 2px (base — universal across the system)
- **Shadow:** shadow-xs

Cards always sit on top of the page surface (neutral-primary-soft) and are the only common surface that lifts off it. They never repeat the page surface tone.

## Card Heading

- Desktop: 18px, bold weight (700), heading color
- Mobile: 16px, bold weight (700), heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## Card Body

- Padding: 24px on all sides (compact variants may reduce to 16px)
- Body text: 14px, body color, 1.5 line-height
- Numerals (tickers, prices, quantities, percentages) follow the tabular treatment from `typography.md`

## States

### Static Card (no interactivity)
- Background: neutral-primary-medium
- Border: 1px, border-default
- Radius: 2px
- Shadow: shadow-xs
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: border becomes border-default-medium, shadow steps up to shadow-sm
- Transition: border and shadow, 150ms
- Cursor: pointer

### Highlighted Card (one per surface, optional)
- Same base styles as static card
- Border: 1px, border-brand
- Reserved for the single most important card per surface — never use for a row of cards

## Rules

- Background: neutral-primary-medium (never neutral-primary-soft — that is the page surface)
- Border: 1px, border-default
- Radius: 2px (no exceptions — the cyber-slick aesthetic depends on it)
- Shadow: shadow-xs
- Interactive hover: border-default-medium border, shadow-sm shadow
- Non-interactive: no hover styles
- Cards must never alternate background colors within a section — the card surface tone is the same throughout the system
