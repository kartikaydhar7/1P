# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #0A0D14 | #0A0D14 |
| neutral-primary | #0A0D14 | #0A0D14 |
| neutral-primary-medium | #11141D | #11141D |
| neutral-primary-strong | #181C28 | #181C28 |
| neutral-secondary-soft | #0A0D14 | #0A0D14 |
| neutral-secondary | #0A0D14 | #0A0D14 |
| neutral-secondary-medium | #11141D | #11141D |
| neutral-secondary-strong | #1A1F2C | #1A1F2C |
| neutral-tertiary-soft | #11141D | #11141D |
| neutral-tertiary | #181C28 | #181C28 |
| neutral-tertiary-medium | #1F2433 | #1F2433 |
| neutral-quaternary | #2A2F3D | #2A2F3D |
| quaternary-medium | #383D4D | #383D4D |
| gray | #6E7786 | #6E7786 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #0E2A20 | #0E2A20 |
| brand-soft | #143F30 | #143F30 |
| brand | #26A17B | #26A17B |
| brand-medium | #143F30 | #143F30 |
| brand-strong | #1F8666 | #1F8666 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #08251C | #08251C |
| success | #26A17B | #26A17B |
| success-medium | #0E3024 | #0E3024 |
| success-strong | #2DC093 | #2DC093 |
| danger-soft | #2A0814 | #2A0814 |
| danger | #E03050 | #E03050 |
| danger-medium | #4A0E20 | #4A0E20 |
| danger-strong | #B82742 | #B82742 |
| warning-soft | #2A1F0A | #2A1F0A |
| warning | #D4A024 | #D4A024 |
| warning-medium | #4A380F | #4A380F |
| warning-strong | #B8861E | #B8861E |

### Button Glint (custom properties, used for the glint effect over buttons)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(38, 161, 123, 0.18) | rgba(38, 161, 123, 0.18) |
| `--color-1-700` | rgba(38, 161, 123, 0.10) | rgba(38, 161, 123, 0.10) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #0A0D14 | #0A0D14 |
| dark-strong | #050709 | #050709 |
| disabled | #11141D | #11141D |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #92AFD7 |
| sky | #5BA3D4 |
| teal | #26A17B |
| pink | #D45B95 |
| cyan | #5BD4C5 |
| fuchsia | #C45BD4 |
| indigo | #92AFD7 |
| orange | #D49B5B |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #E6E9EF | #E6E9EF |
| black | #050709 | #050709 |
| heading | #E6E9EF | #E6E9EF |
| body | #A0A8B5 | #A0A8B5 |
| body-subtle | #6E7786 | #6E7786 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #143F30 | #143F30 |
| fg-brand | #26A17B | #26A17B |
| fg-brand-strong | #2DC093 | #2DC093 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #26A17B | #26A17B |
| fg-success-strong | #2DC093 | #2DC093 |
| fg-danger | #E03050 | #E03050 |
| fg-danger-strong | #FF5070 | #FF5070 |
| fg-warning-subtle | #D4A024 | #D4A024 |
| fg-warning | #FFC04F | #FFC04F |
| fg-disabled | #4A4F5D | #4A4F5D |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #D4A024 | #D4A024 |
| fg-info | #92AFD7 | #92AFD7 |
| fg-purple | #92AFD7 | #92AFD7 |
| fg-purple-strong | #B0C5E0 | #B0C5E0 |
| fg-cyan | #5BD4C5 | #5BD4C5 |
| fg-indigo | #92AFD7 | #92AFD7 |
| fg-pink | #D45B95 | #D45B95 |
| fg-lime | #2DC093 | #2DC093 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #6E7786 | #6E7786 |
| border-buffer | #0A0D14 | #0A0D14 |
| border-buffer-medium | #11141D | #11141D |
| border-buffer-strong | #181C28 | #181C28 |
| border-muted | #11141D | #11141D |
| border-light-subtle | #0A0D14 | #0A0D14 |
| border-light | #11141D | #11141D |
| border-light-medium | #181C28 | #181C28 |
| border-default-subtle | #181C28 | #181C28 |
| border-default | #1F2433 | #1F2433 |
| border-default-medium | #2A2F3D | #2A2F3D |
| border-default-strong | #383D4D | #383D4D |
| border-success-subtle | #143F30 | #143F30 |
| border-success | #26A17B | #26A17B |
| border-danger-subtle | #4A0E20 | #4A0E20 |
| border-danger | #E03050 | #E03050 |
| border-warning-subtle | #4A380F | #4A380F |
| border-warning | #D4A024 | #D4A024 |
| border-brand-subtle | #143F30 | #143F30 |
| border-brand-light | #26A17B | #26A17B |
| border-brand | #26A17B | #26A17B |
| border-dark-subtle | #1F2433 | #1F2433 |
| border-purple | #92AFD7 | #92AFD7 |
| border-orange | #D49B5B | #D49B5B |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (single surface across the whole product — never alternate)
- Cards layered over the surface: neutral-primary-medium (the card surface tone)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text
- Reserve fg-info / purple (#92AFD7) for sparing accents only — metadata badges, tertiary tags, niche callouts. Never for body copy.
- Reserve the brand accent (#26A17B) for interaction. Aim for one primary brand action per screen — the single-accent rule is load-bearing.

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No light-mode palette. The system is dark-only across all surfaces
- No alternating section backgrounds. Every section sits on the same neutral surface
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No gradients on layout surfaces — the system is flat by intent (the brand button glow is the single exception)
