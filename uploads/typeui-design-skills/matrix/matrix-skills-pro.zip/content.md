# Content & Grid System

> Dependencies: `layout.md`, `typography.md`

## Containers

| Type | Max width | Horizontal padding |
|---|---|---|
| Standard | 1280px | 24px |
| Internal (reading) | 720px | — (45–75 char line length) |

## Vertical Padding

| Breakpoint | Vertical padding |
|---|---|
| Mobile | 32px |
| Tablet (≥768px) | 48px |
| Desktop (≥1024px) | 64px or 96px for hero/feature sections |

## Grid System

Mobile-first with flexible desktop configurations. The cyber-slick aesthetic favors dense, table-like grids over generous editorial whitespace.

| Context | Gap |
|---|---|
| Standard content/cards | 16px |
| Compact widgets/metadata | 8px |
| Hero / feature blocks | 24px |

### Responsive Columns

| Breakpoint | Columns |
|---|---|
| Mobile (default) | 1–2 |
| Small/Tablet (≥640px) | 2–4 |
| Desktop (≥1024px) | 3–12 |

Full support for 6, 7, 8, 9+ column grids where needed. Order-book layouts depend on dense column counts.

## Breakpoints

| Name | Width |
|---|---|
| Small | 640px |
| Medium | 768px |
| Large | 1024px |
| Extra large | 1280px |
| 2x Extra large | 1536px |

## Rules

- Always design mobile-first
- Use layout shifts (column → row) to accommodate horizontal space
- Lists: 16px indentation, 12px vertical gap between items
- Body copy: 14px, 1.5 line-height
- All interactive links follow brand underline/hover protocol
- Numeric grids (tickers, tables, dashboards) use Space Mono's tabular numerals — never override
- The page surface is single-tone — no alternating section backgrounds anywhere in the grid
