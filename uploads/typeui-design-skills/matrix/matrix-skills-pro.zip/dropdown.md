# Dropdown

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `inputs.md`

## Core Specs

### Chevron Icon
- Size: 14x14px
- Spacing: 6px left margin, -2px right margin
- Color: inherits from trigger button

### Menu Container
- Background: neutral-primary-medium
- Border: 1px, border-default
- Radius: 2px (base — universal)
- Shadow: shadow-md
- Z-index: elevated above content

### Menu List
- Padding: 4px
- Font: Space Mono, 13px, body color, medium weight

### Menu Item
- Layout: inline-flex, vertically centered, full width
- Padding: 8px horizontal, 8px vertical
- Radius: 2px
- Hover: neutral-tertiary background, heading text
- Transition: colors, 150ms

## Trigger Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Small | 12px | 12px | 8px |
| Base | 13px | 16px | 10px |
| Large | 14px | 20px | 12px |

## Icon-only Trigger

- Padding: 8px
- Min size: 36x36px
- Icon: 16x16px

## Variants

### Default
- Menu width: 200px, items have 2px radius

### With Divider
- Top border (border-default) between child groups, skip first group

### With Header
- Header padding: 16px horizontal, 12px vertical
- Bottom border: border-default
- Name: heading color, 13px, bold weight, uppercase, 0.04em letter-spacing
- Email: body-subtle color, 12px, truncated

### With Icons
- Icon before label: 14x14px, 8px right margin, body-subtle color
- On hover, icon color changes to heading

### With Checkbox / Radio
- Inputs: 14x14px, 2px radius, focus ring in brand-soft
- Helper text: 11px, body-subtle color, 2px top margin

### With Search
- Search input at top of menu following `inputs.md` specs
- Left icon: 12px left padding, input 36px left padding

### Scrollable
- Max height: 192px, vertical scroll overflow

## States

| State | Appearance |
|---|---|
| Focused trigger | no outline, 2px brand ring |
| Hover item | neutral-tertiary background, heading text |
| Active/open item | brand-softer background, fg-brand text |
| Disabled item | fg-disabled text, not-allowed cursor, no pointer events |
