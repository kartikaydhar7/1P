# Inputs

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Display:** block, full width
- **Radius:** 2px (base — universal across the system)
- **Border:** 1px, border-default-medium
- **Background:** neutral-primary-medium (matches the card surface tone — inputs read as inset slots on cards)
- **Shadow:** none on the input itself; rely on the border for definition
- **Font:** Space Mono, 14px, heading color
- **Padding:** 12px horizontal, 10px vertical
- **Placeholder:** body-subtle color
- **Transition:** all properties, 150ms

## Label

- Display: block
- Font: 12px, medium weight, body color
- Treatment: uppercase, 0.04em letter-spacing
- Margin bottom: 8px
- Label `htmlFor` must match the input `id`

## States

### Default
- Border: border-default-medium
- Background: neutral-primary-medium

### Hover
- Border: border-default-strong

### Focus
- No outline
- Border: border-brand
- Ring: 2px, brand color (offset 0)

### Success
- Border: border-success
- Focus ring: 2px, success color

### Error / Danger
- Border: border-danger
- Focus ring: 2px, danger color

### Disabled
- Background: disabled
- Border: border-default-subtle
- Text: fg-disabled
- Cursor: not-allowed

## Input with Icons

- Icon size: 14x14px
- Icon color: body-subtle
- Container: relative positioned wrapper
- Start icon: absolutely positioned left, 12px left padding — input gets 36px left padding
- End icon: absolutely positioned right, 12px right padding — input gets 36px right padding
- Icons vertically centered within the wrapper

## Rules

- Every input must have a unique `id`
- Every label must have a matching `htmlFor`
- Padding: 12px horizontal, 10px vertical unless overridden for icon variants
- No arbitrary hex or hardcoded colors
- Numeric inputs (price, quantity, percentage) inherit Space Mono's tabular numerals — never override the font on inputs
