# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 32px or 48px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 16px |
| Wide component grid gap | 24px |
| Column layout gap | 32px |

## Container

Standard section container: max-width 1280px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 96px vertical padding
- The single page surface as its background — every section uses neutral-primary-soft. Sections must NEVER alternate or layer different background tones.
- A centered container (max-width 1280px, 24px horizontal padding)
- A section header area with 32px or 48px bottom margin
- Section content below

## Motion & Animation

- Prefer native CSS transitions, animations, and keyframes. Use a motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered animation-delay delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.
- Tickers, counters, and numeric updates may flash briefly in fg-success (rising) or fg-danger (falling) over 200ms — never longer. The cyber-slick aesthetic rewards crisp, fast motion.

## Backgrounds & Visual Depth

- Default to a single, flat dark surface (neutral-primary-soft) across every section. Depth comes from cards lifting onto the surface, not from background gradients or alternating tones.
- Decorative treatments are restricted to: a faint vertical or grid line overlay at very low opacity (border-default-subtle), and the brand button's radial halo. Nothing else.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.
- Never use gradient meshes, noise textures, glassmorphism, or grain overlays — the system is flat and dark on purpose.

## Must

- All sections: consistent 96px vertical padding
- All sections share the same surface — there is no "alternate" or "secondary" section background
- All containers: max-width 1280px, centered, 24px horizontal padding
- Section headers: 32px or 48px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
- Dense, table-like layouts are encouraged — the order-book aesthetic favors tight columns of monospaced data over generous editorial whitespace
