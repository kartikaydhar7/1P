# Modals

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `buttons.md`, `inputs.md`

## Core Specs

### Overlay (Backdrop)
- Fixed, covers full screen
- Z-index: 40
- Background: dark-strong at 70% opacity
- Backdrop blur: small amount (2–4px)

### Content Container
- Background: neutral-primary-medium
- Radius: 2px (base)
- Shadow: shadow-lg
- Padding: 24px

## Anatomy

### Header
- Bottom border: border-default
- Top corners rounded (2px)
- Title: 18px, bold weight (700), heading color, uppercase, 0.04em letter-spacing
- Close button: Ghost variant from `buttons.md`, 6px padding

### Body
- Vertical padding: 24px
- Vertical spacing between elements: 24px
- Text: 14px, 1.5 line-height, body color

### Footer
- Top border: border-default
- Bottom corners rounded (2px)
- Padding-top: 16px

## Variants

### Default (Information)
Standard header + body + footer with primary/secondary action buttons.

### Pop-up (Confirmation)
Centered text, prominent icon, reduced padding:
- Body: 24px padding, text centered
- Icon: centered, 16px bottom margin, 40x40px, brand color

### Form Modal
Body contains inputs following `inputs.md`. Vertical spacing between form elements: 16px.

## Rules

- Backdrop covers full screen with fixed positioning
- Content: neutral-primary-medium background, 2px radius, shadow-lg
- Header/Footer separated by border-default borders
- Close button must be present and functional
- Accessibility: `role="dialog"`, implement focus trap in code
- Dark-only: there is no light variant of the modal
