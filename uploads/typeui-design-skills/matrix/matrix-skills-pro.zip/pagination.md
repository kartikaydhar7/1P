# Pagination

> Dependencies: `colors.md`, `radius.md`

## Container

Font: Space Mono, 13px. Items displayed as flex with -1px overlap for seamless borders.

## Pagination Item

- Layout: flex, centered both axes
- Size: 32x32px (or 36x36px)
- Text: body color, medium weight
- Background: neutral-primary-medium
- Border: 1px, border-default-medium
- Hover: neutral-tertiary background, heading text
- Focus: no outline, 2px ring in brand color
- Overlap: -1px left margin

## Previous / Next Buttons

- Horizontal padding: 12px, height: 32px
- First item: 2px radius on inline-start side
- Last item: 2px radius on inline-end side

## Active Page Item

- Text: fg-brand color
- Background: brand-softer
- Border: border-brand-subtle
- Hover text: fg-brand (stays same)

## Rules

- Display as flex with -1px child overlap for seamless borders
- Items: neutral-primary-medium background, border-default-medium border, body text
- Active: fg-brand text, brand-softer background, border-brand-subtle border
- First item: rounded start, Last item: rounded end
- All items need hover and focus states
