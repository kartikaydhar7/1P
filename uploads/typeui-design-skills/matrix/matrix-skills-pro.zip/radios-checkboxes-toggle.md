# Radios, Checkboxes & Toggles

> Dependencies: `colors.md`, `radius.md`

## Checkbox

- Size: 14x14px
- Radius: 2px
- Border: 1px, border-default-medium
- Background: neutral-primary-medium
- Focus ring: 2px, brand color
- Checked: brand background, checkmark in heading color

### Disabled
- Border: border-default-subtle
- Background: disabled
- Text: fg-disabled

## Radio

- Size: 14x14px
- Radius: fully rounded
- Border: 1px, border-default-medium
- Background: neutral-primary-medium
- Focus ring: 2px, brand color
- Checked: border-brand, indicator: brand color

### Disabled
- Border: border-default-subtle
- Text: fg-disabled

Group all radio items under the same `name` attribute.

## Toggle

### Track
- Fully rounded
- Width: 32px, height: 18px
- Background: neutral-quaternary
- Focus-within ring: 2px, brand color
- Checked track: brand background
- Disabled track: neutral-tertiary background

### Thumb
- Fully rounded
- Diameter: 14px
- Background: heading
- Border: 1px, border-buffer

### Disabled
- Track: neutral-tertiary background
- Label: fg-disabled text

## Rules

- All selection inputs must have `id` matching label `htmlFor`
- Focus states use the brand token for every selection control — the single-accent rule applies here too
- Disabled states: no hover/focus interaction
- Label typography follows `typography.md` UI Labels (uppercase, 0.04em letter-spacing for compact labels)
