# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 2px | Buttons, cards, inputs, modals, sections, alerts, badges, dropdowns, tooltips, popovers, sidebars, tables |
| default | 2px | Badges, tooltips, dropdown items, small controls |
| sm | 2px | Checkboxes, tiny elements |
| full | 9999px | Pills, avatars, toggles, dot indicators, status pulses |

## Rules

- 2px is the universal radius across the entire product. The cyber-slick aesthetic depends on near-square corners — never use anything between 2px and 9999px
- Never introduce arbitrary radius values outside this scale
- Radius must be consistent within each component family
- The only exception to 2px is fully-rounded elements (avatars, toggles, dot indicators, pill badges) which use `full`
- Stacked panels and overlays inherit 2px so the entire system reads as one continuous mono grid
