# Shadows

| Token | Value (semantic description) |
|---|---|
| shadow-2xs | 1px hairline, near-black at 30% opacity — used purely as a fine separator |
| shadow-xs | 1px offset, 2px blur, near-black at 35% opacity |
| shadow-sm | 1px offset, 3px blur, near-black at 40% opacity, plus a 1px inset top edge in border-default-subtle |
| shadow-md | 2px offset, 6px blur, near-black at 45% opacity, plus a 1px inset top edge in border-default-subtle |
| shadow-lg | 4px offset, 12px blur, near-black at 55% opacity, plus a 1px inset top edge in border-default |
| shadow-xl | 8px offset, 24px blur, near-black at 65% opacity, plus a 1px inset top edge in border-default |
| shadow-2xl | 16px offset, 40px blur, near-black at 75% opacity, plus a 1px inset top edge in border-default-medium |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs |
| Inputs, buttons, small controls, lightweight cards | shadow-2xs or shadow-xs |
| Standard cards, popovers, dropdowns | shadow-xs or shadow-sm |
| Prominent cards, sticky surfaces | shadow-md |
| Modals, high-priority overlays | shadow-lg |
| Hero overlays, top-level emphasis (sparingly) | shadow-xl |

## Rules

- Use only these tokens — no custom shadow values
- Shadows are dark-on-dark and intentionally subtle; the system reads through borders and value contrast first, shadows second
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
- Never use a shadow with a brand-color glow as decoration on layout surfaces — the brand-color glow is reserved for the brand button only
