# Sidebars

> Dependencies: `colors.md`, `radius.md`, `typography.md`, `badges.md`, `alerts.md`

## Core Specs

- Background: neutral-primary-soft (matches the page surface — the sidebar reads as a continuous part of the surface, not a lifted card)
- Right border: 1px, border-default (for left-sidebar); left border for right-sidebar
- Width: 240px

## Anatomy

### Outer Container
Hidden on mobile, visible at small breakpoint. Needs a toggle/trigger for mobile.

### Inner Wrapper
- Full height, vertical scroll overflow
- Padding: 12px horizontal, 16px vertical

### Navigation List
- Vertical spacing: 4px between items
- Font weight: medium

### Navigation Item
- Layout: flex, vertically centered
- Padding: 8px horizontal, 8px vertical
- Text: body color, 13px, uppercase, 0.04em letter-spacing
- Radius: 2px (base)
- Hover: neutral-primary-medium background, heading text color
- Transition: colors, 150ms
- Icon: 16x16px, body-subtle color, hover → heading color
- Label: 10px left margin from icon

### Active Item
- Background: brand-softer
- Text: fg-brand-strong
- Border-left: 2px brand on the inline-start edge

### Separator
- 16px top padding, 16px top margin
- Top border: border-default-subtle
- 8px vertical spacing below

### Bottom CTA / Card
- Padding: 16px
- Top margin: 24px
- Radius: 2px (base)
- Background: neutral-primary-medium
- Border: 1px, border-default
- Can also use any alert variant from `alerts.md`

## Rules

- Responsive: hidden on mobile with a trigger mechanism
- Icons: 16x16px, body-subtle color (hover: heading color)
- Multi-level menus: indent with 28px left padding
- Spacing follows 8px grid
- Only neutral, brand, or status tokens — no arbitrary colors
- The sidebar shares the page surface — never give it a separate elevated background
