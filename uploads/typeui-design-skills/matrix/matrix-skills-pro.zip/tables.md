# Tables

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Wrapper

- Horizontal scroll overflow
- Background: neutral-primary-medium (sits as a card on the page surface)
- Radius: 2px (base)
- Border: 1px, border-default
- Shadow: shadow-xs

## Table Element

- Full width, left-aligned text by default; numeric columns right-align
- Font: Space Mono, 13px, body color
- Tabular numerals on every numeric cell

## Table Head

- Font: 11px, body-subtle color, medium weight (500), uppercase, 0.04em letter-spacing
- Background: neutral-secondary-medium
- Bottom border: border-default
- Cell padding: 16px horizontal, 10px vertical

## Table Body

- Row background: neutral-primary-medium
- Row bottom border: border-default-subtle (omit on last row to avoid doubling with wrapper border)
- Row hover: neutral-tertiary background (optional)
- Row header: bold weight (700), heading color, no-wrap
- Cell padding: 16px horizontal, 12px vertical
- Numeric cells: tabular numerals; positive deltas render in fg-success, negative in fg-danger

## Compact (dense, order-book style)

For trading tables, tickers, and high-density data displays:
- Cell padding: 8px horizontal, 6px vertical
- Font: 12px
- Row bottom border: border-default-subtle on every row (no omission)
- No row hover

## Rules

- Wrapper must have horizontal scroll overflow for responsive scrolling
- Last row: omit bottom border to avoid doubling with wrapper border (standard density only)
- Row headers: always `scope="row"` for semantic structure
- Hover on rows is optional and never used in the compact variant
- No arbitrary hex codes — use token colors only
- The table is the densest surface in the system; treat it as the canonical mono-numeric showcase
