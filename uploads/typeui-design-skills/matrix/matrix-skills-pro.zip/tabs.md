# Tabs

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs

- Typography: Space Mono, 12px, bold weight (700), uppercase, 0.04em letter-spacing, body color
- Transitions: all properties, 150ms

## Variants

### 1. Underline (Default)

**Wrapper:** bottom border, border-default

**Tab Item:**
- Padding: 16px horizontal, 12px vertical
- Bottom border: 2px, transparent
- Top corners: 2px radius
- Transition: colors, 150ms

| State | Appearance |
|---|---|
| Active | fg-brand text, border-brand bottom border |
| Inactive | transparent bottom border; hover → heading text, border-default-strong bottom border |
| Disabled | fg-disabled text, not-allowed cursor |

### 2. Pills

**Tab Item:**
- Padding: 12px horizontal, 8px vertical
- Radius: 2px (base)
- Font weight: bold
- Transition: all, 150ms

| State | Appearance |
|---|---|
| Active | brand-softer background, fg-brand-strong text, border 1px border-brand-subtle |
| Inactive | body text; hover → neutral-primary-medium background, heading text |
| Disabled | fg-disabled text, not-allowed cursor |

### 3. Full Width

Children overlap with -1px left margin on all except first.

**Tab Item:**
- Full width, centered text
- Padding: 12px horizontal, 12px vertical
- Background: neutral-primary-medium
- Border: 1px, border-default
- Transition: colors, 150ms
- Hover: neutral-tertiary background, heading text

| State | Appearance |
|---|---|
| Active | brand-softer background, fg-brand-strong text |
| First item | rounded start (2px) |
| Last item | rounded end (2px) |

## Tabs with Icons

- Icon size: 14x14px or 16x16px
- Spacing: 6px right margin
- Layout: inline-flex, centered
- Icons inherit the text color of the tab state
