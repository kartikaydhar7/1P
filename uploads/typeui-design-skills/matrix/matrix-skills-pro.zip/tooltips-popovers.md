# Tooltips & Popovers

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Tooltips

### Core Specs
- Padding: 8px horizontal, 6px vertical
- Font: Space Mono, 12px, medium weight, uppercase, 0.04em letter-spacing
- Radius: 2px
- Shadow: shadow-xs
- Transition: opacity, 150ms

### Dark (Default)
- Background: dark-strong
- Text: heading
- Border: 1px, border-default

### Light (use sparingly — there is no true light mode; this is a brighter dark variant)
- Background: neutral-primary-strong
- Text: heading
- Border: 1px, border-default-medium

## Popovers

### Core Specs
- Background: neutral-primary-medium
- Radius: 2px
- Shadow: shadow-md
- Border: 1px, border-default
- Transition: opacity, 150ms

### Header / Title
- Padding: 12px horizontal, 8px vertical
- Background: neutral-secondary-medium
- Bottom border: border-default
- Font: 12px, bold weight (700), uppercase, 0.04em letter-spacing, heading color

### Body / Content
- Standard: 12px horizontal, 10px vertical padding; 13px, body color
- Rich: 16px padding; 13px, body color, 1.5 line-height

## Arrows

- Size: 8x8px rotated 45deg
- Color must match the background of the tooltip/popover variant
- Border: matches the parent border color on the two visible edges

## Rules

- Tooltips: 2px radius
- Popovers: 2px radius
- Dark tooltips: dark-strong background, heading text
- Light tooltips/popovers: semantic neutral background + border tokens
- Arrows match parent background and inherit a 1px border on the visible edges
