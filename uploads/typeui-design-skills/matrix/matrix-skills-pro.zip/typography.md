# Typography

> Dependencies: `colors.md`

## Core Rules

- **Font:** Space Mono, monospace — configured at app level, never override. The mono grid is foundational; text should feel like terminal output, not editorial prose.
- **Headings:** bold weight (700), heading text color, slight tightening through letter-spacing
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Numerals:** tabular by default — Space Mono provides monospaced numerics, which the system relies on for tickers, tables, and any quantitative UI
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 56px | 1.05 | -0.4px | 24px |
| `h2` | 40px | 1.1 | -0.3px | — |
| `h3` | 32px | 1.15 | -0.2px | — |
| `h4` | 24px | 1.2 | 0 | — |
| `h5` | 20px | 1.3 | 0 | — |
| `h6` | 16px | 1.35 | 0.04em (uppercase) | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 40px | 32px |
| `h2` | 32px | 26px |
| `h3` | 26px | 22px |
| `h4` | 22px | 20px |
| `h5` | 18px | 18px |
| `h6` | 14px | 14px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.05 for any heading.

## Paragraphs

### Leading Paragraph
- Size: 18px
- Weight: normal (400)
- Color: body
- Line-height: 1.6
- Max width: ~70 characters

### Normal Paragraph
- Size: 14px
- Weight: normal (400)
- Color: body
- Line-height: 1.5
- Max width: ~65 characters

### Small Supporting Copy
- Size: 12px
- Weight: normal (400)
- Color: body-subtle
- Line-height: 1.5
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight | Treatment |
|---|---|---|---|
| Button labels | 14px | 700 (bold) | uppercase, 0.04em letter-spacing |
| Input labels | 12px or 14px | 500 (medium) | uppercase, 0.04em letter-spacing |
| Captions / meta / badges | 11px or 12px | 500 (medium) | uppercase, 0.04em letter-spacing |
| Tabular data / tickers | 12px or 14px | 400 (normal) | tabular numerals |

Do not apply paragraph line-height (1.5) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline, hover → no underline
- **CTA links:** fg-brand color, medium weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text (700 weight, heading color)
- `<em>` for tone emphasis only, not visual hierarchy (no italics in monospaced families — keep upright, lighten color slightly)
- All-caps for short labels: uppercase, 0.04em letter-spacing, 11px or 12px

## Dark Mode

The system is dark-only. There is no light variant. Hierarchy and sizes never change between sessions; only the dark palette renders. Size, weight, and spacing remain constant.
