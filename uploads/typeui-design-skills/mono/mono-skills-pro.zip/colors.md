# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #F5F3EF | #0C0A06 |
| neutral-primary | #F5F3EF | #080705 |
| neutral-primary-medium | #F5F3EF | #1C1A16 |
| neutral-primary-strong | #F5F3EF | #33302A |
| neutral-secondary-soft | #EDEBE6 | #0C0A06 |
| neutral-secondary | #EDEBE6 | #080705 |
| neutral-secondary-medium | #EDEBE6 | #1C1A16 |
| neutral-secondary-strong | #EDEBE6 | #33302A |
| neutral-tertiary-soft | #E7E4DE | #0C0A06 |
| neutral-tertiary | #E7E4DE | #1C1A16 |
| neutral-tertiary-medium | #E7E4DE | #33302A |
| neutral-quaternary | #DDD9D1 | #33302A |
| quaternary-medium | #DDD9D1 | #403D36 |
| gray | #C8C3B9 | #403D36 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #E6F4FA | #0B1F27 |
| brand-soft | #BBE0F0 | #163E4F |
| brand | #389DC6 | #389DC6 |
| brand-medium | #88C5E0 | #163E4F |
| brand-strong | #2A7A9B | #389DC6 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #ECFDF5 | #002C22 |
| success | #007A55 | #009966 |
| success-medium | #D0FAE5 | #004F3B |
| success-strong | #006045 | #007A55 |
| danger-soft | #FEF0F2 | #4D0218 |
| danger | #C70036 | #C70036 |
| danger-medium | #FFE4E6 | #8B0836 |
| danger-strong | #A50036 | #A50036 |
| warning-soft | #FFF7ED | #7C2D12 |
| warning | #F97316 | #F97316 |
| warning-medium | #FFEDD5 | #7C2D12 |
| warning-strong | #C2410C | #C2410C |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.15) | rgba(255,255,255,0.08) |
| `--color-1-700` | rgba(0,0,0,0.08) | rgba(0,0,0,0.20) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #1A170F | #1A170F |
| dark-strong | #0C0A06 | #33302A |
| disabled | #E7E4DE | #1A170F |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #A855F7 |
| sky | #0EA5E9 |
| teal | #0D9488 |
| pink | #DB2777 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #FB923C |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #0C0A06 | #0C0A06 |
| heading | #1A170F | #F5F3EF |
| body | #5C564E | #9C968E |
| body-subtle | #78716B | #9C968E |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #88C5E0 | #163E4F |
| fg-brand | #389DC6 | #389DC6 |
| fg-brand-strong | #2A7A9B | #88C5E0 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #047857 | #065F46 |
| fg-success-strong | #065F46 | #10B981 |
| fg-danger | #BE123C | #F43F5E |
| fg-danger-strong | #881337 | #F87171 |
| fg-warning-subtle | #EA580C | #F97316 |
| fg-warning | #7C2D12 | #FBBF24 |
| fg-disabled | #9C968E | #5C564E |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #312E81 | #93C5FD |
| fg-purple | #9333EA | #A855F7 |
| fg-purple-strong | #7E3AF2 | #DDD6FE |
| fg-cyan | #0891B2 | #06B6D4 |
| fg-indigo | #4F46E5 | #4F46E5 |
| fg-pink | #DB2777 | #DB2777 |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #1A170F | #4D4A42 |
| border-buffer | #F5F3EF | #080705 |
| border-buffer-medium | #F5F3EF | #1A170F |
| border-buffer-strong | #F5F3EF | #33302A |
| border-muted | #88C5E0 | #163E4F |
| border-light-subtle | #88C5E0 | #163E4F |
| border-light | #389DC6 | #389DC6 |
| border-light-medium | #2A7A9B | #163E4F |
| border-default-subtle | #88C5E0 | #163E4F |
| border-default | #389DC6 | #389DC6 |
| border-default-medium | #2A7A9B | #163E4F |
| border-default-strong | #163E4F | #0B1F27 |
| border-success-subtle | #A7F3D0 | #064E3B |
| border-success | #047857 | #065F46 |
| border-danger-subtle | #FECDD3 | #881337 |
| border-danger | #BE123C | #BE123C |
| border-warning-subtle | #FED7AA | #7C2D12 |
| border-warning | #EA580C | #F97316 |
| border-brand-subtle | #88C5E0 | #163E4F |
| border-brand-light | #389DC6 | #389DC6 |
| border-brand | #2A7A9B | #389DC6 |
| border-dark-subtle | #1A170F | #33302A |
| border-purple | #A855F7 | #A855F7 |
| border-orange | #FB923C | #FB923C |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
