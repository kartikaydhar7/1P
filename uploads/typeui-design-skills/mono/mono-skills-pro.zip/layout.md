# Layout & Spacing

## Spacing Rhythm

Base unit: **4px**. All spacing values should be multiples of 4px.

| Context | Value |
|---|---|
| Section vertical padding | 64px |
| Section header → content | 32px or 48px |
| Heading → paragraph | 12px |
| Container horizontal padding | 16px |
| Flex/grid row gap | 12px |
| Card grid gap | 16px |
| Wide component grid gap | 24px |
| Column layout gap | 32px |

## Container

Standard section container: max-width 1152px, centered, 16px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 64px vertical padding
- Background: always #020804 (deep black) — every section, every page, no exceptions
- A centered container (max-width 1152px, 16px horizontal padding)
- A section header area with 32px bottom margin
- Section content below

### Critical: Single Dark Background Rule

- **ALL sections** must use #020804 as their background — there is NO alternating between section colors
- **Never** use neutral-primary-soft, neutral-secondary-soft, or any light/cream background for sections
- The entire page is one continuous black surface; sections are separated by dashed-line dividers (brand color, 1px dashed border), not by background color changes
- Section dividers: a full-width 1px dashed border in brand color between sections, centered with decorative dot markers at intervals

### Matrix Color Discipline

- **Text**: All headings and body text use the brand token and its shades (brand, brand-strong, fg-brand, fg-brand-strong). No warm grays, no cream — brand tokens only
- **Borders**: All card borders, input borders, and container borders use the brand border tokens (border-brand, border-brand-light, border-brand-subtle) on the black background
- **Buttons**: Brand token for fills, outlines, and text. Button hover states use brand-strong or a subtle glow effect
- **Cards**: Black background (#020804) with 1px border using brand border tokens. No background differentiation between cards and the page — only the border separates them
- **Links and interactive elements**: fg-brand for default state, fg-brand-strong for hover
- **Icons**: fg-brand color
- **The only two colors visible on screen** should be #020804 (black) and shades of the brand token. Status colors (danger, warning, success) are the sole exception for alerts and validation states

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.
- Matrix terminal aesthetic favors snappy, confident transitions — keep durations short (150–250ms) with ease-out curves.

## Backgrounds & Visual Depth

- Default to a single flat black (#020804) background across the entire page. No gradients, no alternating fills, no light surfaces.
- Apply subtle terminal-inspired treatments — faint scanline overlays, barely-visible CRT phosphor grain, subtle matrix-rain decorative elements — all in the brand color at very low opacity (2–5%) so the black stays dominant.
- Section separation is achieved through dashed-line dividers in brand color, not through background color changes.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.
- Card and container depth comes from brand-color borders only, not from shadows or background tints.

## Must

- All sections: consistent 64px vertical padding
- All containers: max-width 1152px, centered, 16px horizontal padding
- Section headers: 32px or 48px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
- **Every background on the page is #020804** — sections, cards, modals, dropdowns, popovers, sidebar — all black
- **All visible UI color is the brand color** — text, borders, icons, buttons, links. The only exceptions are status colors for alerts/validation
- **No white text, no gray text, no cream text** — headings and body both use brand token shades
- **Sections are separated by full-width dashed-line dividers** in brand color, not by background color changes
