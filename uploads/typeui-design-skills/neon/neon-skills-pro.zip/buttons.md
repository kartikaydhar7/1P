# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except ghost and disabled)

- **Radius:** 8px (base) or 9999px for pills
- **Border:** 2px solid
- **Shadow:** none by default
- **Font weight:** 500 (medium)
- **Font:** Inter
- **Box sizing:** border-box
- **Transition:** color, background-color, border-color transitions on hover
- **Style:** All buttons use an outline style — transparent background with a visible border. On hover, background fills with the corresponding color.

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 12px | 6px |
| Small | 14px | 12px | 8px |
| Base (default) | 14px | 16px | 10px |
| Large | 16px | 20px | 12px |
| Extra large | 16px | 24px | 14px |

## Variants

### Brand
- **Background:** transparent
- **Border:** brand token
- **Text:** fg-brand color
- **Hover:** brand background, dark text (#0A0A0A)
- **Focus ring:** 4px, brand-medium color

### Secondary
- **Background:** transparent
- **Border:** border-default-medium
- **Text:** heading color
- **Hover:** brand background, dark text (#0A0A0A)
- **Focus ring:** 4px, neutral-tertiary color

### Tertiary
- **Background:** transparent
- **Border:** border-default
- **Text:** body color
- **Hover:** brand background, dark text (#0A0A0A)
- **Focus ring:** 4px, neutral-tertiary-soft color

### Success
- **Background:** transparent
- **Border:** border-success
- **Text:** fg-success-strong color
- **Hover:** success background, white text
- **Focus ring:** 4px, success-medium color

### Danger
- **Background:** transparent
- **Border:** border-danger
- **Text:** fg-danger-strong color
- **Hover:** danger background, white text
- **Focus ring:** 4px, danger-medium color

### Warning
- **Background:** transparent
- **Border:** border-warning
- **Text:** fg-warning color
- **Hover:** warning background, dark text (#0A0A0A)
- **Focus ring:** 4px, warning-medium color

### Dark
- **Background:** transparent
- **Border:** border-dark
- **Text:** heading color
- **Hover:** dark background, white text
- **Focus ring:** 4px, neutral-tertiary color

### Ghost (NO shadow)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color
- **Hover:** neutral-secondary-medium background
- **Focus ring:** 4px, neutral-tertiary color
- **No shadow**

### Disabled (NO shadow)
- **Background:** disabled token
- **Border:** border-default-medium
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow**

## Icons in Buttons

- Icon size: 16x16px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
