# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** `#000000` — always pure black, matching the body/landing page background. No exceptions.
- **Border:** 2px solid, border-default color — same 2px width used for buttons, inputs, and all other interactive elements. Consistent border weight across every component.
- **Radius:** 8px (base)
- **Shadow:** shadow-xs

## Card Heading

- Desktop: 20px, medium weight, heading color
- Mobile: 16px, medium weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: `#000000`
- Border: 2px, border-default
- Radius: 8px
- Shadow: shadow-xs
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card (bg `#000000`, border 2px)
- Hover: neutral-secondary-medium background, border-brand-light border, neon glow via shadow-md
- Transition: colors, box-shadow
- Cursor: pointer

## Rules

- Background: `#000000` — always pure black. No other background color allowed.
- Border: 2px, border-default — consistent with buttons and inputs
- Radius: 8px
- Shadow: shadow-xs
- Interactive hover: neutral-secondary-medium background with neon glow
- Non-interactive: no hover styles
