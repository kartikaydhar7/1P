# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFFFF | #000000 |
| neutral-primary | #FFFFFF | #0A0A0A |
| neutral-primary-medium | #FFFFFF | #111111 |
| neutral-primary-strong | #FFFFFF | #1A1A1A |
| neutral-secondary-soft | #F5F5F5 | #050505 |
| neutral-secondary | #F0F0F0 | #0A0A0A |
| neutral-secondary-medium | #E8E8E8 | #111111 |
| neutral-secondary-strong | #E0E0E0 | #1A1A1A |
| neutral-tertiary-soft | #E0E0E0 | #0D0D0D |
| neutral-tertiary | #D5D5D5 | #141414 |
| neutral-tertiary-medium | #CCCCCC | #1A1A1A |
| neutral-quaternary | #BBBBBB | #222222 |
| quaternary-medium | #AAAAAA | #2A2A2A |
| gray | #888888 | #333333 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #F5FDE8 | #0D1A02 |
| brand-soft | #E4F9B8 | #1A3306 |
| brand | #BBF351 | #BBF351 |
| brand-medium | #D4F785 | #2D4A0F |
| brand-strong | #8BC825 | #D4F785 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #ECFDF5 | #001A12 |
| success | #007A55 | #00CC88 |
| success-medium | #D0FAE5 | #003D2E |
| success-strong | #006045 | #007A55 |
| danger-soft | #FEF0F2 | #1A0008 |
| danger | #E5003D | #FF3366 |
| danger-medium | #FFE4E6 | #4D001A |
| danger-strong | #B80030 | #E5003D |
| warning-soft | #FFF7ED | #1A0E02 |
| warning | #FF8A33 | #FF8A33 |
| warning-medium | #FFEDD5 | #4D2806 |
| warning-strong | #CC5500 | #CC5500 |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #1A1A1A | #1A1A1A |
| dark-strong | #0A0A0A | #222222 |
| disabled | #E8E8E8 | #111111 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #BF5AF2 |
| sky | #00D4FF |
| teal | #00E5CC |
| pink | #FF2D78 |
| cyan | #00E5FF |
| fuchsia | #E040FB |
| indigo | #6366F1 |
| orange | #FF9F0A |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #0A0A0A | #0A0A0A |
| heading | #0A0A0A | #F0F0F0 |
| body | #555555 | #A0A0A0 |
| body-subtle | #777777 | #707070 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #D4F785 | #2D4A0F |
| fg-brand | #8BC825 | #BBF351 |
| fg-brand-strong | #6B9E1A | #D4F785 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #007A55 | #00CC88 |
| fg-success-strong | #006045 | #00FF99 |
| fg-danger | #E5003D | #FF3366 |
| fg-danger-strong | #B80030 | #FF6688 |
| fg-warning-subtle | #CC5500 | #FF8A33 |
| fg-warning | #994000 | #FFAA55 |
| fg-disabled | #999999 | #555555 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FFD700 | #FFD700 |
| fg-info | #3B3B9E | #93C5FD |
| fg-purple | #BF5AF2 | #BF5AF2 |
| fg-purple-strong | #9945D4 | #D8B4FE |
| fg-cyan | #00B8CC | #00E5FF |
| fg-indigo | #6366F1 | #6366F1 |
| fg-pink | #FF2D78 | #FF2D78 |
| fg-lime | #8BC825 | #BBF351 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #1A1A1A | #333333 |
| border-buffer | #FFFFFF | #000000 |
| border-buffer-medium | #FFFFFF | #0A0A0A |
| border-buffer-strong | #FFFFFF | #1A1A1A |
| border-muted | #F0F0F0 | #080808 |
| border-light-subtle | #E8E8E8 | #0A0A0A |
| border-light | #E0E0E0 | #111111 |
| border-light-medium | #D5D5D5 | #1A1A1A |
| border-default-subtle | #CCCCCC | #0D0D0D |
| border-default | #CCCCCC | #1A1A1A |
| border-default-medium | #BBBBBB | #222222 |
| border-default-strong | #AAAAAA | #333333 |
| border-success-subtle | #A7F3D0 | #003D2E |
| border-success | #007A55 | #00CC88 |
| border-danger-subtle | #FECDD3 | #4D001A |
| border-danger | #E5003D | #FF3366 |
| border-warning-subtle | #FED7AA | #4D2806 |
| border-warning | #CC5500 | #FF8A33 |
| border-brand-subtle | #D4F785 | #2D4A0F |
| border-brand-light | #BBF351 | #BBF351 |
| border-brand | #8BC825 | #BBF351 |
| border-dark-subtle | #1A1A1A | #222222 |
| border-purple | #BF5AF2 | #BF5AF2 |
| border-orange | #FF9F0A | #FF9F0A |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating) — both resolve to black/near-black in dark mode
- Primary buttons: outline style with brand border, transparent background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
