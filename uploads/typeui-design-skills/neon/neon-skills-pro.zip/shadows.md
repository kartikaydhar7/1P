# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `0 1px rgb(0 0 0 / 0.15)` |
| shadow-xs | `0 1px 2px 0 rgb(0 0 0 / 0.2)` |
| shadow-sm | `0 1px 3px 0 rgb(0 0 0 / 0.25), 0 1px 2px -1px rgb(0 0 0 / 0.15)` |
| shadow-md | `0 4px 6px -1px rgb(0 0 0 / 0.3), 0 0 10px -2px rgba(187, 243, 81, 0.06)` |
| shadow-lg | `0 10px 15px -3px rgb(0 0 0 / 0.3), 0 0 15px -4px rgba(187, 243, 81, 0.08)` |
| shadow-xl | `0 20px 25px -5px rgb(0 0 0 / 0.3), 0 0 25px -5px rgba(187, 243, 81, 0.10)` |
| shadow-2xl | `0 25px 50px -12px rgb(0 0 0 / 0.5), 0 0 40px rgba(187, 243, 81, 0.12)` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls, lightweight cards | shadow-xs or shadow-sm |
| Standard cards, popovers, dropdowns | shadow-md |
| Prominent cards, sticky surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use only these tokens — no custom box-shadow values
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
- Higher elevations include a subtle neon brand glow for depth on dark backgrounds
