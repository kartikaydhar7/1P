# Typography

> Dependencies: `colors.md`

## Core Rules

- **Heading font:** Quantico, sans-serif — used for all heading elements (h1–h6), configured at app level
- **Body font:** Inter, sans-serif — used for paragraphs, labels, and all non-heading text, configured at app level
- **Headings:** bold weight (700), heading text color, slight letter-spacing for futuristic feel
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 90px | 1 | -0.5px | 32px |
| `h2` | 67px | 1.1 | 0.2px | — |
| `h3` | 50px | 1.2 | 0.2px | — |
| `h4` | 42px | 1.25 | 0.1px | — |
| `h5` | 34px | 1.35 | — | — |
| `h6` | 28px | 1.25 | — | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 62px | 50px |
| `h2` | 53px | 42px |
| `h3` | 42px | 34px |
| `h4` | 36px | 30px |
| `h5` | 30px | 28px |
| `h6` | 25px | 25px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.1 for any heading.

## Display / Hero Headings

For high-impact section headings (e.g. "The A to Z of modern business protection"), use a **display size** that is massive and full-width:

| Element | Desktop | Tablet (≥768px) | Mobile (default) |
|---|---|---|---|
| Display heading | 100px | 78px | 50px |

- Line-height: 1.05
- Letter-spacing: tight (-0.5px)
- Weight: bold (700)
- Must span the full container width — no max-width constraint on the text
- Use sparingly: only for the single most important heading per page or major section divider

## Paragraphs

### Leading Paragraph
- Size: 20px
- Weight: normal
- Color: body
- Line-height: 1.7
- Max width: ~70 characters

### Normal Paragraph
- Size: 16px
- Weight: normal
- Color: body
- Line-height: 1.7
- Max width: ~65 characters

### Small Supporting Copy
- Size: 14px
- Weight: normal
- Color: body
- Line-height: 1.6
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 16px | 500 (medium) |
| Input labels | 14px or 16px | 500 (medium) |
| Captions / meta / badges | 12px or 14px | 500 (medium) |

Do not apply paragraph line-height (1.7) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline, hover → no underline
- **CTA links:** fg-brand color, medium weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, 0.4px letter-spacing, 12px or 14px

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, and spacing remain constant.
