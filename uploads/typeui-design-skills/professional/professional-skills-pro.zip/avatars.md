# Avatars

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Circular shape:** fully rounded (9999px)
- **Rounded square shape:** 8px radius
- **Default size:** 36x36px
- **Image fit:** cover

## Sizes

| Size | Dimensions | Radius |
|---|---|---|
| Extra Small | 18x18px | 2px |
| Small | 24x24px | 2px |
| Base | 32x32px | 8px |
| Large | 40x40px | 8px |
| XL | 48x48px | 8px |
| 2XL | 56x56px | 8px |

## Bordered Avatar

- 4px padding, fully rounded, 2px outline in border-default color
- Alternative: 2px box-shadow ring in border-default color

## Stacked Avatars

- Displayed in a row (flex)
- Each avatar: 36x36px, fully rounded, 2px border in border-buffer color
- Overlap: -12px negative margin on all except first

### Stacked Counter
- Same size as avatars (36x36px), fully rounded
- Background: dark-strong, text: white, 11px font, medium weight
- Same overlap margin as other avatars

## Avatar with Text

- Flex row, 8px gap between avatar and text
- Avatar: 36x36px, fully rounded, cover fit
- Name: heading color, medium weight
- Subtitle: 13px, body color
