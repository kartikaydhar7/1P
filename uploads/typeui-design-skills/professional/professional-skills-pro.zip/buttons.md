# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except ghost and disabled)

- **Radius:** 8px (base) or 9999px for pills
- **Border:** 1px solid
- **Shadow:** shadow-xs
- **Gradient:** Every button except ghost and disabled uses a gradient background:
  - `linear-gradient(#0a50c0 0%, #0244aa 25%, #013a96 50%, #013080 75%, #012060 100%)`
- **Font weight:** 500 (medium)
- **Font:** "Open Sans"
- **Box sizing:** border-box
- **Transition:** color transitions on hover

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 11px | 10px | 4px |
| Small | 12px | 12px | 6px |
| Base (default) | 13px | 14px | 8px |
| Large | 14px | 16px | 10px |
| Extra large | 14px | 20px | 12px |

## Variants

### Brand
- **Background:** brand token
- **Border:** transparent
- **Text:** black
- **Hover:** brand-strong background
- **Focus ring:** 4px, brand-medium color

### Secondary
- **Background:** neutral-secondary-medium
- **Border:** border-default-medium
- **Text:** body color
- **Hover:** neutral-tertiary-medium background, heading text color
- **Focus ring:** 4px, neutral-tertiary color

### Tertiary
- **Background:** neutral-primary-soft
- **Border:** border-default
- **Text:** body color
- **Hover:** neutral-secondary-medium background, heading text color
- **Focus ring:** 4px, neutral-tertiary-soft color

### Success
- **Background:** success token
- **Border:** transparent
- **Text:** white
- **Hover:** success-strong background
- **Focus ring:** 4px, success-medium color

### Danger
- **Background:** danger token
- **Border:** transparent
- **Text:** white
- **Hover:** danger-strong background
- **Focus ring:** 4px, danger-medium color

### Warning
- **Background:** warning token
- **Border:** transparent
- **Text:** white
- **Hover:** warning-strong background
- **Focus ring:** 4px, warning-medium color

### Dark
- **Background:** dark token
- **Border:** transparent
- **Text:** white
- **Hover:** dark-strong background
- **Focus ring:** 4px, neutral-tertiary color

### Ghost (NO shadow, NO gradient)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color
- **Hover:** neutral-secondary-medium background
- **Focus ring:** 4px, neutral-tertiary color
- **No shadow, no gradient effect**

### Disabled (NO shadow, NO gradient)
- **Background:** disabled token
- **Border:** border-default-medium
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no gradient**

## Icons in Buttons

- Icon size: 16x16px
- Icon color: match text color (e.g., black for brand buttons)
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
