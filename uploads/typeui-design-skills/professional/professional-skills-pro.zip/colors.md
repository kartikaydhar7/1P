# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFFFF | #0F1111 |
| neutral-primary | #FFFFFF | #000000 |
| neutral-primary-medium | #FFFFFF | #191E1E |
| neutral-primary-strong | #FFFFFF | #2D3333 |
| neutral-secondary-soft | #F7F8F8 | #0F1111 |
| neutral-secondary | #F7F8F8 | #000000 |
| neutral-secondary-medium | #F0F2F2 | #191E1E |
| neutral-secondary-strong | #E9ECEC | #2D3333 |
| neutral-tertiary-soft | #EAEDED | #0F1111 |
| neutral-tertiary | #EAEDED | #191E1E |
| neutral-tertiary-medium | #E3E6E6 | #2D3333 |
| neutral-quaternary | #D5D9D9 | #2D3333 |
| quaternary-medium | #D5D9D9 | #3D4444 |
| gray | #BBBFBF | #3D4444 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #FEF7ED | #3D2A0F |
| brand-soft | #FCECD3 | #5C3F18 |
| brand | #F3A848 | #F3A848 |
| brand-medium | #F8D4A0 | #5C3F18 |
| brand-strong | #D4882A | #F3A848 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #F0FCF5 | #002C22 |
| success | #007A55 | #009966 |
| success-medium | #D0FAE5 | #004F3B |
| success-strong | #006045 | #007A55 |
| danger-soft | #FEF0F0 | #4D0218 |
| danger | #CC0C39 | #CC0C39 |
| danger-medium | #FFE0E3 | #8B0836 |
| danger-strong | #A30028 | #A30028 |
| warning-soft | #FFF7ED | #7C2D12 |
| warning | #F97316 | #F97316 |
| warning-medium | #FFEDD5 | #7C2D12 |
| warning-strong | #C2410C | #C2410C |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.20) | rgba(255,255,255,0.10) |
| `--color-1-700` | rgba(0,0,0,0.08) | rgba(0,0,0,0.20) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #131A22 | #131A22 |
| dark-strong | #0F1111 | #2D3333 |
| disabled | #EAEDED | #191E1E |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #A855F7 |
| sky | #0EA5E9 |
| teal | #007185 |
| pink | #DB2777 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #F3A848 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #0F1111 | #0F1111 |
| heading | #0F1111 | #FFFFFF |
| body | #565959 | #A4A9A9 |
| body-subtle | #767676 | #A4A9A9 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #F8D4A0 | #5C3F18 |
| fg-brand | #D4882A | #F3A848 |
| fg-brand-strong | #B87320 | #F8D4A0 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #047857 | #065F46 |
| fg-success-strong | #065F46 | #10B981 |
| fg-danger | #CC0C39 | #F43F5E |
| fg-danger-strong | #8B0836 | #F87171 |
| fg-warning-subtle | #EA580C | #F97316 |
| fg-warning | #7C2D12 | #FBBF24 |
| fg-disabled | #949494 | #565959 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #232F3E | #93C5FD |
| fg-purple | #9333EA | #A855F7 |
| fg-purple-strong | #7E3AF2 | #DDD6FE |
| fg-cyan | #007185 | #06B6D4 |
| fg-indigo | #4F46E5 | #4F46E5 |
| fg-pink | #DB2777 | #DB2777 |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #131A22 | #3D4444 |
| border-buffer | #FFFFFF | #000000 |
| border-buffer-medium | #FFFFFF | #191E1E |
| border-buffer-strong | #FFFFFF | #2D3333 |
| border-muted | #F7F8F8 | #0F1111 |
| border-light-subtle | #EAEDED | #0F1111 |
| border-light | #EAEDED | #191E1E |
| border-light-medium | #EAEDED | #2D3333 |
| border-default-subtle | #D5D9D9 | #0F1111 |
| border-default | #D5D9D9 | #191E1E |
| border-default-medium | #D5D9D9 | #2D3333 |
| border-default-strong | #BBBFBF | #3D4444 |
| border-success-subtle | #A7F3D0 | #064E3B |
| border-success | #047857 | #065F46 |
| border-danger-subtle | #FECDD3 | #8B0836 |
| border-danger | #CC0C39 | #CC0C39 |
| border-warning-subtle | #FED7AA | #7C2D12 |
| border-warning | #EA580C | #F97316 |
| border-brand-subtle | #F8D4A0 | #5C3F18 |
| border-brand-light | #F3A848 | #F3A848 |
| border-brand | #D4882A | #F3A848 |
| border-dark-subtle | #131A22 | #2D3333 |
| border-purple | #A855F7 | #A855F7 |
| border-orange | #F3A848 | #F3A848 |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
