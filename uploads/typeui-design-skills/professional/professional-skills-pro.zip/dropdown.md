# Dropdown

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `inputs.md`

## Core Specs

### Chevron Icon
- Size: 16x16px
- Spacing: 6px left margin, -2px right margin
- Color: inherits from trigger button

### Menu Container
- Background: neutral-primary-soft
- Border: 1px, border-default
- Radius: 8px (base)
- Shadow: shadow-sm
- Z-index: elevated above content

### Menu List
- Padding: 6px
- Font: 13px, body color, medium weight

### Menu Item
- Layout: inline-flex, vertically centered, full width
- Padding: 6px horizontal, 6px vertical
- Radius: 4px (default)
- Hover: neutral-tertiary-medium background, heading text
- Transition: colors, 150ms

## Trigger Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Small | 12px | 10px | 6px |
| Base | 13px | 14px | 8px |
| Large | 14px | 16px | 10px |

## Icon-only Trigger

- Padding: 8px
- Min size: 40x40px
- Icon: 20x20px

## Variants

### Default
- Menu width: 176px, items have 4px radius

### With Divider
- Top border (border-default) between child groups, skip first group

### With Header
- Header padding: 12px horizontal, 8px vertical
- Bottom border: border-default
- Name: heading color, 13px, semibold weight
- Email: body-subtle color, 13px, truncated

### With Icons
- Icon before label: 16x16px, 8px right margin, body color
- On hover, icon color changes to heading

### With Checkbox / Radio
- Inputs: 16x16px, 2px radius, focus ring in brand-soft
- Helper text: 11px, body-subtle color, 2px top margin

### With Search
- Search input at top of menu following `inputs.md` specs
- Left icon: 10px left padding, input 32px left padding

### Scrollable
- Max height: 192px, vertical scroll overflow

## States

| State | Appearance |
|---|---|
| Focused trigger | no outline, 2px brand ring |
| Hover item | neutral-tertiary-medium background, heading text |
| Active/open item | neutral-tertiary-soft background, heading text |
| Disabled item | fg-disabled text, not-allowed cursor, no pointer events |
