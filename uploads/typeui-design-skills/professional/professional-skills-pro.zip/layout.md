# Layout & Spacing

## Spacing Rhythm

Base unit: **4px**. All spacing values should be multiples of 4px.

| Context | Value |
|---|---|
| Section vertical padding | 48px |
| Section header → content | 24px or 32px |
| Heading → paragraph | 12px |
| Container horizontal padding | 16px |
| Flex/grid row gap | 12px |
| Card grid gap | 16px |
| Wide component grid gap | 24px |
| Column layout gap | 32px |

## Container

Standard section container: max-width 1440px, centered, 16px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 48px vertical padding
- A background color (alternate between neutral-primary-soft and neutral-secondary-soft)
- A centered container (max-width 1440px, 16px horizontal padding)
- A section header area with 24px bottom margin
- Section content below

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Keep animations minimal and functional — transitions should be quick and subtle, focused on hover states and content reveals.
- Avoid heavy page-load animations. Prioritize instant content display over choreographed entrance effects.

## Backgrounds & Visual Depth

- Default to clean, flat backgrounds with subtle color differentiation between sections.
- Use simple white cards on light gray backgrounds for clear content separation.
- Product imagery should be the primary visual element — backgrounds and UI chrome should stay minimal and unobtrusive.
- Every visual treatment must serve a functional purpose (separation, hierarchy, or emphasis). No decorative effects that compete with product content.

## Must

- All sections: consistent 48px vertical padding
- All containers: max-width 1440px, centered, 16px horizontal padding
- Section headers: 24px or 32px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
