# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `0 1px rgb(0 0 0 / 0.04)` |
| shadow-xs | `0 1px 2px 0 rgb(0 0 0 / 0.04)` |
| shadow-sm | `0 1px 2px 0 rgb(0 0 0 / 0.06), 0 1px 2px -1px rgb(0 0 0 / 0.06)` |
| shadow-md | `0 2px 4px -1px rgb(0 0 0 / 0.06), 0 1px 3px -1px rgb(0 0 0 / 0.06)` |
| shadow-lg | `0 6px 12px -3px rgb(0 0 0 / 0.08), 0 3px 5px -3px rgb(0 0 0 / 0.06)` |
| shadow-xl | `0 14px 20px -5px rgb(0 0 0 / 0.08), 0 6px 8px -5px rgb(0 0 0 / 0.06)` |
| shadow-2xl | `0 20px 40px -10px rgb(0 0 0 / 0.15)` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs |
| Inputs, buttons, small controls, lightweight cards | shadow-2xs or shadow-xs |
| Standard cards, popovers, dropdowns | shadow-xs or shadow-sm |
| Prominent cards, sticky surfaces | shadow-sm or shadow-md |
| Modals, high-priority overlays | shadow-md or shadow-lg |
| Hero overlays, top-level emphasis (sparingly) | shadow-xl |

## Rules

- Use only these tokens — no custom box-shadow values
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
