# Tooltips & Popovers

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Tooltips

### Core Specs
- Padding: 10px horizontal, 6px vertical
- Font: 12px, medium weight
- Radius: 4px (default)
- Shadow: shadow-2xs
- Transition: opacity, 300ms

### Dark (Default)
- Background: dark
- Text: white
- Border: transparent

### Light
- Background: neutral-primary-medium
- Text: heading color
- Border: 1px, border-default

## Popovers

### Core Specs
- Background: neutral-primary
- Radius: 8px (base)
- Shadow: shadow-sm
- Border: 1px, border-default
- Transition: opacity, 300ms

### Header / Title
- Padding: 10px horizontal, 6px vertical
- Background: neutral-secondary-soft
- Bottom border: border-default
- Font: 13px, medium weight, heading color

### Body / Content
- Standard: 10px horizontal, 6px vertical padding; 13px, body color
- Rich: 12px padding; 13px, body color

## Arrows

- Size: 8x8px rotated 45deg
- Color must match the background of the tooltip/popover variant

## Rules

- Tooltips: 4px radius
- Popovers: 8px radius
- Dark tooltips: dark background, white text
- Light tooltips/popovers: semantic neutral background + border tokens
- Arrows match parent background color
