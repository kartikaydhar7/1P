# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** dark
- **Border:** none (transparent)
- **Radius:** 2px (base)
- **Shadow:** shadow-sm
- **Color context:** all child text inside cards must use white or light-equivalent tokens for readability on the dark surface

## Card Heading

- Desktop: 20px, bold weight, white color
- Mobile: 16px, bold weight, white color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: dark
- Border: none (transparent)
- Radius: 2px
- Shadow: shadow-sm
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: dark-strong background
- Transition: colors
- Cursor: pointer

## Rules

- Background: dark
- Border: none (transparent)
- Radius: 2px
- Shadow: shadow-sm
- Interactive hover: dark-strong background
- Non-interactive: no hover styles
- All text inside cards must use white or light-equivalent tokens for readability on the dark surface
