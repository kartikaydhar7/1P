# Borders

## Width Scale

| Context | Width |
|---|---|
| Default (inputs, buttons, cards) | 2px |
| Emphasis / focus | 3px |

## Rules

- Use solid borders by default — thick black borders are the signature of this retro NeoBrutalism style
- Dashed borders only for special cases like file dropzones
- Components in the same family must use matching border widths
- Never mix 2px and 3px borders within a single component

## Usage

| Context | Width |
|---|---|
| Inputs / selects / textareas | 2px default; 3px on focus or error |
| Buttons | 2px solid for all variants |
| Cards / containers | 2px solid; bold outlines define the retro aesthetic |
