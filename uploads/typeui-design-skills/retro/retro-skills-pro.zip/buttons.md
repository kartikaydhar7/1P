# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except ghost and disabled)

- **Radius:** 6px (base) or 9999px for pills
- **Border:** 2px solid, border-default color (black)
- **Shadow:** none
- **Glint effect:** disabled — no glint, no box-shadow on any button
- **Font weight:** 600 (semibold)
- **Font:** "Open Sans"
- **Box sizing:** border-box
- **Transition:** color transitions on hover

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 12px | 6px |
| Small | 14px | 12px | 8px |
| Base (default) | 14px | 16px | 10px |
| Large | 16px | 20px | 12px |
| Extra large | 16px | 24px | 14px |

## Variants

### Brand
- **Background:** brand token
- **Border:** 2px solid, border-default color
- **Text:** heading color
- **Hover:** brand-strong background
- **Focus ring:** 4px, brand-medium color
- **Glint:** no

### Secondary
- **Background:** neutral-secondary-medium
- **Border:** 2px solid, border-default color
- **Text:** body color
- **Hover:** neutral-tertiary-medium background, heading text color
- **Focus ring:** 4px, neutral-tertiary color
- **Glint:** no

### Tertiary
- **Background:** neutral-primary-soft
- **Border:** 2px solid, border-default color
- **Text:** body color
- **Hover:** neutral-secondary-medium background, heading text color
- **Focus ring:** 4px, neutral-tertiary-soft color
- **Glint:** no

### Success
- **Background:** success token
- **Border:** 2px solid, border-default color
- **Text:** white
- **Hover:** success-strong background
- **Focus ring:** 4px, success-medium color
- **Glint:** no

### Danger
- **Background:** danger token
- **Border:** 2px solid, border-default color
- **Text:** white
- **Hover:** danger-strong background
- **Focus ring:** 4px, danger-medium color
- **Glint:** no

### Warning
- **Background:** warning token
- **Border:** 2px solid, border-default color
- **Text:** white
- **Hover:** warning-strong background
- **Focus ring:** 4px, warning-medium color
- **Glint:** no

### Dark
- **Background:** dark token
- **Border:** 2px solid, border-default color
- **Text:** white
- **Hover:** dark-strong background
- **Focus ring:** 4px, neutral-tertiary color
- **Glint:** no

### Ghost (NO shadow, NO glint)
- **Background:** transparent
- **Border:** 2px solid, border-default color
- **Text:** heading color
- **Hover:** neutral-secondary-medium background
- **Focus ring:** 4px, neutral-tertiary color
- **No shadow, no glint effect**

### Disabled (NO shadow, NO glint)
- **Background:** disabled token
- **Border:** 2px solid, border-default-medium color
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no glint**

## Icons in Buttons

- Icon size: 16x16px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
