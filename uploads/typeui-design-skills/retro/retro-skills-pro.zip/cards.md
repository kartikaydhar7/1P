# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-primary-soft
- **Border:** 2px solid, border-default color (black)
- **Radius:** 6px (base)
- **Shadow:** none

## Card Heading

- Desktop: 20px, semibold weight, heading color
- Mobile: 16px, semibold weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-primary-soft
- Border: 2px solid, border-default
- Radius: 6px
- Shadow: none
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: neutral-secondary-medium background
- Transition: colors
- Cursor: pointer

## Rules

- Background: neutral-primary-soft
- Border: 2px solid, border-default
- Radius: 6px
- Shadow: none
- Interactive hover: neutral-secondary-medium background
- Non-interactive: no hover styles
