# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFFFF | #101828 |
| neutral-primary | #FFFFFF | #030712 |
| neutral-primary-medium | #FFFFFF | #1E2939 |
| neutral-primary-strong | #FFFFFF | #333E4F |
| neutral-secondary-soft | #FFFFFF | #101828 |
| neutral-secondary | #FFFFFF | #030712 |
| neutral-secondary-medium | #F9FAFB | #1E2939 |
| neutral-secondary-strong | #F3F4F6 | #333E4F |
| neutral-tertiary-soft | #F3F4F6 | #101828 |
| neutral-tertiary | #F3F4F6 | #1E2939 |
| neutral-tertiary-medium | #E5E7EB | #333E4F |
| neutral-quaternary | #D1D5DC | #333E4F |
| quaternary-medium | #D1D5DC | #4A5565 |
| gray | #9CA3AF | #4A5565 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #FFF0E8 | #3D2818 |
| brand-soft | #FFE3D5 | #5C3D25 |
| brand | #FFD1BA | #FFD1BA |
| brand-medium | #FFDBC9 | #5C3D25 |
| brand-strong | #D4A68A | #E8B89A |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #ECFDF5 | #002C22 |
| success | #007A55 | #009966 |
| success-medium | #D0FAE5 | #004F3B |
| success-strong | #006045 | #007A55 |
| danger-soft | #FEF0F2 | #4D0218 |
| danger | #C70036 | #C70036 |
| danger-medium | #FFE4E6 | #8B0836 |
| danger-strong | #A50036 | #A50036 |
| warning-soft | #FFF7ED | #7C2D12 |
| warning | #F97316 | #F97316 |
| warning-medium | #FFEDD5 | #7C2D12 |
| warning-strong | #C2410C | #C2410C |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(0,0,0,0) | rgba(0,0,0,0) |
| `--color-1-700` | rgba(0,0,0,0) | rgba(0,0,0,0) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #000000 | #000000 |
| dark-strong | #000000 | #374151 |
| disabled | #F3F4F6 | #1F2937 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #A855F7 |
| sky | #0EA5E9 |
| teal | #0D9488 |
| pink | #DB2777 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #FB923C |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #111827 | #111827 |
| heading | #000000 | #FFFFFF |
| body | #374151 | #9CA3AF |
| body-subtle | #4B5563 | #9CA3AF |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #FFE3D5 | #5C3D25 |
| fg-brand | #C4764A | #FFD1BA |
| fg-brand-strong | #A0553A | #FFE3D5 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #047857 | #065F46 |
| fg-success-strong | #065F46 | #10B981 |
| fg-danger | #BE123C | #F43F5E |
| fg-danger-strong | #881337 | #F87171 |
| fg-warning-subtle | #EA580C | #F97316 |
| fg-warning | #7C2D12 | #FBBF24 |
| fg-disabled | #9CA3AF | #6B7280 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #312E81 | #93C5FD |
| fg-purple | #9333EA | #A855F7 |
| fg-purple-strong | #7E3AF2 | #DDD6FE |
| fg-cyan | #0891B2 | #06B6D4 |
| fg-indigo | #4F46E5 | #4F46E5 |
| fg-pink | #DB2777 | #DB2777 |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #000000 | #4B5563 |
| border-buffer | #FFFFFF | #030712 |
| border-buffer-medium | #FFFFFF | #1F2937 |
| border-buffer-strong | #FFFFFF | #374151 |
| border-muted | #E5E7EB | #111827 |
| border-light-subtle | #D1D5DC | #111827 |
| border-light | #D1D5DC | #1F2937 |
| border-light-medium | #9CA3AF | #374151 |
| border-default-subtle | #1A1A1A | #111827 |
| border-default | #000000 | #4B5563 |
| border-default-medium | #000000 | #374151 |
| border-default-strong | #000000 | #4B5563 |
| border-success-subtle | #A7F3D0 | #064E3B |
| border-success | #047857 | #065F46 |
| border-danger-subtle | #FECDD3 | #881337 |
| border-danger | #BE123C | #BE123C |
| border-warning-subtle | #FED7AA | #7C2D12 |
| border-warning | #EA580C | #F97316 |
| border-brand-subtle | #FFE3D5 | #5C3D25 |
| border-brand-light | #FFD1BA | #FFD1BA |
| border-brand | #C4764A | #FFD1BA |
| border-dark-subtle | #000000 | #374151 |
| border-purple | #A855F7 | #A855F7 |
| border-orange | #FB923C | #FB923C |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating) — both resolve to white for a clean retro canvas
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
