# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 6px | Buttons, cards, inputs, modals, sections |
| default | 4px | Badges, tooltips, dropdown items, small controls |
| sm | 2px | Checkboxes, tiny elements |
| full | 9999px | Pills, avatars, toggles, dot indicators |

## Rules

- 6px is the default radius across the product
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
