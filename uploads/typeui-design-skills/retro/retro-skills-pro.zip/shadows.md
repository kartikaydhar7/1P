# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `none` |
| shadow-xs | `none` |
| shadow-sm | `none` |
| shadow-md | `none` |
| shadow-lg | `none` |
| shadow-xl | `none` |
| shadow-2xl | `none` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls, lightweight cards | shadow-xs or shadow-sm |
| Standard cards, popovers, dropdowns | shadow-md |
| Prominent cards, sticky surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- All shadow tokens resolve to `none` — this design system uses a flat, shadow-free NeoBrutalism aesthetic
- Depth and separation are conveyed through thick borders and background contrast, never through box-shadow
- Use only these tokens — no custom box-shadow values
- Never add shadow to buttons, cards, inputs, or any interactive elements
