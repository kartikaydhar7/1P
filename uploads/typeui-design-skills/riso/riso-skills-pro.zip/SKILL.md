# Design System — Agent Instructions

This skill describes the visual design language for all UI output. Every component, layout, and page should follow the design specs in the module files below. These describe *what the design looks like* — you choose how to implement the styles.

## Style
A playful, joyful, two-color **risograph print** aesthetic — built on a single warm off-white paper surface (#F3EEE4) running through every section, a fluorescent brand pink (#F237A1) reserved as the sole interaction driver, a deep federal-blue secondary (#2C3FA7) carrying every heading and the signature offset print-shadow, soft periwinkle paragraphs (#637EC2), warmer cream cards (#FBF6EC) layered with a 1px parchment border (#E4E0D9), Space Grotesk as the single typeface, and 4px corners across every component. Depth comes exclusively from flat hard offset shadows in secondary blue — there are no gradients, no soft drop-shadows, and no alternating section backgrounds. The system is colorful, opinionated, and illustrative: each full-width section reads as one continuous sheet of risograph paper with deliberate two-color registration offsets that give the interface its print-block joy.

## Before Writing Any Code

1. **Read every module that applies.** For a landing page, read at minimum: `layout.md`, `typography.md`, `colors.md`, `buttons.md`, `cards.md`, `shadows.md`, `radius.md`, `borders.md`. Do NOT write component code until you have loaded all relevant modules.

## Critical Rules

- **Tokens are AGNOSTIC, NOT framework classes:** The tokens defined in the `.md` files (like `neutral-primary`, `heading`, `border-default`) are agnostic design system tokens, NOT literal classes from any specific framework. Do not blindly use them as utility classes unless you have explicitly mapped them in your styling configuration. You must implement the mapping yourself.

- **Cross-reference modules.** A card containing buttons must satisfy both `cards.md` AND `buttons.md`.
- **Dark mode is automatic.** Color tokens resolve differently in light/dark via the token system. Never manually swap colors.
- **Every interactive element needs hover, focus, and disabled states** — defined in the relevant module.
- **Use semantic HTML:** proper heading hierarchy (`h1`→`h6`), `<button>` for actions, `<a>` for navigation, ARIA attributes where needed.
- **Single surface background.** Every full-width section uses the same surface tone (`neutral-primary`, #F3EEE4). No alternating section colors — depth is created via cards, offset shadows, and illustrative compositions.
- **4px corners everywhere.** Buttons, cards, inputs, modals, alerts, panels — every standard component uses `border-radius: 4px`. Avatars, dot indicators, and tiny status pills are the only exceptions.
- **Hard offset shadows only.** Every shadow token is a flat solid-color offset in the secondary blue (#2C3FA7) — no blur, no spread, no rgba softness. Soft drop-shadows are forbidden.
- **Brand pink is the sole interaction driver.** Reserve `brand` (#F237A1) for one primary action per screen. Never use it for body copy, large background fills, or decorative accents.
- **Headings in heading color, paragraphs in body color.** Headings always use the deep federal blue (`heading`, #2C3FA7); paragraphs always use the soft periwinkle (`body`, #637EC2). Never invert this pairing.
- **Each section may include a graphic illustration or geometric SVG composition** (halftone dots, simple shapes, two-color print marks) as a compositional element — not decoration.

## Module Index

### Foundation (read first for any UI work)
- [colors.md](colors.md) — all background, text, and border color tokens
- [typography.md](typography.md) — heading scale, paragraphs, labels, links
- [layout.md](layout.md) — spacing rhythm, containers, animation, visual depth
- [radius.md](radius.md) — border-radius scale
- [shadows.md](shadows.md) — elevation tokens
- [borders.md](borders.md) — border widths and styles

### Components
- [buttons.md](buttons.md) — button variants, sizes, states, print-offset shadow
- [button-group.md](button-group.md) — grouped button structure
- [cards.md](cards.md) — card structure, background, interactivity
- [inputs.md](inputs.md) — form controls, labels, states
- [alerts.md](alerts.md) — alert variants
- [badges.md](badges.md) — badge variants, sizes, dismissible chips
- [lists.md](lists.md) — list components
- [avatars.md](avatars.md) — avatar variants, sizes, indicators
- [icon-shapes.md](icon-shapes.md) — icon containers

### Complex Components
- [accordion.md](accordion.md) — accordion variants
- [dropdown.md](dropdown.md) — dropdown menus
- [modals.md](modals.md) — modal dialogs
- [tabs.md](tabs.md) — tab navigation
- [tables.md](tables.md) — table structure
- [pagination.md](pagination.md) — pagination components
- [sidebars.md](sidebars.md) — sidebar navigation
- [radios-checkboxes-toggle.md](radios-checkboxes-toggle.md) — selection controls
- [tooltips-popovers.md](tooltips-popovers.md) — tooltips and popovers
- [content.md](content.md) — grid system, responsiveness
