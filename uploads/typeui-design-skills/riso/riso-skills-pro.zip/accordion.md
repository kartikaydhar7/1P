# Accordion

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `typography.md`

## Core Specs

- **Wrapper:** full width, 1px border (border-default color #E4E0D9), 4px radius — clips first/last item corners
- **Item separator:** 1px bottom border (border-default) on every item except the last
- **Background:** neutral-secondary (#FBF6EC) on the entire wrapper, so the accordion reads as a layered card

## Trigger (Button)

- **Layout:** flex, space-between, full width
- **Padding:** 20px horizontal, 16px vertical
- **Font:** Space Grotesk, 16px, weight 600
- **Text color:** heading (#2C3FA7)
- **Background:** neutral-secondary (#FBF6EC)
- **Hover:** neutral-secondary-strong (#F4ECDA) background
- **Focus:** outline none, 2px solid border-brand on the trigger + 2px 2px offset shadow in secondary blue
- **Transition:** background-color 150ms, transform 120ms
- **Open state:** neutral-secondary-strong background, chevron rotated 180°

## Panel (Content)

- **Padding:** 20px horizontal, 16px vertical
- **Background:** neutral-primary-soft (#F8F4EB) — slightly cooler than the trigger so the open panel reads as the underlying paper
- **Top border:** 1px, border-default color
- **Font:** Space Grotesk, 15px, weight 400, body color (#637EC2), line-height 1.55

## Chevron Icon

- Size: 16x16px
- Color: heading color (#2C3FA7) — flat single-color print mark
- Closed: 0deg rotation
- Open: 180deg rotation
- Transition: transform 150ms ease-out

## Variants

### Default (Collapse)
One panel open at a time. Items stacked inside a single shared bordered/rounded wrapper.

### Separated Cards
Each item is independent — has its own 1px border-default, 4px radius, and shadow-md (4px 4px offset in secondary blue). 12px bottom margin between items. No shared outer border. Each item carries the same press-toward-shadow motion as standard cards on hover.

### Always Open
Multiple panels can expand simultaneously. Same styling as Default.

### Flush
No outer border. Trigger and panel have transparent backgrounds, sitting directly on the page surface (#F3EEE4). Only 1px bottom border dividers between items. Use inside containers that already provide a background (cards, modals).

## States

| State | Trigger appearance |
|---|---|
| Closed | heading text, neutral-secondary background |
| Open | heading text, neutral-secondary-strong background, chevron rotated 180° |
| Hover | neutral-secondary-strong background |
| Focus | 2px border-brand stroke + 2px offset shadow in secondary blue, no native outline |
| Disabled | fg-disabled text, not-allowed cursor, no hover/focus |

## Rules

- Radius is always 4px on the wrapper.
- Use the parchment hairline (1px border-default) on the wrapper and item separators — never use a thicker border for accordions.
- Open state never colorizes the background with brand pink — the trigger remains in the cream tones.
- Reserve the offset print-shadow for the Separated Cards variant; the Default variant keeps a calm flat appearance.
