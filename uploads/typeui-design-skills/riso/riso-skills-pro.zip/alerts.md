# Alerts

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `typography.md`

## Core Specs

- **Padding:** 16px (vertical) 20px (horizontal)
- **Radius:** 4px (base)
- **Border:** 1px solid (color from variant)
- **Shadow:** shadow-xs (2px 2px offset in secondary blue) — gentle print-offset registration
- **Heading:** Space Grotesk, 16px, weight 600
- **Body:** Space Grotesk, 14px, weight 400, 1.55 line-height
- **Icon:** 18x18px, aligned to the heading baseline, 12px gap from the text block

## Layout

- `inline-flex` row: optional leading icon (18px) + text block + optional dismiss button.
- Text block stacks heading on top of body with 4px vertical gap.
- Dismiss button (when present): ghost style, 16x16px tap target, body color, hover → heading color.

## Variants

### Brand
- **Background:** brand-softer (#FDE3F0)
- **Border:** 1px solid border-brand-subtle
- **Heading:** fg-brand-strong (#C42985)
- **Body:** body
- **Offset shadow:** shadow-xs in secondary blue

### Success
- **Background:** success-soft
- **Border:** 1px solid border-success-subtle
- **Heading:** fg-success-strong
- **Body:** body
- **Offset shadow:** shadow-xs in success-strong

### Danger
- **Background:** danger-soft
- **Border:** 1px solid border-danger-subtle
- **Heading:** fg-danger-strong
- **Body:** body
- **Offset shadow:** shadow-xs in danger-strong

### Warning
- **Background:** warning-soft
- **Border:** 1px solid border-warning-subtle
- **Heading:** fg-warning
- **Body:** body
- **Offset shadow:** shadow-xs in warning-strong

### Info (neutral)
- **Background:** neutral-secondary (#FBF6EC)
- **Border:** 1px solid border-default (#E4E0D9)
- **Heading:** heading (#2C3FA7)
- **Body:** body (#637EC2)
- **Offset shadow:** shadow-xs in secondary blue

## Rules

- Always use the soft-tint background + subtle border + status text color combination — the alert is a quiet panel, not a saturated banner.
- Radius is always 4px.
- The shadow is always a hard 2px offset in the variant's strong color (or secondary blue for the neutral info variant) — never blurred.
- Never set the alert background to the saturated status color — use the `-soft` token.
