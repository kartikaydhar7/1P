# Avatars

> Dependencies: `colors.md`, `radius.md`, `typography.md`

## Core Specs

- **Circular shape:** fully rounded (9999px) — circular avatars stay circular
- **Rounded square shape:** 4px radius (matches the system)
- **Default size:** 40x40px
- **Image fit:** cover

## Sizes

| Size | Dimensions | Radius (square) |
|---|---|---|
| Extra Small | 20x20px | 2px |
| Small | 24x24px | 4px |
| Base | 32x32px | 4px |
| Medium | 40x40px | 4px |
| Large | 48x48px | 4px |
| XL | 56x56px | 4px |
| 2XL | 64x64px | 4px |

## Bordered Avatar

- 2px solid border in `border-default` (#E4E0D9) for circular avatars sitting on the surface
- For square avatars, use a 1px solid `border-default` border with 4px radius
- Alternative: 2px solid border in `border-dark` (#2C3FA7) for promoted / featured avatars (matches the print-frame stroke)

## Stacked Avatars

- Displayed in a row (flex)
- Each avatar: 40x40px, fully rounded, 2px border in `border-buffer` color (#F3EEE4 — the surface tone, so the border carves space against the page)
- Overlap: -12px negative margin on all except the first

### Stacked Counter
- Same size as avatars (40x40px), fully rounded
- Background: dark (#2C3FA7, the secondary blue), text: white, Space Grotesk 12px, weight 600
- Same overlap margin as other avatars

## Avatar with Text

- Flex row, 12px gap between avatar and text
- Avatar: 40x40px, fully rounded, cover fit
- Name: Space Grotesk, 15px, weight 600, heading color (#2C3FA7)
- Subtitle: Space Mono, 12px, letter-spacing 0.04em, body color (#637EC2)

## Initial / Letter Avatars

- Background: a soft accent tint cycled per user — pick from brand-soft, sky-soft (use `accent.sky` at ~60% mix with neutral), success-soft, warning-soft. The accent should feel like a riso color block, not a flat random hex.
- Initial: Space Grotesk, weight 700, heading color, sized to ~40% of the avatar dimension.

## Status Indicator (online dot)

- Positioned absolutely: 0 bottom, 0 right
- Size: 10x10px, fully rounded
- 2px border in `border-buffer` color (#F3EEE4)
- Background: success (online), warning (idle), danger (busy), gray (offline)

## Rules

- Square avatars share the system's 4px radius — never use 8/12/16px on avatar squares.
- Circular avatars stay fully rounded; they are one of the few exceptions to the 4px-everywhere rule.
- Borders use the parchment hairline by default; the secondary-blue stroke is reserved for featured avatars.
