# Badges

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `typography.md`

## Core Specs

- **Border:** 1px (solid)
- **Default radius:** 4px (matches the system)
- **Pill radius:** 9999px (only for status pills and notification dots)
- **Font:** Space Mono, 11px, weight 500, letter-spacing 0.04em, UPPERCASE
- **Background:** the soft tint of the variant
- **Border color:** the subtle/medium token of the variant

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Default (small) | 11px | 8px | 3px |
| Large | 12px | 10px | 5px |

## Variants

### Brand
- **Background:** brand-softer (#FDE3F0)
- **Border:** 1px solid border-brand-subtle
- **Text:** fg-brand-strong (#C42985)

### Alternative (Neutral Soft)
- **Background:** neutral-primary-soft (#F8F4EB)
- **Border:** 1px solid border-default (#E4E0D9)
- **Text:** heading (#2C3FA7)

### Gray (Neutral Medium)
- **Background:** neutral-secondary-medium (#FBF6EC)
- **Border:** 1px solid border-default (#E4E0D9)
- **Text:** heading (#2C3FA7)

### Danger
- **Background:** danger-soft
- **Border:** 1px solid border-danger-subtle
- **Text:** fg-danger-strong

### Success
- **Background:** success-soft
- **Border:** 1px solid border-success-subtle
- **Text:** fg-success-strong

### Warning
- **Background:** warning-soft
- **Border:** 1px solid border-warning-subtle
- **Text:** fg-warning

### Dark
- **Background:** dark (#2C3FA7, the secondary blue)
- **Border:** transparent
- **Text:** white

## Pill Badges

Use 9999px radius instead of 4px — reserved for status pills (online / offline / draft) and notification dots only. Standard tags and chips stay at 4px radius.

## Badges with Icons

- Icon size (default): 12x12px
- Icon size (large): 14x14px
- Icon spacing: 4px margin next to the label
- Icons should be flat single-color marks consistent with the print aesthetic

## Icon-only Badge

Square shape — equalize dimensions to 24x24px, no horizontal text padding, 4px radius.

## Dismissible Badges

Badge content + a close button. Close button hover backgrounds per variant:

| Variant | Close button hover background |
|---|---|
| Brand | brand-soft |
| Alternative | neutral-tertiary |
| Gray | neutral-quaternary |
| Danger | danger-medium |
| Success | success-medium |
| Warning | warning-medium |

## Dot / Notification Badge

- Positioned absolutely: -4px top, -4px right
- Size: 10x10px, fully rounded
- 2px border in border-buffer color (#F3EEE4)
- Background: brand (#F237A1) for primary alerts, danger for error counts

## Rules

- Default radius is 4px on every standard badge — never round square chips into pills unless they represent persistent status states.
- Use Space Mono uppercase for the badge label so badges read as print-mark metadata rather than UI buttons.
- Never apply the offset print-shadow to badges — they are quiet metadata, not interactive surfaces.
