# Borders

## Width Scale

| Context | Width |
|---|---|
| Default (cards, inputs, buttons, panels) | 1px |
| Emphasis / button outline / two-color print frame | 2px |
| Strong focus ring (status, error) | 2px |

## Rules

- Use **solid** borders by default — the flat risograph print look depends on crisp solid lines.
- Default border color across the system is `border-default` (#E4E0D9) — a warm parchment hairline that sits gently on the cream surface without competing with the print accents.
- Buttons get a 2px border in the secondary blue (#2C3FA7) so the two-color print effect (pink fill + blue stroke + blue offset shadow) reads clearly.
- Dashed borders only for special cases (file dropzones, drag/drop targets) — never on standard interactive elements.
- Components in the same family must use matching border widths.
- Never mix 1px and 2px borders within a single component.

## Usage

| Context | Width | Color token |
|---|---|---|
| Inputs / selects / textareas | 1px default; 2px on focus or error | border-default → border-brand on focus / border-danger on error |
| Buttons | 2px (secondary-blue print stroke) | border-dark (#2C3FA7) |
| Cards / containers | 1px | border-default (#E4E0D9) |
| Modals, popovers, dropdowns | 1px | border-default (#E4E0D9) |
| Status panels (success / warning / danger) | 1px (the offset shadow carries the emphasis) | border-success / border-warning / border-danger |

## Print-Frame Rule

The combination of **brand-pink fill + 2px secondary-blue border + secondary-blue offset shadow** is the signature risograph "two-color registration" print frame. It is reserved for the primary button and any other element acting as the screen's single primary call-to-action. Cards and inputs use the calmer 1px parchment border instead.
