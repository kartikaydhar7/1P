# Button Groups

> Dependencies: `buttons.md`, `colors.md`, `radius.md`, `shadows.md`

## Core Specs

- **Wrapper:** inline-flex, 4px radius, shadow-md (single hard offset in secondary blue)
- **Children overlap:** -1px left margin on all except the first button — the strokes merge into one continuous print line
- **Buttons inside the group must NOT have individual offset shadows.** Only the wrapper carries the print-offset shadow.

## Anatomy

### Wrapper
- Display: inline-flex
- Radius: 4px
- Shadow: shadow-md (4px 4px 0 0 secondary blue #2C3FA7)
- Background: inherits from the buttons inside it

### First Button
- 4px radius on inline-start side only, 0 on inline-end
- Carries the left half of the wrapper's print frame

### Middle Button(s)
- No radius (0 on all corners)

### Last Button
- 4px radius on inline-end side only, 0 on inline-start
- Carries the right half of the wrapper's print frame

### All buttons except first
- -1px left margin to overlap the 2px secondary-blue strokes — the group reads as a single print row

## Hover / Active Behavior

- The wrapper inherits the press-toward-shadow motion from `buttons.md`: on hover the entire group translates `(2px, 2px)` and the wrapper's offset shadow shrinks 4px → 2px.
- Individual buttons inside the group still get their own background hover state (e.g. brand-medium fill), but they never animate independently — the group moves as one print block.

## Rules

- Buttons inside groups follow all styles from `buttons.md` (background, border, focus rings, font, padding) **except** individual offset shadows — those are removed in favor of the wrapper-level shadow.
- The 2px secondary-blue stroke is preserved on each button, but adjacent strokes merge via the -1px overlap so the group reads as one continuous outline.
- Icon-only buttons: 16x16px icon, match the height of text buttons.
- Never mix variants within a single group (no half-brand / half-secondary groups). Use a consistent variant per group; if you need contrasting actions, place separate buttons side-by-side instead of in a group.
