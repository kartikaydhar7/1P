# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `typography.md`

## Core Specs (every button except ghost and disabled)

Every button — regardless of stack — must compose to the following base style. Use design tokens or framework utilities; the visual result must match the rules below. The pattern is a flat, two-color **risograph print** button: a brand-pink fill with a secondary-blue 2px stroke and a hard offset shadow in the same secondary blue, so it reads like a two-color print pass with deliberate registration offset.

### Property Reference

| Property | Value |
|---|---|
| `outline` | `none` |
| `color` | white (#FFFFFF) |
| `background-color` | brand color (#F237A1) |
| `padding` | `12px 24px` (vertical / horizontal) |
| `border` | `2px solid` secondary color (#2C3FA7) |
| `border-radius` | `4px` |
| `box-shadow` | `4px 4px 0 0` secondary color (#2C3FA7) |
| `font-family` | "Space Grotesk" |
| `font-size` | `16px` |
| `font-weight` | `600` |
| `letter-spacing` | `0` |
| `cursor` | `pointer` |
| `transition` | `transform 120ms ease-out, box-shadow 120ms ease-out, background-color 200ms ease` |
| `box-sizing` | `border-box` |
| `position` | `relative` |
| `display` | `inline-flex` |
| `align-items` | `center` |
| `justify-content` | `center` |
| `gap` | `8px` |

### Rules (apply in any stack)

- **Outline:** never visible — always `outline: none`. Use the offset shadow ring for focus/state, never the native outline.
- **Color (text):** white on the brand pink fill. Never hard-code body or heading colors on top of the brand fill — the contrast is part of the print look.
- **Padding:** vertical `12px`, horizontal `24px`. Do not shrink horizontal padding below 16px on the smallest size — the wide horizontal padding is what gives the button its print-block silhouette.
- **Border:** always **2px solid** in the secondary blue (`border-dark` token, #2C3FA7). The stroke is what makes the button read as a two-color print, never use a 1px border or a brand-color border for the primary variant.
- **Border-radius:** always `4px`. The risograph aesthetic is built on near-square shapes — never use full-pill radius for the standard button.
- **Background:** brand color token. Never raw hex.
- **Box-shadow:** a **single hard offset** in the secondary blue, no blur, no spread:
  - `4px 4px 0 0 <secondary-color>` — a flat solid block sitting offset to the bottom-right, as if a second print pass landed slightly out of register.
- **Transition:** snappy on transform / shadow (120ms), softer on color (200ms). Keep it punchy on press, smoother on color shifts.
- **Box sizing:** always `border-box` so the 2px stroke + offset shadow don't push the layout.
- **Font:** `"Space Grotesk"`, weight `600`. Never set the button label in the label/mono font.

### Hover / Active

- **Hover:** translate `(2px, 2px)` and shrink the offset shadow from `4px 4px 0 0` → `2px 2px 0 0` so the button visually presses **toward** its own shadow (away from the page). Background brightens slightly to `brand-medium` (#F66BB9).
- **Active / pressed:** translate `(4px, 4px)` and collapse the offset shadow to `0 0 0 0` — the button meets its shadow flush against the page.
- **Focus-visible:** keep the base `4px 4px 0 0 <secondary>` offset shadow and add a soft `0 0 0 4px <brand-soft>` ring (`brand-soft` = #FAB5DC) underneath it so a pink halo outlines the print frame. The native outline stays `none`.

### Stack-agnostic notes

- Implementations should expose three button-state tokens (resting / hover / active) for the `transform` and `box-shadow` pair so each variant inherits the press-into-shadow motion automatically.
- For component libraries with style props or class composition, expose the offset shadow color as a per-variant override so status buttons (success, danger, warning) can swap the shadow color to match their fill while keeping the same 4px offset.
- For server-rendered HTML/CSS, drop the base style block into a single class (e.g. `.button`) and add modifier classes per variant — the rules are CSS-only and have no framework dependency.

## Sizes

| Size | Font size | Horizontal padding | Vertical padding | Offset shadow |
|---|---|---|---|---|
| Extra small | 13px | 12px | 6px | shadow-xs (2px 2px) |
| Small | 14px | 16px | 8px | shadow-sm (3px 3px) |
| Base (default) | 16px | 24px | 12px | shadow-md (4px 4px) |
| Large | 17px | 28px | 14px | shadow-lg (6px 6px) |
| Extra large | 18px | 32px | 16px | shadow-xl (8px 8px) |

The base size matches the canonical rule above (`padding: 12px 24px`). Other sizes scale around it but keep the 2px stroke, 4px radius, and the press-toward-shadow hover motion intact. The shadow offset scales with the size.

## Variants

Each variant swaps `color`, `background-color`, and the offset shadow color. Border stays `2px solid #2C3FA7` for the primary, brand-pink-driven variants; status variants may swap the stroke to match their intent (see below). Radius stays `4px`, transition stays the same.

### Brand
- **Background:** brand (#F237A1)
- **Border:** 2px solid secondary (#2C3FA7)
- **Text:** white
- **Offset shadow:** secondary (#2C3FA7)
- **Hover:** brand-medium background, shadow shrinks 4px → 2px, button translates +2/+2
- **Focus ring:** 4px brand-soft halo behind the offset shadow
- **Print offset:** yes

### Secondary
- **Background:** neutral-secondary (#FBF6EC, the card-cream tone)
- **Border:** 2px solid secondary (#2C3FA7)
- **Text:** heading color (#2C3FA7)
- **Offset shadow:** secondary (#2C3FA7)
- **Hover:** neutral-secondary-strong background
- **Focus ring:** 4px brand-soft halo behind the offset shadow
- **Print offset:** yes

### Tertiary
- **Background:** neutral-primary (#F3EEE4, the surface tone)
- **Border:** 1px solid border-default (#E4E0D9)
- **Text:** heading color (#2C3FA7)
- **Offset shadow:** none — tertiary is the calmest variant
- **Hover:** neutral-secondary background
- **Focus ring:** 2px border-brand on focus only
- **Print offset:** no

### Success
- **Background:** success (#4A8B3C)
- **Border:** 2px solid success-strong (#2E5C24)
- **Text:** white
- **Offset shadow:** success-strong (#2E5C24)
- **Hover:** success-strong background, press-toward-shadow motion
- **Focus ring:** 4px success-medium halo
- **Print offset:** yes

### Danger
- **Background:** danger (#E04A3F)
- **Border:** 2px solid danger-strong (#A52E25)
- **Text:** white
- **Offset shadow:** danger-strong (#A52E25)
- **Hover:** danger-strong background, press-toward-shadow motion
- **Focus ring:** 4px danger-medium halo
- **Print offset:** yes

### Warning
- **Background:** warning (#E0A33C)
- **Border:** 2px solid warning-strong (#9C6D1C)
- **Text:** dark (#2C3FA7) for contrast on the warm yellow
- **Offset shadow:** warning-strong (#9C6D1C)
- **Hover:** warning-strong background, press-toward-shadow motion
- **Focus ring:** 4px warning-medium halo
- **Print offset:** yes

### Dark
- **Background:** dark (#2C3FA7, the secondary blue)
- **Border:** 2px solid dark-strong (#1F2D7A)
- **Text:** white
- **Offset shadow:** brand pink (#F237A1) — inverts the two-color print pairing for emphasis
- **Hover:** dark-strong background, press-toward-shadow motion
- **Focus ring:** 4px brand-soft halo
- **Print offset:** yes

### Ghost (NO border, NO offset shadow)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color (#2C3FA7)
- **Hover:** neutral-secondary background
- **Focus ring:** 2px border-brand on focus only (the offset shadow is removed for ghost)
- **No translate on hover, no offset shadow, no print-frame**

### Disabled (NO offset shadow)
- **Background:** disabled (#ECE5D6)
- **Border:** 1px solid border-default (#E4E0D9)
- **Text:** fg-disabled (#A89E89)
- **Cursor:** not-allowed
- **No hover, no focus motion, no offset shadow, no translate**

## Icons in Buttons

- Icon size: 16x16px (matches the 16px label).
- Spacing: 8px gap between icon and label (matches the inline-flex `gap` token).
- Layout: inline-flex, vertically centered with the label.
- Icons should read as flat two-color print marks — solid fills, single-weight strokes. Avoid heavily detailed or photo-real icons that fight the flat risograph aesthetic.

## Prohibited

- No soft drop-shadows on buttons — the flat hard offset is the visual signature.
- No raw hex values in component code apart from the print-stroke / print-shadow blue (`#2C3FA7`), which is intentionally pinned via the `border-dark` and shadow tokens to keep every variant on the same registered second-color pass. Everywhere else, use design tokens.
- No native `outline` on focus — always rely on the offset shadow + halo ring.
- No removing the press-toward-shadow hover/active motion — the translate + shadow shrink is what gives the button its risograph "press into the paper" feel.
- No full-pill radius (9999px) on standard buttons — radius is always `4px`.
