# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `typography.md`

## Core Specs

- **Background:** `neutral-secondary` (#FBF6EC) — the warmer cream tone that sits one shade lighter than the surface (#F3EEE4), so cards read as a separate layered sheet on the risograph paper.
- **Border:** 1px solid `border-default` (#E4E0D9) — a warm parchment hairline.
- **Radius:** 4px (base).
- **Shadow:** shadow-md — a flat 4px offset in the secondary blue (#2C3FA7), no blur. Subtle cards may use shadow-sm; promoted cards may use shadow-lg.
- **Padding:** 24px (base) — see Layout below for size variants.
- **Heading text:** `heading` color (#2C3FA7), set in Space Grotesk 700.
- **Body text:** `body` color (#637EC2), set in Space Grotesk 400, line-height 1.55.

## Card Heading

- Desktop: 22px, font-heading, heading color
- Mobile: 18px, font-heading, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## Card Padding Sizes

| Size | Padding |
|---|---|
| Compact | 16px |
| Base (default) | 24px |
| Spacious | 32px |
| Hero | 48px |

## States

### Static Card (no interactivity)
- Background: neutral-secondary (#FBF6EC)
- Border: 1px solid border-default (#E4E0D9)
- Radius: 4px
- Shadow: shadow-md (offset in secondary blue)
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card.
- Hover: translate `(2px, 2px)` and shrink the shadow from `4px 4px` → `2px 2px` — the same press-toward-shadow motion used on buttons.
- Active: translate `(4px, 4px)` and collapse the shadow to `0 0` (card meets its shadow).
- Transition: transform 120ms ease-out, box-shadow 120ms ease-out.
- Cursor: pointer.

### Promoted / Featured Card
- Same base styles, but with a 2px solid `border-dark` (#2C3FA7) instead of the parchment hairline, and shadow-lg (6px 6px offset). Reserve this for the single most important card per section.
- Optional accent: replace the offset shadow color with brand pink (#F237A1) for high-emphasis hero cards — this paints the two-color print frame in pink + blue and should be used sparingly.

## Rules

- Background: always `neutral-secondary` (#FBF6EC). Never use white, brand pink, or saturated accent colors as the card surface — cards are always the calm cream sheet.
- Border: 1px solid `border-default` (#E4E0D9) for standard cards. Promoted cards step up to 2px `border-dark`.
- Radius: 4px on every card, no exceptions.
- Shadow: a flat hard offset in the secondary blue — never a soft drop-shadow.
- Heading text: heading color (deep blue). Body text: body color (soft periwinkle). Never set body copy in the brand pink.
- Interactive hover: press-toward-shadow motion (translate + shadow shrink). Never use opacity changes or scale > 1 — those break the flat print look.
- Non-interactive: no hover styles.

## Prohibited

- No saturated brand or accent backgrounds for cards — the card surface is always `neutral-secondary` (#FBF6EC).
- No soft drop-shadows or blurred elevations — only the flat offset in secondary blue.
- No radii outside of 4px on standard cards.
- No body text in brand pink — paragraph text inside cards is always `body` color.
