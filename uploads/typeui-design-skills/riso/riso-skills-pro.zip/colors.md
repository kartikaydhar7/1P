# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #F8F4EB | #1A1F35 |
| neutral-primary | #F3EEE4 | #131628 |
| neutral-primary-medium | #F3EEE4 | #1A1F35 |
| neutral-primary-strong | #ECE5D6 | #232A45 |
| neutral-secondary-soft | #FFFCF5 | #1F2640 |
| neutral-secondary | #FBF6EC | #1A1F35 |
| neutral-secondary-medium | #FBF6EC | #232A45 |
| neutral-secondary-strong | #F4ECDA | #2C3556 |
| neutral-tertiary-soft | #F0E9DA | #232A45 |
| neutral-tertiary | #ECE5D6 | #2C3556 |
| neutral-tertiary-medium | #E4DCC8 | #36406A |
| neutral-quaternary | #DBD2BC | #36406A |
| quaternary-medium | #C8BEA6 | #4A547A |
| gray | #A89E89 | #6A7396 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #FDE3F0 | #3D1228 |
| brand-soft | #FAB5DC | #5A1E40 |
| brand | #F237A1 | #FF6BBE |
| brand-medium | #F66BB9 | #5A1E40 |
| brand-strong | #C42985 | #F237A1 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #E0F2DA | #1F2E14 |
| success | #4A8B3C | #6BB058 |
| success-medium | #B8DCAB | #2E5C24 |
| success-strong | #2E5C24 | #4A8B3C |
| danger-soft | #F8DDD9 | #3D1410 |
| danger | #E04A3F | #F26B5F |
| danger-medium | #F0B8B0 | #6B1F1A |
| danger-strong | #A52E25 | #E04A3F |
| warning-soft | #FBE9C8 | #3D2A0E |
| warning | #E0A33C | #F2BC58 |
| warning-medium | #F4D695 | #6B4A18 |
| warning-strong | #9C6D1C | #E0A33C |

### Button Glint (custom properties, used for the offset shadow & two-color print effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(250,182,220,0.30) | rgba(255,107,190,0.20) |
| `--color-1-700` | rgba(44,63,167,0.20) | rgba(99,126,194,0.30) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #2C3FA7 | #2C3FA7 |
| dark-strong | #1F2D7A | #4A5BC2 |
| disabled | #ECE5D6 | #232A45 |

### Accent (risograph two-color print accents)
| Token | Value (same both modes) |
|---|---|
| purple | #8B5CCF |
| sky | #6680C2 |
| teal | #4FA28A |
| pink | #F237A1 |
| cyan | #5FB5C5 |
| fuchsia | #E04AB8 |
| indigo | #2C3FA7 |
| orange | #E58A4A |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #1A1A1A | #1A1A1A |
| heading | #2C3FA7 | #C8D0F0 |
| body | #637EC2 | #8FA2D0 |
| body-subtle | #8FA2D0 | #637EC2 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #FAB5DC | #5A1E40 |
| fg-brand | #F237A1 | #FF6BBE |
| fg-brand-strong | #C42985 | #FAB5DC |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #2E5C24 | #6BB058 |
| fg-success-strong | #1F4118 | #8BC97A |
| fg-danger | #A52E25 | #F26B5F |
| fg-danger-strong | #6B1F1A | #F4948A |
| fg-warning-subtle | #E0A33C | #F2BC58 |
| fg-warning | #6B4A18 | #F2D580 |
| fg-disabled | #A89E89 | #6A7396 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #D49032 | #F2BC58 |
| fg-info | #2C3FA7 | #8FA2D0 |
| fg-purple | #8B5CCF | #B58EE0 |
| fg-purple-strong | #5C3A91 | #C8A8E5 |
| fg-cyan | #4F97A5 | #8AC8D2 |
| fg-indigo | #2C3FA7 | #637EC2 |
| fg-pink | #F237A1 | #F66BB9 |
| fg-lime | #5C8B3C | #8BC97A |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #2C3FA7 | #4A5BC2 |
| border-buffer | #F3EEE4 | #131628 |
| border-buffer-medium | #F3EEE4 | #1A1F35 |
| border-buffer-strong | #ECE5D6 | #232A45 |
| border-muted | #F0E9DA | #1A1F35 |
| border-light-subtle | #ECE5D6 | #1F2640 |
| border-light | #E4E0D9 | #232A45 |
| border-light-medium | #DBD2BC | #2C3556 |
| border-default-subtle | #EAE4D9 | #1F2640 |
| border-default | #E4E0D9 | #2C3556 |
| border-default-medium | #DBD2BC | #36406A |
| border-default-strong | #C8BEA6 | #4A547A |
| border-success-subtle | #C5E5B5 | #2E5C24 |
| border-success | #4A8B3C | #6BB058 |
| border-danger-subtle | #F0BFB5 | #6B1F1A |
| border-danger | #A52E25 | #E04A3F |
| border-warning-subtle | #F0D08E | #6B4A18 |
| border-warning | #D49032 | #E0A33C |
| border-brand-subtle | #FAB5DC | #5A1E40 |
| border-brand-light | #F66BB9 | #F66BB9 |
| border-brand | #F237A1 | #FF6BBE |
| border-dark-subtle | #2C3FA7 | #4A5BC2 |
| border-purple | #8B5CCF | #B58EE0 |
| border-orange | #E58A4A | #E58A4A |

## Semantic Usage Rules

- Page/section backgrounds: a single warm off-white surface tone (`neutral-primary` = #F3EEE4) used across **every** section. No alternating section backgrounds — the surface is one continuous risograph paper sheet.
- Cards over surface: warmer cream tone `neutral-secondary` (#FBF6EC) — slightly lighter than the surface to read as a layered sheet sitting on top of the paper.
- Primary buttons: brand pink (#F237A1) fill — the sole interaction driver, reserve it for the single most important action per screen.
- Headings: `heading` text color (deep federal blue #2C3FA7) — every heading from `h1` through `h6`.
- Body text / paragraphs: `body` text color (soft periwinkle blue #637EC2) — desaturated complement to the heading blue, set in the body sans.
- CTA links: `fg-brand` text color (brand pink) for the one primary action; secondary inline links use `heading` blue with underline.
- Default borders for cards, inputs, and elements: `border-default` (#E4E0D9) — a warm parchment hairline that sits gently on the cream surface.
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning.
- Disabled: disabled background + fg-disabled text.

## Prohibited

- No raw hex/rgb values in component code — always use design tokens.
- No brand pink for long-form paragraphs — body copy is always set in the soft periwinkle `body` token.
- No alternating section background colors — a single surface tone (#F3EEE4) carries the entire page, the way a single sheet of risograph paper would.
- No introducing a second saturated accent — the brand pink (#F237A1) is the only interaction driver. Secondary blue (#2C3FA7) is reserved for headings, borders, and the offset print-shadow detail.
- No gradients — risograph is flat by design. Depth comes from offset solid colors and slight registration mis-alignment, never from gradients.
- No manual light/dark value swapping — let the token system handle it.
