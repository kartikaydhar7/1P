# Content & Grid System

> Dependencies: `layout.md`, `typography.md`

## Containers

| Type | Max width | Horizontal padding |
|---|---|---|
| Standard | 1152px | 24px |
| Wide marketing | 1280px | 24px |
| Internal (reading) | 720px | 24px (~60–70 char line length) |

## Vertical Padding

| Breakpoint | Vertical padding |
|---|---|
| Mobile | 48px |
| Tablet (≥768px) | 64px |
| Desktop (≥1024px) | 96px (default) or 128px for hero/feature sections |

## Grid System

Mobile-first with flexible desktop configurations.

| Context | Gap |
|---|---|
| Standard content / cards | 24px |
| Wide component grid | 32px |
| Compact widgets / metadata | 16px |

### Responsive Columns

| Breakpoint | Columns |
|---|---|
| Mobile (default) | 1–2 |
| Small / Tablet (≥640px) | 2–3 |
| Desktop (≥1024px) | 3–4 |
| Wide (≥1280px) | 3–6 |

Full support for 6, 7, 8, 9+ column grids where needed (typically reserved for utility / dashboard layouts, not marketing).

## Breakpoints

| Name | Width |
|---|---|
| Small | 640px |
| Medium | 768px |
| Large | 1024px |
| Extra large | 1280px |
| 2x Extra large | 1536px |

## Rhythm

- Body copy: Space Grotesk, 16px, line-height 1.55, body color (#637EC2)
- Lead paragraphs: 20px, line-height 1.55
- Headings → following paragraph: 16px gap
- Section header → content: 48px gap (mobile) or 64px (desktop)
- Section header eyebrow (Space Mono uppercase) → heading: 12px gap

## Rules

- Always design mobile-first.
- Use layout shifts (column → row) to accommodate horizontal space — never scale a desktop grid down to mobile by shrinking gaps below 16px.
- Lists: 24px indentation, 16px vertical gap between items (matches `lists.md`).
- Body copy: 16px, line-height 1.55, body color.
- All interactive links follow the typography link protocol — heading-blue inline links by default, brand-pink reserved for the single primary CTA per view.
- Every full-width section uses the same surface background (`neutral-primary`, #F3EEE4) — gridded section content sits on top of that single sheet, no alternating backgrounds.
