# Dropdown

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `typography.md`, `inputs.md`

## Core Specs

### Chevron Icon
- Size: 16x16px
- Spacing: 8px left margin, -2px right margin
- Color: inherits from the trigger button

### Menu Container
- Background: neutral-secondary (#FBF6EC) — the card-cream tone, so the menu reads as a layered sheet over the surface
- Border: 1px solid border-default (#E4E0D9)
- Radius: 4px
- Shadow: shadow-lg (6px 6px offset in secondary blue) — the print-offset signals the menu is floating above the surface
- Z-index: elevated above content

### Menu List
- Padding: 6px
- Font: Space Grotesk, 14px, weight 500

### Menu Item
- Layout: inline-flex, vertically centered, full width
- Padding: 8px 10px
- Radius: 4px
- Color: heading (#2C3FA7) by default
- Hover: neutral-secondary-strong (#F4ECDA) background
- Active / selected: brand-softer (#FDE3F0) background, fg-brand-strong text — single-accent rule applies
- Transition: background-color 120ms ease

## Trigger Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Small | 14px | 12px | 8px |
| Base | 16px | 16px | 10px |
| Large | 17px | 20px | 12px |

Triggers inherit the `inputs.md` styling when used as a select; when the trigger is a button, it inherits `buttons.md` (typically the Secondary variant).

## Icon-only Trigger

- Padding: 8px
- Min size: 40x40px (4px radius square)
- Icon: 20x20px, heading color

## Variants

### Default
- Menu width: 200px (or fit-content), item radius: 4px.

### With Divider
- 1px top border (border-default) between child groups, skip the first group.

### With Header
- Header padding: 14px horizontal, 12px vertical
- Bottom border: 1px border-default
- Name: Space Grotesk, 14px, weight 600, heading color
- Email / supporting line: Space Mono, 12px, body-subtle color, truncated

### With Icons
- Icon before label: 16x16px, 8px right margin, heading color
- On hover, the icon color stays heading; on selected items the icon switches to fg-brand

### With Checkbox / Radio
- Inputs: 16x16px, 2px radius (per `radios-checkboxes-toggle.md`), focus ring in brand-soft
- Helper text: Space Mono, 11px, body-subtle color, 2px top margin

### With Search
- Search input at top of menu following `inputs.md` specs (4px radius, parchment border)
- Left icon: 14px left padding, input 40px left padding

### Scrollable
- Max height: 240px, vertical scroll overflow, 6px right padding to clear the scrollbar

## States

| State | Appearance |
|---|---|
| Focused trigger | no native outline, 2px border-brand stroke + 2px offset shadow in secondary blue |
| Hover item | neutral-secondary-strong background, heading text |
| Active / selected item | brand-softer background, fg-brand-strong text |
| Disabled item | fg-disabled text, not-allowed cursor, no pointer events |

## Rules

- Radius on the menu container and every item is 4px.
- The menu always sits on a `neutral-secondary` background — never use the page surface (#F3EEE4) for the menu container, so the print-offset shadow has visible separation from the page.
- The shadow under the menu is always a hard offset in secondary blue — never a soft drop-shadow.
- Use the brand-pink accent for the active / selected item only — at most one item should appear selected at any time.
