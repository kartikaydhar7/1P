# Icon Shapes

> Dependencies: `colors.md`, `radius.md`, `borders.md`

## Core Specs

- Box sizing: border-box
- Icon must be perfectly centered (inline-flex, centered both axes)
- Circle: fully rounded (9999px)
- Rounded square: 4px radius across all sizes (matches the system)

## Sizes

| Size | Container | Icon |
|---|---|---|
| XS | 24x24px | 14x14px |
| SM | 32x32px | 16x16px |
| MD | 40x40px | 20x20px |
| LG | 48x48px | 24x24px |
| XL | 56x56px | 28x28px |

## Border (optional)

- Default: 1px solid `border-default` (#E4E0D9) for icon shapes sitting on the surface
- Featured: 2px solid `border-dark` (#2C3FA7) — pairs with the offset print-shadow when the icon shape acts as a small interactive print-frame

## Color Variants

### Brand
- Shape: rounded square (4px) — primary; circle allowed for inline list use
- Background: brand-softer (#FDE3F0)
- Icon color: fg-brand-strong (#C42985)

### Gray
- Shape: rounded square (4px)
- Background: neutral-secondary (#FBF6EC)
- Icon color: heading (#2C3FA7)

### Indigo (Heading-blue)
- Shape: rounded square (4px)
- Background: neutral-secondary (#FBF6EC)
- Icon color: heading (#2C3FA7)
- Use for default informational icons that should pair with the heading-blue type

### Danger
- Shape: rounded square (4px)
- Background: danger-soft
- Icon color: fg-danger-strong

### Success
- Shape: rounded square (4px)
- Background: success-soft
- Icon color: fg-success-strong

### Warning
- Shape: rounded square (4px)
- Background: warning-soft
- Icon color: fg-warning

### Print-Frame (Featured)
- Shape: rounded square (4px)
- Background: brand (#F237A1)
- Icon color: white
- Border: 2px solid border-dark (#2C3FA7)
- Box-shadow: 4px 4px 0 0 secondary (#2C3FA7) — the full print-frame treatment
- Use sparingly for the single most important callout per section

## Rules

- Default to the rounded square shape with 4px radius — it matches the system's print-block silhouette.
- Use the circle shape only when the icon sits inline within text (list items, avatar contexts).
- Never apply soft drop-shadows; only the hard offset is allowed, and only on the print-frame variant.
