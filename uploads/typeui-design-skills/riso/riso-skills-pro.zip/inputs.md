# Inputs

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `typography.md`

## Core Specs

- **Display:** block, full width
- **Radius:** 4px (base)
- **Border:** 1px, border-default (#E4E0D9)
- **Background:** neutral-secondary (#FBF6EC)
- **Shadow:** none on rest, shadow-xs (2px 2px offset in secondary blue) on focus
- **Font:** Space Grotesk, 16px (mobile-friendly default), heading color
- **Padding:** 14px horizontal, 12px vertical
- **Placeholder:** body color (#637EC2)
- **Transition:** border-color 150ms ease, box-shadow 150ms ease

## Label

- Display: block
- Font: Space Grotesk, 14px, weight 500, heading color (#2C3FA7)
- Margin bottom: 8px
- Label `htmlFor` must match the input `id`
- Optional eyebrow style: Space Mono, 12px, uppercase, letter-spacing 0.04em — used when the label sits above grouped fields as a section kicker.

## Helper / Error Text

- Font: Space Mono, 12px, letter-spacing 0.04em
- Default color: body (#637EC2)
- Error color: fg-danger
- Margin top: 6px

## States

### Default
- Border: 1px solid border-default (#E4E0D9)
- Background: neutral-secondary (#FBF6EC)
- No shadow

### Hover
- Border: 1px solid border-default-medium (#DBD2BC)

### Focus
- No native outline
- Border: 2px solid border-brand (#F237A1)
- Box-shadow: 2px 2px 0 0 secondary (#2C3FA7) — the print-offset signature, applied only on focus

### Success
- Border: 2px solid border-success
- Focus shadow: 2px 2px 0 0 success-strong

### Error / Danger
- Border: 2px solid border-danger
- Focus shadow: 2px 2px 0 0 danger-strong

### Disabled
- Background: disabled (#ECE5D6)
- Text: fg-disabled (#A89E89)
- Border: 1px solid border-default
- Cursor: not-allowed
- No focus state

## Input with Icons

- Icon size: 16x16px
- Icon color: body (#637EC2); switch to fg-brand when the icon represents an action (clear, search submit, etc.)
- Container: relative positioned wrapper
- Start icon: absolutely positioned left, 14px left padding — input gets 40px left padding
- End icon: absolutely positioned right, 14px right padding — input gets 40px right padding
- Icons vertically centered within the wrapper

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Small | 14px | 12px | 8px |
| Base (default) | 16px | 14px | 12px |
| Large | 17px | 16px | 14px |

## Rules

- Every input must have a unique `id`.
- Every label must have a matching `htmlFor`.
- Radius is always 4px — never round inputs to pill shapes.
- Padding: 14px horizontal, 12px vertical unless overridden for icon variants.
- Focus state always carries the 2px brand-pink stroke + 2px secondary-blue offset shadow — that pairing is the input's print-frame signature.
- No arbitrary hex or hardcoded colors.
