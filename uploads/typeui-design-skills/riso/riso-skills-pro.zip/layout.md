# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px. The risograph aesthetic leans on generous negative space — whitespace is treated as a feature, not a gap to fill.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1152px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Eyebrow / kicker label (Space Mono, uppercase, optional)
2. Heading (`h1`–`h3`)
3. Leading paragraph
4. Normal paragraph(s)
5. Lists, CTA links, or component grids

## Section Pattern

Every section uses **the same single surface background** (`neutral-primary`, #F3EEE4) — there is **no alternating section pattern** in this design system. The page reads as one continuous sheet of risograph paper, and depth is created through cards, offset print shadows, and large illustrative compositions, not through alternating section colors.

Each section has:
- 96px vertical padding
- The single surface background `neutral-primary` (#F3EEE4) — never alternate, never swap to brand or accent colors at the section level
- A centered container (max-width 1152px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below
- Headings always in `heading` color (deep blue #2C3FA7)
- Body copy always in `body` color (soft periwinkle #637EC2)

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use a JS animation library only when CSS cannot achieve the behavior.
- The signature interaction is the **press-toward-shadow** motion shared by buttons and interactive cards (translate + offset-shadow shrink). Reuse this primitive across hoverable components.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single staged page-load reveal using `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered transitions for moments that reinforce hierarchy or reward attention.
- Never animate radius or border thickness — they are part of the system's identity and stay constant.

## Backgrounds & Visual Depth

- Default to the single surface tone (#F3EEE4) for every full-width section. Depth and rhythm come from:
  - Cards in the warmer cream tone (#FBF6EC) layered over the surface, with a 4px offset shadow in secondary blue.
  - Large illustrative SVG compositions (geometric shapes, halftone dots, two-color print marks, simple grainy textures) treated as compositional elements, not decoration.
  - The brand pink used sparingly for the single primary call-to-action per view.
- All cards, buttons, inputs, and interactive elements use the parchment border (`border-default`, #E4E0D9) by default, stepping up to the 2px secondary-blue stroke only for the print-frame variants.
- Every decorative element must serve a compositional purpose (depth, separation, emphasis, or playful narrative). No purely ornamental effects competing with content.
- The risograph "registration offset" is a load-bearing visual — buttons and promoted cards should always carry the hard offset shadow in secondary blue so the two-color print pairing is reinforced across the page.

## Must

- All sections share the same surface background (#F3EEE4)
- All sections: consistent 96px vertical padding
- All containers: max-width 1152px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
- Headings in heading color (deep blue), paragraphs in body color (soft periwinkle), brand pink reserved for the single primary action per view
