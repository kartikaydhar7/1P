# Lists

> Dependencies: `colors.md`, `typography.md`

## Core Specs

- Item spacing: 16px vertical gap between list items
- Font: Space Grotesk, 16px, weight 400
- Text color: body (#637EC2)
- Heading list items (when a list item carries its own title): Space Grotesk, 16px, weight 600, heading color (#2C3FA7), with the body line beneath in body color

## List Icons

- Size: 20x20px
- Prevent squishing: no shrink
- Spacing: 8px right margin between icon and text
- Active / featured icon: fg-brand color (#F237A1) — used to mark the single highlighted item per list
- Neutral icon: heading color (#2C3FA7) — flat two-color print mark
- Status icons (success / danger / warning): fg-success / fg-danger / fg-warning

## Inactive / Disabled Items

Strikethrough text with `body-subtle` color and a `body-subtle` decoration line. Icons drop to `fg-disabled`.

## Numbered Lists

- Numerals set in Space Mono, 14px, weight 500, heading color
- Right-align the numeral in a 24px gutter to the left of the text block
- Optional eyebrow style: a small Space Mono numeral set in fg-brand for the highlighted step in a flow

## Pattern

Vertical flex list with 16px gap. Each item is a flex row with centered alignment — icon (20x20, no-shrink, 8px right margin) followed by the text block. Headings within an item use heading color, supporting copy uses body color, and a single highlighted item per list may swap its icon to fg-brand to draw the eye.

## Rules

- Reserve the brand-pink list icon for at most one item per list — the single-accent rule applies inside lists too.
- Never set list body text in brand pink; only the leading icon may carry the brand color.
- Spacing between list items stays at 16px — do not tighten lists into dense rows.
