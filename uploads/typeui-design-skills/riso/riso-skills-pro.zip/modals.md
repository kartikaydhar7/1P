# Modals

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `buttons.md`, `inputs.md`, `typography.md`

## Core Specs

### Overlay (Backdrop)
- Fixed, covers full screen
- Z-index: 40
- Background: secondary blue (#2C3FA7) at 35% opacity — the riso second-color screen tints the backdrop instead of plain black
- Optional very small blur (≤2px) to keep the surface readable, never a heavy blur

### Content Container
- Background: neutral-secondary (#FBF6EC) — the card-cream tone, so the modal reads as a layered sheet over the tinted backdrop
- Radius: 4px
- Border: 1px solid border-default (#E4E0D9)
- Shadow: shadow-xl (8px 8px offset in secondary blue)
- Padding: 24px

## Anatomy

### Header
- Bottom border: 1px border-default
- Top corners: 4px radius (matches the container)
- Title: Space Grotesk, 22px, weight 700, heading color (#2C3FA7)
- Optional eyebrow above title: Space Mono, 12px, uppercase, body-subtle color
- Close button: Ghost variant from `buttons.md`, 8px padding, 16px icon, heading color

### Body
- Vertical padding: 24px
- Vertical spacing between elements: 20px
- Text: Space Grotesk, 16px, 1.55 line-height, body color (#637EC2)

### Footer
- Top border: 1px border-default
- Bottom corners: 4px radius
- Padding: 16px 24px
- Layout: flex, end-aligned, 12px gap between actions
- Primary action uses the Brand button variant; secondary action uses the Tertiary button variant

## Variants

### Default (Information)
Standard header + body + footer with primary / secondary action buttons.

### Pop-up (Confirmation)
Centered text, prominent icon, reduced padding:
- Body: 24px padding, text centered
- Icon: centered, 16px bottom margin, 48x48px icon-shape (rounded square 4px) in the variant's color (brand for confirms, danger for destructive, success for completion)

### Form Modal
Body contains inputs following `inputs.md`. Vertical spacing between form elements: 16px. Submit action uses the Brand button.

### Drawer / Side Modal
Same content rules but full-height, anchored to the inline-end of the viewport, max-width 480px. Radius applies only on the inline-start corners (top/bottom inline-start = 4px, inline-end = 0).

## Rules

- Radius is always 4px on the container.
- Backdrop is the riso secondary-blue tint, not plain black — it reinforces the two-color print pairing across the system.
- Modal background is `neutral-secondary` (#FBF6EC), never the page surface (#F3EEE4). The contrast between the modal and the tinted backdrop is what makes the modal feel like a layered print sheet.
- Close button must be present and functional, placed in the header inline-end.
- Accessibility: `role="dialog"`, focus trap in code, `aria-labelledby` referencing the title, dismiss on overlay click + Escape.
- Dark mode automatic via the token system.
