# Pagination

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `typography.md`

## Container

Font: Space Grotesk, 14px. Items displayed as a flex row with -1px overlap so adjacent borders merge into one continuous print line.

## Pagination Item

- Layout: flex, centered both axes
- Size: 40x40px
- Text: heading color (#2C3FA7), weight 500
- Background: neutral-secondary (#FBF6EC)
- Border: 1px solid border-default (#E4E0D9)
- Hover: neutral-secondary-strong (#F4ECDA) background
- Focus: no native outline, 2px border-brand stroke + 2px 2px offset shadow in secondary blue
- Transition: background-color 120ms, transform 120ms
- Overlap: -1px left margin

## Previous / Next Buttons

- Horizontal padding: 14px, height: 40px
- Layout: inline-flex, vertically centered, 6px gap between icon and label
- First item (Previous): 4px radius on inline-start corners, 0 on inline-end
- Last item (Next): 4px radius on inline-end corners, 0 on inline-start
- Disabled: fg-disabled text, not-allowed cursor, no hover state

## Active Page Item

- Text: white
- Background: brand (#F237A1)
- Border: 1px solid border-dark (#2C3FA7) — the active item carries the print-frame stroke so the user's location reads as the page's accent print mark
- Box-shadow: none (the brand fill on the calm cream row provides enough emphasis without an offset shadow)
- Hover: brand-medium (#F66BB9) background

## Ellipsis

- Same dimensions as a page item (40x40px)
- No background, no border, no interactivity
- Text: Space Mono, body-subtle color, centered ellipsis character

## Rules

- Display as a flex row with -1px child overlap for seamless borders.
- Items: neutral-secondary background, 1px border-default, heading text, 4px radius on the row's first/last items only.
- Active page: brand fill, white text, 1px border-dark — the only place brand pink appears in pagination.
- All interactive items need hover and focus states (focus = brand-pink stroke + offset shadow).
- The pagination row never carries its own offset shadow — the active page is the sole emphasis mark.
