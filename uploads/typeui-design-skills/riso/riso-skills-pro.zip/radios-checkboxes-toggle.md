# Radios, Checkboxes & Toggles

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `typography.md`

## Checkbox

- Size: 18x18px
- Radius: 2px (the system's `sm` token — small selection control)
- Border: 2px solid border-default-medium (#DBD2BC)
- Background: neutral-secondary (#FBF6EC)
- Focus ring: 3px solid brand-soft (#FAB5DC), no native outline
- Transition: background-color 120ms, border-color 120ms

### Checked
- Background: brand (#F237A1)
- Border: 2px solid border-brand
- Indicator (check mark): white, 2px stroke

### Disabled
- Border: 2px solid border-light (#E4E0D9)
- Background: disabled (#ECE5D6)
- Indicator: fg-disabled
- Cursor: not-allowed

## Radio

- Size: 18x18px
- Radius: 9999px (fully rounded — radios stay circular)
- Border: 2px solid border-default-medium
- Background: neutral-secondary
- Focus ring: 3px brand-soft, no native outline
- Transition: background-color 120ms, border-color 120ms

### Checked
- Border: 2px solid border-brand (#F237A1)
- Inner indicator: 8x8px circle, brand color centered inside the radio

### Disabled
- Border: 2px solid border-light-medium
- Background: disabled
- Cursor: not-allowed

Group all radio items under the same `name` attribute.

## Toggle

### Track
- Width: 36px, height: 20px
- Radius: 9999px (fully rounded — toggles stay pill-shaped, the only standard control besides radios that does)
- Background: neutral-tertiary-medium (#E4DCC8)
- Focus-within ring: 3px brand-soft
- Checked track: brand (#F237A1)
- Disabled track: disabled (#ECE5D6)
- Transition: background-color 150ms

### Thumb
- 16x16px, fully rounded
- Background: white
- Border: 1px solid border-default
- Box-shadow: 1px 1px 0 0 secondary blue (#2C3FA7) — a tiny print-offset on the thumb tying the toggle to the rest of the system
- Translates 16px on the inline axis between off and on states (transition: transform 150ms ease)

### Disabled
- Track: disabled background
- Thumb: thumb stays white but the print-offset shadow is removed
- Label: fg-disabled text
- Cursor: not-allowed

## Label & Helper Text

- Label: Space Grotesk, 14px, weight 500, heading color (#2C3FA7), aligned to the start of the control with 8px gap
- Helper / description: Space Mono, 12px, body-subtle color, sits beneath the label with 4px top margin

## Rules

- Checkbox uses the `sm` (2px) radius — it is one of the few exceptions to the 4px-everywhere rule.
- Radios and toggle tracks stay fully rounded; the toggle is the only "pill" shape allowed in the standard component set.
- Checked / on states all use the brand pink — the single-accent rule applies inside forms too.
- All selection inputs must have `id` matching label `htmlFor`.
- Focus states use the brand-soft token for the ring, never the saturated brand color directly.
- Disabled states: no hover / focus interaction, no print-offset shadow.
