# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 4px | Buttons, cards, inputs, modals, sections, alerts, dropdowns — every standard component |
| default | 4px | Badges, tooltips, dropdown items, small controls |
| sm | 2px | Checkboxes, tags, tiny chips |
| full | 9999px | Avatars, dot indicators, single-character status pills |

## Rules

- **4px is the default radius across the entire product.** Every standard component (button, card, input, modal, alert, panel) uses `base` (4px).
- The risograph aesthetic is built on near-square shapes — radii stay small and uniform so the print-block feel reads cleanly.
- Never use arbitrary radius values outside this scale.
- Radius must be consistent within each component family.
- The only exceptions to the 4px rule are: avatars and dot indicators (`full`), and very small selection controls like checkbox boxes (`sm` = 2px).
