# Shadows

The risograph aesthetic uses **hard offset shadows** in the secondary blue (#2C3FA7) — they read as a misregistered second-color print pass rather than soft elevation. No blur, no rgba softness — flat, two-color print stacking.

| Token | Value |
|---|---|
| shadow-2xs | `1px 1px 0 0 #2C3FA7` |
| shadow-xs | `2px 2px 0 0 #2C3FA7` |
| shadow-sm | `3px 3px 0 0 #2C3FA7` |
| shadow-md | `4px 4px 0 0 #2C3FA7` |
| shadow-lg | `6px 6px 0 0 #2C3FA7` |
| shadow-xl | `8px 8px 0 0 #2C3FA7` |
| shadow-2xl | `10px 10px 0 0 #2C3FA7` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, badges, small controls | shadow-xs |
| Buttons, lightweight cards | shadow-md |
| Standard cards, popovers, dropdowns | shadow-md |
| Prominent cards, sticky surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use only these tokens — no custom box-shadow values.
- All shadows are **flat two-color print offsets** in the secondary blue. No blur radius, no spread, no rgba transparency.
- Keep elevation steps intentional; avoid jumping multiple levels.
- Components in the same family share the same baseline elevation.
- Hover/focus on interactive elevated elements: step **down** by one level (the element appears to press toward the shadow), not up. This matches the risograph "press into the print" interaction.
- Never stack multiple shadow tokens on one element.
- Never replace the hard offset with a soft drop-shadow — soft shadows break the flat print aesthetic.
- The shadow color is always the secondary blue (#2C3FA7). Never colorize the shadow with brand pink for general components.
