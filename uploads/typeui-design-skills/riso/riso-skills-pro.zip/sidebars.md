# Sidebars

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `typography.md`, `badges.md`, `alerts.md`

## Core Specs

- Background: neutral-secondary (#FBF6EC) — the sidebar reads as a layered card column on the surface
- Right border: 1px solid border-default (#E4E0D9) for left-sidebars; left border for right-sidebars
- Width: 264px

## Anatomy

### Outer Container
Hidden on mobile, visible at small breakpoint. Needs a toggle / trigger for mobile (the trigger uses the Ghost button variant from `buttons.md`).

### Inner Wrapper
- Full height, vertical scroll overflow
- Padding: 16px horizontal, 20px vertical

### Brand / Logo Block
- Padding: 8px 12px, 16px bottom margin
- Logo height: 28px, heading color (or brand pink for the wordmark accent)

### Navigation Section Header
- Font: Space Mono, 12px, weight 500, letter-spacing 0.04em, UPPERCASE
- Color: body-subtle (#8FA2D0)
- Padding: 8px 10px, 8px bottom margin

### Navigation List
- Vertical spacing: 4px between items
- Font: Space Grotesk, 14px, weight 500

### Navigation Item
- Layout: flex, vertically centered
- Padding: 10px horizontal, 10px vertical
- Text: heading color (#2C3FA7)
- Radius: 4px
- Hover: neutral-secondary-strong (#F4ECDA) background
- Transition: background-color 120ms
- Icon: 20x20px, heading color
- Label: 12px left margin from icon
- Trailing badge / count: aligned to the inline-end of the row, uses the Gray badge variant

### Active Item
- Background: brand-softer (#FDE3F0)
- Text: fg-brand-strong (#C42985)
- Icon color: fg-brand
- Optional 2px brand-pink left rule (3px wide, full row height) anchored to the inline-start edge of the item — the riso "active page mark"

### Separator
- 1px top border in border-default
- 16px top padding, 16px top margin
- 8px vertical spacing below

### Bottom CTA / Card
- Padding: 16px
- Top margin: 24px
- Radius: 4px
- Background: brand-softer (#FDE3F0) for the brand variant; neutral-secondary-strong for a neutral upgrade prompt
- Border: 1px solid border-default (or border-brand-subtle for the brand variant)
- Optional offset shadow: shadow-sm (3px 3px in secondary blue) for emphasis
- Can also reuse any alert variant from `alerts.md`

## Rules

- Background is the warm cream `neutral-secondary` so the sidebar layers cleanly over the surface.
- Radius on every nav item is 4px.
- The brand-pink color appears only on the active item (text + icon + optional left rule) — no other nav row may carry brand pink.
- Icons are flat single-color print marks at 20x20px.
- Multi-level menus: indent with 32px left padding for child items, keep the radius at 4px.
- Spacing follows the 8px grid.
- Only token colors — no arbitrary hex values.
