# Tables

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `typography.md`

## Wrapper

- Horizontal scroll overflow
- Background: neutral-secondary (#FBF6EC) — the card-cream tone, so the table reads as a layered sheet over the surface
- Radius: 4px
- Border: 1px solid border-default (#E4E0D9)
- Shadow: shadow-md (4px 4px offset in secondary blue) — promoted tables may step up to shadow-lg

## Table Element

- Full width, left-aligned text (right-aligned for RTL)
- Font: Space Grotesk, 14px, body color (#637EC2)
- `border-collapse: collapse` so the 1px parchment dividers register cleanly without doubling

## Table Head

- Font: Space Mono, 12px, weight 500, letter-spacing 0.04em, UPPERCASE, heading color (#2C3FA7)
- Background: neutral-secondary-strong (#F4ECDA) — slightly darker than the body to mark the header row
- Bottom border: 1px border-default
- Cell padding: 16px horizontal, 12px vertical

## Table Body

- Row background: neutral-secondary (#FBF6EC) — every row uses the same warm cream, no zebra striping
- Row bottom border: 1px border-default (omit on the last row to avoid doubling with the wrapper border)
- Row hover: neutral-secondary-strong (#F4ECDA) background (optional)
- Row header (first cell when used as `<th scope="row">`): Space Grotesk, 14px, weight 600, heading color, no-wrap
- Cell padding: 16px horizontal, 14px vertical

## Numeric Columns

- Numeric values: Space Mono, 14px, weight 500, heading color, right-aligned
- Currency / unit suffixes use the same Space Mono treatment so financial / metric data reads as print-mark metadata

## Selection / Sort Indicators

- Sort caret: 12x12px, heading color, sits 4px to the right of the column label
- Active sort: caret in fg-brand (#F237A1) — at most one column may show the active sort caret
- Selected row: 1px brand-pink left rule on the inline-start cell + brand-softer (#FDE3F0) background

## Rules

- Wrapper radius is 4px and the wrapper carries the offset print-shadow.
- No zebra striping — the riso aesthetic uses the parchment hairline divider as the only row separator.
- Headers set in Space Mono uppercase so they read as print-mark metadata, distinct from body cells set in Space Grotesk.
- Active sort indicator is the only place brand pink may appear inside a table — body cells stay in body / heading colors.
- Last row: omit bottom border to avoid doubling with the wrapper border.
- Row headers: always `scope="row"` for semantic structure.
- No arbitrary hex codes — use token colors only.
