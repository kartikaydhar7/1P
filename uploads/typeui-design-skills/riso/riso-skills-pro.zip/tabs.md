# Tabs

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `typography.md`

## Core Specs

- Typography: Space Grotesk, 15px, weight 500, body color (default)
- Transitions: background-color 150ms, color 150ms, transform 120ms

## Variants

### 1. Underline (Default)

**Wrapper:** 1px bottom border, border-default (#E4E0D9)

**Tab Item:**
- Padding: 14px horizontal, 14px vertical
- Bottom border: 3px solid transparent (resting state)
- Top corners: 4px radius
- Transition: color 150ms, border-color 150ms

| State | Appearance |
|---|---|
| Active | heading text, border-brand (#F237A1) 3px bottom border |
| Inactive | body text, transparent bottom border; hover → heading text, border-default-strong bottom border |
| Disabled | fg-disabled text, not-allowed cursor |

### 2. Pills

**Tab Item:**
- Padding: 16px horizontal, 10px vertical
- Radius: 4px
- Font: Space Grotesk, weight 600
- Transition: background-color 150ms, transform 120ms, box-shadow 120ms

| State | Appearance |
|---|---|
| Active | brand background (#F237A1), white text, 2px border-dark stroke + 2px 2px offset shadow in secondary blue (mini print-frame) |
| Inactive | neutral-secondary background, heading text; hover → neutral-secondary-strong background |
| Disabled | fg-disabled text, not-allowed cursor |

### 3. Full Width

Children overlap with -1px left margin on all except the first — the strokes merge into one continuous print row.

**Tab Item:**
- Full width, centered text
- Padding: 14px horizontal, 14px vertical
- Background: neutral-secondary (#FBF6EC)
- Border: 1px border-default (#E4E0D9)
- Transition: background-color 150ms

| State | Appearance |
|---|---|
| Active | neutral-secondary-strong background, heading text, 2px top border in border-brand (the brand-pink stroke marks the active tab) |
| Inactive | hover → neutral-secondary-strong background |
| First item | 4px radius on inline-start corners |
| Last item | 4px radius on inline-end corners |

### 4. Print-Frame Tabs (promoted)

Each tab is its own bordered card with the full print-frame treatment. Reserve for top-level navigation in marketing pages.

**Tab Item:**
- Padding: 14px 20px
- Radius: 4px
- Background: neutral-secondary
- Border: 2px solid border-dark (#2C3FA7)
- Shadow: shadow-md (4px 4px offset in secondary blue) on the active tab; inactive tabs get no shadow
- 12px gap between items (no overlap)

| State | Appearance |
|---|---|
| Active | brand background, white text, full print-frame (2px border + 4px offset shadow) |
| Inactive | neutral-secondary background, heading text, 1px border-default, no shadow |
| Hover | neutral-secondary-strong background, 2px 2px offset shadow appears |

## Tabs with Icons

- Icon size: 16x16px or 20x20px
- Spacing: 8px right margin
- Layout: inline-flex, centered
- Icons inherit the text color of the tab state — flat single-color print marks

## Rules

- Radius is always 4px on every variant.
- The underline variant uses the brand pink as the active indicator — this is one of the few places brand pink can appear without being the page's primary CTA, because the underline is a low-saturation accent.
- The pill and print-frame variants apply the offset print-shadow only on the active tab — never on every tab simultaneously.
- Never combine multiple variants on the same row.
