# Tooltips & Popovers

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `typography.md`

## Tooltips

### Core Specs
- Padding: 10px horizontal, 6px vertical
- Font: Space Mono, 12px, weight 500, letter-spacing 0.04em
- Radius: 4px
- Shadow: shadow-xs (2px 2px offset in secondary blue)
- Transition: opacity 200ms, transform 200ms (slight 4px translate on enter / leave)
- Max width: 240px, body text wraps

### Dark (Default)
- Background: dark (#2C3FA7, the secondary blue)
- Text: white
- Border: 1px solid border-dark

### Light
- Background: neutral-secondary (#FBF6EC)
- Text: heading color (#2C3FA7)
- Border: 1px solid border-default (#E4E0D9)

## Popovers

### Core Specs
- Background: neutral-secondary (#FBF6EC) — the card-cream tone, layered over the surface
- Radius: 4px
- Shadow: shadow-md (4px 4px offset in secondary blue)
- Border: 1px solid border-default (#E4E0D9)
- Transition: opacity 250ms, transform 200ms
- Max width: 320px

### Header / Title
- Padding: 12px horizontal, 10px vertical
- Background: neutral-secondary-strong (#F4ECDA)
- Bottom border: 1px border-default
- Font: Space Grotesk, 14px, weight 600, heading color (#2C3FA7)

### Body / Content
- Standard: 12px horizontal, 10px vertical padding; Space Grotesk 14px, body color (#637EC2), line-height 1.5
- Rich: 16px padding; Space Grotesk 14px, body color, line-height 1.55

### Footer (optional, for popover actions)
- Padding: 12px horizontal, 10px vertical
- Top border: 1px border-default
- Layout: flex, end-aligned, 8px gap between actions

## Arrows

- Size: 8x8px rotated 45deg
- Color must match the background of the tooltip / popover variant
- Border: matches the variant border (1px) on the two visible sides
- Positioned 6px from the anchor edge so the offset shadow sits cleanly behind it

## Rules

- Both tooltips and popovers use the system 4px radius.
- Both carry the hard offset shadow in secondary blue — never a soft drop-shadow.
- Dark tooltips use the secondary blue (`dark` token), not pure black — the secondary blue keeps the print-pairing consistent across the system.
- Arrows always match the parent background color.
- Tooltip copy is set in Space Mono uppercase for short metadata labels; multi-sentence descriptions belong in popovers, not tooltips.
