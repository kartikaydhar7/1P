# Typography

> Dependencies: `colors.md`

## Core Rules

- **Heading font:** "Space Grotesk", sans-serif — configured at app level via Google Fonts import. Weights used: 500, 600, 700.
- **Body font:** "Space Grotesk", sans-serif — same family as headings (single-typeface system). Weights used: 400, 500.
- **Label / caption font:** "Space Mono", monospace — reserved for small all-caps eyebrow labels, captions, metadata, and code-like UI chrome.
- **Headings:** weight 700, **heading** text color (deep federal blue #2C3FA7), tight tracking (-0.03em on display sizes, -0.01em on smaller headings)
- **Body copy:** weight 400, **body** text color (soft periwinkle #637EC2), line-height 1.55. Never use brand pink for paragraphs longer than one sentence.
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels.

## Heading Scale

### Desktop

| Element | Size | Weight | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|---|
| `h1` (display) | 68px | 700 | 1.05 | -0.03em | 24px |
| `h2` | 48px | 700 | 1.1 | -0.02em | — |
| `h3` | 36px | 700 | 1.15 | -0.01em | — |
| `h4` | 28px | 600 | 1.2 | -0.01em | — |
| `h5` | 22px | 600 | 1.3 | 0 | — |
| `h6` | 18px | 600 | 1.35 | 0 | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 48px | 36px |
| `h2` | 38px | 30px |
| `h3` | 30px | 24px |
| `h4` | 24px | 22px |
| `h5` | 20px | 18px |
| `h6` | 16px | 16px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.05 for any heading.

## Paragraphs

### Leading Paragraph
- Size: 20px
- Weight: 400
- Color: body
- Line-height: 1.55
- Max width: ~70 characters

### Normal Paragraph
- Size: 16px
- Weight: 400
- Color: body
- Line-height: 1.55
- Max width: ~65 characters

### Small Supporting Copy
- Size: 14px
- Weight: 400
- Color: body
- Line-height: 1.5
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Font | Size | Weight | Letter-spacing | Case |
|---|---|---|---|---|---|
| Button labels | Space Grotesk | 16px | 600 | 0 | as-typed |
| Input labels | Space Grotesk | 14px | 500 | 0 | as-typed |
| Eyebrow / kicker labels | Space Mono | 12px | 500 | 0.04em | UPPERCASE |
| Captions / meta | Space Mono | 12px | 500 | 0.04em | as-typed |
| Tags / badges | Space Mono | 11px or 12px | 500 | 0.04em | UPPERCASE |

Do not apply paragraph line-height (1.55) to control labels — UI labels use 1.2–1.35.

## Links

- **Inline links:** Same size as surrounding text, `heading` color (deep blue), 1px underline offset by 2px, hover → underline removed.
- **Primary CTA links:** `fg-brand` color (brand pink), weight 600, 1px underline, hover → underline removed.
- Reserve the brand-pink CTA link for **one** primary call-to-action per view; all other links stay in the heading-blue color.

## Emphasis

- `<strong>` for high-priority emphasis in body text — same color as surrounding body, weight 600.
- `<em>` for tone emphasis only, not visual hierarchy.
- All-caps eyebrow labels: Space Mono, 12px, weight 500, letter-spacing 0.04em — used as section kickers above headings.

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via the token system). Size, weight, and spacing remain constant.
