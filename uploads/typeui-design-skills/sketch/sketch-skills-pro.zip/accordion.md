# Accordion

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`

## Core Specs

- **Wrapper:** full width, 2px **dashed** border (border-default color), 24px radius — clips first/last item corners
- **Background:** neutral-primary-medium (warm cream paper)
- **Item separator:** 2px dashed bottom border (border-default) on every item except last

## Trigger (Button)

- **Layout:** flex, space-between, full width
- **Padding:** 24px horizontal, 18px vertical
- **Font:** "Elms Sans", 16px, medium weight
- **Text color:** heading
- **Background:** transparent (the wrapper provides the warm cream surface)
- **Hover:** neutral-tertiary background
- **Focus:** outline none, 4px brand-soft ring inset
- **Transition:** colors, 150ms
- **Open state:** neutral-tertiary background

## Panel (Content)

- **Padding:** 24px horizontal, 18px vertical
- **Background:** neutral-primary-soft
- **Top border:** 2px dashed, border-default color
- **Font:** "Elms Sans", 16px, body color, 1.7 line-height

## Chevron Icon

- Size: 18x18px
- Color: body text color
- Style: hand-drawn / sketched stroke when possible
- Closed: 0deg rotation
- Open: 180deg rotation
- Transition: transform, 150ms

## Variants

### Default (Collapse)
One panel open at a time. Items stacked inside a single shared dashed wrapper with 24px radius.

### Separated Cards
Each item is independent — has its own 2px dashed border, 24px radius, and shadow-md (pencil shadow). 12px bottom margin between items. No shared outer border.

### Always Open
Multiple panels can expand simultaneously. Same styling as Default.

### Flush
No outer border. Trigger and panel have transparent backgrounds. Only 2px dashed bottom border dividers between items. Use inside containers that already provide a background.

## States

| State | Trigger appearance |
|---|---|
| Closed | heading text, transparent background |
| Open | heading text, neutral-tertiary background |
| Hover | neutral-tertiary background |
| Focus | 4px brand-soft inset ring, no outline |
| Disabled | fg-disabled text, not-allowed cursor, no hover/focus |
