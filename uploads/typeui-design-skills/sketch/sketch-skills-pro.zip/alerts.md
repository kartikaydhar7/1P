# Alerts

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`

## Core Specs

- **Padding:** 20px
- **Radius:** 24px (base)
- **Border:** 2px **dashed**
- **Shadow:** shadow-sm (pencil offset)
- **Heading:** "Elms Sans", 16px, medium weight
- **Body:** "Elms Sans", 14px, normal weight, 1.65 line-height

## Variants

### Brand
- **Background:** brand-softer
- **Border:** 2px dashed border-brand-subtle
- **Text:** fg-brand-strong

### Success
- **Background:** success-soft
- **Border:** 2px dashed border-success-subtle
- **Text:** fg-success-strong

### Danger
- **Background:** danger-soft
- **Border:** 2px dashed border-danger-subtle
- **Text:** fg-danger-strong

### Warning
- **Background:** warning-soft
- **Border:** 2px dashed border-warning-subtle
- **Text:** fg-warning
