# Avatars

> Dependencies: `colors.md`, `radius.md`, `borders.md`

## Core Specs

- **Circular shape:** fully rounded (999px)
- **Rounded square shape:** 24px radius
- **Border:** 2px solid border-dark on every avatar so it reads as a hand-drawn outlined portrait
- **Default size:** 40x40px
- **Image fit:** cover

## Sizes

| Size | Dimensions | Radius |
|---|---|---|
| Extra Small | 20x20px | 999px |
| Small | 28x28px | 999px |
| Base | 36x36px | 999px |
| Large | 48x48px | 24px (square variant) or 999px |
| XL | 60x60px | 24px (square variant) or 999px |
| 2XL | 72x72px | 24px (square variant) or 999px |

## Bordered Avatar

- 4px padding, fully rounded, 2px solid outline in border-dark color
- Alternative: 2px box-shadow ring in border-dark color paired with shadow-xs (pencil offset) for a sketched feel

## Stacked Avatars

- Displayed in a row (flex)
- Each avatar: 40x40px, fully rounded, 2px solid border in border-buffer color (so the cream paper shows through between portraits)
- Overlap: -16px negative margin on all except first

### Stacked Counter
- Same size as avatars (40x40px), fully rounded
- Background: dark, text: white, 12px font, "Elms Sans" medium weight
- 2px solid border in border-buffer color
- Same overlap margin as other avatars

## Avatar with Text

- Flex row, 12px gap between avatar and text
- Avatar: 40x40px, fully rounded, cover fit
- Name: "Elms Sans", heading color, medium weight
- Subtitle: "Elms Sans", 14px, body color
