# Badges

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs

- **Border:** 2px solid
- **Default radius:** 999px (full pill — every badge is a pill in this system)
- **Pill radius:** 999px (alias of default)
- **Shadow:** shadow-xs (subtle pencil offset) — optional, omit on dense inline contexts like table cells
- **Font:** "Elms Sans", medium weight

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Default (small) | 12px | 10px | 3px |
| Large | 14px | 14px | 5px |

## Variants

### Brand
- **Background:** brand-softer
- **Border:** 2px solid border-brand-subtle
- **Text:** fg-brand-strong

### Alternative (Neutral Soft)
- **Background:** neutral-primary-soft
- **Border:** 2px solid border-default
- **Text:** heading

### Gray (Neutral Medium)
- **Background:** neutral-secondary-medium
- **Border:** 2px solid border-default
- **Text:** heading

### Danger
- **Background:** danger-soft
- **Border:** 2px solid border-danger-subtle
- **Text:** fg-danger-strong

### Success
- **Background:** success-soft
- **Border:** 2px solid border-success-subtle
- **Text:** fg-success-strong

### Warning
- **Background:** warning-soft
- **Border:** 2px solid border-warning-subtle
- **Text:** fg-warning

### Dark
- **Background:** dark
- **Border:** 2px solid border-dark
- **Text:** white

## Pill Badges

The default badge is already a pill (999px radius). There is no non-pill badge variant in this system.

## Badges with Icons

- Icon size (default): 12x12px
- Icon size (large): 14x14px
- Icon spacing: 6px margin next to label

## Icon-only Badge

Square shape — equalize dimensions to 28x28px, no horizontal text padding, keep the 999px radius so it reads as a circular tag.

## Dismissible Badges

Badge content + a close button. Close button hover backgrounds per variant:

| Variant | Close button hover background |
|---|---|
| Brand | brand-soft |
| Alternative | neutral-tertiary |
| Gray | neutral-quaternary |
| Danger | danger-medium |
| Success | success-medium |
| Warning | warning-medium |

## Dot / Notification Badge

- Positioned absolutely: -4px top, -4px right
- Size: 12x12px, fully rounded (999px)
- 2px border in border-buffer color
- Background: danger
