# Borders

## Width Scale

| Context | Width |
|---|---|
| Default (inputs, buttons, badges, small controls) | 2px |
| Cards, modals, popovers, big surfaces | 2px (dashed) |
| Emphasis / focus | 2px |

## Style

| Context | Style |
|---|---|
| Cards, modals, alerts, popovers, big decorative surfaces | dashed |
| Inputs, buttons, badges, table cells, dividers | solid |

## Rules

- Every visible border is at least 2px so it reads as a confident hand-drawn line
- Cards and other "paper" surfaces use **2px dashed** borders to evoke a sketched outline
- Inputs, buttons, badges and grouped controls use **2px solid** borders so the pill silhouette stays crisp
- Components in the same family must use matching border widths and styles
- Never mix 1px and 2px borders within a single component
- Never mix dashed and solid borders within the same component

## Usage

| Context | Width | Style |
|---|---|---|
| Inputs / selects / textareas | 2px default; 2px on focus or error | solid |
| Buttons | 2px solid for outlined / secondary variants | solid |
| Cards / containers | 2px dashed in border-default color | dashed |
| Modals / popovers | 2px dashed | dashed |
| Alerts | 2px dashed | dashed |
| Tables | 2px solid wrapper, 2px solid row dividers | solid |
| Dropdown menus | 2px dashed wrapper | dashed |
