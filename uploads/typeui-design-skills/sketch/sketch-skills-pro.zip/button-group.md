# Button Groups

> Dependencies: `buttons.md`, `colors.md`, `radius.md`, `shadows.md`

## Core Specs

- **Wrapper:** inline-flex with 8px gap between children, no shared background
- **Children spacing:** 8px gap (no -1px overlap — every button stays as its own pill)
- **Each button keeps its own pill silhouette and pencil shadow** from `buttons.md`. The wrapper does not collapse them into a single bar.

## Anatomy

### Wrapper
- Display: inline-flex
- Gap: 8px between children
- Radius: not applicable (no shared bounding shape)
- Shadow: not applicable (each button carries its own pencil shadow)

### Every Button in the Group
- Radius: 999px (full pill) — no special start/end radius treatment
- Border: 2px solid per the variant in `buttons.md`
- Shadow: shadow-sm (pencil offset) per `buttons.md`
- Hover / active behavior follows `buttons.md` translate + shrink-shadow pattern

### Vertical Group
- Same rules, but `flex-direction: column` and 8px vertical gap

## Rules

- Buttons inside groups follow ALL styles from `buttons.md` (background, border, focus rings, pill radius, pencil shadow) without exception
- Never merge buttons into a single connected bar — the hand-drawn aesthetic favors a row of independent pill capsules
- Icon-only buttons: 16x16px icon, match height of text buttons, keep the 999px radius (circular)
