# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except ghost and disabled)

Every button — regardless of stack (HTML/CSS, React, Vue, Svelte, Angular, Tailwind, Sass, plain CSS, etc.) — must compose to the following base style. Use design tokens or framework utilities; the visual result must match the rules below.

### Property Reference

| Property | Value |
|---|---|
| `outline` | `none` |
| `color` | brand color |
| `padding` | `16px` (top/bottom) |
| `padding-left` | `32px` |
| `padding-right` | `32px` |
| `border` | `2px dashed #2B2418` |
| `border-radius` | `999px` (full pill) |
| `background-color` | brand color |
| `box-shadow` | `0 0 0 4px <brand-color>, 2px 2px 4px 2px rgba(0, 0, 0, 0.5)` |
| `transition` | `.1s ease-in-out, .4s color` |

### Rules (apply in any stack)

- **Outline:** never visible — always `outline: none`. Use the `box-shadow` ring for focus/state, never the native outline.
- **Color (text):** use the brand color token (`var(--color-brand)` / `theme.colors.brand` / `$brand` — whatever the stack exposes). Never hard-code a hex for text.
- **Padding:** vertical `16px`, horizontal `32px`. Do not shrink horizontal padding — pill buttons read as confident, hand-drawn capsules only when generously padded.
- **Border:** always **2px dashed** with the warm graphite ink color `#2B2418` (matches `--pencil-ink` from `colors.md`). The dashed stroke is what makes the button look hand-drawn — never use solid borders for this button.
- **Border radius:** always `999px` so the pill silhouette is fully rounded regardless of width/height.
- **Background:** brand color token. Never raw hex.
- **Box-shadow:** dual-layer:
  1. `0 0 0 4px <brand-color>` — a 4px solid ring in the brand color flush against the border (acts as a soft halo / focus ring baked in).
  2. `2px 2px 4px 2px rgba(0, 0, 0, 0.5)` — a graphite drop shadow offset to the bottom-right, consistent with the pencil aesthetic in `shadows.md`.
- **Transition:** `0.1s ease-in-out` for transforms / shadows, `0.4s` for color changes. Keep it snappy on press, smoother on color shifts.
- **Box sizing:** always `border-box` so the dashed border + glow ring don't push the layout.
- **Font:** `"Elms Sans"`, weight `500`.

### Hover / Active

- **Hover:** translate `-1px / -1px` and slightly shrink the drop-shadow offset (`2px 2px 4px 2px` → `1px 1px 4px 2px`) so the button feels pressed into the paper.
- **Active / pressed:** translate `+2px / +2px` and collapse the drop-shadow to `0 0 0 4px <brand-color>` only — the button visually meets its own shadow.
- **Focus-visible:** the `0 0 0 4px <brand-color>` ring is already part of the base shadow; do not add a second ring on focus.

### Stack-agnostic notes

- **Tailwind:** prefer arbitrary values matching the spec — `rounded-full border-2 border-dashed border-[#2B2418] py-4 px-8 outline-none transition-[0.1s_ease-in-out,0.4s_color]` and apply the brand color via `bg-brand text-brand` plus a custom shadow utility.
- **CSS-in-JS / styled-components / Emotion:** export the base style block above as a named style and compose variants on top.
- **Vue / Svelte / Angular:** apply the rules via component-scoped styles or a global `.button` class — the rules are CSS-only and have no framework dependency.
- **Plain HTML/CSS:** drop the base CSS block into a stylesheet and add `class="button"` to any `<button>` or `<a>` tag.

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 16px | 6px |
| Small | 14px | 18px | 8px |
| Base (default) | 16px | 32px | 16px |
| Large | 16px | 36px | 18px |
| Extra large | 18px | 40px | 20px |

The base size matches the canonical CSS rule above (`padding: 16px 32px`). Other sizes scale around it but keep the dashed border, full radius, and dual-layer shadow intact.

## Variants

Each variant swaps `color`, `background-color`, and the first ring of the box-shadow to its own token. Border stays `2px dashed #2B2418`, radius stays `999px`, transition stays the same.

### Brand
- **Background:** brand token
- **Text:** white (use white text on brand fill — overrides the default brand-on-brand pattern when the button needs maximum contrast)
- **Hover:** brand-strong background
- **Focus ring:** baked into the 4px brand-medium ring
- **Pencil glint:** yes
- **Pencil shadow:** yes

### Secondary
- **Background:** neutral-primary-medium (warm cream paper)
- **Text:** heading color
- **Border:** 2px dashed #2B2418
- **Hover:** neutral-tertiary-medium background
- **Focus ring:** 4px, brand-soft color
- **Pencil glint:** yes
- **Pencil shadow:** yes

### Tertiary
- **Background:** neutral-primary-soft
- **Border:** 2px dashed #2B2418
- **Text:** body color
- **Hover:** neutral-secondary-medium background, heading text color
- **Focus ring:** 4px, neutral-tertiary-soft color
- **Pencil glint:** yes
- **Pencil shadow:** yes

### Success
- **Background:** success token
- **Text:** white
- **Hover:** success-strong background
- **Focus ring:** 4px, success-medium color
- **Pencil glint:** yes
- **Pencil shadow:** yes

### Danger
- **Background:** danger token
- **Text:** white
- **Hover:** danger-strong background
- **Focus ring:** 4px, danger-medium color
- **Pencil glint:** yes
- **Pencil shadow:** yes

### Warning
- **Background:** warning token
- **Text:** dark
- **Hover:** warning-strong background
- **Focus ring:** 4px, warning-medium color
- **Pencil glint:** yes
- **Pencil shadow:** yes

### Dark
- **Background:** dark token
- **Text:** white
- **Hover:** dark-strong background
- **Focus ring:** 4px, neutral-tertiary color
- **Pencil glint:** yes
- **Pencil shadow:** yes

### Ghost (NO shadow, NO glint)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color
- **Hover:** neutral-secondary-medium background
- **Focus ring:** 4px, brand-soft color (added on focus only since base ring is removed)
- **No shadow, no pencil glint, no translate on hover**

### Disabled (NO shadow, NO glint)
- **Background:** disabled token
- **Border:** 2px dashed border-default
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no pencil glint, no translate**

## Icons in Buttons

- Icon size: 16x16px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
- Icon stroke should look hand-drawn whenever possible (consistent with the pencil aesthetic). Avoid heavily filled, photo-real icons.

## Prohibited

- No solid borders on this button — the dashed stroke is the visual signature.
- No raw hex values in component code apart from the dashed border ink (`#2B2418`), which is intentionally pinned to keep the hand-drawn outline identical across themes. Everywhere else, use design tokens.
- No native `outline` on focus — always rely on the box-shadow ring.
- No removing the dual-layer `box-shadow` — both the brand ring and the graphite drop are required for the depth effect.
