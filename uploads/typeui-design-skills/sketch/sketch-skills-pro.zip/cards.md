# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`, `borders.md`, `buttons.md`

## Core Specs

Every card — regardless of stack (HTML/CSS, React, Vue, Svelte, Angular, Tailwind, Sass, plain CSS, etc.) — must compose to the following base style. Use design tokens or framework utilities; the visual result must match the rules below.

### Base CSS (stack-agnostic, copy-paste ready)

```css
.card {
  outline: none;
  color: var(--color-body);
  padding: 24px;
  border: 2px dashed #2B2418;
  border-radius: 24px;
  background-color: var(--color-neutral-primary-medium);
  box-shadow:
    0 0 0 4px var(--color-neutral-primary-medium),
    2px 2px 4px 2px rgba(0, 0, 0, 0.5);
  transition: 0.15s ease-in-out, 0.4s color;
}
```

### Property Reference

| Property | Value |
|---|---|
| `outline` | `none` |
| `color` | body color |
| `padding` | `24px` (use `32px` on large feature cards) |
| `border` | `2px dashed #2B2418` |
| `border-radius` | `24px` |
| `background-color` | neutral-primary-medium |
| `box-shadow` | `0 0 0 4px <same-as-background>, 2px 2px 4px 2px rgba(0, 0, 0, 0.5)` |
| `transition` | `.15s ease-in-out, .4s color` |

### Shadow Rules

Cards use a **dual-layer shadow** structurally identical to buttons (per `buttons.md`), but the inner ring color is **always the same as the card's background-color**, not the brand color. This way the ring reads as a soft "thickening" of the card itself — extending the paper outward — instead of competing with the graphite drop shadow.

1. `0 0 0 4px var(<same-token-as-background-color>)` — a 4px solid ring in **the exact same color as the card background**. The ring blends with the card and visually grows the dashed paper outward by 4px before the drop shadow takes over.
2. `2px 2px 4px 2px rgba(0, 0, 0, 0.5)` — a graphite drop shadow offset to the bottom-right, consistent with the pencil aesthetic in `shadows.md`.

This replaces the previous `shadow-md` token for cards. The shadow now visually unifies cards and buttons (same dual-layer structure) while keeping cards subtle — the ring is invisible against the background but still creates a clean buffer between the dashed border and the drop shadow.

### Background ↔ Ring Pairing (mandatory)

The ring color **must always match the background color** of the card. Pick the pair that fits the section:

- **Default cards (background: `neutral-primary-medium`):** `0 0 0 4px var(--color-neutral-primary-medium)`
- **Quiet cards (background: `neutral-primary-soft`):** `0 0 0 4px var(--color-neutral-primary-soft)`
- **Brand-soft cards (background: `brand-softer`):** `0 0 0 4px var(--color-brand-softer)`

Never use a ring color that differs from the card background. The graphite drop layer (`2px 2px 4px 2px rgba(0, 0, 0, 0.5)`) is constant in every variant.

## Card Heading

- Desktop: 26px, "Delicious Handrawn", regular weight, heading color
- Mobile: 22px, "Delicious Handrawn", regular weight, heading color
- Body inside the card uses "Elms Sans" per `typography.md`
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-primary-medium
- Border: 2px dashed `#2B2418`
- Radius: 24px
- Shadow: `0 0 0 4px var(--color-neutral-primary-medium), 2px 2px 4px 2px rgba(0, 0, 0, 0.5)` (ring matches background)
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- **Hover:** translate `-2px / -2px` and shrink the graphite drop offset to `1px 1px 4px 2px rgba(0, 0, 0, 0.5)` so the card feels lifted off the page. Background may also deepen to neutral-tertiary — if it does, swap the ring color to match the new background so the ring stays invisible.
- **Active / pressed:** translate `+2px / +2px` and collapse the graphite drop to 0; only the background-matching ring remains, so the card visually meets its own shadow.
- Transition: `transform 150ms, box-shadow 150ms, background-color 150ms`
- Cursor: pointer
- Focus-visible: add a 4px `brand-soft` outline offset by 2px (do not use the inner ring for focus, since it matches the background and is invisible).

## Stack-agnostic notes

- **Tailwind:** apply `border-2 border-dashed border-[#2B2418] rounded-[24px] p-6 bg-neutral-primary-medium` plus a custom shadow utility `shadow-[0_0_0_4px_var(--color-neutral-primary-medium),_2px_2px_4px_2px_rgba(0,0,0,0.5)]`. The ring token must always equal the bg token.
- **CSS-in-JS / styled-components / Emotion:** export the base style block above as a named style and compose interactive variants on top.
- **Vue / Svelte / Angular:** apply the rules via component-scoped styles or a global `.card` class — the rules are CSS-only and have no framework dependency.
- **Plain HTML/CSS:** drop the base CSS block into a stylesheet and add `class="card"` to any container.

## Rules

- Background: neutral-primary-medium (warm cream, deeper than the page background)
- Border: 2px **dashed** `#2B2418` — never solid for a standard card
- Radius: 24px
- Shadow: dual-layer — first ring **always matches the card background**, second layer is the graphite drop. Never a soft blurred shadow.
- Interactive hover: translate + reduced graphite drop offset, never just a background swap
- Non-interactive: no hover styles
- Cards must never appear flat — the dashed border + dual-layer shadow combination is what gives them their illustrated identity

## Prohibited

- No solid borders on the card outline — the dashed stroke is the visual signature.
- No raw hex values apart from the dashed border ink (`#2B2418`), which is intentionally pinned to keep the hand-drawn outline identical across themes.
- No mismatched ring + background — the inner ring **must** be the same color token as the background. Brand-colored or accent-colored rings are reserved for buttons, not cards.
- No removing the dual-layer `box-shadow` — both the matching ring and the graphite drop are required.
- No mixing soft/blurred drop-shadows with this style; the entire card system must stay visually unified with the buttons.
