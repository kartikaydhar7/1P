# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFAF5 | #1A1611 |
| neutral-primary | #FFFAF5 | #14110C |
| neutral-primary-medium | #F4EDDF | #221D15 |
| neutral-primary-strong | #ECE3D0 | #2D261B |
| neutral-secondary-soft | #FFFAF5 | #1A1611 |
| neutral-secondary | #F4EDDF | #14110C |
| neutral-secondary-medium | #F4EDDF | #221D15 |
| neutral-secondary-strong | #ECE3D0 | #2D261B |
| neutral-tertiary-soft | #F4EDDF | #1A1611 |
| neutral-tertiary | #ECE3D0 | #221D15 |
| neutral-tertiary-medium | #E5D7BF | #2D261B |
| neutral-quaternary | #D9C9AE | #3A2F22 |
| quaternary-medium | #C9B795 | #4A3D2C |
| gray | #B0997B | #5A4B36 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #E8F9F4 | #0E574E |
| brand-soft | #B9EFE2 | #168478 |
| brand | #1DAD97 | #3EC3AD |
| brand-medium | #82DEC8 | #168478 |
| brand-strong | #168478 | #1DAD97 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #ECFDF5 | #002C22 |
| success | #1DAD97 | #3EC3AD |
| success-medium | #B9EFE2 | #0E574E |
| success-strong | #168478 | #1DAD97 |
| danger-soft | #FDECEC | #4D1A1A |
| danger | #C0392B | #E74C3C |
| danger-medium | #F5CFCB | #7A2C24 |
| danger-strong | #8B2A20 | #E74C3C |
| warning-soft | #FDF3E1 | #6B4A12 |
| warning | #E69A1A | #F5B341 |
| warning-medium | #F8E1B7 | #8A5F18 |
| warning-strong | #B57612 | #E69A1A |

### Button Glint (CSS custom properties, used for the soft inset highlight on filled controls)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,250,245,0.30) | rgba(255,250,245,0.10) |
| `--color-1-700` | rgba(31,27,18,0.18) | rgba(0,0,0,0.30) |

### Pencil Shadow (CSS custom properties, used for the hand-drawn offset shadow)
| Variable | Light | Dark |
|---|---|---|
| `--pencil-ink` | #2B2418 | #0A0805 |
| `--pencil-ink-soft` | rgba(43,36,24,0.55) | rgba(0,0,0,0.55) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #2B2418 | #2B2418 |
| dark-strong | #1F1B12 | #3A2F22 |
| disabled | #ECE3D0 | #2D261B |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #8E7CC3 |
| sky | #6FB8D1 |
| teal | #1DAD97 |
| pink | #D87BA1 |
| cyan | #5BB4B0 |
| fuchsia | #B569A8 |
| indigo | #5E6FB4 |
| orange | #E29F5C |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFAF5 | #FFFAF5 |
| black | #1F1B12 | #1F1B12 |
| heading | #1F1B12 | #FFFAF5 |
| body | #4A3F2E | #C9B795 |
| body-subtle | #6F6151 | #A89878 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #B9EFE2 | #168478 |
| fg-brand | #168478 | #3EC3AD |
| fg-brand-strong | #0E574E | #B9EFE2 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #168478 | #1DAD97 |
| fg-success-strong | #0E574E | #3EC3AD |
| fg-danger | #8B2A20 | #E74C3C |
| fg-danger-strong | #6B1F18 | #F08070 |
| fg-warning-subtle | #B57612 | #F5B341 |
| fg-warning | #6B4A12 | #FACC7A |
| fg-disabled | #A89878 | #6F6151 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #C99216 | #F5C846 |
| fg-info | #3D4980 | #9CB1E0 |
| fg-purple | #6E5CA3 | #B5A3D9 |
| fg-purple-strong | #574786 | #D6CAEB |
| fg-cyan | #3D8E8A | #7FCDC8 |
| fg-indigo | #4458A0 | #8095CD |
| fg-pink | #B85C82 | #E8A7C0 |
| fg-lime | #6B8E23 | #B5CC6B |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #2B2418 | #C9B795 |
| border-buffer | #FFFAF5 | #14110C |
| border-buffer-medium | #FFFAF5 | #221D15 |
| border-buffer-strong | #FFFAF5 | #2D261B |
| border-muted | #F4EDDF | #1A1611 |
| border-light-subtle | #ECE3D0 | #1A1611 |
| border-light | #ECE3D0 | #221D15 |
| border-light-medium | #E5D7BF | #2D261B |
| border-default-subtle | #D9C9AE | #2D261B |
| border-default | #C9B795 | #3A2F22 |
| border-default-medium | #B0997B | #4A3D2C |
| border-default-strong | #8E7A5F | #5A4B36 |
| border-success-subtle | #B9EFE2 | #0E574E |
| border-success | #168478 | #1DAD97 |
| border-danger-subtle | #F5CFCB | #7A2C24 |
| border-danger | #8B2A20 | #C0392B |
| border-warning-subtle | #F8E1B7 | #6B4A12 |
| border-warning | #B57612 | #E69A1A |
| border-brand-subtle | #B9EFE2 | #168478 |
| border-brand-light | #3EC3AD | #82DEC8 |
| border-brand | #1DAD97 | #3EC3AD |
| border-dark-subtle | #2B2418 | #3A2F22 |
| border-purple | #8E7CC3 | #B5A3D9 |
| border-orange | #E29F5C | #E29F5C |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default cream paper), alternate sections may use neutral-secondary for slightly deeper warmth
- Cards, popovers and any element layered over the page: neutral-primary-medium (#F4EDDF) so they read as a separate "paper card" sitting on the main paper background
- Primary buttons: brand background
- Headings: heading text color (warm graphite)
- Body text: body text color (warm pencil tone)
- CTA links: fg-brand text color
- Default borders: border-default (warm taupe), drawn dashed on cards and decorative containers
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No pure white (#FFFFFF) or pure black (#000000) — always favor the warm cream / warm graphite tokens
- No cool grays for surfaces or text — the entire palette must stay on the warm cream/teal axis
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
