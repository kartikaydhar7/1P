# Dropdown

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `inputs.md`

## Core Specs

### Chevron Icon
- Size: 16x16px
- Spacing: 8px left margin, -2px right margin
- Color: inherits from trigger button
- Style: hand-drawn / sketched stroke when possible

### Menu Container
- Background: neutral-primary-medium (warm cream paper)
- Border: 2px **dashed**, border-default
- Radius: 24px (base)
- Shadow: shadow-md (pencil offset)
- Z-index: elevated above content

### Menu List
- Padding: 12px
- Font: "Elms Sans", 14px, body color, medium weight

### Menu Item
- Layout: inline-flex, vertically centered, full width
- Padding: 12px horizontal, 10px vertical
- Radius: 999px (pill — items match the brand's rounded silhouette)
- Hover: neutral-tertiary background, heading text
- Transition: colors, 150ms

## Trigger Sizes

Triggers reuse the button sizing from `buttons.md` (always pill 999px). The sizes below are convenience aliases.

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Small | 14px | 18px | 8px |
| Base | 14px | 22px | 10px |
| Large | 16px | 26px | 12px |

## Icon-only Trigger

- Padding: 10px
- Min size: 44x44px
- Radius: 999px (full circle)
- Icon: 20x20px

## Variants

### Default
- Menu width: 200px, items have 999px radius

### With Divider
- 2px dashed top border (border-default) between child groups, skip first group

### With Header
- Header padding: 18px horizontal, 14px vertical
- 2px dashed bottom border: border-default
- Name: "Delicious Handrawn", 18px, heading color
- Email: "Elms Sans", body-subtle color, 14px, truncated

### With Icons
- Icon before label: 16x16px, 10px right margin, body color
- On hover, icon color changes to heading

### With Checkbox / Radio
- Inputs: 18x18px, 6px radius (checkbox) or 999px (radio), focus ring in brand-soft
- Helper text: 12px, body-subtle color, 4px top margin

### With Search
- Search input at top of menu following `inputs.md` specs (pill, 999px radius)
- Left icon: 18px left padding, input 44px left padding

### Scrollable
- Max height: 240px, vertical scroll overflow

## States

| State | Appearance |
|---|---|
| Focused trigger | no outline, 4px brand-soft ring |
| Hover item | neutral-tertiary background, heading text |
| Active/open item | brand-softer background, fg-brand-strong text |
| Disabled item | fg-disabled text, not-allowed cursor, no pointer events |
