# Icon Shapes

> Dependencies: `colors.md`, `radius.md`, `borders.md`

## Core Specs

- Box sizing: border-box
- Icon must be perfectly centered (inline-flex, centered both axes)
- Border: 2px solid border-dark on every shape so it reads as a hand-drawn outlined badge (omit only on transparent / ghost variants)
- Circle: fully rounded (999px)
- Rounded square: 24px radius (MD/LG/XL), 16px radius (XS/SM)
- Icons themselves should use a hand-drawn / sketched stroke style whenever possible to stay on-brand

## Sizes

| Size | Container | Icon |
|---|---|---|
| XS | 28x28px | 14x14px |
| SM | 36x36px | 18x18px |
| MD | 44x44px | 22x22px |
| LG | 52x52px | 26x26px |
| XL | 60x60px | 30x30px |

## Color Variants

### Brand
- Shape: circle
- Background: brand-softer
- Icon color: fg-brand-strong

### Gray
- Shape: circle
- Background: neutral-secondary-medium
- Icon color: body

### Danger
- Shape: circle
- Background: danger-soft
- Icon color: fg-danger-strong

### Success
- Shape: circle
- Background: success-soft
- Icon color: fg-success-strong

### Warning
- Shape: circle
- Background: warning-soft
- Icon color: fg-warning
