# Inputs

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs

- **Display:** block, full width
- **Radius:** 999px (full pill)
- **Border:** 2px solid, border-default-medium (warm taupe)
- **Background:** neutral-primary-soft (warm cream paper)
- **Shadow:** shadow-xs — pencil-drawn offset shadow from `shadows.md`
- **Font:** "Elms Sans", 16px, heading color
- **Padding:** 20px horizontal, 12px vertical (extra horizontal padding so text breathes inside the pill)
- **Placeholder:** body-subtle color
- **Transition:** border-color 150ms, box-shadow 150ms, background-color 150ms

Multi-line inputs (textarea) keep the same styling but use a 24px radius instead of a full pill so they remain readable on multiple lines.

## Label

- Display: block
- Font: "Elms Sans", 14px, medium weight, heading color
- Margin bottom: 8px
- Margin left: 16px (so the label visually aligns with the pill content area, not the rounded edge)
- Label `htmlFor` must match the input `id`

## States

### Default
- Border: 2px solid border-default-medium
- Background: neutral-primary-soft
- Shadow: shadow-xs

### Hover
- Border: 2px solid border-default-strong

### Focus
- No outline
- Border: 2px solid border-brand
- Ring: 4px, brand-soft

### Success
- Border: 2px solid border-success
- Focus ring: 4px, success-medium

### Error / Danger
- Border: 2px solid border-danger
- Focus ring: 4px, danger-medium

### Disabled
- Background: disabled
- Text: fg-disabled
- Border: 2px solid border-default
- Shadow: none
- Cursor: not-allowed

## Input with Icons

- Icon size: 16x16px (use hand-drawn-style icons to match the aesthetic)
- Icon color: body
- Container: relative positioned wrapper
- Start icon: absolutely positioned left, 18px left padding — input gets 44px left padding
- End icon: absolutely positioned right, 18px right padding — input gets 44px right padding
- Icons vertically centered within the wrapper

## Rules

- Every input must have a unique `id`
- Every label must have a matching `htmlFor`
- Padding: 20px horizontal, 12px vertical unless overridden for icon variants
- Always use the pill (999px) radius for single-line inputs; only textareas drop down to 24px
- No arbitrary hex or hardcoded colors
- The pencil shadow must always be present on enabled inputs — it is part of the visual identity
