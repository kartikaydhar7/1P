# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 24px (hand-drawn headings need slightly more breathing room) |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 32px |
| Wide component grid gap | 40px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1200px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`) — set in "Delicious Handrawn" per `typography.md`
2. Leading paragraph — "Elms Sans"
3. Normal paragraph(s) — "Elms Sans"
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 96px vertical padding
- A background color from the warm cream palette in `colors.md`. The page baseline is **neutral-primary-soft (#FFFAF5)**. Alternating sections may use **neutral-secondary** for a slightly deeper warmth, but the base canvas is always cream — never cool gray or pure white.
- A centered container (max-width 1200px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below
- Optional decorative pencil-drawn illustrations (small spot doodles, dashed dividers, hand-drawn arrows) to reinforce the sketch identity — these must support, never compete with, the content.

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.
- Hover micro-motion across the system follows the same "press into the paper" idiom: translate -1px / -1px and shrink the pencil-shadow offset by 1px on hover; reverse on press.

## Backgrounds & Visual Depth

- The entire app sits on the warm cream **neutral-primary-soft (#FFFAF5)** canvas. Layered elements (cards, popovers, modals, dropdown menus, sidebars CTAs) sit on **neutral-primary-medium (#F4EDDF)** so the cream-on-cream contrast creates depth without leaving the warm palette.
- Apply contextual treatments — pencil-drawn doodles, dashed underlines, hand-drawn arrows, sketched dividers, soft paper-grain overlays — that align with the hand-drawn brand aesthetic.
- Avoid glossy gradients, neon glows, glassmorphism blurs, or photographic textures — they fight the pencil illustration language.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.

## Must

- All sections: consistent 96px vertical padding
- All containers: max-width 1200px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
- Page background is always the warm cream neutral-primary-soft — never pure white, never cool gray
