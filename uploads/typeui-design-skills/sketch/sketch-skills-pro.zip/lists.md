# Lists

> Dependencies: `colors.md`, `typography.md`

## Core Specs

- Item spacing: 16px vertical gap between list items
- Font: "Elms Sans"
- Text: body color

## List Icons

- Size: 20x20px (hand-drawn / sketched stroke style preferred — checkmarks, arrows, dots that look pencil-drawn)
- Prevent squishing: no shrink
- Spacing: 10px right margin between icon and text
- Active/featured icon: fg-brand color
- Neutral icon: body color

## Inactive / Disabled Items

Strikethrough text with body-subtle color decoration on the list item. The strikethrough itself should feel like a hand-drawn pencil cross-out where possible.

## Pattern

Vertical flex list with 16px gap. Each item is a flex row with centered alignment — hand-drawn icon (20x20, no-shrink, 10px right margin) followed by a span of body-colored text in "Elms Sans".
