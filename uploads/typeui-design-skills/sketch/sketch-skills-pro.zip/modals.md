# Modals

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `buttons.md`, `inputs.md`

## Core Specs

### Overlay (Backdrop)
- Fixed, covers full screen
- Z-index: 40
- Background: dark token at 50% opacity (warm graphite veil, never pure black)
- Backdrop blur: small amount

### Content Container
- Background: neutral-primary-medium (warm cream paper card sitting on the page)
- Border: 2px **dashed**, border-default
- Radius: 24px (base)
- Shadow: shadow-xl (pencil offset)
- Padding: 24px

## Anatomy

### Header
- 2px dashed bottom border: border-default
- Top corners rounded (24px)
- Title: "Delicious Handrawn", 28px, regular weight, heading color
- Close button: Ghost variant from `buttons.md` (still pill, 999px), 8px padding

### Body
- Vertical padding: 24px
- Vertical spacing between elements: 24px
- Text: "Elms Sans", 16px, 1.7 line-height, body color

### Footer
- 2px dashed top border: border-default
- Bottom corners rounded (24px)
- Action buttons stay pill-shaped per `buttons.md`

## Variants

### Default (Information)
Standard header + body + footer with primary/secondary action buttons.

### Pop-up (Confirmation)
Centered text, prominent icon, reduced padding:
- Body: 24px padding, text centered
- Icon: centered, 16px bottom margin, 56x56px, brand color or status color depending on intent (uses an Icon Shape from `icon-shapes.md`)

### Form Modal
Body contains inputs following `inputs.md` (pill, 999px). Vertical spacing between form elements: 20px.

## Rules

- Backdrop covers full screen with fixed positioning
- Content: neutral-primary-medium background, 24px radius, 2px dashed border, shadow-xl
- Header/Footer separated by 2px dashed border-default borders
- Close button must be present and functional, follows pill button rules from `buttons.md`
- Accessibility: `role="dialog"`, implement focus trap in code
- Dark mode automatic via token system
