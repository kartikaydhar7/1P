# Pagination

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`

## Container

Font: "Elms Sans", 14px. Items displayed as flex with 8px gap (no overlap — every item is its own pill).

## Pagination Item

- Layout: flex, centered both axes
- Size: 40x40px
- Text: body color, medium weight
- Background: neutral-primary-medium (warm cream)
- Border: 2px solid, border-default
- Radius: 999px (full pill / circle)
- Shadow: shadow-xs (pencil offset)
- Hover: neutral-tertiary background, heading text, translate -1px / -1px
- Focus: no outline, 4px brand-soft ring
- Active (pressed): translate +1px / +1px, shadow collapses

## Previous / Next Buttons

- Horizontal padding: 18px, height: 40px
- Radius: 999px (full pill — same as numbered items, no special start/end radius)
- May include a hand-drawn arrow icon (16x16px) with 8px gap from label

## Active Page Item

- Text: white
- Background: brand
- Border: 2px solid border-dark
- Hover background: brand-strong (text stays white)

## Rules

- Display as flex with 8px gap between items — no -1px overlap, every pill is independent
- Items: pill-shaped (999px), 2px solid border-default, neutral-primary-medium background, body text
- Active: brand background, white text, 2px border-dark outline
- Pencil shadow is part of the visual identity — keep shadow-xs on every item
- All items need hover and focus states
