# Radios, Checkboxes & Toggles

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`

## Checkbox

- Size: 20x20px
- Radius: 6px (small rounded square — keeps it readable as a checkbox even in the pill-heavy system)
- Border: 2px solid, border-default-medium
- Background: neutral-primary-soft
- Shadow: shadow-2xs (subtle pencil offset)
- Focus ring: 4px, brand-soft
- Checked: brand background, white check (use a hand-drawn check stroke when possible)

### Disabled
- Border: 2px solid border-light
- Background: disabled
- Text: fg-disabled
- No shadow

## Radio

- Size: 20x20px
- Radius: 999px (fully rounded)
- Border: 2px solid, border-default-medium
- Background: neutral-primary-soft
- Shadow: shadow-2xs (subtle pencil offset)
- Focus ring: 4px, brand-soft
- Checked: 2px solid border-brand, inner dot (10x10px) in brand color

### Disabled
- Border: 2px solid border-light-medium
- Background: disabled
- Text: fg-disabled
- No shadow

Group all radio items under the same `name` attribute.

## Toggle

### Track
- Width: 44px, height: 26px
- Radius: 999px (fully rounded)
- Background: neutral-quaternary
- Border: 2px solid border-default
- Shadow: shadow-2xs (subtle pencil offset)
- Focus-within ring: 4px, brand-soft
- Checked track: brand background, border stays border-dark
- Disabled track: neutral-tertiary background, no shadow

### Thumb
- Size: 18x18px
- Radius: 999px (fully rounded)
- Background: neutral-primary-soft
- Border: 2px solid border-dark
- Translates from left to right when checked

### Disabled
- Track: neutral-tertiary background
- Label: fg-disabled text
- No shadow, no hover

## Rules

- All selection inputs must have `id` matching label `htmlFor`
- Focus states use the appropriate brand-soft ring for each control type
- Disabled states: no hover/focus interaction
- The pencil shadow is part of the visual identity for the enabled states — never drop it on default/checked
