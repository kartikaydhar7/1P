# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 24px | Cards, modals, popovers, sections, dropdown menus, alerts, tables, large containers |
| default | 16px | Tooltips, accordion items, dropdown items, medium controls |
| sm | 8px | Small chips, tiny decorative blocks |
| full | 999px | Buttons, badges, inputs, selects, pills, avatars, toggles, dot indicators, pagination items |

## Rules

- 24px is the default radius for any "big" surface (cards, modals, sections, table wrappers)
- 999px (full) is the default radius for every interactive control: buttons, inputs, selects, badges, pagination items
- Avatars and toggle thumbs are always fully rounded
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
- Never mix pill controls (999px) with sharp-corner controls in the same group
