# Shadows

All shadows in this system are **pencil-drawn shadows**: chunky, slightly offset solid blocks (no blur, or only a hint of blur) using the warm `--pencil-ink` ink color from `colors.md`. They are meant to look as if a hand drew the outline of the element with a soft graphite pencil and the shadow is the second pass of the stroke. Avoid soft, modern, blurred drop-shadows.

| Token | CSS value |
|---|---|
| shadow-2xs | `1px 1px 0 0 var(--pencil-ink-soft)` |
| shadow-xs | `2px 2px 0 0 var(--pencil-ink)` |
| shadow-sm | `3px 3px 0 0 var(--pencil-ink), 4px 4px 0 0 var(--pencil-ink-soft)` |
| shadow-md | `4px 4px 0 0 var(--pencil-ink), 6px 6px 0 0 var(--pencil-ink-soft)` |
| shadow-lg | `5px 5px 0 0 var(--pencil-ink), 8px 8px 0 0 var(--pencil-ink-soft)` |
| shadow-xl | `6px 6px 0 0 var(--pencil-ink), 10px 10px 0 0 var(--pencil-ink-soft)` |
| shadow-2xl | `8px 8px 0 0 var(--pencil-ink), 14px 14px 0 0 var(--pencil-ink-soft)` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs |
| Inputs, badges, small controls | shadow-xs |
| Buttons, lightweight cards, popovers | shadow-sm |
| Standard cards, dropdowns | shadow-md |
| Prominent cards, sticky surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use only these tokens — no custom box-shadow values
- All shadows are offset to the bottom-right (positive X and Y), never centered or above the element
- Always use the `--pencil-ink` / `--pencil-ink-soft` custom properties so the shadow color stays consistent with the warm graphite palette
- Never use blurred soft shadows (e.g. `0 4px 6px rgba(0,0,0,.1)`) — they break the hand-drawn aesthetic
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: shrink the offset by ~1px and translate the element by the same amount on each axis to give a "press into the page" feeling. Do not jump up by a full level.
- Active / pressed: collapse the shadow to `shadow-2xs` or 0 and translate the element 2px right and 2px down so it visually meets the original shadow position
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
