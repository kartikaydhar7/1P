# Sidebars

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `typography.md`, `badges.md`, `alerts.md`

## Core Specs

- Background: neutral-primary-soft (cream paper, same as page)
- Right border: 2px dashed, border-default (for left-sidebar); left border for right-sidebar
- Width: 272px

## Anatomy

### Outer Container
Hidden on mobile, visible at small breakpoint. Needs a toggle/trigger for mobile.

### Inner Wrapper
- Full height, vertical scroll overflow
- Padding: 16px horizontal, 20px vertical

### Navigation List
- Vertical spacing: 8px between items
- Font: "Elms Sans", medium weight

### Navigation Item
- Layout: flex, vertically centered
- Padding: 12px horizontal, 10px vertical
- Text: heading color
- Radius: 999px (full pill — matches the rest of the system)
- Hover: neutral-tertiary background
- Transition: colors, 150ms
- Icon: 20x20px, body color, hover → heading color, 75ms transition (hand-drawn stroke style)
- Label: 12px left margin from icon

### Active Item
- Background: brand-softer
- Border: 2px solid border-brand-subtle
- Text: fg-brand-strong

### Separator
- 16px top padding, 16px top margin
- 2px dashed top border: border-default
- 8px vertical spacing below

### Bottom CTA / Card
- Padding: 20px
- Top margin: 24px
- Radius: 24px (base)
- Border: 2px dashed border-default
- Background: brand-softer
- Shadow: shadow-sm (pencil offset)
- Can also use any alert variant from `alerts.md`

## Rules

- Responsive: hidden on mobile with a trigger mechanism
- Icons: 20x20px hand-drawn stroke style, body color (hover: heading color)
- Multi-level menus: indent with 44px left padding
- Spacing follows 8px grid
- Only neutral, brand, or status tokens — no arbitrary colors
- Navigation items always use the pill 999px radius — never sharp rectangular tabs
