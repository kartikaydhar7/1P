# Tables

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`

## Wrapper

- Horizontal scroll overflow
- Background: neutral-primary-medium (warm cream paper)
- Radius: 24px (base)
- Border: 2px **dashed**, border-default
- Shadow: shadow-md (pencil offset)
- Overflow-clip so the dashed corners stay clean

## Table Element

- Full width, left-aligned text (right-aligned for RTL)
- Font: "Elms Sans", 14px, body color

## Table Head

- Font: "Elms Sans", 14px, body color, medium weight
- Background: neutral-tertiary (slightly deeper warm cream so the header band stands out)
- 2px solid bottom border: border-default
- Cell padding: 24px horizontal, 14px vertical

## Table Body

- Row background: transparent (lets the wrapper's neutral-primary-medium show through)
- Row bottom border: 2px solid border-default-subtle (omit on last row to avoid doubling with wrapper border)
- Row hover: neutral-tertiary background (optional)
- Row header: medium weight, heading color, no-wrap
- Cell padding: 24px horizontal, 18px vertical

## Rules

- Wrapper must have horizontal scroll overflow for responsive scrolling
- Wrapper border is 2px **dashed** — the table is a "paper card" that happens to contain rows
- Row dividers are 2px solid (not dashed) so individual rows remain easy to scan
- Last row: omit bottom border to avoid doubling with wrapper border
- Row headers: always `scope="row"` for semantic structure
- Hover on rows is optional
- No arbitrary hex codes — use token colors only
