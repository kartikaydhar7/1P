# Tabs

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`

## Core Specs

- Typography: "Elms Sans", 14px, medium weight, body color
- Transitions: all properties, 200ms

## Variants

### 1. Underline (Default)

**Wrapper:** 2px solid bottom border, border-default

**Tab Item:**
- Padding: 18px horizontal, 14px vertical
- Bottom border: 3px solid transparent (so the active sketch underline reads as a hand-drawn pencil mark)
- Top corners: 16px radius
- Transition: colors, 150ms

| State | Appearance |
|---|---|
| Active | fg-brand text, 3px border-brand bottom border |
| Inactive | transparent bottom border; hover → heading text, 3px border-default-strong bottom border |
| Disabled | fg-disabled text, not-allowed cursor |

### 2. Pills (Recommended for the sketch system)

**Tab Item:**
- Padding: 18px horizontal, 10px vertical
- Radius: 999px (full pill)
- Border: 2px solid transparent (becomes border-dark when active)
- Font weight: medium
- Transition: all, 200ms

| State | Appearance |
|---|---|
| Active | brand background, white text, 2px solid border-dark, shadow-xs (pencil offset) |
| Inactive | body text; hover → neutral-tertiary background, heading text |
| Disabled | fg-disabled text, not-allowed cursor |

### 3. Full Width

Children sit side-by-side with 8px gap (no -1px overlap — every tab is its own pill).

**Tab Item:**
- Full width, centered text
- Padding: 18px horizontal, 14px vertical
- Background: neutral-primary-medium
- Border: 2px solid border-default
- Radius: 999px (full pill)
- Shadow: shadow-xs (pencil offset)
- Transition: colors, 150ms
- Hover: neutral-tertiary background, heading text

| State | Appearance |
|---|---|
| Active | brand background, white text, 2px solid border-dark |
| First / Last item | same 999px radius — no special start/end treatment |

## Tabs with Icons

- Icon size: 16x16px or 20x20px (hand-drawn stroke style)
- Spacing: 8px right margin
- Layout: inline-flex, centered
- Icons inherit the text color of the tab state
