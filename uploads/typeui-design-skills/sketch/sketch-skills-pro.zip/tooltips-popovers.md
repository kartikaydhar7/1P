# Tooltips & Popovers

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`

## Tooltips

### Core Specs
- Padding: 14px horizontal, 8px vertical
- Font: "Elms Sans", 14px, medium weight
- Radius: 999px (full pill — short tooltips look like little hand-drawn captions)
- Shadow: shadow-xs (pencil offset)
- Transition: opacity, 300ms

### Dark (Default)
- Background: dark
- Text: white
- Border: 2px solid border-dark

### Light
- Background: neutral-primary-medium
- Text: heading color
- Border: 2px solid border-default

## Popovers

### Core Specs
- Background: neutral-primary-medium (warm cream paper)
- Radius: 24px (base)
- Shadow: shadow-md (pencil offset)
- Border: 2px **dashed**, border-default
- Transition: opacity, 300ms

### Header / Title
- Padding: 16px horizontal, 12px vertical
- Background: neutral-tertiary
- 2px dashed bottom border: border-default
- Font: "Delicious Handrawn", 18px, regular weight, heading color

### Body / Content
- Standard: 16px horizontal, 12px vertical padding; "Elms Sans", 14px, body color
- Rich: 20px padding; "Elms Sans", 14px, body color, 1.65 line-height

## Arrows

- Size: 10x10px rotated 45deg
- Color must match the background of the tooltip/popover variant
- For popovers, the arrow stays solid (the dashed border is decorative on the body, not the pointer)

## Rules

- Tooltips: 999px (full pill) radius
- Popovers: 24px radius with 2px dashed border
- Dark tooltips: dark background, white text, 2px solid border-dark outline
- Light tooltips/popovers: semantic neutral background + border tokens
- Pencil shadow is part of the visual identity — never drop the offset shadow on tooltips or popovers
- Arrows match parent background color
