# Typography

> Dependencies: `colors.md`

## Core Rules

- **Heading font:** "Delicious Handrawn", cursive — hand-drawn display face used for every `h1`–`h6`. Load from Google Fonts (https://fonts.google.com/specimen/Delicious+Handrawn). Configure at the app level, never override.
- **Body / UI font:** "Elms Sans", sans-serif — calm, expressive sans used for paragraphs, labels, buttons, inputs, badges and every other UI element. Load from Google Fonts (https://fonts.google.com/specimen/Elms+Sans). Configure at the app level, never override.
- **Headings:** regular weight (400) — the hand-drawn face already carries visual weight, never apply bold or semibold to it
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 72px | 1.05 | -0.5px | 24px |
| `h2` | 52px | 1.1 | -0.3px | — |
| `h3` | 40px | 1.15 | — | — |
| `h4` | 32px | 1.2 | — | — |
| `h5` | 26px | 1.3 | — | — |
| `h6` | 22px | 1.35 | — | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 48px | 36px |
| `h2` | 40px | 30px |
| `h3` | 32px | 26px |
| `h4` | 28px | 22px |
| `h5` | 24px | 20px |
| `h6` | 20px | 18px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.05 for any heading. Hand-drawn faces need a touch more breathing room than geometric sans, so do not crowd them.

## Paragraphs

### Leading Paragraph
- Font: "Elms Sans"
- Size: 20px
- Weight: normal (400)
- Color: body
- Line-height: 1.7
- Max width: ~70 characters

### Normal Paragraph
- Font: "Elms Sans"
- Size: 16px
- Weight: normal (400)
- Color: body
- Line-height: 1.7
- Max width: ~65 characters

### Small Supporting Copy
- Font: "Elms Sans"
- Size: 14px
- Weight: normal (400)
- Color: body
- Line-height: 1.6
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 16px | 500 (medium) |
| Input labels | 14px or 16px | 500 (medium) |
| Captions / meta / badges | 12px or 14px | 500 (medium) |

All UI labels use "Elms Sans". Do not apply paragraph line-height (1.7) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline, hover → no underline
- **CTA links:** fg-brand color, medium weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, 0.4px letter-spacing, 12px or 14px, "Elms Sans"
- Decorative one-off display moments (taglines, hero accent words) may also use "Delicious Handrawn" inline — keep them short, never inside paragraphs

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Font families, sizes, weights, and spacing remain constant.
