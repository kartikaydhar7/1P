# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except ghost and disabled)

- **Radius:** 14px (base) or 9999px for pills
- **Border:** 1px solid
- **Shadow:** shadow-sm
- **Skeuomorphic effect:** Every button except ghost and disabled gets a combined box-shadow that layers inset top-edge highlight, inset bottom-edge depth, external drop shadow, ambient shadow, and an outline ring:
  - `inset 0 2px 5px #ffffffa6, inset 0 -3px 7px #00000073, 0 6px 14px #00000073, 0 2px 4px #00000040, 0 0 0 1px #6b3000`
- **Font weight:** 500 (medium)
- **Font:** Geist
- **Box sizing:** border-box
- **Transition:** color transitions on hover

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 12px | 6px |
| Small | 14px | 12px | 8px |
| Base (default) | 14px | 16px | 10px |
| Large | 16px | 20px | 12px |
| Extra large | 16px | 24px | 14px |

## Variants

### Brand
- **Background:** `linear-gradient(180deg, #fad090 0%, #e87c14 45%, #a84e00 100%)`
- **Border:** transparent
- **Text:** white
- **Hover:** darken gradient — `linear-gradient(180deg, #e8b870 0%, #d06c0e 45%, #8a4000 100%)`
- **Focus ring:** 4px, brand-medium color
- **Skeuomorphic shadow:** yes

### Secondary
- **Background:** neutral-secondary-medium
- **Border:** border-default-medium
- **Text:** body color
- **Hover:** neutral-tertiary-medium background, heading text color
- **Focus ring:** 4px, neutral-tertiary color
- **Skeuomorphic shadow:** yes

### Tertiary
- **Background:** neutral-primary-soft
- **Border:** border-default
- **Text:** body color
- **Hover:** neutral-secondary-medium background, heading text color
- **Focus ring:** 4px, neutral-tertiary-soft color
- **Skeuomorphic shadow:** yes

### Success
- **Background:** success token
- **Border:** transparent
- **Text:** white
- **Hover:** success-strong background
- **Focus ring:** 4px, success-medium color
- **Skeuomorphic shadow:** yes

### Danger
- **Background:** danger token
- **Border:** transparent
- **Text:** white
- **Hover:** danger-strong background
- **Focus ring:** 4px, danger-medium color
- **Skeuomorphic shadow:** yes

### Warning
- **Background:** warning token
- **Border:** transparent
- **Text:** white
- **Hover:** warning-strong background
- **Focus ring:** 4px, warning-medium color
- **Skeuomorphic shadow:** yes

### Dark
- **Background:** dark token
- **Border:** transparent
- **Text:** white
- **Hover:** dark-strong background
- **Focus ring:** 4px, neutral-tertiary color
- **Skeuomorphic shadow:** yes

### Ghost (NO shadow, NO skeuomorphic effect)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color
- **Hover:** neutral-secondary-medium background
- **Focus ring:** 4px, neutral-tertiary color
- **No shadow, no skeuomorphic effect**

### Disabled (NO shadow, NO skeuomorphic effect)
- **Background:** disabled token
- **Border:** border-default-medium
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no skeuomorphic effect**

## Icons in Buttons

- Icon size: 16x16px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
