# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** `linear-gradient(175deg, #ddd4b0 0%, #c8bc90 30%, #b8ac80 55%, #ccc09a 80%, #d8cca8 100%)`
- **Border:** 1px, border-default color
- **Radius:** 14px (base)
- **Shadow:** shadow-md

## Card Heading

- Desktop: 20px, medium weight, heading color
- Mobile: 16px, medium weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: `linear-gradient(175deg, #ddd4b0 0%, #c8bc90 30%, #b8ac80 55%, #ccc09a 80%, #d8cca8 100%)`
- Border: 1px, border-default
- Radius: 14px
- Shadow: shadow-md
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: shadow-lg (step up one elevation level for tactile press feedback)
- Transition: box-shadow, 200ms
- Cursor: pointer

## Rules

- Background: card gradient (see Core Specs)
- Border: 1px, border-default
- Radius: 14px
- Shadow: shadow-md
- Interactive hover: step up to shadow-lg
- Non-interactive: no hover styles
