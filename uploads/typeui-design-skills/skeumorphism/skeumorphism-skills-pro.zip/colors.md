# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #F5EDE0 | #1E1810 |
| neutral-primary | #F5EDE0 | #141008 |
| neutral-primary-medium | #F5EDE0 | #2E2618 |
| neutral-primary-strong | #F5EDE0 | #3E3428 |
| neutral-secondary-soft | #EDE5D5 | #1E1810 |
| neutral-secondary | #EDE5D5 | #141008 |
| neutral-secondary-medium | #EDE5D5 | #2E2618 |
| neutral-secondary-strong | #EDE5D5 | #3E3428 |
| neutral-tertiary-soft | #E0D6C0 | #1E1810 |
| neutral-tertiary | #E0D6C0 | #2E2618 |
| neutral-tertiary-medium | #E0D6C0 | #3E3428 |
| neutral-quaternary | #D8CCA8 | #3E3428 |
| quaternary-medium | #D8CCA8 | #4E4438 |
| gray | #C8BC90 | #4E4438 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #FFF3E0 | #3A1E05 |
| brand-soft | #FDDCB0 | #6B3007 |
| brand | #D36C0E | #E87C14 |
| brand-medium | #F5C88A | #6B3007 |
| brand-strong | #A85400 | #D36C0E |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #F0FAF0 | #0A2A1E |
| success | #2E8B57 | #3CB371 |
| success-medium | #C8F0D0 | #1A4A30 |
| success-strong | #1E6B40 | #2E8B57 |
| danger-soft | #FFF0F0 | #4A0818 |
| danger | #C0392B | #C0392B |
| danger-medium | #FFD5D0 | #7A1828 |
| danger-strong | #A0302A | #A0302A |
| warning-soft | #FFF8ED | #5A2508 |
| warning | #E8820E | #E8820E |
| warning-medium | #FFE8C0 | #5A2508 |
| warning-strong | #B86400 | #B86400 |

### Button Glint (CSS custom properties, used for the skeuomorphic box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.65) | rgba(255,255,255,0.20) |
| `--color-1-700` | rgba(0,0,0,0.45) | rgba(0,0,0,0.55) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #3A2E1E | #3A2E1E |
| dark-strong | #2A1E10 | #4A3E28 |
| disabled | #E0D6C0 | #2E2618 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #9B59B6 |
| sky | #5DADE2 |
| teal | #1ABC9C |
| pink | #E74C8A |
| cyan | #3DC0C8 |
| fuchsia | #B84CC8 |
| indigo | #6C5CE7 |
| orange | #E87C14 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFF5E8 | #FFF5E8 |
| black | #2A1E10 | #2A1E10 |
| heading | #3A2E1E | #F5EDE0 |
| body | #6B5D48 | #B8AC90 |
| body-subtle | #8A7C64 | #A89C80 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #F5C88A | #6B3007 |
| fg-brand | #D36C0E | #F5A050 |
| fg-brand-strong | #A85400 | #F5C88A |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #2E8B57 | #1E6B40 |
| fg-success-strong | #1E6B40 | #3CB371 |
| fg-danger | #C0392B | #E74C3C |
| fg-danger-strong | #8B1A1A | #FF6B5A |
| fg-warning-subtle | #D36C0E | #E8820E |
| fg-warning | #7A4008 | #FBBF24 |
| fg-disabled | #A89C80 | #6B5D48 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #D4A017 | #D4A017 |
| fg-info | #3A2E60 | #90B0E0 |
| fg-purple | #8E44AD | #9B59B6 |
| fg-purple-strong | #7D3C98 | #D2B4DE |
| fg-cyan | #17A2B8 | #3DC0C8 |
| fg-indigo | #6C5CE7 | #6C5CE7 |
| fg-pink | #E74C8A | #E74C8A |
| fg-lime | #7D8A2E | #9ACD32 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #4A3E28 | #6B5D48 |
| border-buffer | #F5EDE0 | #141008 |
| border-buffer-medium | #F5EDE0 | #2E2618 |
| border-buffer-strong | #F5EDE0 | #3E3428 |
| border-muted | #EDE5D5 | #1E1810 |
| border-light-subtle | #E0D6C0 | #1E1810 |
| border-light | #E0D6C0 | #2E2618 |
| border-light-medium | #E0D6C0 | #3E3428 |
| border-default-subtle | #D8CCA8 | #1E1810 |
| border-default | #D8CCA8 | #2E2618 |
| border-default-medium | #D8CCA8 | #3E3428 |
| border-default-strong | #D8CCA8 | #4E4438 |
| border-success-subtle | #A8E0B8 | #0A3A20 |
| border-success | #2E8B57 | #1E6B40 |
| border-danger-subtle | #F0C0B8 | #7A1828 |
| border-danger | #C0392B | #C0392B |
| border-warning-subtle | #F5D0A0 | #5A2508 |
| border-warning | #D36C0E | #E8820E |
| border-brand-subtle | #F5C88A | #6B3007 |
| border-brand-light | #D36C0E | #D36C0E |
| border-brand | #D36C0E | #F5A050 |
| border-dark-subtle | #4A3E28 | #4A3E28 |
| border-purple | #9B59B6 | #9B59B6 |
| border-orange | #E87C14 | #E87C14 |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background with gradient
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
