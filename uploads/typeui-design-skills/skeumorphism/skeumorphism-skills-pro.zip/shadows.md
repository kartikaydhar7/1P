# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `0 1px 2px #00000015, 0 0 0 1px #5a503220` |
| shadow-xs | `inset 0 1px 2px #ffffff40, inset 0 -1px 3px #00000020, 0 2px 4px #00000020, 0 0 0 1px #5a503230` |
| shadow-sm | `inset 0 2px 4px #ffffff50, inset 0 -2px 5px #00000028, 0 4px 10px #00000028, 0 1px 3px #00000020, 0 0 0 1px #5a503240` |
| shadow-md | `inset 0 3px 6px #ffffff8c, inset 0 -4px 10px #0000004d, 0 18px 55px #5046288c, 0 4px 12px #0000004d, 0 0 0 1px #5a503280` |
| shadow-lg | `inset 0 3px 7px #ffffff80, inset 0 -4px 12px #00000050, 0 22px 60px #50462890, 0 5px 14px #00000050, 0 0 0 1px #5a503288` |
| shadow-xl | `inset 0 4px 8px #ffffff70, inset 0 -5px 14px #00000058, 0 28px 70px #50462898, 0 6px 18px #00000058, 0 0 0 1px #5a503290` |
| shadow-2xl | `inset 0 5px 10px #ffffff60, inset 0 -6px 16px #00000060, 0 35px 80px #504628a0, 0 8px 22px #00000060, 0 0 0 1px #5a503298` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls, lightweight cards | shadow-xs or shadow-sm |
| Standard cards, popovers, dropdowns | shadow-md |
| Prominent cards, sticky surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use only these tokens — no custom box-shadow values
- Every shadow token includes layered inset highlights, inset bottom shadows, external drop shadows, and a subtle outline ring to simulate physical depth
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
