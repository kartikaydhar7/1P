# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** transparent
- **Border:** none
- **Radius:** 0 (no border radius)
- **Shadow:** none

## Card Heading

- Desktop: 20px, medium weight, heading color
- Mobile: 16px, medium weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: transparent
- Border: none
- Radius: 0
- Shadow: none
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: neutral-secondary-medium background
- Transition: colors
- Cursor: pointer

## Rules

- Background: transparent
- Border: none
- Radius: 0
- Shadow: none
- Interactive hover: neutral-secondary-medium background
- Non-interactive: no hover styles
