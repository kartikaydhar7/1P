# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #F5F2F0 | #141210 |
| neutral-primary | #F5F2F0 | #0A0908 |
| neutral-primary-medium | #F5F2F0 | #1E1B18 |
| neutral-primary-strong | #F5F2F0 | #3D3833 |
| neutral-secondary-soft | #EFEBE8 | #141210 |
| neutral-secondary | #EFEBE8 | #0A0908 |
| neutral-secondary-medium | #EFEBE8 | #1E1B18 |
| neutral-secondary-strong | #EFEBE8 | #3D3833 |
| neutral-tertiary-soft | #E8E3DF | #141210 |
| neutral-tertiary | #E8E3DF | #1E1B18 |
| neutral-tertiary-medium | #E8E3DF | #3D3833 |
| neutral-quaternary | #DDD7D2 | #3D3833 |
| quaternary-medium | #DDD7D2 | #4F4A44 |
| gray | #C7C0BA | #4F4A44 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #F6ECF8 | #1E0124 |
| brand-soft | #E2C6E8 | #2D0338 |
| brand | #480355 | #7A2589 |
| brand-medium | #D4A8DC | #2D0338 |
| brand-strong | #360140 | #480355 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #ECFDF5 | #002C22 |
| success | #007A55 | #009966 |
| success-medium | #D0FAE5 | #004F3B |
| success-strong | #006045 | #007A55 |
| danger-soft | #FEF0F2 | #4D0218 |
| danger | #C70036 | #C70036 |
| danger-medium | #FFE4E6 | #8B0836 |
| danger-strong | #A50036 | #A50036 |
| warning-soft | #FFF7ED | #7C2D12 |
| warning | #F97316 | #F97316 |
| warning-medium | #FFEDD5 | #7C2D12 |
| warning-strong | #C2410C | #C2410C |

### Button Glint (CSS custom properties — glint effect is disabled, values zeroed)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(0,0,0,0) | rgba(0,0,0,0) |
| `--color-1-700` | rgba(0,0,0,0) | rgba(0,0,0,0) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #2D2825 | #2D2825 |
| dark-strong | #1A1714 | #443E3B |
| disabled | #E8E3DF | #2D2825 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #A855F7 |
| sky | #0EA5E9 |
| teal | #0D9488 |
| pink | #DB2777 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #FB923C |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #1A1714 | #1A1714 |
| heading | #1A1714 | #F5F2F0 |
| body | #5C5552 | #B0A8A0 |
| body-subtle | #7A7572 | #B0A8A0 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #D4A8DC | #2D0338 |
| fg-brand | #480355 | #B864C8 |
| fg-brand-strong | #360140 | #D4A8DC |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #047857 | #065F46 |
| fg-success-strong | #065F46 | #10B981 |
| fg-danger | #BE123C | #F43F5E |
| fg-danger-strong | #881337 | #F87171 |
| fg-warning-subtle | #EA580C | #F97316 |
| fg-warning | #7C2D12 | #FBBF24 |
| fg-disabled | #B0A8A0 | #7A7572 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #312E81 | #93C5FD |
| fg-purple | #9333EA | #A855F7 |
| fg-purple-strong | #7E3AF2 | #DDD6FE |
| fg-cyan | #0891B2 | #06B6D4 |
| fg-indigo | #4F46E5 | #4F46E5 |
| fg-pink | #DB2777 | #DB2777 |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #2D2825 | #5C5552 |
| border-buffer | #F5F2F0 | #0A0908 |
| border-buffer-medium | #F5F2F0 | #2D2825 |
| border-buffer-strong | #F5F2F0 | #443E3B |
| border-muted | #EFEBE8 | #141210 |
| border-light-subtle | #E8E3DF | #141210 |
| border-light | #E8E3DF | #2D2825 |
| border-light-medium | #E8E3DF | #443E3B |
| border-default-subtle | #DDD7D2 | #141210 |
| border-default | #DDD7D2 | #2D2825 |
| border-default-medium | #DDD7D2 | #443E3B |
| border-default-strong | #DDD7D2 | #5C5552 |
| border-success-subtle | #A7F3D0 | #064E3B |
| border-success | #047857 | #065F46 |
| border-danger-subtle | #FECDD3 | #881337 |
| border-danger | #BE123C | #BE123C |
| border-warning-subtle | #FED7AA | #7C2D12 |
| border-warning | #EA580C | #F97316 |
| border-brand-subtle | #D4A8DC | #2D0338 |
| border-brand-light | #7A2589 | #7A2589 |
| border-brand | #480355 | #B864C8 |
| border-dark-subtle | #2D2825 | #443E3B |
| border-purple | #A855F7 | #A855F7 |
| border-orange | #FB923C | #FB923C |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (default), neutral-secondary-soft (alternating)
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
