# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 120px |
| Section header → content | 64px or 80px |
| Heading → paragraph | 24px |
| Container horizontal padding | 32px |
| Flex/grid row gap | 24px |
| Card grid gap | 32px |
| Wide component grid gap | 48px |
| Column layout gap | 64px |

## Container

Standard section container: max-width 1280px, centered, 32px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s) in 2 or 3 columns
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 120px vertical padding
- A uniform background color: #F5F2F0 (neutral-primary-soft) for all sections
- A centered container (max-width 1280px, 32px horizontal padding)
- A section header area with 64px or 80px bottom margin
- Section content below

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Backgrounds & Visual Depth

- Default to a single, uniform warm background (#F5F2F0) across all sections for a clean minimalist feel.
- Avoid layered gradients, noise textures, or decorative patterns. The design relies on whitespace, large photography, bold typography, and content hierarchy rather than surface treatments.
- Every visual element must serve a compositional purpose (hierarchy, separation, or emphasis). No purely ornamental effects competing with content.

## Must

- All sections: consistent 120px vertical padding
- All containers: max-width 1280px, centered, 32px horizontal padding
- Section headers: 64px or 80px bottom margin
- Generous vertical rhythm with large breathing room between sections and around headings
- Layouts readable and properly spaced on both desktop and mobile
- Big photographs used to punctuate content, spanning full container width or used as hero elements
- Body paragraphs arranged in 2 or 3 columns for readability
