# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 12px | Modals, sections, containers, accordion wrappers |
| default | 8px | Tooltips, dropdown items, small controls |
| sm | 4px | Checkboxes, tiny elements |
| full | 9999px | Buttons, badges, inputs, pills, avatars, toggles, dot indicators |

## Rules

- 9999px (full/pill) is the default radius for buttons, badges, and inputs
- 12px (base) is used for container-level elements like modals, sections, and accordion wrappers
- Cards have 0 radius (transparent, borderless)
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
