# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFFFFF | #101828 |
| neutral-primary | #FFFFFF | #030712 |
| neutral-primary-medium | #FFFFFF | #1E2939 |
| neutral-primary-strong | #FFFFFF | #333E4F |
| neutral-secondary-soft | #FFFFFF | #101828 |
| neutral-secondary | #FFFFFF | #030712 |
| neutral-secondary-medium | #F9FAFB | #1E2939 |
| neutral-secondary-strong | #F3F4F6 | #333E4F |
| neutral-tertiary-soft | #F5F5F5 | #101828 |
| neutral-tertiary | #F0F0F0 | #1E2939 |
| neutral-tertiary-medium | #EBEBEB | #333E4F |
| neutral-quaternary | #E0E0E0 | #333E4F |
| quaternary-medium | #D6D6D6 | #4A5565 |
| gray | #C4C4C4 | #4A5565 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #FEF3EB | #3D1A00 |
| brand-soft | #FADCCA | #6B2E00 |
| brand | #C44900 | #D96B20 |
| brand-medium | #F0C4A0 | #6B2E00 |
| brand-strong | #9E3A00 | #C44900 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #ECFDF5 | #002C22 |
| success | #007A55 | #009966 |
| success-medium | #D0FAE5 | #004F3B |
| success-strong | #006045 | #007A55 |
| danger-soft | #FEF0F2 | #4D0218 |
| danger | #C70036 | #C70036 |
| danger-medium | #FFE4E6 | #8B0836 |
| danger-strong | #A50036 | #A50036 |
| warning-soft | #FFF7ED | #7C2D12 |
| warning | #F97316 | #F97316 |
| warning-medium | #FFEDD5 | #7C2D12 |
| warning-strong | #C2410C | #C2410C |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.25) | rgba(255,255,255,0.12) |
| `--color-1-700` | rgba(0,0,0,0.12) | rgba(0,0,0,0.25) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #1F2937 | #1F2937 |
| dark-strong | #111827 | #374151 |
| disabled | #F3F4F6 | #1F2937 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #7C5E4A |
| sky | #5A8FA8 |
| teal | #4A7A73 |
| pink | #B85C5C |
| cyan | #4A8A96 |
| fuchsia | #8A5A7A |
| indigo | #5A5A7A |
| orange | #C44900 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #111827 | #111827 |
| heading | #1A1A1A | #FFFFFF |
| body | #4A4A4A | #9CA3AF |
| body-subtle | #6E6E6E | #9CA3AF |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #F0C4A0 | #6B2E00 |
| fg-brand | #C44900 | #E8985A |
| fg-brand-strong | #9E3A00 | #FADCCA |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #047857 | #065F46 |
| fg-success-strong | #065F46 | #10B981 |
| fg-danger | #BE123C | #F43F5E |
| fg-danger-strong | #881337 | #F87171 |
| fg-warning-subtle | #EA580C | #F97316 |
| fg-warning | #7C2D12 | #FBBF24 |
| fg-disabled | #9CA3AF | #6B7280 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #3D3520 | #D4C9A8 |
| fg-purple | #7C5E4A | #9E8A78 |
| fg-purple-strong | #5C4030 | #C4B098 |
| fg-cyan | #4A8A96 | #5A9AA6 |
| fg-indigo | #5A5A7A | #7A7A9A |
| fg-pink | #B85C5C | #C87A7A |
| fg-lime | #65A30D | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #1F2937 | #4B5563 |
| border-buffer | #FFFFFF | #030712 |
| border-buffer-medium | #FFFFFF | #1F2937 |
| border-buffer-strong | #FFFFFF | #374151 |
| border-muted | #F9FAFB | #111827 |
| border-light-subtle | #F3F4F6 | #111827 |
| border-light | #F3F4F6 | #1F2937 |
| border-light-medium | #F3F4F6 | #374151 |
| border-default-subtle | #E5E7EB | #111827 |
| border-default | #E5E7EB | #1F2937 |
| border-default-medium | #E5E7EB | #374151 |
| border-default-strong | #E5E7EB | #4B5563 |
| border-success-subtle | #A7F3D0 | #064E3B |
| border-success | #047857 | #065F46 |
| border-danger-subtle | #FECDD3 | #881337 |
| border-danger | #BE123C | #BE123C |
| border-warning-subtle | #FED7AA | #7C2D12 |
| border-warning | #EA580C | #F97316 |
| border-brand-subtle | #F0C4A0 | #6B2E00 |
| border-brand-light | #D96B20 | #D96B20 |
| border-brand | #C44900 | #E8985A |
| border-dark-subtle | #1F2937 | #374151 |
| border-purple | #7C5E4A | #7C5E4A |
| border-orange | #C44900 | #C44900 |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft for all sections — consistent white, no alternating
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
