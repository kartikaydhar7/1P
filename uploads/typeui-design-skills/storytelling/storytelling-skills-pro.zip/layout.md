# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 120px |
| Section header → content | 64px or 80px |
| Heading → paragraph | 24px |
| Container horizontal padding | 32px |
| Flex/grid row gap | 24px |
| Card grid gap | 32px |
| Wide component grid gap | 48px |
| Column layout gap | 64px |

## Container

Standard section container: max-width 1440px, centered, 32px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 120px vertical padding
- A white background (neutral-primary-soft) — all sections use the same white background, never alternate
- A centered container (max-width 1440px, 32px horizontal padding) for text content
- A section header area with 64px bottom margin
- Section content below
- Sections are separated by thin horizontal rules or generous whitespace — never by background color changes
- Do NOT use card-based layouts for primary content — content flows directly within full-width sections

## Timeline Entry Layout (primary page pattern)

Each timeline entry is a **vertically stacked** block — image and text are NEVER side by side. The structure is:

1. **Full-bleed diagonal image** — spans the entire viewport width (edge to edge, no container, no max-width). Uses `clip-path: polygon()` to create angled top and bottom edges (e.g. `polygon(0 8%, 100% 0, 100% 92%, 0 100%)`). The image has a tall aspect ratio (~16:9 or ~2:1) and covers the full width. Alternating entries use mirrored clip-path angles.
2. **Text block below the image** — sits inside the standard centered container (max-width 1440px, 32px padding). Contains: an uppercase brand-colored label, the large 160px year heading (h2), a section title (h3), and body paragraphs.

Key rules:
- Image and text are stacked vertically, NEVER placed in columns or side by side
- Images are full-bleed (100% viewport width, no horizontal padding, no max-width constraint)
- Text content is contained (max-width 1440px, centered, 32px horizontal padding)
- Diagonal clip-path angles alternate direction between entries
- No cards, no grid columns — pure vertical flow

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered transitions for timeline entries — each section fades and slides into view as the user scrolls, reinforcing the chronological narrative.
- Scroll-triggered parallax on diagonally-clipped images adds depth to the storytelling experience.

## Backgrounds & Visual Depth

- All backgrounds must be clean white (neutral-primary-soft). No gradient fills, no colored section backgrounds, no alternating tones.
- Visual depth and interest comes entirely from oversized typography, diagonal image clipping, and generous whitespace — not from background treatments.
- Diagonal clip-paths on images are the primary decorative device. They create angular momentum that guides the eye down the timeline.
- Thin horizontal rules or large whitespace gaps separate sections — never colored backgrounds or heavy borders.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.

## Must

- All sections: consistent 120px vertical padding, white background throughout
- All containers: max-width 1440px, centered, 32px horizontal padding
- Section headers: 64px or 80px bottom margin
- Consistent vertical rhythm, generous whitespace, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
- Primary page layout follows a vertical timeline: full-bleed diagonal images stacked above their text blocks — never side by side
- No card-based grid layouts for storytelling content — content lives directly in full-width sections
- Images are full-bleed (100vw, edge to edge) with diagonal polygon clip-path — text is contained (max-width 1440px)
