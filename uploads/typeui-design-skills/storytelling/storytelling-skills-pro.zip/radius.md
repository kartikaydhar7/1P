# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 4px | Buttons, cards, inputs, modals, sections |
| default | 4px | Badges, tooltips, dropdown items, small controls |
| sm | 2px | Checkboxes, tiny elements |
| full | 9999px | Pills, avatars, toggles, dot indicators |

## Rules

- 4px is the default radius across the product — sharp, editorial corners
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
