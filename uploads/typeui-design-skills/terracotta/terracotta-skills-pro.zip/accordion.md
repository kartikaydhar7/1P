# Accordion

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Wrapper:** full width, 1px border (border-default color), 16px radius — clips first/last item corners
- **Item separator:** 1px bottom border (border-default) on every item except last

## Trigger (Button)

- **Layout:** flex, space-between, full width
- **Padding:** 20px horizontal, 18px vertical
- **Font:** DM Sans, 15px, medium weight
- **Text color:** heading
- **Background:** neutral-tertiary
- **Hover:** neutral-tertiary-medium background
- **Focus:** outline none, 2px ring in brand color
- **Transition:** colors, 200ms
- **Open state:** neutral-tertiary-medium background

## Panel (Content)

- **Padding:** 20px horizontal, 18px vertical
- **Background:** neutral-primary-soft
- **Top border:** 1px, border-default color
- **Font:** DM Sans, 15px, body color, 1.7 line-height

## Chevron Icon

- Size: 16x16px
- Color: body text color
- Closed: 0deg rotation
- Open: 180deg rotation
- Transition: transform, 150ms

## Variants

### Default (Collapse)
One panel open at a time. Items stacked inside a single shared bordered/rounded wrapper.

### Separated Cards
Each item is independent — has its own 1px border, 16px radius, and shadow-xs. 8px bottom margin between items. No shared outer border.

### Always Open
Multiple panels can expand simultaneously. Same styling as Default.

### Flush
No outer border. Trigger and panel have transparent backgrounds. Only bottom border dividers between items. Use inside containers that already provide a background.

## States

| State | Trigger appearance |
|---|---|
| Closed | heading text, neutral-tertiary background |
| Open | heading text, neutral-tertiary-medium background |
| Hover | neutral-tertiary-medium background |
| Focus | 2px brand ring, no outline |
| Disabled | fg-disabled text, not-allowed cursor, no hover/focus |
