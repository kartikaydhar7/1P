# Borders

## Width Scale

| Context | Width |
|---|---|
| Default (inputs, buttons, cards, navbar) | 1px |
| Emphasis / focus | 2px |

## Default Border Color

The default border across the system uses **border-default** (`#E2D9C8` light / `#2B1D14` dark) — a warm parchment tone that reads as a soft outline against the cream surface, never as a hard line.

## Rules

- Use solid borders by default
- Dashed borders only for special cases like file dropzones
- Components in the same family must use matching border widths
- Never mix 1px and 2px borders within a single component
- Borders should always feel soft and warm — never harsh black or cold gray

## Usage

| Context | Width | Color token |
|---|---|---|
| Inputs / selects / textareas | 1px default; 2px on focus or error | border-default-medium → border-brand on focus |
| Buttons | 1px for variants that require outlining | border-default |
| Cards / containers | 1px subtle; avoid stacked heavy borders | border-default |
| Navbar / sidebar dividers | 1px | border-default |
| Dividers between content blocks | 1px | border-light |
