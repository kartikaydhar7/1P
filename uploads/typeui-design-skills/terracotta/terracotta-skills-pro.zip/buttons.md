# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs (every button except ghost and disabled)

- **Radius:** 16px (base) or 9999px for pills
- **Border:** 1px solid
- **Shadow:** shadow-xs
- **Glint effect:** Every button except ghost and disabled gets a combined box-shadow that layers the base shadow with an inset top-edge highlight and a subtle outer color glow:
  - `var(--shadow-xs), inset var(--color-1-400) 0 6px 0px -5px, var(--color-1-700) 0 4px 10px -5px`
- **Font:** DM Sans
- **Font weight:** 500 (medium)
- **Box sizing:** border-box
- **Transition:** background and color transitions on hover, 200ms

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 12px | 6px |
| Small | 14px | 14px | 8px |
| Base (default) | 15px | 18px | 10px |
| Large | 16px | 22px | 12px |
| Extra large | 17px | 26px | 14px |

## Variants

### Brand (Primary)
- **Background:** `linear-gradient(to bottom right, brand, brand-strong)` — terracotta gradient (lighter at top-left, darker at bottom-right)
- **Border:** transparent
- **Text:** white
- **Hover:** `linear-gradient(to bottom right, brand-strong, brand-strong)` — settles into the deeper terracotta
- **Focus ring:** 4px, brand-medium color
- **Glint:** yes
- **Use:** the single primary action per screen

### Secondary
- **Background:** `linear-gradient(to bottom right, gray, quaternary-medium)` — secondary taupe gradient (lighter at top-left, darker at bottom-right; resolves with the warm secondary tone and its darker shade)
- **Border:** transparent
- **Text:** white
- **Hover:** `linear-gradient(to bottom right, quaternary-medium, quaternary-medium)`
- **Focus ring:** 4px, neutral-tertiary-medium color
- **Glint:** yes

### Tertiary
- **Background:** `linear-gradient(to bottom right, gray, quaternary-medium)` — same secondary-color gradient
- **Border:** 1px, border-default
- **Text:** white
- **Hover:** `linear-gradient(to bottom right, quaternary-medium, quaternary-medium)`
- **Focus ring:** 4px, neutral-tertiary-soft color
- **Glint:** yes

### Success
- **Background:** `linear-gradient(to bottom right, success, success-strong)`
- **Border:** transparent
- **Text:** white
- **Hover:** `linear-gradient(to bottom right, success-strong, success-strong)`
- **Focus ring:** 4px, success-medium color
- **Glint:** yes

### Danger
- **Background:** `linear-gradient(to bottom right, danger, danger-strong)`
- **Border:** transparent
- **Text:** white
- **Hover:** `linear-gradient(to bottom right, danger-strong, danger-strong)`
- **Focus ring:** 4px, danger-medium color
- **Glint:** yes

### Warning
- **Background:** `linear-gradient(to bottom right, warning, warning-strong)`
- **Border:** transparent
- **Text:** white
- **Hover:** `linear-gradient(to bottom right, warning-strong, warning-strong)`
- **Focus ring:** 4px, warning-medium color
- **Glint:** yes

### Dark
- **Background:** `linear-gradient(to bottom right, dark, dark-strong)`
- **Border:** transparent
- **Text:** white
- **Hover:** `linear-gradient(to bottom right, dark-strong, dark-strong)`
- **Focus ring:** 4px, neutral-tertiary-medium color
- **Glint:** yes

### Ghost (NO shadow, NO glint)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color
- **Hover:** neutral-secondary-medium background
- **Focus ring:** 4px, neutral-tertiary-medium color
- **No shadow, no glint effect, no gradient**

### Disabled (NO shadow, NO glint)
- **Background:** disabled token (flat, no gradient)
- **Border:** border-default-medium
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no glint, no gradient**

## Gradient Direction

- All gradient buttons share the same direction: `to bottom right` (top-left lighter, bottom-right darker)
- The "darker" stop is always the corresponding `*-strong` token of the same color family
- This consistent diagonal gives a unified, sun-warmed surface treatment across every variant

## Icons in Buttons

- Icon size: 16x16px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
