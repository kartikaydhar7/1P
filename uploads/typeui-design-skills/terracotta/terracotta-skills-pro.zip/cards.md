# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-tertiary (warmer cream — sits one shade darker than the page surface for clear visual separation)
- **Border:** 1px, border-default color
- **Radius:** 16px (base)
- **Shadow:** shadow-xs

## Card Heading

- Font: DM Serif Display
- Desktop: 22px, regular weight (400), heading color
- Mobile: 18px, regular weight (400), heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## Card Body Text

- Font: DM Sans, body color, line-height 1.7

## States

### Static Card (no interactivity)
- Background: neutral-tertiary
- Border: 1px, border-default
- Radius: 16px
- Shadow: shadow-xs
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: neutral-tertiary-medium background
- Transition: colors, 200ms
- Cursor: pointer

## Rules

- Background: neutral-tertiary (always one shade warmer/darker than the page surface so cards visibly lift off the section)
- Border: 1px, border-default
- Radius: 16px
- Shadow: shadow-xs
- Interactive hover: neutral-tertiary-medium background
- Non-interactive: no hover styles
- Cards never use a gradient background — gradients are reserved for buttons
