# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FBF4E7 | #1F1610 |
| neutral-primary | #FBF4E7 | #18110B |
| neutral-primary-medium | #F3E8D8 | #2B1D14 |
| neutral-primary-strong | #EADDC6 | #3A2818 |
| neutral-secondary-soft | #FBF4E7 | #1F1610 |
| neutral-secondary | #FBF4E7 | #18110B |
| neutral-secondary-medium | #F3E8D8 | #2B1D14 |
| neutral-secondary-strong | #EADDC6 | #3A2818 |
| neutral-tertiary-soft | #F3E8D8 | #2B1D14 |
| neutral-tertiary | #F3E8D8 | #2B1D14 |
| neutral-tertiary-medium | #E2D9C8 | #3A2818 |
| neutral-quaternary | #E2D9C8 | #3A2818 |
| quaternary-medium | #C8B89E | #4D3624 |
| gray | #A89378 | #5C4938 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #FBEDE3 | #3D1F0E |
| brand-soft | #F4D5BF | #5A2E15 |
| brand | #C56A3C | #D8825A |
| brand-medium | #E89971 | #5A2E15 |
| brand-strong | #9C4F25 | #C56A3C |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #EEF3E0 | #1F2A0F |
| success | #6B8B3F | #88A85C |
| success-medium | #DCE6BD | #2B3818 |
| success-strong | #4A6128 | #6B8B3F |
| danger-soft | #FBE8E0 | #3D140A |
| danger | #B83A1F | #D54A2A |
| danger-medium | #F4C9B5 | #6B1F0E |
| danger-strong | #8B2812 | #B83A1F |
| warning-soft | #FBEFD8 | #3D2810 |
| warning | #D49032 | #E5A045 |
| warning-medium | #F4DCA8 | #6B4A18 |
| warning-strong | #9C6418 | #D49032 |

### Button Glint (custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,244,231,0.30) | rgba(251,244,231,0.10) |
| `--color-1-700` | rgba(43,29,20,0.18) | rgba(0,0,0,0.30) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #2B1D14 | #2B1D14 |
| dark-strong | #18110B | #3A2818 |
| disabled | #EADDC6 | #2B1D14 |

### Accent (warm, earthen-leaning)
| Token | Value (same both modes) |
|---|---|
| purple | #9C5C9E |
| sky | #6B9BB8 |
| teal | #5C8B82 |
| pink | #C5708B |
| cyan | #6B9BA8 |
| fuchsia | #B85C8E |
| indigo | #6E6E9C |
| orange | #D88B5C |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #2B1D14 | #2B1D14 |
| heading | #2B1D14 | #FBF4E7 |
| body | #5C4938 | #C8B89E |
| body-subtle | #8B6F5B | #A89378 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #F4D5BF | #5A2E15 |
| fg-brand | #C56A3C | #D8825A |
| fg-brand-strong | #9C4F25 | #E89971 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #4A6128 | #88A85C |
| fg-success-strong | #3D5020 | #A6C278 |
| fg-danger | #8B2812 | #E5704F |
| fg-danger-strong | #6B1F0E | #E5907A |
| fg-warning-subtle | #D49032 | #E5A045 |
| fg-warning | #6B4A18 | #E5BD78 |
| fg-disabled | #A89378 | #5C4938 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #D4A018 | #E5BD45 |
| fg-info | #4A4A78 | #A0A0D8 |
| fg-purple | #8B4F88 | #B878B8 |
| fg-purple-strong | #6B3A6B | #D4A0D4 |
| fg-cyan | #4A788B | #78A8B8 |
| fg-indigo | #4F4F8B | #7878B8 |
| fg-pink | #B85C7C | #B85C7C |
| fg-lime | #708B3C | #A8C278 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #2B1D14 | #5C4938 |
| border-buffer | #FBF4E7 | #18110B |
| border-buffer-medium | #FBF4E7 | #2B1D14 |
| border-buffer-strong | #FBF4E7 | #3A2818 |
| border-muted | #F3E8D8 | #1F1610 |
| border-light-subtle | #F0E5D0 | #1F1610 |
| border-light | #EADDC6 | #2B1D14 |
| border-light-medium | #E2D9C8 | #3A2818 |
| border-default-subtle | #E2D9C8 | #1F1610 |
| border-default | #E2D9C8 | #2B1D14 |
| border-default-medium | #E2D9C8 | #3A2818 |
| border-default-strong | #C8B89E | #5C4938 |
| border-success-subtle | #C5D89E | #2B3818 |
| border-success | #6B8B3F | #4A6128 |
| border-danger-subtle | #F0BFA8 | #6B1F0E |
| border-danger | #8B2812 | #8B2812 |
| border-warning-subtle | #F0CB8E | #6B4A18 |
| border-warning | #D49032 | #D49032 |
| border-brand-subtle | #F4D5BF | #5A2E15 |
| border-brand-light | #C56A3C | #C56A3C |
| border-brand | #C56A3C | #D8825A |
| border-dark-subtle | #2B1D14 | #3A2818 |
| border-purple | #9C5C9E | #9C5C9E |
| border-orange | #D88B5C | #D88B5C |

## Semantic Usage Rules

- Page/section backgrounds: surface cream tone — every section uses the same single surface color (no alternating)
- Cards over surface: warmer cream tone (one shade darker than surface) for clear visual separation
- Primary buttons: brand terracotta with a subtle gradient (top-left lighter brand → bottom-right darker brand)
- Headings: heading text color set in the display serif
- Body text: body text color set in the body sans
- CTA links: fg-brand text color
- Default borders: border-default (warm parchment outline)
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No alternating background colors between adjacent sections — single surface color across the page
- No introducing a second saturated accent — terracotta is the sole interaction driver
- No manual light/dark value swapping — let the token system handle it
