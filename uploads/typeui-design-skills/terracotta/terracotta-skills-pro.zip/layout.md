# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 32px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1152px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`) set in the display serif
2. Leading paragraph (DM Sans, generous line-height)
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 96px vertical padding
- The single page surface background (neutral-primary-soft) — sections do NOT alternate background colors
- A centered container (max-width 1152px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below

The visual rhythm between sections comes from typography, cards, generous whitespace, and the warm cream surface — not from background contrast.

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `keyframes`. Use a motion library only when CSS cannot achieve the behavior.
- Prioritize calm, slow motion in line with the editorial aesthetic — 200–400ms eases, no bouncy or aggressive motion.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Backgrounds & Visual Depth

- The page is intentionally flat in surface color — depth comes from cards (warmer cream), borders (parchment), and subtle shadows.
- Avoid decorative gradient meshes, noise textures, or heavy patterns on backgrounds — the warmth of the palette is the texture.
- Gradients are reserved for buttons (top-left lighter → bottom-right darker), never for sections or cards.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis).

## Must

- All sections: consistent 96px vertical padding
- All sections: identical surface background — never alternate
- All containers: max-width 1152px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Consistent vertical rhythm, generous whitespace — negative space is a feature
- Layouts readable and properly spaced on both desktop and mobile
