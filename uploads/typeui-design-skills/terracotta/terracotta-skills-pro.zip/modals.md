# Modals

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `buttons.md`, `inputs.md`

## Core Specs

### Overlay (Backdrop)
- Fixed, covers full screen
- Z-index: 40
- Background: warm ink (#2B1D14) at 55% opacity
- Backdrop blur: small amount

### Content Container
- Background: neutral-tertiary
- Radius: 16px (base)
- Shadow: shadow-xl
- Padding: 24px

## Anatomy

### Header
- Bottom border: border-default
- Top corners rounded (16px)
- Title: DM Serif Display, 24px, regular weight (400), heading color
- Close button: Ghost variant from `buttons.md`, 6px padding

### Body
- Vertical padding: 24px
- Vertical spacing between elements: 24px
- Text: DM Sans, 16px, 1.7 line-height, body color

### Footer
- Top border: border-default
- Bottom corners rounded (16px)

## Variants

### Default (Information)
Standard header + body + footer with primary/secondary action buttons.

### Pop-up (Confirmation)
Centered text, prominent icon, reduced padding:
- Body: 24px padding, text centered
- Icon: centered, 16px bottom margin, 48x48px, body-subtle color

### Form Modal
Body contains inputs following `inputs.md`. Vertical spacing between form elements: 16px.

## Rules

- Backdrop covers full screen with fixed positioning
- Content: neutral-tertiary background (the card cream), 16px radius, shadow-xl
- Header/Footer separated by border-default borders
- Close button must be present and functional
- Accessibility: `role="dialog"`, implement focus trap in code
- Dark mode automatic via token system
