# Pagination

> Dependencies: `colors.md`, `radius.md`

## Container

Font: DM Sans, 14px. Items displayed as flex with -1px overlap for seamless borders.

## Pagination Item

- Layout: flex, centered both axes
- Size: 40x40px
- Text: body color, medium weight
- Background: neutral-tertiary
- Border: 1px, border-default-medium
- Hover: neutral-tertiary-medium background, heading text
- Focus: no outline
- Overlap: -1px left margin

## Previous / Next Buttons

- Horizontal padding: 14px, height: 40px
- First item: 16px radius on inline-start side
- Last item: 16px radius on inline-end side

## Active Page Item

- Text: white
- Background: brand
- Hover text: white (stays same)

## Rules

- Display as flex with -1px child overlap for seamless borders
- Items: neutral-tertiary background, border-default-medium border, body text
- Active: white text on brand background — terracotta marks the current page
- First item: rounded start (16px), Last item: rounded end (16px)
- All items need hover and focus states
