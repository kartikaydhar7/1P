# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 16px | Buttons, cards, inputs, modals, sections, navbar, sidebars, tabs, popovers |
| default | 8px | Badges, tooltips, dropdown items, small controls |
| sm | 4px | Checkboxes, tiny elements |
| full | 9999px | Pills, avatars, toggles, dot indicators |

## Rules

- 16px is the default radius across the product — every primary surface (cards, buttons, inputs, modals, panels) uses it
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
- Soft corners reinforce the warm, human aesthetic — never use sharp 0px corners on primary surfaces
