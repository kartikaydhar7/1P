# Shadows

Shadows use a warm, brown-tinted base (rather than pure black) so elevations sit naturally on the cream surface.

| Token | Value |
|---|---|
| shadow-2xs | `0 1px rgb(43 29 20 / 0.04)` |
| shadow-xs | `0 1px 2px 0 rgb(43 29 20 / 0.05)` |
| shadow-sm | `0 1px 3px 0 rgb(43 29 20 / 0.08), 0 1px 2px -1px rgb(43 29 20 / 0.06)` |
| shadow-md | `0 4px 8px -2px rgb(43 29 20 / 0.08), 0 2px 4px -2px rgb(43 29 20 / 0.06)` |
| shadow-lg | `0 10px 20px -4px rgb(43 29 20 / 0.10), 0 4px 8px -4px rgb(43 29 20 / 0.06)` |
| shadow-xl | `0 20px 30px -8px rgb(43 29 20 / 0.12), 0 8px 12px -6px rgb(43 29 20 / 0.08)` |
| shadow-2xl | `0 28px 56px -16px rgb(43 29 20 / 0.22)` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls, lightweight cards | shadow-xs or shadow-sm |
| Standard cards, popovers, dropdowns | shadow-sm or shadow-md |
| Prominent cards, sticky surfaces | shadow-md or shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use only these tokens — no custom box-shadow values
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
- Shadows are warm and soft — never use cold, hard, or neon-style shadows
