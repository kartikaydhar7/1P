# Sidebars

> Dependencies: `colors.md`, `radius.md`, `typography.md`, `badges.md`, `alerts.md`

## Core Specs

- Background: neutral-tertiary (warmer card cream — sets the sidebar apart from the page surface)
- Right border: 1px, border-default (for left-sidebar); left border for right-sidebar
- Width: 256px

## Anatomy

### Outer Container
Hidden on mobile, visible at small breakpoint. Needs a toggle/trigger for mobile.

### Inner Wrapper
- Full height, vertical scroll overflow
- Padding: 12px horizontal, 16px vertical

### Navigation List
- Vertical spacing: 8px between items
- Font: DM Sans, medium weight

### Navigation Item
- Layout: flex, vertically centered
- Padding: 10px horizontal, 10px vertical
- Text: heading color
- Radius: 16px (base)
- Hover: neutral-tertiary-medium background
- Transition: colors, 200ms
- Icon: 20x20px, body color, hover → heading color, 150ms transition
- Label: 12px left margin from icon

### Active Item
- Background: brand-softer
- Text: fg-brand-strong
- Optional: 2px brand left-edge accent for stronger emphasis

### Separator
- 16px top padding, 16px top margin
- Top border: border-default
- 8px vertical spacing below

### Bottom CTA / Card
- Padding: 16px
- Top margin: 24px
- Radius: 16px (base)
- Background: brand-softer
- Can also use any alert variant from `alerts.md`

## Rules

- Responsive: hidden on mobile with a trigger mechanism
- Icons: 20x20px, body color (hover: heading color)
- Multi-level menus: indent with 44px left padding
- Spacing follows 8px grid
- Only neutral, brand, or status tokens — no arbitrary colors
