# Tables

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Wrapper

- Horizontal scroll overflow
- Background: neutral-tertiary
- Radius: 16px (base)
- Border: 1px, border-default
- Shadow: shadow-xs

## Table Element

- Full width, left-aligned text (right-aligned for RTL)
- Font: DM Sans, 14px, body color

## Table Head

- Font: DM Sans, 13px, body-subtle color, medium weight, uppercase, 0.05em letter-spacing
- Background: neutral-tertiary-medium
- Bottom border: border-default
- Cell padding: 24px horizontal, 14px vertical

## Table Body

- Row background: neutral-tertiary
- Row bottom border: border-default (omit on last row to avoid doubling with wrapper border)
- Row hover: neutral-tertiary-medium background (optional)
- Row header: medium weight, heading color, no-wrap
- Cell padding: 24px horizontal, 16px vertical

## Rules

- Wrapper must have horizontal scroll overflow for responsive scrolling
- Last row: omit bottom border to avoid doubling with wrapper border
- Row headers: always `scope="row"` for semantic structure
- Hover on rows is optional
- No arbitrary hex codes — use token colors only
