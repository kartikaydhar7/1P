# Tooltips & Popovers

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Tooltips

### Core Specs
- Padding: 12px horizontal, 8px vertical
- Font: DM Sans, 13px, medium weight
- Radius: 8px (default)
- Shadow: shadow-sm
- Transition: opacity, 200ms

### Dark (Default)
- Background: dark (warm ink)
- Text: white
- Border: transparent

### Light
- Background: neutral-tertiary
- Text: heading color
- Border: 1px, border-default

## Popovers

### Core Specs
- Background: neutral-tertiary
- Radius: 16px (base)
- Shadow: shadow-md
- Border: 1px, border-default
- Transition: opacity, 200ms

### Header / Title
- Padding: 14px horizontal, 10px vertical
- Background: neutral-tertiary-medium
- Bottom border: border-default
- Font: DM Sans, 14px, medium weight, heading color

### Body / Content
- Standard: 14px horizontal, 10px vertical padding; DM Sans, 14px, body color
- Rich: 16px padding; DM Sans, 14px, body color

## Arrows

- Size: 8x8px rotated 45deg
- Color must match the background of the tooltip/popover variant

## Rules

- Tooltips: 8px radius (small inline UI hint)
- Popovers: 16px radius (matches the surface system)
- Dark tooltips: warm-ink background, white text
- Light tooltips/popovers: semantic neutral background + border tokens
- Arrows match parent background color
