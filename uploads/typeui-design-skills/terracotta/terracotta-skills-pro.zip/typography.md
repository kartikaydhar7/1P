# Typography

> Dependencies: `colors.md`

## Core Rules

- **Heading font:** DM Serif Display, serif — used for `h1`–`h6` and any display text
- **Body / UI font:** DM Sans, sans-serif — used for paragraphs, buttons, labels, inputs, navigation, and every non-heading element
- **Headings:** regular weight (400), heading text color, slight negative letter-spacing for the largest sizes
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 60px | 1.05 | -0.9px | 24px |
| `h2` | 44px | 1.15 | -0.5px | — |
| `h3` | 36px | 1.2 | -0.3px | — |
| `h4` | 30px | 1.25 | -0.2px | — |
| `h5` | 24px | 1.3 | — | — |
| `h6` | 20px | 1.35 | — | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 44px | 36px |
| `h2` | 36px | 30px |
| `h3` | 30px | 26px |
| `h4` | 26px | 22px |
| `h5` | 22px | 20px |
| `h6` | 18px | 18px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.05 for any heading.

## Paragraphs

### Leading Paragraph
- Font: DM Sans
- Size: 20px
- Weight: normal
- Color: body
- Line-height: 1.7
- Max width: ~70 characters

### Normal Paragraph
- Font: DM Sans
- Size: 17px
- Weight: normal
- Color: body
- Line-height: 1.7
- Max width: ~65 characters

### Small Supporting Copy
- Font: DM Sans
- Size: 14px
- Weight: normal
- Color: body-subtle
- Line-height: 1.6
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 15px | 500 (medium) |
| Input labels | 14px or 16px | 500 (medium) |
| Captions / meta / badges | 12px or 14px | 500 (medium) |
| Eyebrow / overline label | 12px | 500, uppercase, 0.1em letter-spacing |

UI labels use DM Sans. Do not apply paragraph line-height (1.7) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline (offset 2–3px), hover → no underline
- **CTA links:** fg-brand color, medium weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` rendered with the heading serif italic for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, 0.1em letter-spacing, 12px or 14px

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via the token system). Font, size, weight, and spacing remain constant.
