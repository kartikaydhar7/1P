# Design System — Agent Instructions

This skill describes the visual design language for all UI output. Every component, layout, and page should follow the design specs in the module files below. These describe *what the design looks like* — you choose how to implement the styles.

## Style
A playful Tetris-arcade interface inspired by a neobrutalist cartridge aesthetic: bold display typography (Bangers) layered over an Open Sans body, high-contrast alternating sections in soft blue (#DFE7FF) and near-black (#1C202B), a hot-pink brand color (#E22D6D) that pops against everything, signature 8px dashed borders on cards, hard offset shadow slabs in #1C202B, clip-path notched buttons that "slam" into their shadow on press, and a subtle tetris/grid pattern threaded behind every page.

## Before Writing Any Code

1. **Read every module that applies.** For a landing page, read at minimum: `layout.md`, `typography.md`, `colors.md`, `buttons.md`, `cards.md`, `shadows.md`, `radius.md`, `borders.md`. Do NOT write any markup until you have loaded all relevant modules.

## Critical Rules

- **Tokens are AGNOSTIC, NOT framework classes:** The tokens defined in the `.md` files (like `neutral-primary-soft`, `heading`, `border-default`, `--gradient-from`) are agnostic design system tokens, NOT literal classes for any specific CSS framework. Do not blindly use them as utility class names — you must explicitly map them in your styling layer (CSS custom properties, theme config, etc.) yourself.

- **Cross-reference modules.** A card containing buttons must satisfy both `cards.md` AND `buttons.md`.
- **Dark mode is automatic.** The CSS custom properties resolve differently in light/dark via `@media (prefers-color-scheme: dark)`. Never manually swap colors.
- **Every interactive element needs hover, focus, and disabled states** — defined in the relevant module.
- **Use semantic HTML:** proper heading hierarchy (`h1`→`h6`), `<button>` for actions, `<a>` for navigation, ARIA attributes where needed.
- **The 4 design signatures of this system, applied everywhere:**
  1. Bangers display headings (uppercase) + Open Sans body
  2. 8px dashed borders on cards and feature surfaces
  3. Hard offset shadow slabs in #1C202B (no blur)
  4. Alternating section backgrounds (#DFE7FF ↔ #1C202B) with a subtle square/tetris pattern behind every page

## Module Index

### Foundation (read first for any UI work)
- [colors.md](colors.md) — all background, text, and border color tokens
- [typography.md](typography.md) — heading scale (Bangers), paragraphs (Open Sans), labels, links
- [layout.md](layout.md) — spacing rhythm, containers, alternating sections, tetris pattern, animation
- [radius.md](radius.md) — border-radius scale (intentionally tight)
- [shadows.md](shadows.md) — hard offset slab elevation tokens
- [borders.md](borders.md) — border widths and styles (8px dashed signature)

### Components
- [buttons.md](buttons.md) — clip-path notched buttons, shadow slab, gradient brand variant, glint effect
- [button-group.md](button-group.md) — grouped button structure
- [cards.md](cards.md) — 8px dashed border card structure, background, interactivity
- [inputs.md](inputs.md) — form controls, labels, states
- [alerts.md](alerts.md) — alert variants
- [badges.md](badges.md) — badge variants, sizes, dismissible chips
- [lists.md](lists.md) — list components
- [avatars.md](avatars.md) — avatar variants, sizes, indicators
- [icon-shapes.md](icon-shapes.md) — icon containers

### Complex Components
- [accordion.md](accordion.md) — accordion variants
- [dropdown.md](dropdown.md) — dropdown menus
- [modals.md](modals.md) — modal dialogs
- [tabs.md](tabs.md) — tab navigation
- [tables.md](tables.md) — table structure
- [pagination.md](pagination.md) — pagination components
- [sidebars.md](sidebars.md) — sidebar navigation
- [radios-checkboxes-toggle.md](radios-checkboxes-toggle.md) — selection controls
- [tooltips-popovers.md](tooltips-popovers.md) — tooltips and popovers
- [content.md](content.md) — grid system, responsiveness
