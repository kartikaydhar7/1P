# Accordion

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`

## Core Specs

- **Wrapper:** full width, 4px solid border (border-default #1C202B), 4px radius — clips first/last item corners
- **Item separator:** 2px solid bottom border (border-default) on every item except last

## Trigger (Button)

- **Layout:** flex, space-between, full width
- **Padding:** 24px horizontal, 18px vertical
- **Font:** Open Sans, 16px, 700 (bold), uppercase, 0.5px letter-spacing
- **Text color:** heading
- **Background:** neutral-primary (white)
- **Hover:** neutral-tertiary (#DFE7FF) background
- **Focus:** outline none, 3px ring in brand color (#E22D6D)
- **Transition:** background 150ms
- **Open state:** brand-softer (#FFE5EE) background

## Panel (Content)

- **Padding:** 24px horizontal, 20px vertical
- **Background:** neutral-primary
- **Top border:** 2px solid, border-default
- **Font:** Open Sans, 16px, body color, 1.6 line-height

## Chevron Icon

- Size: 18x18px
- Color: heading text color
- Closed: 0deg rotation
- Open: 180deg rotation
- Transition: transform, 150ms

## Variants

### Default (Collapse)
One panel open at a time. Items stacked inside a single shared bordered/rounded wrapper.

### Separated Cards
Each item is independent — has its own **8px dashed border** (matches the card signature), 4px radius, and shadow-sm hard offset slab. 12px bottom margin between items. No shared outer border.

### Always Open
Multiple panels can expand simultaneously. Same styling as Default.

### Flush
No outer border. Trigger and panel have transparent backgrounds. Only 2px bottom border dividers between items. Use inside containers that already provide a background.

## States

| State | Trigger appearance |
|---|---|
| Closed | heading text, neutral-primary background |
| Open | heading text, brand-softer background |
| Hover | neutral-tertiary background |
| Focus | 3px brand ring, no outline |
| Disabled | fg-disabled text, not-allowed cursor, no hover/focus |
