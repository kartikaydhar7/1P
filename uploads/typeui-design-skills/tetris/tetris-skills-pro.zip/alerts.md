# Alerts

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`

## Core Specs

- **Padding:** 20px
- **Radius:** 4px (base)
- **Border:** 4px dashed (matches the dashed signature, scaled down from cards)
- **Shadow:** shadow-sm (6px 6px 0 0 #1C202B)
- **Heading:** Open Sans, 16px, 700 (bold), uppercase
- **Body:** Open Sans, 14px, 400, 1.55 line-height

## Variants

### Brand
- **Background:** brand-softer (#FFE5EE)
- **Border:** 4px dashed border-brand (#E22D6D)
- **Text:** fg-brand-strong

### Success
- **Background:** success-soft
- **Border:** 4px dashed border-success
- **Text:** fg-success-strong

### Danger
- **Background:** danger-soft
- **Border:** 4px dashed border-danger
- **Text:** fg-danger-strong

### Warning
- **Background:** warning-soft
- **Border:** 4px dashed border-warning
- **Text:** fg-warning
