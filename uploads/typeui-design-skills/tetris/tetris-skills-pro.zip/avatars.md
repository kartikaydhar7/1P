# Avatars

> Dependencies: `colors.md`, `radius.md`, `borders.md`

## Core Specs

- **Circular shape:** fully rounded (9999px)
- **Rounded square shape:** 4px radius (blocky tetris feel)
- **Default size:** 40x40px
- **Image fit:** cover
- **Default frame:** 2px solid border-default (#1C202B) on every avatar so they read as crisp tokens against any background

## Sizes

| Size | Dimensions | Radius |
|---|---|---|
| Extra Small | 18x18px | 2px |
| Small | 24x24px | 2px |
| Base | 32x32px | 4px |
| Large | 44x44px | 4px |
| XL | 56x56px | 4px |
| 2XL | 64x64px | 4px |

## Bordered Avatar

- 4px padding, fully rounded, 3px outline in border-default color
- Alternative: 3px box-shadow ring in border-brand color for emphasis

## Stacked Avatars

- Displayed in a row (flex)
- Each avatar: 40x40px, fully rounded, 3px solid border in border-default (#1C202B)
- Overlap: -14px negative margin on all except first

### Stacked Counter
- Same size as avatars (40x40px), fully rounded
- Background: dark (#1C202B), text: white, 12px Open Sans 700 uppercase
- Same overlap margin as other avatars

## Avatar with Text

- Flex row, 12px gap between avatar and text
- Avatar: 40x40px, fully rounded, cover fit, 2px border-default frame
- Name: heading color, Open Sans 700, uppercase, 14px, 0.5px letter-spacing
- Subtitle: 14px Open Sans 400, body color
