# Badges

> Dependencies: `colors.md`, `radius.md`, `typography.md`

## Core Specs

- **Border:** 2px solid (use `border-default` token unless variant overrides)
- **Default radius:** 2px (blocky to match the tetris aesthetic)
- **Pill radius:** 9999px
- **Font:** Open Sans, 700 (bold), uppercase, 0.5px letter-spacing

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Default (small) | 12px | 8px | 3px |
| Large | 14px | 10px | 5px |

## Variants

### Brand
- **Background:** brand-softer (#FFE5EE)
- **Border:** 2px solid border-brand (#E22D6D)
- **Text:** fg-brand-strong

### Alternative (Neutral Soft)
- **Background:** neutral-primary (white)
- **Border:** 2px solid border-default (#1C202B)
- **Text:** heading

### Gray (Neutral Medium)
- **Background:** neutral-tertiary (#DFE7FF)
- **Border:** 2px solid border-default (#1C202B)
- **Text:** heading

### Danger
- **Background:** danger-soft
- **Border:** 2px solid border-danger
- **Text:** fg-danger-strong

### Success
- **Background:** success-soft
- **Border:** 2px solid border-success
- **Text:** fg-success-strong

### Warning
- **Background:** warning-soft
- **Border:** 2px solid border-warning
- **Text:** fg-warning

### Dark
- **Background:** dark (#1C202B)
- **Border:** 2px solid dark
- **Text:** white

### Tetromino Accent (decorative)
- **Background:** any accent token from `colors.md` (purple, sky, teal, orange, indigo)
- **Border:** 2px solid border-default (#1C202B)
- **Text:** white or dark depending on contrast

## Pill Badges

Use 9999px radius instead of 2px on any variant.

## Badges with Icons

- Icon size (default): 12x12px
- Icon size (large): 14x14px
- Icon spacing: 4px margin next to label

## Icon-only Badge

Square shape — equalize dimensions to 24x24px, no horizontal text padding.

## Dismissible Badges

Badge content + a close button. Close button hover backgrounds per variant:

| Variant | Close button hover background |
|---|---|
| Brand | brand-soft |
| Alternative | neutral-tertiary |
| Gray | neutral-quaternary |
| Danger | danger-medium |
| Success | success-medium |
| Warning | warning-medium |

## Dot / Notification Badge

- Positioned absolutely: -4px top, -4px right
- Size: 12x12px, fully rounded
- 2px border in border-buffer color
- Background: brand (#E22D6D)
