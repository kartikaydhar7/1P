# Borders

## Width Scale

| Context | Width |
|---|---|
| Subtle dividers (table rows, list separators) | 1px |
| Inputs, small controls | 2px |
| Default (sections, panels, alerts) | 4px |
| Cards & feature surfaces | **8px** |
| Hero / emphasis frame | 10px or 12px |

## Style Scale

| Style | Default usage |
|---|---|
| solid | Inputs, dividers, status accents, alerts |
| **dashed** | **Cards (8px), feature panels, dropzones, decorative frames** — the signature treatment of the system |
| double | Special hero callouts only |

## Rules

- The signature look is the **8px dashed border** on cards and feature surfaces — apply it consistently across the product
- Default border color is `border-default` (#1C202B in light, #DFE7FF in dark) so the dashed silhouette pops on both backgrounds
- Use solid borders for inputs and controls where dashed would hurt legibility
- Components in the same family must use matching border widths AND styles
- Never mix dashed and solid borders within a single component
- Brand-emphasized panels swap border color to `border-brand` (#E22D6D) while keeping the 8px dashed style

## Usage

| Context | Width | Style |
|---|---|---|
| Inputs / selects / textareas | 2px default; 3px on focus or error | solid |
| Buttons | 0 (silhouette via clip-path, see `buttons.md`) | — |
| Cards / containers | 8px | dashed |
| Sections / hero frames | 10–12px | dashed |
| Tooltip / popover | 2px | solid |
| Dropdown menu | 4px | solid |
| Modal | 4px | solid |
