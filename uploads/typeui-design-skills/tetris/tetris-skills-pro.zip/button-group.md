# Button Groups

> Dependencies: `buttons.md`, `colors.md`, `radius.md`, `shadows.md`

## Core Specs

- **Wrapper:** inline-flex, 0px radius (clip-path silhouettes already handle the corners), shadow-sm offset slab in #1C202B applied to the WRAPPER (not the children)
- **Children spacing:** 4px gap between buttons (instead of overlap, because clip-path notches make true overlapping look broken)
- **Buttons inside the group must NOT have individual shadow slabs.** Only the wrapper has the offset slab.
- **Clip-path:** individual buttons keep their own clip-path notches per `buttons.md`

## Anatomy

### Wrapper
- Display: inline-flex
- Gap: 4px between children
- Radius: 0
- Shadow: shadow-sm (6px 6px 0 0 #1C202B)
- Padding: 4px (so the inner buttons stay clear of the wrapper edge and the slab reads cleanly)

### Each Button
- Follows `buttons.md` for size, padding, font, color, glint, and hover
- No individual offset shadow slab
- Active: still translates 3px down/right inside the wrapper

## Rules

- Buttons inside groups follow all styles from `buttons.md` (background, clip-path silhouette, glint, focus rings) EXCEPT individual shadow slabs
- Icon-only buttons: 18x18px icon, match height of text buttons
- Group wrapper background can be neutral-primary or neutral-tertiary to give the cluster a subtle base plate
