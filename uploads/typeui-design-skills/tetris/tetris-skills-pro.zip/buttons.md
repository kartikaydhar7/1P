# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs (every button except ghost and disabled)

- **Shape (clip-path):** every button is clipped into a notched/beveled tetris-block silhouette using:
  ```
  clip-path: polygon(calc(100% - 10px) 0px, 100% 10px, 100% 100%, 10px 100%, 0px calc(100% - 10px), 0px 0px);
  ```
  Because clip-path replaces the rounded corner, the CSS `border-radius` token is set to `0`.
- **Hard offset shadow (the “stacked block” look from the reference site):** every non-ghost / non-disabled button is wrapped or layered with a pseudo-element that sits behind it and is offset down + right. The pseudo-element uses the SAME clip-path so the silhouette matches:
  ```
  /* shadow layer (::before or wrapper background) */
  background: var(--gradient-shadow); /* #1C202B */
  clip-path: polygon(calc(100% - 10px) 0px, 100% 10px, 100% 100%, 10px 100%, 0px calc(100% - 10px), 0px 0px);
  height: calc(100% + 6px);
  width: calc(100% + 6px);
  position: absolute;
  top: 6px;
  left: 6px;
  z-index: -1;
  ```
  This produces the chunky stacked-block drop shadow seen on the reference site (a flat dark slab behind every button).
- **Border:** 0 (the silhouette is provided by clip-path); use `border: 0` and let color come from the background.
- **Press interaction:** on `:active`, translate the button by `translate(3px, 3px)` so it visually slams into its shadow slab.
- **Glint effect:** every button except ghost and disabled gets a combined inset highlight + soft outer glow that layers on top of the silhouette:
  - `inset var(--color-1-400) 0 6px 0px -5px, var(--color-1-700) 0 4px 10px -5px`
- **Font weight:** 700 (bold)
- **Font:** Open Sans, uppercase, 1px letter-spacing
- **Box sizing:** border-box
- **Transition:** transform 80ms ease-out, color 120ms, filter 120ms

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 16px | 8px |
| Small | 14px | 20px | 10px |
| Base (default) | 16px | 24px | 12px |
| Large | 18px | 28px | 14px |
| Extra large | 20px | 36px | 18px |

## Variants

### Brand (Primary)
- **Background:** linear gradient `linear-gradient(135deg, var(--gradient-from) 0%, var(--gradient-to) 100%)` — i.e. `#ff512f` → `#dd2476`
- **Border:** 0
- **Text:** white
- **Shadow slab:** `--gradient-shadow` (#1C202B), 6px down/right, same clip-path
- **Hover:** brightness 1.05 filter, shadow slab unchanged
- **Active:** translate 3px 3px (slams into shadow)
- **Focus ring:** 4px brand-medium outline-offset 2px (uses outline because clip-path crops borders)
- **Glint:** yes

### Secondary
- **Background:** neutral-primary-soft (#DFE7FF)
- **Border:** 0
- **Text:** heading
- **Shadow slab:** `--gradient-shadow` (#1C202B), 6px offset
- **Hover:** brightness 1.05
- **Active:** translate 3px 3px
- **Focus ring:** 4px brand-medium outline-offset 2px
- **Glint:** yes

### Tertiary
- **Background:** white (light) / neutral-secondary-medium (dark)
- **Border:** 0
- **Text:** heading
- **Shadow slab:** `--gradient-shadow` (#1C202B), 6px offset
- **Hover:** brightness 0.97
- **Active:** translate 3px 3px
- **Focus ring:** 4px neutral-tertiary-soft outline-offset 2px
- **Glint:** yes

### Success
- **Background:** success token
- **Border:** 0
- **Text:** white
- **Shadow slab:** `--gradient-shadow` (#1C202B), 6px offset
- **Hover:** brightness 1.05
- **Focus ring:** 4px success-medium outline-offset 2px
- **Glint:** yes

### Danger
- **Background:** danger token (#E22D6D)
- **Border:** 0
- **Text:** white
- **Shadow slab:** `--gradient-shadow` (#1C202B), 6px offset
- **Hover:** brightness 1.05
- **Focus ring:** 4px danger-medium outline-offset 2px
- **Glint:** yes

### Warning
- **Background:** warning token (#FFB020)
- **Border:** 0
- **Text:** dark (#1C202B)
- **Shadow slab:** `--gradient-shadow` (#1C202B), 6px offset
- **Hover:** brightness 1.05
- **Focus ring:** 4px warning-medium outline-offset 2px
- **Glint:** yes

### Dark
- **Background:** dark token (#1C202B)
- **Border:** 0
- **Text:** white
- **Shadow slab:** brand (#E22D6D), 6px offset (high-energy contrast variant)
- **Hover:** brightness 1.1
- **Focus ring:** 4px neutral-tertiary outline-offset 2px
- **Glint:** yes

### Ghost (NO shadow slab, NO glint)
- **Background:** transparent
- **Border:** 0
- **Clip-path:** still applied for silhouette consistency
- **Text:** heading color
- **Hover:** neutral-tertiary background fill
- **Focus ring:** 4px neutral-tertiary outline-offset 2px
- **No shadow slab, no glint effect, no active translate**

### Disabled (NO shadow slab, NO glint)
- **Background:** disabled token
- **Border:** 0
- **Clip-path:** still applied for silhouette consistency
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow slab, no glint, no active translate**

## Pill Buttons

For pill-shaped CTAs (rare — only on hero/PLAY NOW–style emphasis), skip the clip-path notches and use `border-radius: 9999px` instead. The shadow slab still applies and uses `border-radius: 9999px` to match.

## Icons in Buttons

- Icon size: 18x18px (base) / 20x20px (large)
- Spacing: 10px gap between icon and label
- Layout: inline-flex, vertically centered
- Icons inherit the text color of the button variant
