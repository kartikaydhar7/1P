# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `borders.md`, `typography.md`

## Core Specs

- **Background:** neutral-primary (white) on light sections, neutral-primary-medium on dark sections
- **Border:** **8px dashed**, border-default color (#1C202B in light mode, #DFE7FF in dark mode)
- **Radius:** 4px (kept tight to read as a tetris block — the dashed border carries the personality)
- **Shadow:** shadow-md — a hard offset slab (no blur) of #1C202B, 8px down + 8px right, to match the chunky block aesthetic
- **Padding:** 24px (base) / 32px (feature cards)

## Card Heading

- Desktop: 28px, Bangers font, uppercase, heading color
- Mobile: 22px, Bangers font, uppercase, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-primary
- Border: 8px dashed, border-default
- Radius: 4px
- Shadow: shadow-md (hard offset slab in #1C202B)
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: border color shifts to brand (#E22D6D), shadow offset increases to 10px down + 10px right
- Active: translates 4px down + 4px right (slams into shadow)
- Transition: transform 100ms ease-out, border-color 150ms, box-shadow 150ms
- Cursor: pointer

### Featured / Brand Card
- Background: brand-softer (#FFE5EE) on light, brand-soft on dark
- Border: 8px dashed, border-brand (#E22D6D)
- Shadow: shadow-md hard offset slab in #1C202B

## Decorative Treatments

- Cards may include a subtle tetris/grid pattern overlay (see `layout.md`) at 8–12% opacity behind the content
- Optional small tetromino badge (24x24px) clipped into a corner using accent colors from `colors.md`

## Rules

- The 8px dashed border is the signature treatment — never replace it with a solid border on standard cards
- Border color always pulls from the tokens, never raw hex
- Shadow is always the hard #1C202B offset slab — never a soft blurred drop shadow
- Cards on a dark section (#1C202B) flip border color to a light token (border-buffer or #DFE7FF)
