# Color Tokens

## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #DFE7FF | #1C202B |
| neutral-primary | #FFFFFF | #14171F |
| neutral-primary-medium | #C8D4FF | #262B38 |
| neutral-primary-strong | #A9BAFF | #333949 |
| neutral-secondary-soft | #1C202B | #DFE7FF |
| neutral-secondary | #14171F | #FFFFFF |
| neutral-secondary-medium | #262B38 | #C8D4FF |
| neutral-secondary-strong | #333949 | #A9BAFF |
| neutral-tertiary-soft | #EFF3FF | #1C202B |
| neutral-tertiary | #DFE7FF | #262B38 |
| neutral-tertiary-medium | #C8D4FF | #333949 |
| neutral-quaternary | #B7C4ED | #404858 |
| quaternary-medium | #A9BAFF | #4A5568 |
| gray | #94A3CC | #5A6478 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #FFE5EE | #36081C |
| brand-soft | #FBC0D2 | #5A0E2F |
| brand | #E22D6D | #FF4683 |
| brand-medium | #F58FAD | #6F133B |
| brand-strong | #B11F55 | #E22D6D |

### Brand Gradient (used by primary brand buttons and emphasis surfaces)
| Variable | Value |
|---|---|
| `--gradient-from` | #ff512f |
| `--gradient-to` | #dd2476 |
| `--gradient-shadow` | #1C202B |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #E4FFE0 | #0A2E14 |
| success | #2BB04A | #3DD865 |
| success-medium | #C7F6C0 | #16572A |
| success-strong | #1F7A33 | #2BB04A |
| danger-soft | #FFE0EA | #3D0818 |
| danger | #E22D6D | #FF4683 |
| danger-medium | #FBC0D2 | #6F133B |
| danger-strong | #B11F55 | #E22D6D |
| warning-soft | #FFF1D6 | #4A2A05 |
| warning | #FFB020 | #FFC247 |
| warning-medium | #FFD984 | #6E4108 |
| warning-strong | #B57400 | #FFB020 |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.4) | rgba(255,255,255,0.18) |
| `--color-1-700` | rgba(28,32,43,0.6) | rgba(0,0,0,0.55) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #1C202B | #1C202B |
| dark-strong | #0F1218 | #2A2F3D |
| disabled | #EFF3FF | #262B38 |

### Accent (Tetromino-inspired)
| Token | Value (same both modes) |
|---|---|
| purple | #A23DDB |
| sky | #2DC8E2 |
| teal | #2DCFA0 |
| pink | #E22D6D |
| cyan | #2DC8E2 |
| fuchsia | #E22DBF |
| indigo | #4D5BFF |
| orange | #FF8B2D |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #1C202B | #1C202B |
| heading | #1C202B | #FFFFFF |
| body | #2F3645 | #DFE7FF |
| body-subtle | #4A5468 | #B7C4ED |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #FBC0D2 | #6F133B |
| fg-brand | #E22D6D | #FF6B95 |
| fg-brand-strong | #B11F55 | #FBC0D2 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #1F7A33 | #2BB04A |
| fg-success-strong | #16572A | #3DD865 |
| fg-danger | #B11F55 | #FF6B95 |
| fg-danger-strong | #851740 | #FBC0D2 |
| fg-warning-subtle | #B57400 | #FFB020 |
| fg-warning | #6E4108 | #FFC247 |
| fg-disabled | #94A3CC | #5A6478 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FFB020 | #FFC247 |
| fg-info | #4D5BFF | #A9BAFF |
| fg-purple | #A23DDB | #C977FF |
| fg-purple-strong | #7E2EAB | #E0B3FF |
| fg-cyan | #2DC8E2 | #5BD8EA |
| fg-indigo | #4D5BFF | #6F7CFF |
| fg-pink | #E22D6D | #FF6B95 |
| fg-lime | #8BCF2D | #A6E055 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #1C202B | #DFE7FF |
| border-buffer | #FFFFFF | #1C202B |
| border-buffer-medium | #DFE7FF | #262B38 |
| border-buffer-strong | #C8D4FF | #333949 |
| border-muted | #EFF3FF | #14171F |
| border-light-subtle | #DFE7FF | #1C202B |
| border-light | #C8D4FF | #262B38 |
| border-light-medium | #B7C4ED | #333949 |
| border-default-subtle | #1C202B | #DFE7FF |
| border-default | #1C202B | #DFE7FF |
| border-default-medium | #1C202B | #DFE7FF |
| border-default-strong | #0F1218 | #FFFFFF |
| border-success-subtle | #C7F6C0 | #16572A |
| border-success | #1F7A33 | #2BB04A |
| border-danger-subtle | #FBC0D2 | #6F133B |
| border-danger | #B11F55 | #E22D6D |
| border-warning-subtle | #FFD984 | #6E4108 |
| border-warning | #B57400 | #FFB020 |
| border-brand-subtle | #FBC0D2 | #6F133B |
| border-brand-light | #F58FAD | #FF4683 |
| border-brand | #E22D6D | #FF4683 |
| border-dark-subtle | #1C202B | #333949 |
| border-purple | #A23DDB | #C977FF |
| border-orange | #FF8B2D | #FFA655 |

## Semantic Usage Rules

- Page/section backgrounds alternate between **neutral-primary-soft (#DFE7FF light blue)** and **neutral-secondary-soft (#1C202B near-black)** for a high-contrast Tetris-arcade rhythm
- On dark sections (neutral-secondary-soft), text uses white/heading-on-dark and borders use border-buffer for contrast
- Primary buttons: brand gradient (`--gradient-from` → `--gradient-to`) with `--gradient-shadow` offset shadow
- Headings: heading text color, always paired with the Bangers display font (see typography.md)
- Body text: body text color, Open Sans font
- CTA links: fg-brand text color
- Default borders: border-default — solid 4px or **dashed 8px** for cards and decorative panels
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
- No soft pastel-only sections — at least one alternating section per page must use the dark (#1C202B) treatment to keep the arcade feel
