# Dropdown

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `inputs.md`, `typography.md`

## Core Specs

### Chevron Icon
- Size: 18x18px
- Spacing: 8px left margin, -2px right margin
- Color: inherits from trigger button

### Menu Container
- Background: neutral-primary (white)
- Border: 4px solid, border-default (#1C202B)
- Radius: 4px (base)
- Shadow: shadow-md (8px 8px 0 0 #1C202B hard offset slab)
- Z-index: elevated above content

### Menu List
- Padding: 8px
- Font: Open Sans, 14px, body color, 600 (semibold)

### Menu Item
- Layout: inline-flex, vertically centered, full width
- Padding: 12px horizontal, 10px vertical
- Radius: 2px (default)
- Hover: brand-softer (#FFE5EE) background, fg-brand-strong text
- Transition: background 120ms

## Trigger Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Small | 14px | 16px | 10px |
| Base | 16px | 20px | 12px |
| Large | 18px | 24px | 14px |

## Icon-only Trigger

- Padding: 10px
- Min size: 44x44px
- Icon: 22x22px

## Variants

### Default
- Menu width: 200px, items have 2px radius

### With Divider
- 2px top border (border-default) between child groups, skip first group

### With Header
- Header padding: 16px horizontal, 14px vertical
- Bottom border: 2px border-default
- Name: heading color, 14px Open Sans 700 uppercase
- Email: body-subtle color, 14px, truncated

### With Icons
- Icon before label: 18x18px, 10px right margin, body color
- On hover, icon color changes to fg-brand

### With Checkbox / Radio
- Inputs: 16x16px, 2px radius, 2px border-default, focus ring in brand-soft
- Helper text: 12px, body-subtle color, 4px top margin

### With Search
- Search input at top of menu following `inputs.md` specs
- Left icon: 14px left padding, input 40px left padding

### Scrollable
- Max height: 240px, vertical scroll overflow

## States

| State | Appearance |
|---|---|
| Focused trigger | no outline, 3px brand ring |
| Hover item | brand-softer background, fg-brand-strong text |
| Active/open item | brand-soft background, fg-brand-strong text |
| Disabled item | fg-disabled text, not-allowed cursor, no pointer events |
