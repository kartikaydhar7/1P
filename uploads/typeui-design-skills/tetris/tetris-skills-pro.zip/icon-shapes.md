# Icon Shapes

> Dependencies: `colors.md`, `radius.md`, `borders.md`

## Core Specs

- Box sizing: border-box
- Icon must be perfectly centered (inline-flex, centered both axes)
- Circle: fully rounded (9999px)
- Rounded square: 4px radius (MD/LG/XL), 2px radius (XS/SM) — kept tight to read as a tetris block
- All containers carry a 2px solid border-default frame so they punch against the soft blue / dark sections

## Sizes

| Size | Container | Icon |
|---|---|---|
| XS | 24x24px | 14x14px |
| SM | 32x32px | 18x18px |
| MD | 44x44px | 22x22px |
| LG | 52x52px | 26x26px |
| XL | 64x64px | 32x32px |

## Color Variants

### Brand
- Shape: rounded square (tetris block)
- Background: brand-softer (#FFE5EE)
- Border: 2px solid border-brand (#E22D6D)
- Icon color: fg-brand-strong

### Gray
- Shape: rounded square
- Background: neutral-tertiary (#DFE7FF)
- Border: 2px solid border-default
- Icon color: heading

### Danger
- Shape: rounded square
- Background: danger-soft
- Border: 2px solid border-danger
- Icon color: fg-danger-strong

### Success
- Shape: rounded square
- Background: success-soft
- Border: 2px solid border-success
- Icon color: fg-success-strong

### Warning
- Shape: rounded square
- Background: warning-soft
- Border: 2px solid border-warning
- Icon color: fg-warning

### Tetromino Accent (decorative)
- Shape: rounded square
- Background: any accent token (purple / sky / teal / orange / indigo / fuchsia)
- Border: 2px solid border-default
- Icon color: white
