# Inputs

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `typography.md`

## Core Specs

- **Display:** block, full width
- **Radius:** 4px (base)
- **Border:** 2px solid, border-default (#1C202B)
- **Background:** neutral-primary (white)
- **Shadow:** shadow-xs (4px 4px 0 0 #1C202B hard offset slab)
- **Font:** Open Sans, 16px, heading color
- **Padding:** 14px horizontal, 12px vertical
- **Placeholder:** body-subtle color
- **Transition:** border-color 150ms, box-shadow 150ms

## Label

- Display: block
- Font: Open Sans, 14px, 700 (bold), uppercase, 0.5px letter-spacing, heading color
- Margin bottom: 8px
- Label `htmlFor` must match the input `id`

## States

### Default
- Border: 2px border-default (#1C202B)
- Background: neutral-primary
- Shadow: shadow-xs

### Hover
- Border: 2px border-brand-light
- Shadow: shadow-xs

### Focus
- No outline
- Border: 3px border-brand (#E22D6D)
- Shadow: shadow-sm (6px 6px 0 0 #1C202B)

### Success
- Border: 3px border-success
- Shadow: shadow-xs (color stays #1C202B)

### Error / Danger
- Border: 3px border-danger (#E22D6D / #B11F55)
- Shadow: shadow-xs (color stays #1C202B)

### Disabled
- Background: disabled
- Border: 2px border-light
- Shadow: none
- Text: fg-disabled
- Cursor: not-allowed

## Input with Icons

- Icon size: 18x18px
- Icon color: body
- Container: relative positioned wrapper
- Start icon: absolutely positioned left, 14px left padding — input gets 40px left padding
- End icon: absolutely positioned right, 14px right padding — input gets 40px right padding
- Icons vertically centered within the wrapper

## Rules

- Every input must have a unique `id`
- Every label must have a matching `htmlFor`
- Padding: 14px horizontal, 12px vertical unless overridden for icon variants
- No arbitrary hex or hardcoded colors
- Inputs use solid borders (not dashed) for legibility — the dashed treatment is reserved for cards / panels
