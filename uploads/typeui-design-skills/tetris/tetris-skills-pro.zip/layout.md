# Layout & Spacing

## Spacing Rhythm

Base unit: **8px** (mirrors a single tetris cell). All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1200px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`) in the Bangers display font, uppercase
2. Leading paragraph (Open Sans)
3. Normal paragraph(s) (Open Sans)
4. Lists, CTA links, or component grids

## Section Pattern (Alternating)

Each section has:
- 96px vertical padding
- An **alternating background color** that gives the page its arcade rhythm:
  - Odd / hero / content sections: **neutral-primary-soft (#DFE7FF)** — the soft blue base
  - Even / contrast sections: **neutral-secondary-soft (#1C202B)** — the dark slab; flip text to white/heading-on-dark
- A centered container (max-width 1200px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below

The alternating pattern (#DFE7FF → #1C202B → #DFE7FF → #1C202B …) is mandatory for any landing-style page; never run two consecutive sections with the same background.

## Background Pattern (Tetris Grid)

Every page MUST carry a subtle tetris-themed background pattern behind section content. Two acceptable treatments — pick one and use it consistently across the page:

### A) Square Grid Pattern
- 32x32px square grid drawn with 1px lines
- Light sections: line color `rgba(28, 32, 43, 0.08)` over the #DFE7FF background
- Dark sections: line color `rgba(255, 255, 255, 0.06)` over the #1C202B background
- Implemented as a repeating `background-image` (linear-gradient or SVG tile) at the section level

### B) Subtle Tetromino Scatter
- A handful of small tetromino silhouettes (8–12 per viewport, 24–48px each) scattered behind the content using accent colors at 6–10% opacity
- Tetrominoes use the accent palette from `colors.md` (purple, sky, teal, orange, pink, indigo)
- Must sit BEHIND content (z-index: 0) and never compete with foreground text or components

Patterns must be `pointer-events: none` and `user-select: none`.

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use a motion library only when CSS cannot achieve the behavior.
- Tetris-flavored motion is encouraged: a gentle "drop" easing (`cubic-bezier(0.5, 0, 0.75, 0)`) on initial reveals, button press translations of 3px down/right that "slam" into the shadow slab.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Backgrounds & Visual Depth

- Default to layered, atmospheric backgrounds rather than flat solid fills.
- Apply contextual treatments — the tetris grid/tetromino scatter, hard offset shadow slabs (#1C202B), 8px dashed borders, gradient meshes, dramatic outline strokes — that align with the arcade brand.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.

## Must

- All sections: consistent 96px vertical padding
- All containers: max-width 1200px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Backgrounds alternate between #DFE7FF and #1C202B
- Subtle tetris/grid pattern present on every page
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
