# Lists

> Dependencies: `colors.md`, `typography.md`

## Core Specs

- Item spacing: 16px vertical gap between list items
- Text: Open Sans, body color, 16px, 1.6 line-height

## List Icons

- Size: 22x22px (square tetris-block silhouette preferred over generic check marks)
- Prevent squishing: no shrink
- Spacing: 12px right margin between icon and text
- Active/featured icon: fg-brand color (#E22D6D)
- Neutral icon: heading color
- Optional icon container: 2px solid border-default frame, 2px radius (mini tetris tile)

## Inactive / Disabled Items

Strikethrough text with body color decoration on the list item.

## Pattern

Vertical flex list with 16px gap. Each item is a flex row with centered alignment — icon (22x22, no-shrink, 12px right margin) followed by a span of body-colored Open Sans text. For "feature lists" on dark sections, flip text to white and icon to fg-brand for high contrast against #1C202B.
