# Modals

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `buttons.md`, `inputs.md`, `typography.md`

## Core Specs

### Overlay (Backdrop)
- Fixed, covers full screen
- Z-index: 40
- Background: #1C202B at 70% opacity
- Backdrop blur: 4px

### Content Container
- Background: neutral-primary (white)
- Radius: 4px (base)
- Border: 4px solid border-default (#1C202B) — solid here for legibility (the dashed treatment is reserved for cards inside the modal body)
- Shadow: shadow-xl (14px 14px 0 0 #1C202B hard offset slab)
- Padding: 24px
- Optional: a subtle 32x32 grid pattern at 6% opacity behind the body content (matches `layout.md` background pattern)

## Anatomy

### Header
- Bottom border: 2px solid border-default
- Title: Open Sans 700 / Bangers for hero modals, 24px, uppercase, heading color
- Close button: Ghost variant from `buttons.md`, 8px padding, 18x18 icon

### Body
- Vertical padding: 24px
- Vertical spacing between elements: 24px
- Text: Open Sans 16px, 1.6 line-height, body color

### Footer
- Top border: 2px solid border-default
- Padding: 20px
- Action layout: flex, end-aligned, 12px gap between buttons

## Variants

### Default (Information)
Standard header + body + footer with primary/secondary action buttons (see `buttons.md`).

### Pop-up (Confirmation)
Centered text, prominent icon, reduced padding:
- Body: 24px padding, text centered
- Icon: centered, 16px bottom margin, 56x56px, brand or status color, framed with 2px border-default

### Form Modal
Body contains inputs following `inputs.md`. Vertical spacing between form elements: 20px.

## Rules

- Backdrop covers full screen with fixed positioning
- Content: neutral-primary background, 4px solid border, shadow-xl hard offset slab
- Header/Footer separated by 2px border-default
- Close button must be present and functional
- Accessibility: `role="dialog"`, implement focus trap in code
- Dark mode automatic via token system (border + slab flip to light tokens)
