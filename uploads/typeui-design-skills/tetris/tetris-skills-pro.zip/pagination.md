# Pagination

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `typography.md`

## Container

Font: Open Sans, 14px, 700 (bold), uppercase. Items displayed as flex with 4px gap (no overlap — clip-path / hard borders read better with breathing room).

## Pagination Item

- Layout: flex, centered both axes
- Size: 40x40px
- Text: heading color, Open Sans 700
- Background: neutral-primary (white)
- Border: 2px solid border-default (#1C202B)
- Radius: 2px
- Hover: brand-softer (#FFE5EE) background, fg-brand-strong text
- Focus: 3px brand outline, outline-offset 2px
- Active press: translate 2px down/right (slams into a 4px shadow-xs offset slab)

## Previous / Next Buttons

- Horizontal padding: 14px, height: 40px
- Use the same 2px border-default frame and 2px radius as item buttons
- Optionally use the brand button silhouette (clip-path from `buttons.md`) for the very first/last in a hero pagination

## Active Page Item

- Text: white
- Background: brand (#E22D6D)
- Border: 2px solid border-default
- Shadow: shadow-xs offset slab in #1C202B
- Hover: stays brand background, brightness 1.05

## Rules

- Display as flex with 4px gap between children
- Items: white background, 2px solid border-default, heading text
- Active: brand background (#E22D6D), white text, hard offset slab
- All items need hover and focus states
- Never use blurred drop shadows — only the offset slab from `shadows.md`
