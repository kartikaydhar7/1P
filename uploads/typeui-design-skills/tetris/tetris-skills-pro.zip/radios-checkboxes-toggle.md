# Radios, Checkboxes & Toggles

> Dependencies: `colors.md`, `radius.md`, `borders.md`

## Checkbox

- Size: 20x20px
- Radius: 2px (mini tetris tile)
- Border: 2px solid border-default (#1C202B)
- Background: neutral-primary
- Focus ring: 3px, brand-soft, outline-offset 2px
- Checked: brand background (#E22D6D), white check icon

### Disabled
- Border: 2px border-light
- Background: disabled
- Text: fg-disabled

## Radio

- Size: 20x20px
- Radius: fully rounded
- Border: 2px solid border-default
- Background: neutral-primary
- Focus ring: 3px, brand-soft
- Checked: 2px border-brand frame, inner dot in brand (#E22D6D)

### Disabled
- Border: 2px border-light
- Text: fg-disabled

Group all radio items under the same `name` attribute.

## Toggle

### Track
- Width: 44px, Height: 24px
- Radius: 2px (rectangular tetris-block toggle, NOT pill — fits the blocky aesthetic)
- Border: 2px solid border-default (#1C202B)
- Background: neutral-tertiary (#DFE7FF)
- Focus-within ring: 3px, brand-soft outline-offset 2px
- Checked track: brand background (#E22D6D)
- Disabled track: disabled background

### Thumb
- 16x16px square, 2px radius
- Background: white
- Border: 2px solid border-default
- Slides 20px left↔right with a 120ms ease-out transition

### Disabled
- Track: disabled background
- Label: fg-disabled text

## Rules

- All selection inputs must have `id` matching label `htmlFor`
- Focus states use the brand-soft ring on every control
- Disabled states: no hover/focus interaction
- The toggle is intentionally squared (NOT a pill) to match the tetris/blocky personality
