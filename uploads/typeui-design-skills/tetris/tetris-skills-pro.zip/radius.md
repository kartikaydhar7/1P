# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 4px | Cards, sections, inputs, modals — kept tight so surfaces read as tetris blocks |
| default | 2px | Badges, tooltips, dropdown items, small controls |
| sm | 0px | Buttons (silhouette is provided by clip-path), checkboxes, hard-edged tiles |
| full | 9999px | Pills, avatars, toggles, dot indicators, hero PLAY-NOW CTAs |

## Rules

- 4px is the default radius across the product — we lean blocky to match the tetris aesthetic
- Buttons use a `clip-path` notch instead of a radius (see `buttons.md`); their CSS `border-radius` is 0
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
- The visual personality comes from the dashed borders + clip-path + offset shadow slabs, NOT from large rounded corners
