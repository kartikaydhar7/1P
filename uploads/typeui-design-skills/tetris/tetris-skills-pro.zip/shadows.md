# Shadows

All shadows in this system are **hard offset slabs** (no blur, no spread) in the dark token color #1C202B — matching the chunky stacked-block look on the reference site. Soft Material-style blurred shadows are not used.

| Token | CSS value |
|---|---|
| shadow-2xs | `2px 2px 0 0 #1C202B` |
| shadow-xs | `4px 4px 0 0 #1C202B` |
| shadow-sm | `6px 6px 0 0 #1C202B` |
| shadow-md | `8px 8px 0 0 #1C202B` |
| shadow-lg | `10px 10px 0 0 #1C202B` |
| shadow-xl | `14px 14px 0 0 #1C202B` |
| shadow-2xl | `18px 18px 0 0 #1C202B` |

## Dark Mode

On dark sections (#1C202B background) and in dark mode, the slab color flips to a light contrast token so the offset stays visible:

| Token | Dark-mode CSS value |
|---|---|
| shadow-2xs | `2px 2px 0 0 #DFE7FF` |
| shadow-xs | `4px 4px 0 0 #DFE7FF` |
| shadow-sm | `6px 6px 0 0 #DFE7FF` |
| shadow-md | `8px 8px 0 0 #DFE7FF` |
| shadow-lg | `10px 10px 0 0 #DFE7FF` |
| shadow-xl | `14px 14px 0 0 #DFE7FF` |
| shadow-2xl | `18px 18px 0 0 #DFE7FF` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs |
| Inputs, small controls, lightweight cards | shadow-xs or shadow-sm |
| Standard cards, popovers, dropdowns | shadow-md |
| Buttons (via the offset shadow-slab pseudo-element from `buttons.md`) | shadow-sm equivalent (6px) |
| Prominent cards, sticky surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use only these tokens — no custom box-shadow values
- All shadows are hard offset slabs (no blur, no spread radius) — never use blurred drop shadows
- Slab color = #1C202B on light surfaces, #DFE7FF (or border-default token) on dark surfaces
- Keep elevation steps intentional; avoid jumping multiple levels
- Hover/focus on interactive elevated elements: increase the offset by 2px (e.g. shadow-md → shadow-lg) for a "lift" feel, paired with a 2px translate on press
- Never stack multiple shadow tokens on one element
- Buttons get their slab via the dedicated pseudo-element described in `buttons.md` — do NOT also apply a shadow token to the button itself
