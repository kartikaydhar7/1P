# Sidebars

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `typography.md`, `badges.md`, `alerts.md`

## Core Specs

- Background: neutral-primary (white) on light pages, neutral-secondary-soft (#1C202B) on dark pages
- Right border: 4px solid border-default (#1C202B) — left border for right-sidebar (light/dark flips automatically via tokens)
- Width: 272px

## Anatomy

### Outer Container
Hidden on mobile, visible at small breakpoint. Needs a toggle/trigger for mobile.

### Inner Wrapper
- Full height, vertical scroll overflow
- Padding: 16px horizontal, 20px vertical

### Navigation List
- Vertical spacing: 6px between items
- Font: Open Sans, 14px, 700 (bold), uppercase, 0.5px letter-spacing

### Navigation Item
- Layout: flex, vertically centered
- Padding: 12px horizontal, 10px vertical
- Text: heading color
- Radius: 2px
- Border: 2px solid transparent (reserved so the active state can swap to a visible border without a layout shift)
- Hover: brand-softer background (#FFE5EE), fg-brand-strong text
- Transition: background 120ms, color 120ms
- Icon: 22x22px, body color, hover → fg-brand color, 75ms transition
- Label: 12px left margin from icon

### Active Item
- Background: brand (#E22D6D)
- Text: white
- Border: 2px solid border-default (#1C202B) — gives the active row the chunky tetris-tile feel
- Shadow: shadow-2xs (2px 2px 0 0 #1C202B)
- Icon: white

### Separator
- 16px top padding, 16px top margin
- Top border: 2px solid border-default
- 8px vertical spacing below

### Bottom CTA / Card
- Padding: 20px
- Top margin: 24px
- Radius: 4px
- Border: 8px dashed border-brand (matches the card signature from `cards.md`)
- Background: brand-softer (#FFE5EE)
- Can also use any alert variant from `alerts.md`

## Rules

- Responsive: hidden on mobile with a trigger mechanism
- Icons: 22x22px, body color (hover: fg-brand)
- Multi-level menus: indent with 44px left padding
- Spacing follows the 8px grid
- Only neutral, brand, or status tokens — no arbitrary colors
- Active row must use the brand background + offset slab combo so the user always sees where they are
