# Tables

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`

## Wrapper

- Horizontal scroll overflow
- Background: neutral-primary (white)
- Radius: 4px (base)
- Border: 4px solid border-default (#1C202B) — solid at this scale; the dashed treatment is reserved for cards
- Shadow: shadow-sm (6px 6px 0 0 #1C202B)

## Table Element

- Full width, left-aligned text (right-aligned for RTL)
- Font: Open Sans, 14px, body color

## Table Head

- Font: Open Sans, 14px, 700 (bold), uppercase, 0.5px letter-spacing, heading color
- Background: neutral-tertiary (#DFE7FF)
- Bottom border: 3px solid border-default
- Cell padding: 24px horizontal, 14px vertical

## Table Body

- Row background: neutral-primary
- Row bottom border: 2px solid border-default (omit on last row to avoid doubling with wrapper border)
- Row hover: brand-softer (#FFE5EE) background (optional)
- Row header: 700 weight uppercase, heading color, no-wrap
- Cell padding: 24px horizontal, 16px vertical

### Zebra Stripe Variant
Alternating rows use neutral-tertiary-soft background to evoke the tetris-grid pattern.

## Rules

- Wrapper must have horizontal scroll overflow for responsive scrolling
- Last row: omit bottom border to avoid doubling with wrapper border
- Row headers: always `scope="row"` for semantic structure
- Hover on rows is optional but recommended for interactive tables
- No arbitrary hex codes — use token colors only
