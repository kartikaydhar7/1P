# Tabs

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`

## Core Specs

- Typography: Open Sans, 14px, 700 (bold), uppercase, 0.5px letter-spacing, body color
- Transitions: background 150ms, color 150ms, border-color 150ms

## Variants

### 1. Underline (Default)

**Wrapper:** 3px solid bottom border, border-default (#1C202B)

**Tab Item:**
- Padding: 18px horizontal, 16px vertical
- Bottom border: 4px solid transparent (reserved so the active state can swap without layout shift)
- Top corners: 2px radius
- Transition: color 150ms, border-color 150ms

| State | Appearance |
|---|---|
| Active | fg-brand text, 4px solid border-brand bottom border |
| Inactive | transparent bottom border; hover → heading text, border-default-strong bottom border |
| Disabled | fg-disabled text, not-allowed cursor |

### 2. Pills (Tetris Tiles)

**Tab Item:**
- Padding: 16px horizontal, 12px vertical
- Radius: 2px (blocky tile)
- Border: 2px solid border-default (#1C202B)
- Background: neutral-primary
- Transition: background 150ms, color 150ms

| State | Appearance |
|---|---|
| Active | brand background (#E22D6D), white text, shadow-xs offset slab in #1C202B |
| Inactive | body text; hover → brand-softer background, fg-brand-strong text |
| Disabled | fg-disabled text, not-allowed cursor |

### 3. Full Width

Children sit in a row with a 4px gap (no overlap — the hard borders need air).

**Tab Item:**
- Full width, centered text
- Padding: 18px horizontal, 16px vertical
- Background: neutral-primary
- Border: 2px solid border-default
- Radius: 2px
- Transition: background 150ms

| State | Appearance |
|---|---|
| Active | brand background (#E22D6D), white text |
| First / Last item | match siblings (no special radius — keep the row uniform) |

## Tabs with Icons

- Icon size: 18x18px or 22x22px
- Spacing: 10px right margin
- Layout: inline-flex, centered
- Icons inherit the text color of the tab state
