# Tooltips & Popovers

> Dependencies: `colors.md`, `radius.md`, `borders.md`, `shadows.md`, `typography.md`

## Tooltips

### Core Specs
- Padding: 12px horizontal, 8px vertical
- Font: Open Sans, 13px, 700 (bold), uppercase, 0.5px letter-spacing
- Radius: 2px (default)
- Border: 2px solid border-default
- Shadow: shadow-xs (4px 4px 0 0 #1C202B hard offset slab)
- Transition: opacity 200ms

### Dark (Default)
- Background: dark (#1C202B)
- Text: white
- Border: 2px solid #1C202B (matches background)

### Light
- Background: neutral-primary (white)
- Text: heading
- Border: 2px solid border-default

### Brand
- Background: brand (#E22D6D)
- Text: white
- Border: 2px solid border-default

## Popovers

### Core Specs
- Background: neutral-primary
- Radius: 4px (base)
- Shadow: shadow-md (8px 8px 0 0 #1C202B hard offset slab)
- Border: 4px solid border-default
- Transition: opacity 200ms

### Header / Title
- Padding: 14px horizontal, 10px vertical
- Background: neutral-tertiary (#DFE7FF)
- Bottom border: 2px solid border-default
- Font: Open Sans, 14px, 700 (bold), uppercase, heading color

### Body / Content
- Standard: 14px horizontal, 10px vertical padding; Open Sans 14px, body color
- Rich: 18px padding; Open Sans 14px, body color

## Arrows

- Size: 10x10px rotated 45deg
- Color must match the background of the tooltip/popover variant
- Border: 2px solid border-default on the two visible edges so the arrow reads as a continuation of the bordered shape

## Rules

- Tooltips: 2px radius, 2px border
- Popovers: 4px radius, 4px border
- Dark tooltips: dark background, white text
- Light tooltips/popovers: neutral background + 2px border-default
- Arrows match parent background color and border treatment
- Always use the hard offset slab shadow — never a blurred drop shadow
