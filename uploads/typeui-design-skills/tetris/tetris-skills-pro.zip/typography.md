# Typography

> Dependencies: `colors.md`

## Core Rules

- **Display / Heading font:** **Bangers** (Google Fonts: https://fonts.google.com/specimen/Bangers) — bold cartoon-arcade marquee font, used for ALL headings (`h1`–`h6`) and large display labels
- **Body / UI font:** **Open Sans** (Google Fonts: https://fonts.google.com/specimen/Open+Sans) — used for paragraphs, buttons, badges, inputs, navigation, and any non-heading text
- **Headings:** weight 400 (Bangers is a single-weight display face), heading text color, slightly increased letter-spacing for the arcade feel
- **Body copy:** Open Sans, weight 400 normal / 600 semibold / 700 bold, body text color
- Never use the brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels
- **Font loading:** Both fonts must be loaded at the app/root level. Never override the font family on individual components except where this file states otherwise

## Heading Scale (Bangers)

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 96px | 1 | 2px | 32px |
| `h2` | 64px | 1.05 | 1.5px | 24px |
| `h3` | 44px | 1.1 | 1px | 20px |
| `h4` | 32px | 1.15 | 1px | 16px |
| `h5` | 26px | 1.2 | 0.5px | 12px |
| `h6` | 22px | 1.25 | 0.5px | 12px |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 64px | 44px |
| `h2` | 48px | 36px |
| `h3` | 36px | 28px |
| `h4` | 28px | 24px |
| `h5` | 22px | 20px |
| `h6` | 20px | 18px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.0 for any heading — Bangers is condensed enough that very tight line-heights still read.

### Heading Treatments

- Headings should be `text-transform: uppercase` to match the arcade marquee feel
- Hero `h1` may use the **brand gradient** (`--gradient-from` → `--gradient-to`) as a `background-clip: text` fill, paired with a 4–6px dark text-shadow for depth
- Outline headings (used on dark sections): white text with a 3px `-webkit-text-stroke` in #1C202B

## Paragraphs (Open Sans)

### Leading Paragraph
- Size: 20px
- Weight: 400
- Color: body
- Line-height: 1.65
- Max width: ~70 characters

### Normal Paragraph
- Size: 16px
- Weight: 400
- Color: body
- Line-height: 1.65
- Max width: ~65 characters

### Small Supporting Copy
- Size: 14px
- Weight: 400
- Color: body
- Line-height: 1.55
- Use only for helper text, legal text, captions, metadata.

## UI Labels (Open Sans)

| Context | Size | Weight |
|---|---|---|
| Button labels | 16px | 700 (bold), uppercase, 1px letter-spacing |
| Input labels | 14px or 16px | 600 (semibold) |
| Captions / meta / badges | 12px or 14px | 700 (bold), uppercase, 0.5px letter-spacing |

Do not apply paragraph line-height (1.65) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, 2px solid underline, hover → underline color shifts to brand-strong
- **CTA links:** fg-brand color, 700 weight, uppercase, underline on hover

## Emphasis

- `<strong>` for high-priority emphasis in body text — uses 700 weight
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps eyebrow labels: Open Sans 700, 12px or 14px, 1.5px letter-spacing — pair with a brand-colored bullet or arrow

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, font family, and spacing remain constant. On dark sections (#1C202B background), prefer the outline-heading treatment for any non-hero headings to maintain the playful arcade contrast.
