# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-primary-soft with backdrop-filter blur (12px) for glassmorphism on gradient backgrounds
- **Border:** 1px, border-default color with a subtle top-edge highlight (1px inset border using rgba(255,255,255,0.15))
- **Radius:** 20px (base)
- **Shadow:** shadow-md

## Card Heading

- Desktop: 20px, medium weight, heading color
- Mobile: 16px, medium weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-primary-soft with backdrop-filter blur (12px)
- Border: 1px, border-default
- Radius: 20px
- Shadow: shadow-md
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: neutral-secondary-medium background, shadow-lg elevation
- Transition: colors, shadow
- Cursor: pointer

## Rules

- Background: neutral-primary-soft with backdrop-filter blur (12px)
- Border: 1px, border-default
- Radius: 20px
- Shadow: shadow-md
- Interactive hover: neutral-secondary-medium background, shadow-lg
- Non-interactive: no hover styles
