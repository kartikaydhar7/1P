# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #FFF8F3 | #1E0F07 |
| neutral-primary | #FFF5EE | #160A04 |
| neutral-primary-medium | #FFECE0 | #2E1A10 |
| neutral-primary-strong | #FFE2D1 | #3F2518 |
| neutral-secondary-soft | #FFEFE5 | #1E0F07 |
| neutral-secondary | #FFEBDC | #160A04 |
| neutral-secondary-medium | #FFE3D0 | #2E1A10 |
| neutral-secondary-strong | #FFD9C0 | #3F2518 |
| neutral-tertiary-soft | #FFD5BA | #1E0F07 |
| neutral-tertiary | #FFCBAB | #2E1A10 |
| neutral-tertiary-medium | #FFC09B | #3F2518 |
| neutral-quaternary | #FFB388 | #3F2518 |
| quaternary-medium | #FFA777 | #523426 |
| gray | #E89468 | #523426 |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #FFF3EC | #3D1E0E |
| brand-soft | #FDE0D0 | #6B2E14 |
| brand | #FA824D | #FB9567 |
| brand-medium | #FDCBB2 | #6B2E14 |
| brand-strong | #D4602A | #FA824D |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #EEFCF4 | #002E1F |
| success | #059669 | #10B981 |
| success-medium | #D1FADF | #004D37 |
| success-strong | #047857 | #059669 |
| danger-soft | #FFF0F0 | #4A0D0D |
| danger | #DC2626 | #EF4444 |
| danger-medium | #FFE0E0 | #7F1D1D |
| danger-strong | #B91C1C | #DC2626 |
| warning-soft | #FFF8ED | #713F12 |
| warning | #F59E0B | #FBBF24 |
| warning-medium | #FEF0C7 | #713F12 |
| warning-strong | #D97706 | #F59E0B |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,200,160,0.30) | rgba(255,200,160,0.15) |
| `--color-1-700` | rgba(120,40,0,0.15) | rgba(120,40,0,0.30) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #3F2518 | #3F2518 |
| dark-strong | #2D1208 | #523426 |
| disabled | #FFECE0 | #2E1A10 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #B065F7 |
| sky | #38BDF8 |
| teal | #14B8A6 |
| pink | #F472B6 |
| cyan | #22D3EE |
| fuchsia | #D946EF |
| indigo | #6366F1 |
| orange | #FA824D |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #2D1208 | #2D1208 |
| heading | #2D1208 | #FFF8F3 |
| body | #6B4535 | #C4A090 |
| body-subtle | #8B6555 | #C4A090 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #FDCBB2 | #6B2E14 |
| fg-brand | #FA824D | #FB9567 |
| fg-brand-strong | #D4602A | #FDCBB2 |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #059669 | #047857 |
| fg-success-strong | #047857 | #10B981 |
| fg-danger | #DC2626 | #F87171 |
| fg-danger-strong | #991B1B | #FCA5A5 |
| fg-warning-subtle | #D97706 | #F59E0B |
| fg-warning | #92400E | #FBBF24 |
| fg-disabled | #C4A090 | #6B4535 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FBBF24 | #FBBF24 |
| fg-info | #3B2F15 | #E8D5A8 |
| fg-purple | #9333EA | #B065F7 |
| fg-purple-strong | #7C3AED | #DDD6FE |
| fg-cyan | #0891B2 | #22D3EE |
| fg-indigo | #6366F1 | #6366F1 |
| fg-pink | #EC4899 | #F472B6 |
| fg-lime | #65A30D | #A3E635 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #3F2518 | #523426 |
| border-buffer | #FFF8F3 | #160A04 |
| border-buffer-medium | #FFF8F3 | #2E1A10 |
| border-buffer-strong | #FFF8F3 | #3F2518 |
| border-muted | #FFF5EE | #1E0F07 |
| border-light-subtle | #FFECE0 | #1E0F07 |
| border-light | #FFECE0 | #2E1A10 |
| border-light-medium | #FFECE0 | #3F2518 |
| border-default-subtle | #FFE2D1 | #1E0F07 |
| border-default | #FECBAB | #2E1A10 |
| border-default-medium | #FECBAB | #3F2518 |
| border-default-strong | #FECBAB | #523426 |
| border-success-subtle | #BBF7D0 | #064E3B |
| border-success | #059669 | #047857 |
| border-danger-subtle | #FECACA | #7F1D1D |
| border-danger | #DC2626 | #EF4444 |
| border-warning-subtle | #FDE68A | #713F12 |
| border-warning | #D97706 | #F59E0B |
| border-brand-subtle | #FDCBB2 | #6B2E14 |
| border-brand-light | #FB9567 | #FB9567 |
| border-brand | #FA824D | #FB9567 |
| border-dark-subtle | #3F2518 | #523426 |
| border-purple | #B065F7 | #B065F7 |
| border-orange | #FA824D | #FA824D |

## Semantic Usage Rules

- Page background: ONE continuous dark gradient (near-black warm tones with subtle brand-colored radial glows) applied to the body. Sections are always transparent — NEVER set per-section backgrounds. Glassmorphic cards/panels use very subtle warm-tinted glass (5–6% opacity) on top of this dark surface.
- Primary buttons: brand background
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- The page MUST use a single dark gradient background on the body — near-black warm tones with subtle orange radial glows. NEVER use bright, white, or light backgrounds. NEVER apply per-section gradients. All sections are transparent.
- No manual light/dark value swapping — let the CSS custom properties handle it
