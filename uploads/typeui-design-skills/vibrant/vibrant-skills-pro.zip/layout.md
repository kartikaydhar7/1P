# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1152px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 96px vertical padding
- Transparent background — the page uses ONE continuous dark gradient on the body level. Individual sections NEVER set their own background color or gradient.
- A centered container (max-width 1152px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below

## Page-Level Background (Critical)

The ENTIRE page/app uses a single, continuous, dark gradient background applied to the body or root element. This gradient is dark and moody — built from near-black warm tones (#0D0604) through deep dark brown (#2D1208), with subtle warm radial glows (using brand-strong and brand at very low opacity, 7–18%) to create depth. The result is a rich, premium, dark surface where all content lives. Individual sections are always transparent and inherit this background. NEVER apply per-section gradients. NEVER use light, white, or bright backgrounds for sections.

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.

## Backgrounds & Visual Depth

- The body-level dark gradient is the ONLY background. It should feel like a single continuous dark surface with warm, subtle orange luminosity. Think deep espresso tones with hints of ember glow — never bright, never white.
- Layer glassmorphism surfaces (backdrop-filter blur, very subtle warm-tinted semi-transparent backgrounds at 5–6% opacity, subtle border highlights) on top of this dark background to create depth and separation for cards and panels.
- Apply contextual treatments — gradient meshes, noise textures, geometric patterns, layered transparencies, dramatic warm shadows, decorative borders, grain overlays — that align with the bold, futuristic brand aesthetic.
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.
- Include premium product mockups (drink cans, bottles, packaging) throughout the page to create a rich, immersive product showcase feel. Mockups should glow softly against the dark background using colored drop-shadows matching their brand accent.

## Must

- All sections: consistent 96px vertical padding
- All containers: max-width 1152px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
