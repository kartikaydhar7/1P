# Accordion

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Wrapper:** full width, 2px border (border-default color), 0px radius — sharp corners on all items
- **Item separator:** 2px bottom border (border-default) on every item except last

## Trigger (Button)

- **Layout:** flex, space-between, full width
- **Padding:** 16px horizontal, 12px vertical
- **Font:** 14px, bold weight
- **Text color:** heading
- **Background:** neutral-secondary-soft
- **Hover:** neutral-tertiary-soft background
- **Focus:** outline none, 3px dotted ring in heading color
- **Transition:** none — instant state changes
- **Open state:** neutral-tertiary-soft background

## Panel (Content)

- **Padding:** 16px horizontal, 12px vertical
- **Background:** neutral-primary-soft
- **Top border:** 2px, border-default color
- **Font:** 14px, body color, 1.5 line-height

## Chevron Icon

- Size: 16x16px
- Color: body text color
- Closed: 0deg rotation
- Open: 180deg rotation
- Transition: none — instant rotation

## Variants

### Default (Collapse)
One panel open at a time. Items stacked inside a single shared bordered/sharp-cornered wrapper.

### Separated Cards
Each item is independent — has its own 2px border, 0px radius, and shadow-xs. 8px bottom margin between items. No shared outer border.

### Always Open
Multiple panels can expand simultaneously. Same styling as Default.

### Flush
No outer border. Trigger and panel have transparent backgrounds. Only bottom border dividers between items. Use inside containers that already provide a background.

## States

| State | Trigger appearance |
|---|---|
| Closed | heading text, neutral-secondary-soft background |
| Open | heading text, neutral-tertiary-soft background |
| Hover | neutral-tertiary-soft background |
| Focus | 3px dotted heading color ring, no outline |
| Disabled | fg-disabled text, not-allowed cursor, no hover/focus |
