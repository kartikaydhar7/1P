# Alerts

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Padding:** 12px
- **Radius:** 0px (base)
- **Border:** 2px solid
- **Heading:** 14px, bold weight
- **Body:** 14px, normal weight, 1.5 line-height

## Variants

### Brand
- **Background:** brand-softer
- **Border:** 2px solid border-brand-subtle
- **Text:** fg-brand-strong

### Success
- **Background:** success-soft
- **Border:** 2px solid border-success-subtle
- **Text:** fg-success-strong

### Danger
- **Background:** danger-soft
- **Border:** 2px solid border-danger-subtle
- **Text:** fg-danger-strong

### Warning
- **Background:** warning-soft
- **Border:** 2px solid border-warning-subtle
- **Text:** fg-warning
