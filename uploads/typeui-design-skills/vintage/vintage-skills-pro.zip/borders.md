# Borders

## Width Scale

| Context | Width |
|---|---|
| Default (inputs, buttons, cards) | 2px |
| Emphasis / focus | 3px |

## Rules

- Use solid borders by default
- Dashed borders only for special cases like file dropzones
- Components in the same family must use matching border widths
- Never mix 2px and 3px borders within a single component
- All borders should contribute to the 3D beveled appearance — use light color on top/left edges and dark color on bottom/right edges for raised elements, invert for sunken elements

## Usage

| Context | Width |
|---|---|
| Inputs / selects / textareas | 2px default (sunken bevel); 3px on focus or error |
| Buttons | 2px for the raised 3D bevel effect |
| Cards / containers | 2px with 3D raised bevel; avoid stacked heavy borders |
