# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except ghost and disabled)

- **Radius:** 0px (base) — all buttons have sharp square corners
- **Border:** 2px solid
- **Shadow:** shadow-sm (3D raised bevel effect)
- **Glint effect:** Every button except ghost and disabled gets a 3D beveled box-shadow that creates a raised appearance with a bright top-left edge and dark bottom-right edge:
  - `var(--shadow-sm), inset var(--color-1-400) 0 1px 0px 0px, var(--color-1-700) 0 1px 0px 0px`
- **Font weight:** 700 (bold)
- **Font:** "Silkscreen", cursive
- **Box sizing:** border-box
- **Transition:** none — state changes are instant

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 8px | 4px |
| Small | 14px | 12px | 6px |
| Base (default) | 14px | 16px | 8px |
| Large | 16px | 20px | 10px |
| Extra large | 16px | 24px | 12px |

## Variants

### Brand
- **Background:** brand token
- **Border:** 2px outset border-default
- **Text:** heading color
- **Hover:** brand-strong background
- **Focus ring:** 3px, dotted, heading color
- **Glint:** yes

### Secondary
- **Background:** neutral-secondary-medium
- **Border:** 2px outset border-default-medium
- **Text:** body color
- **Hover:** neutral-tertiary-medium background, heading text color
- **Focus ring:** 3px, dotted, heading color
- **Glint:** yes

### Tertiary
- **Background:** neutral-primary-soft
- **Border:** 2px outset border-default
- **Text:** body color
- **Hover:** neutral-secondary-medium background, heading text color
- **Focus ring:** 3px, dotted, heading color
- **Glint:** yes

### Success
- **Background:** success token
- **Border:** 2px outset border-success
- **Text:** white
- **Hover:** success-strong background
- **Focus ring:** 3px, dotted, heading color
- **Glint:** yes

### Danger
- **Background:** danger token
- **Border:** 2px outset border-danger
- **Text:** white
- **Hover:** danger-strong background
- **Focus ring:** 3px, dotted, heading color
- **Glint:** yes

### Warning
- **Background:** warning token
- **Border:** 2px outset border-warning
- **Text:** heading color
- **Hover:** warning-strong background
- **Focus ring:** 3px, dotted, heading color
- **Glint:** yes

### Dark
- **Background:** dark token
- **Border:** 2px outset border-dark
- **Text:** white
- **Hover:** dark-strong background
- **Focus ring:** 3px, dotted, white color
- **Glint:** yes

### Ghost (NO shadow, NO glint)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color
- **Hover:** neutral-secondary-medium background
- **Focus ring:** 3px, dotted, heading color
- **No shadow, no glint effect**

### Disabled (NO shadow, NO glint)
- **Background:** disabled token
- **Border:** 2px solid border-default-medium
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no glint**

## Icons in Buttons

- Icon size: 16x16px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
