# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-primary-soft
- **Border:** 2px, outset border-default color
- **Radius:** 0px (base)
- **Shadow:** shadow-md (3D raised bevel)

## Card Heading

- Desktop: 18px, bold weight, heading color
- Mobile: 16px, bold weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: neutral-primary-soft
- Border: 2px, outset border-default
- Radius: 0px
- Shadow: shadow-md
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable)
- Same base styles as static card
- Hover: neutral-secondary-medium background
- Transition: none — instant state change
- Cursor: pointer

## Rules

- Background: neutral-primary-soft
- Border: 2px, outset border-default
- Radius: 0px
- Shadow: shadow-md
- Interactive hover: neutral-secondary-medium background
- Non-interactive: no hover styles
