# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #C0C0C0 | #2A2A2A |
| neutral-primary | #C0C0C0 | #1E1E1E |
| neutral-primary-medium | #C0C0C0 | #383838 |
| neutral-primary-strong | #C0C0C0 | #4A4A4A |
| neutral-secondary-soft | #D4D0C8 | #2A2A2A |
| neutral-secondary | #D4D0C8 | #1E1E1E |
| neutral-secondary-medium | #D4D0C8 | #383838 |
| neutral-secondary-strong | #D4D0C8 | #4A4A4A |
| neutral-tertiary-soft | #B0B0B0 | #2A2A2A |
| neutral-tertiary | #B0B0B0 | #383838 |
| neutral-tertiary-medium | #A0A0A0 | #4A4A4A |
| neutral-quaternary | #808080 | #4A4A4A |
| quaternary-medium | #808080 | #5A5A5A |
| gray | #808080 | #5A5A5A |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #E8E8E8 | #3A3A3A |
| brand-soft | #D8D8D8 | #4A4A4A |
| brand | #C0C0C0 | #C0C0C0 |
| brand-medium | #D0D0D0 | #4A4A4A |
| brand-strong | #A8A8A8 | #A8A8A8 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #C0E8C0 | #003300 |
| success | #008000 | #00AA00 |
| success-medium | #A0D8A0 | #004400 |
| success-strong | #006600 | #008000 |
| danger-soft | #FFD0D0 | #660000 |
| danger | #FF0000 | #FF0000 |
| danger-medium | #FFA0A0 | #880000 |
| danger-strong | #CC0000 | #CC0000 |
| warning-soft | #FFFFC0 | #666600 |
| warning | #FFFF00 | #FFFF00 |
| warning-medium | #FFFF80 | #666600 |
| warning-strong | #CCCC00 | #CCCC00 |

### Button Glint (CSS custom properties, used for the 3D beveled box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,1) | rgba(255,255,255,0.5) |
| `--color-1-700` | rgba(0,0,0,0.5) | rgba(0,0,0,0.7) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #000000 | #000000 |
| dark-strong | #000000 | #404040 |
| disabled | #C0C0C0 | #404040 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #800080 |
| sky | #000080 |
| teal | #008081 |
| pink | #FF00FF |
| cyan | #00FFFF |
| fuchsia | #FF00FF |
| indigo | #000080 |
| orange | #FF8000 |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #000000 | #000000 |
| heading | #000000 | #FFFFFF |
| body | #000000 | #C0C0C0 |
| body-subtle | #808080 | #A0A0A0 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #D0D0D0 | #606060 |
| fg-brand | #000080 | #8080FF |
| fg-brand-strong | #000060 | #A0A0FF |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #008000 | #006600 |
| fg-success-strong | #006600 | #00AA00 |
| fg-danger | #FF0000 | #FF4040 |
| fg-danger-strong | #CC0000 | #FF6060 |
| fg-warning-subtle | #CCCC00 | #FFFF00 |
| fg-warning | #808000 | #FFFF80 |
| fg-disabled | #808080 | #606060 |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FFFF00 | #FFFF00 |
| fg-info | #000080 | #8080FF |
| fg-purple | #800080 | #FF00FF |
| fg-purple-strong | #600060 | #FF80FF |
| fg-cyan | #008080 | #00FFFF |
| fg-indigo | #000080 | #000080 |
| fg-pink | #FF00FF | #FF00FF |
| fg-lime | #008000 | #00FF00 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #404040 | #808080 |
| border-buffer | #FFFFFF | #1E1E1E |
| border-buffer-medium | #FFFFFF | #2A2A2A |
| border-buffer-strong | #FFFFFF | #404040 |
| border-muted | #DFDFDF | #2A2A2A |
| border-light-subtle | #DFDFDF | #2A2A2A |
| border-light | #DFDFDF | #404040 |
| border-light-medium | #DFDFDF | #505050 |
| border-default-subtle | #808080 | #2A2A2A |
| border-default | #808080 | #404040 |
| border-default-medium | #808080 | #505050 |
| border-default-strong | #808080 | #606060 |
| border-success-subtle | #A0D8A0 | #003300 |
| border-success | #008000 | #006600 |
| border-danger-subtle | #FFA0A0 | #660000 |
| border-danger | #FF0000 | #CC0000 |
| border-warning-subtle | #FFFF80 | #666600 |
| border-warning | #CCCC00 | #FFFF00 |
| border-brand-subtle | #D8D8D8 | #484848 |
| border-brand-light | #A0A0A0 | #A0A0A0 |
| border-brand | #808080 | #C0C0C0 |
| border-dark-subtle | #404040 | #505050 |
| border-purple | #800080 | #800080 |
| border-orange | #FF8000 | #FF8000 |

## Semantic Usage Rules

- Page/section backgrounds: ALWAYS use #008081 (teal) — the classic desktop color. Every section and full-page background must be teal.
- Cards, windows, panels: neutral-primary-soft (silver #C0C0C0) — these sit on top of the teal desktop
- Primary buttons: brand background with 3D beveled border effect
- Headings: heading text color
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) — the teal desktop (#008081) is the only page-level background
- No manual light/dark value swapping — let the CSS custom properties handle it
