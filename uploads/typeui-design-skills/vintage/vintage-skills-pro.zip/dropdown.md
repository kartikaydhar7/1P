# Dropdown

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `inputs.md`

## Core Specs

### Chevron Icon
- Size: 16x16px
- Spacing: 6px left margin, -2px right margin
- Color: inherits from trigger button

### Menu Container
- Background: neutral-primary-soft
- Border: 2px, outset border-default
- Radius: 0px (base)
- Shadow: shadow-lg
- Z-index: elevated above content

### Menu List
- Padding: 4px
- Font: 14px, body color, bold weight

### Menu Item
- Layout: inline-flex, vertically centered, full width
- Padding: 6px horizontal, 6px vertical
- Radius: 0px (default)
- Hover: neutral-tertiary-medium background, heading text
- Transition: none — instant state change

## Trigger Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Small | 14px | 12px | 6px |
| Base | 14px | 16px | 8px |
| Large | 16px | 20px | 10px |

## Icon-only Trigger

- Padding: 8px
- Min size: 44x44px
- Icon: 20x20px

## Variants

### Default
- Menu width: 176px, items have 0px radius

### With Divider
- Top border (border-default) between child groups, skip first group

### With Header
- Header padding: 12px horizontal, 8px vertical
- Bottom border: border-default
- Name: heading color, 14px, bold weight
- Email: body-subtle color, 14px, truncated

### With Icons
- Icon before label: 16x16px, 8px right margin, body color
- On hover, icon color changes to heading

### With Checkbox / Radio
- Inputs: 16x16px, 0px radius, focus ring in brand-soft
- Helper text: 12px, body-subtle color, 2px top margin

### With Search
- Search input at top of menu following `inputs.md` specs
- Left icon: 8px left padding, input 32px left padding

### Scrollable
- Max height: 192px, vertical scroll overflow

## States

| State | Appearance |
|---|---|
| Focused trigger | no outline, 3px dotted heading color ring |
| Hover item | neutral-tertiary-medium background, heading text |
| Active/open item | neutral-tertiary-soft background, heading text |
| Disabled item | fg-disabled text, not-allowed cursor, no pointer events |
