# Inputs

> Dependencies: `colors.md`, `radius.md`

## Core Specs

- **Display:** block, full width
- **Radius:** 0px (base)
- **Border:** 2px, inset border-default-medium (sunken 3D bevel — dark top-left, light bottom-right)
- **Background:** white (#FFFFFF)
- **Shadow:** none — depth conveyed through inset border bevel
- **Font:** 14px, heading color, "Silkscreen", cursive
- **Padding:** 8px horizontal, 6px vertical
- **Placeholder:** body-subtle color
- **Transition:** none — instant state changes

## Label

- Display: block
- Font: 14px, bold weight, heading color
- Margin bottom: 8px
- Label `htmlFor` must match the input `id`

## States

### Default
- Border: 2px inset border-default-medium
- Background: white (#FFFFFF)

### Hover
- Border: 2px inset border-default-strong

### Focus
- No outline
- Border: 2px inset border-brand
- Ring: 3px, dotted, heading color

### Success
- Border: 2px inset border-success
- Focus ring: 3px, dotted, heading color

### Error / Danger
- Border: 2px inset border-danger
- Focus ring: 3px, dotted, heading color

### Disabled
- Background: disabled
- Text: fg-disabled
- Cursor: not-allowed

## Input with Icons

- Icon size: 16x16px
- Icon color: body
- Container: relative positioned wrapper
- Start icon: absolutely positioned left, 8px left padding — input gets 32px left padding
- End icon: absolutely positioned right, 8px right padding — input gets 32px right padding
- Icons vertically centered within the wrapper

## Rules

- Every input must have a unique `id`
- Every label must have a matching `htmlFor`
- Padding: 8px horizontal, 6px vertical unless overridden for icon variants
- No arbitrary hex or hardcoded colors
