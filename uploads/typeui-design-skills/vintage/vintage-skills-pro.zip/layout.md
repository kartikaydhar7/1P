# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 64px |
| Section header → content | 32px or 48px |
| Heading → paragraph | 16px |
| Container horizontal padding | 16px |
| Flex/grid row gap | 8px |
| Card grid gap | 16px |
| Wide component grid gap | 24px |
| Column layout gap | 32px |

## Container

Standard section container: max-width 1024px, centered, 16px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 64px vertical padding
- A #008081 (teal) background — ALL sections and page-level surfaces must use the classic teal desktop color
- A centered container (max-width 1024px, 16px horizontal padding)
- A section header area with 32px bottom margin
- Section content below

## Motion & Animation

- Avoid smooth transitions and easing curves. Prefer instant state changes (0ms or near-instant transitions) to match the snappy, immediate feel of classic desktop interfaces.
- No scroll-triggered animations or parallax effects. State changes should be abrupt and direct.
- Hover states should switch instantly, not fade.

## Backgrounds & Visual Depth

- The entire page/app background is always #008081 (teal) — the classic desktop color.
- Cards, windows, dialogs, and panels sit on top of the teal background using silver (#C0C0C0) surfaces.
- Depth is achieved through 3D beveled borders (light top-left edge, dark bottom-right edge) — never through blur or gradient shadows.
- No gradient meshes, noise textures, or decorative overlays. The aesthetic is flat, hard-edged, and pixel-precise.
- Every surface is either raised (outset bevel) or sunken (inset bevel). No flat/borderless surfaces.

## Must

- All sections: consistent 64px vertical padding
- All containers: max-width 1024px, centered, 16px horizontal padding
- Section headers: 32px or 48px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
