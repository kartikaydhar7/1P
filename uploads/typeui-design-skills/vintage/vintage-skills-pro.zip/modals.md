# Modals

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `buttons.md`, `inputs.md`

## Core Specs

### Overlay (Backdrop)
- Fixed, covers full screen
- Z-index: 40
- Background: black at 50% opacity
- No backdrop blur — sharp and opaque

### Content Container
- Background: neutral-primary
- Radius: 0px (base)
- Shadow: shadow-xl (3D raised bevel)
- Padding: 16px

## Anatomy

### Header
- Bottom border: 2px solid border-default
- Top corners: 0px
- Title: 18px, bold weight, heading color
- Close button: Ghost variant from `buttons.md`, 6px padding

### Body
- Vertical padding: 16px
- Vertical spacing between elements: 16px
- Text: 14px, 1.5 line-height, body color

### Footer
- Top border: 2px solid border-default
- Bottom corners: 0px

## Variants

### Default (Information)
Standard header + body + footer with primary/secondary action buttons.

### Pop-up (Confirmation)
Centered text, prominent icon, reduced padding:
- Body: 16px padding, text centered
- Icon: centered, 12px bottom margin, 48x48px, gray color

### Form Modal
Body contains inputs following `inputs.md`. Vertical spacing between form elements: 12px.

## Rules

- Backdrop covers full screen with fixed positioning
- Content: neutral-primary background, 0px radius, shadow-xl
- Header/Footer separated by 2px solid border-default borders
- Close button must be present and functional
- Accessibility: `role="dialog"`, implement focus trap in code
- Dark mode automatic via token system
