# Radios, Checkboxes & Toggles

> Dependencies: `colors.md`, `radius.md`

## Checkbox

- Size: 16x16px
- Radius: 0px
- Border: 2px, inset border-default-medium (sunken bevel)
- Background: white (#FFFFFF)
- Focus ring: 3px, dotted, heading color

### Disabled
- Border: border-light
- Text: fg-disabled

## Radio

- Size: 16x16px
- Radius: 0px (square radio buttons in vintage style)
- Border: 2px, inset border-default-medium (sunken bevel)
- Background: white (#FFFFFF)
- Focus ring: 3px, dotted, heading color
- Checked: border-brand, indicator: heading color

### Disabled
- Border: border-light-medium
- Text: fg-disabled

Group all radio items under the same `name` attribute.

## Toggle

### Track
- Square shape (0px radius)
- Background: neutral-quaternary
- Focus-within ring: 3px, dotted, heading color
- Checked track: brand background
- Disabled track: neutral-tertiary background

### Thumb
- Square shape (0px radius)
- Background: white
- Border: border-buffer

### Disabled
- Track: neutral-tertiary background
- Label: fg-disabled text

## Rules

- All selection inputs must have `id` matching label `htmlFor`
- Focus states use dotted outline for each control type
- Disabled states: no hover/focus interaction
