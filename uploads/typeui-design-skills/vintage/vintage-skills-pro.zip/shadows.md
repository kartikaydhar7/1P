# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `1px 1px 0 0 #808080` |
| shadow-xs | `inset -1px -1px 0 0 #808080, inset 1px 1px 0 0 #FFFFFF` |
| shadow-sm | `inset -1px -1px 0 0 #404040, inset 1px 1px 0 0 #FFFFFF, inset -2px -2px 0 0 #808080, inset 2px 2px 0 0 #DFDFDF` |
| shadow-md | `inset -1px -1px 0 0 #000000, inset 1px 1px 0 0 #FFFFFF, inset -2px -2px 0 0 #808080, inset 2px 2px 0 0 #DFDFDF` |
| shadow-lg | `2px 2px 0 0 #000000, inset -1px -1px 0 0 #808080, inset 1px 1px 0 0 #FFFFFF` |
| shadow-xl | `3px 3px 0 0 #000000, inset -1px -1px 0 0 #808080, inset 1px 1px 0 0 #FFFFFF` |
| shadow-2xl | `4px 4px 0 0 #000000, inset -2px -2px 0 0 #808080, inset 2px 2px 0 0 #FFFFFF` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls, lightweight cards | shadow-xs or shadow-sm |
| Standard cards, popovers, dropdowns | shadow-md |
| Prominent cards, sticky surfaces | shadow-lg |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl |

## Rules

- Use only these tokens — no custom box-shadow values
- All shadows produce hard-edged 3D beveled effects (no blur) — this is the core vintage aesthetic
- Raised elements use inset light top-left and dark bottom-right edges
- Sunken elements (inputs, wells) invert the bevel: dark top-left, light bottom-right
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level
- Never stack multiple shadow tokens on one element
- Never use shadow-xl/shadow-2xl for dense list items or body containers
