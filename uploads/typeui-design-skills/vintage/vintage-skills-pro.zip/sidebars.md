# Sidebars

> Dependencies: `colors.md`, `radius.md`, `typography.md`, `badges.md`, `alerts.md`

## Core Specs

- Background: neutral-primary-soft
- Right border: 2px, outset border-default (for left-sidebar); left border for right-sidebar
- Width: 240px

## Anatomy

### Outer Container
Hidden on mobile, visible at small breakpoint. Needs a toggle/trigger for mobile.

### Inner Wrapper
- Full height, vertical scroll overflow
- Padding: 8px horizontal, 12px vertical

### Navigation List
- Vertical spacing: 4px between items
- Font weight: bold

### Navigation Item
- Layout: flex, vertically centered
- Padding: 8px horizontal, 6px vertical
- Text: heading color
- Radius: 0px (base)
- Hover: neutral-secondary-medium background
- Transition: none — instant state change
- Icon: 16x16px, body color, hover → heading color, instant transition
- Label: 8px left margin from icon

### Active Item
- Background: neutral-secondary-strong
- Text: fg-brand-strong

### Separator
- 12px top padding, 12px top margin
- Top border: 2px solid border-default
- 8px vertical spacing below

### Bottom CTA / Card
- Padding: 12px
- Top margin: 16px
- Radius: 0px (base)
- Background: brand-softer
- Can also use any alert variant from `alerts.md`

## Rules

- Responsive: hidden on mobile with a trigger mechanism
- Icons: 16x16px, body color (hover: heading color)
- Multi-level menus: indent with 32px left padding
- Spacing follows 8px grid
- Only neutral, brand, or status tokens — no arbitrary colors
