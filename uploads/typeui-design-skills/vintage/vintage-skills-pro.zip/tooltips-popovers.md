# Tooltips & Popovers

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Tooltips

### Core Specs
- Padding: 8px horizontal, 6px vertical
- Font: 14px, bold weight
- Radius: 0px (default)
- Shadow: shadow-xs
- Transition: none — instant show/hide

### Dark (Default)
- Background: dark
- Text: white
- Border: 2px solid transparent

### Light
- Background: neutral-primary-medium
- Text: heading color
- Border: 2px, outset border-default

## Popovers

### Core Specs
- Background: neutral-primary
- Radius: 0px (base)
- Shadow: shadow-md
- Border: 2px, outset border-default
- Transition: none — instant show/hide

### Header / Title
- Padding: 8px horizontal, 6px vertical
- Background: neutral-secondary-soft
- Bottom border: 2px solid border-default
- Font: 14px, bold weight, heading color

### Body / Content
- Standard: 8px horizontal, 6px vertical padding; 14px, body color
- Rich: 12px padding; 14px, body color

## Arrows

- Size: 8x8px rotated 45deg
- Color must match the background of the tooltip/popover variant

## Rules

- Tooltips: 0px radius
- Popovers: 0px radius
- Dark tooltips: dark background, white text
- Light tooltips/popovers: semantic neutral background + border tokens
- Arrows match parent background color
