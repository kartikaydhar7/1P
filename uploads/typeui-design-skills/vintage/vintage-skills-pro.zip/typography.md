# Typography

> Dependencies: `colors.md`

## Core Rules

- **Font:** "Silkscreen", cursive — configured at app level, never override. Import from Google Fonts.
- **Headings:** bold weight (700), heading text color
- **Body copy:** body text color, never use brand color for paragraphs longer than one sentence
- **Semantic HTML:** Use `h1`–`h6` in order, never skip levels

## Heading Scale

### Desktop

| Element | Size | Line-height | Letter-spacing | Margin-bottom |
|---|---|---|---|---|
| `h1` | 48px | 1.1 | 0px | 24px |
| `h2` | 36px | 1.15 | 0px | — |
| `h3` | 28px | 1.2 | 0px | — |
| `h4` | 24px | 1.25 | 0px | — |
| `h5` | 20px | 1.3 | 0px | — |
| `h6` | 16px | 1.3 | 0px | — |

### Responsive

| Element | Tablet (≥768px) | Mobile (default) |
|---|---|---|
| `h1` | 36px | 28px |
| `h2` | 28px | 24px |
| `h3` | 24px | 20px |
| `h4` | 20px | 18px |
| `h5` | 18px | 16px |
| `h6` | 16px | 14px |

Mobile-first: start with mobile sizes, scale up at tablet and desktop breakpoints.

Never reduce line-height below 1.1 for any heading.

## Paragraphs

### Leading Paragraph
- Size: 18px
- Weight: normal (400)
- Color: body
- Line-height: 1.6
- Max width: ~70 characters

### Normal Paragraph
- Size: 16px
- Weight: normal (400)
- Color: body
- Line-height: 1.6
- Max width: ~65 characters

### Small Supporting Copy
- Size: 14px
- Weight: normal (400)
- Color: body
- Line-height: 1.5
- Use only for helper text, legal text, captions, metadata.

## UI Labels

| Context | Size | Weight |
|---|---|---|
| Button labels | 14px | 700 (bold) |
| Input labels | 14px | 700 (bold) |
| Captions / meta / badges | 12px or 14px | 700 (bold) |

Do not apply paragraph line-height (1.6) to control labels.

## Links

- **Inline links:** Same size as surrounding text, fg-brand color, underline, hover → no underline
- **CTA links:** fg-brand color, bold weight, underline, hover → no underline

## Emphasis

- `<strong>` for high-priority emphasis in body text
- `<em>` for tone emphasis only, not visual hierarchy
- All-caps only for short labels: uppercase, 0px letter-spacing, 12px or 14px

## Dark Mode

Hierarchy stays identical. Only color tokens change (automatic via CSS custom properties). Size, weight, and spacing remain constant.
